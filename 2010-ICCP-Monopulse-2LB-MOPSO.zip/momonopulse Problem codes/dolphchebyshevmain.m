function[dolph]=dolphchebyshevmain(n)
global n3
n3=n/2;
n=2*n;
suppr=20;
rnot=realpow(10,suppr/20);
z1=rnot+sqrt(rnot*rnot-1);
z2=rnot-sqrt(rnot*rnot-1);
p=n-1;
znot=(realpow(z1,1/p)+realpow(z2,1/p))*.5;
t=chebyshevpoly(n);
for i=1:n/2
    for j=1:n/2
        a(i,j)=t(2*j,2*i);
    end;
end;
for i=1:n/2
    b(i,1)=t(n,2*i)*realpow(znot,2*i-1);
end;
x=inv(a)*b;
for i=1:n/2
    y(i)=x(i)/x(1);
end;
dolph=y;
 %y=[1.0000    0.4639    0.5544    0.6434    0.7274    0.8034    0.8682    0.9193    0.9546    0.9726];
% phi=linspace(0,180,500);
% yax(1)=array_factor_dolph(y,(pi/180)*phi(1));
% maxi=yax(1);
% for i=2:500%This loop finds out the maximum gain 
%     yax(i)=array_factor_dolph(y,(pi/180)*phi(i));
%     if maxi<yax(i)
%         maxi=yax(i);
%     end;
% end;
% for i=1:500%This loop normalizes the Y-axis and finds the normalized gain values in decibels 
%     yax(i)=yax(i)/maxi;
%     yax(i)=10*log10(yax(i));
%     if yax(i)<-70
%        yax(i)=-70;
%     end;
% end;
% plot(phi,yax,'k')
% xlabel('Azimuth angle(deg)');
% ylabel('Gain(db)');
