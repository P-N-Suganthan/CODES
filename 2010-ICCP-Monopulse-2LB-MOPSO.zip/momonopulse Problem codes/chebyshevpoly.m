function[t]=chebyshevpoly(n)

for i=1:n
    t(1,i)=0;
    t(2,i)=0;
end;
t(1,1)=1;
t(2,2)=1;
for i=3:n
    for j=2:n
        t(i,j)=2*t(i-1,j-1)-t(i-2,j);
    end;
    t(i,1)=-t(i-2,1);
end;
