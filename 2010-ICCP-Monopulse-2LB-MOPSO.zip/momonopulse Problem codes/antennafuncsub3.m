function [fit]=antennafuncsub3(x1,no_binary,dolph,no_real)
%This function calculates the fitness value of array 'x1' which is returned in 'y'
dim=no_binary;
subarray=no_real;
y=0;
num=2;
pi=3.141592653589793;
num1=300;
phi=linspace(0,90,num1);
phizero=0;
yax(1)=array_factorsub(x1,(pi/180)*phi(1),dim,dolph,subarray);
maxi=yax;
phi_ref=1;
for i=2:num1%This loop finds out the maximum gain 
    yax(i)=array_factorsub(x1,(pi/180)*phi(i),dim,dolph,subarray);
    if maxi<yax(i)
        maxi=yax(i);
        phizero=phi(i);
        phi_ref=i;
    end;
end;
% yax
% yax

maxtem=0;
count=0;
if yax(1)>yax(num1) && yax(1)>yax(2)
    count=count+1;
    sidelobes(count)=yax(1);
    sllphi(count)=phi(1);
end
if yax(num1)>yax(1) && yax(num1)>yax(num1-1)
    count=count+1;
    sidelobes(count)=yax(num1);
    sllphi(count)=phi(num1);
end
for i=2:num1-1
    if yax(i)>yax(i+1) && yax(i)>yax(i-1)
        count=count+1;
        sidelobes(count)=yax(i);
        sllphi(count)=phi(i);
    end
end
sidelobes=sort(sidelobes,'descend');
% for i=1:num%In this loop the objective function for 
%     %side lobe level suppresion is calculated
%     %num denotes the number of SLLs
%   for j=1:num1
%       phi1=phi_l(i)+(phi_u(i)-phi_l(i))*(j/num1);
%       afphi=array_factorcir(x1,phi1);
%       afphi=afphi/maxi;
%       %if afphi>maxtem
%       %    maxtem=afphi;
%       %end;
%      y=y+afphi;
%   end;
% end;
upper_bound=90;
lower_bound=0;

for i=phi_ref:-1:2                       
    if yax(i)<yax(i+1) && yax(i)<yax(i-1)     
        lower_bound=phi(i); 
		break;
    end    
end 


y=sidelobes(2)/maxi;
% for i=1:num1
%     if (phi_ref+i)>num1-1
%         upper_bound=90;
%         break;
%     end
%     tem=yax(phi_ref+i);
%     if yax(phi_ref+i)<yax(phi_ref+i-1) && yax(phi_ref+i)<yax(phi_ref+i+1)
%         upper_bound=phi(phi_ref+i)-phi(phi_ref);
%         break;
%     end;
% end

% for i=1:num1/2
%     
%     if (phi_ref-i<2)
%         lower_bound=180;
%         break;
%     end
%     tem=yax(phi_ref-i);
%     if yax(phi_ref-i)<yax(phi_ref-i-1) && yax(phi_ref-i)<yax(phi_ref-i+1)
%         lower_bound=phi(phi_ref)-phi(phi_ref-i);
%     break;
%     end;
% end
sllvalue=10*log10(y);
bwfn=upper_bound-lower_bound;
fit=[sllvalue bwfn];
% bwfn
%y=maxtem;
% y1=0;
% for i=1:num_null%The objective function for null control
%     %is calculated here
%     y1=y1+(array_factorsub(x1,null(i))/maxi);
% end;
% y2=0;
% uavg=trapezoidalcir(x1,0,2*pi,50);
% y2=abs(2*pi*maxi*maxi/uavg);
% directivity=10*log10(y2);
% y3=abs(phizero-phi_desired);
% if bwfn>60
%     y=y+10;
% end;
% directivity
%y3=abs((phizero-phi_desired)*(pi/180));
%y=y+y1+1/y2+y3;