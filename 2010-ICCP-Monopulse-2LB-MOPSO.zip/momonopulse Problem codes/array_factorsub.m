function[y]=array_factorsub(x1,phi,dim,dolph,subarray)
%As the function name signifies here the array factor is calculated 


y2=0;
  for i=1:dim     
      index=round(x1(i+subarray));
      if index<.1
          weight=1;
      else
  weight=x1(index);
  if(weight<.01)
	  weight=.01;
  end
      end
  y2=y2+weight*dolph(i)*sin((2*i-1)*(pi/2)*cos(phi));
  end
  y=y2*2;
  y=realpow(y,2);
 