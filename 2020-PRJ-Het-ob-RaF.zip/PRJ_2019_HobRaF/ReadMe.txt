This code is modified from Leo's implementation.
(http://www.mathworks.com/matlabcentral/fileexchange/31036-random-forest. 
Copyright (c) 2011, leo
Copyright (c) 2006, Phillip M. Feldman
All rights reserved.

Some parts of the codes have been taken from:
Zhang, Le, and Ponnuthurai N. Suganthan. "Oblique Decision Tree Ensemble via Multisurface Proximal Support Vector Machine."  IEEE Transactions on Cybernetics, Year: 2015, Volume: PP, Issue: 99(2014).

For linear classifiers, we use the following packages/codes and sources
as listed below:
 1. LIBSVM (http://www.csie.ntu.edu.tw/~cjlin/libsvm)
 2. LIBLINEAR (https://www.csie.ntu.edu.tw/~cjlin/liblinear/)
 3. LSSVM (https://www.esat.kuleuven.be/sista/lssvmlab/)
 4. LDA (https://www.mathworks.com/matlabcentral/fileexchange/29673-lda-linear-discriminant-analysis)
 5. MPSVM (https://github.com/P-N-Suganthan/CODES)
 6. RR (https://github.com/P-N-Suganthan/CODES)

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the distribution

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
First create MEX files for LIBSVM and LibLinear.

Please use the 'demo.m' file to train the Random Forest.

The codes are not optimized for efficiency. The codes have been cleaned for better readability
and documented and are not exactly the same as used in our paper. We have re-run and checked the
codes only in few datasets so if you find any bugs/issues, please write to
Rakesh (rakeshku001@e.ntu.edu.sg or katuwalrakesh@gmail.com).

Please cite properly if you are using this code.

Rakesh Katuwal, P.N. Suganthan, Le Zhang,
Heterogeneous oblique random forest,
Pattern Recognition,
Volume 99,
2020,
107078,
ISSN 0031-3203,
https://doi.org/10.1016/j.patcog.2019.107078.
(http://www.sciencedirect.com/science/article/pii/S0031320319303796)


01-NOV-2019