function b = LSSVM(X,Y)

%https://www.esat.kuleuven.be/sista/lssvmlab/

[~,numFeatures] = size(X);
b = zeros(numFeatures+1,1);

gam = -2:7; 
indx_gam = randi(length(gam));
gamma_temp = gam(indx_gam);
G = 10.^gamma_temp;

type = 'classification';
[alpha,bias] = trainlssvm({X,Y,type,G,[],'lin_kernel','original'});

w = alpha' * X; 

b(1:end-1) = w;
b(end) = bias;

end

