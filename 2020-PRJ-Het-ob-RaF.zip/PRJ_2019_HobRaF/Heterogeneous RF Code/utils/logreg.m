function b = logreg(Input,Target)
%https://www.csie.ntu.edu.tw/~cjlin/liblinear/

Input = sparse(Input);
cl = train(Target,Input,'-q -s 0 -B 1');
b = cl.w; 
b(end) = b(end)*-1;
b = b';

end
% EOF


