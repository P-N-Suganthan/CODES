function b = SVM(Input,Target)
%http://www.csie.ntu.edu.tw/~cjlin/libsvm

[~,numFeatures] = size(Input);
b = zeros(numFeatures+1,1);

r = -2:7;
indx_C = randi(length(r));
C_temp = r(indx_C);
C = 2.^C_temp;

cmd = ['-s -t -h -c -q', 0,0,0,num2str(C)];
cl = svmtrain(Target,Input,cmd);
beta = cl.SVs'*cl.sv_coef; 
bias = -cl.rho; 

b(1:end-1) = beta;
b(end) = bias;

end
% EOF


