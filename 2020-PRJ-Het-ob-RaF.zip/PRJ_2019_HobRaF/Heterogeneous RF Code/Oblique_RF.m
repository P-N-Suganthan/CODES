function [train_acc,test_acc,model]  = Oblique_RF(trainX,trainY,testX,testY,option)


model = ObliqueRF_train(trainX,trainY,option);

predY_train = ObliqueRF_predict(trainX,model);
predY_test = ObliqueRF_predict(testX,model);

train_acc = (length(find(predY_train==trainY))/size(trainY,1))*100;
test_acc = (length(find(predY_test==testY))/size(testY,1))*100;

end




