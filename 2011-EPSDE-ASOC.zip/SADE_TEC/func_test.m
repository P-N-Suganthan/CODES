% function function_plot
% clear;close all
global initial_flag gbestval_hist
fhd=str2func('DE_benchmark_func');
Xmax=[100,100,100,pi,32,32,600,600,5,5,5,5,5,5,5,5];
Xmin=-Xmax;
D=10;
FES=D*10000;
runs=30;
stop_err=1e-5;
for func_num=1:16
for i=1:runs
initial_flag=0;
func_num
i
gbestval_hist=[];ps=2*D;
[PSO_gbest,PSO_gbestval,PSO_fit_cut]= PSO_cf_func(fhd,FES/ps,FES,ps,D,Xmin(func_num),Xmax(func_num),func_num);
PSO_gbestval
PSO_gbestval_hist=gbestval_hist;
eval(['save D:\SADE_TEC\PSO_D' int2str(D) '_' int2str(func_num) '_' int2str(i) ' PSO_gbestval_hist;']);
clear PSO_gbestval_hist
PSO_gbestval_res(func_num,i)=PSO_gbestval;
PSO_fit_cut_res(func_num,i)=PSO_fit_cut;

gbestval_hist=[];ps=2*D;
[PSO_local_gbest,PSO_local_gbestval,PSO_local_fit_cut]= PSO_cf_local_func(fhd,FES/ps,FES,ps,D,Xmin(func_num),Xmax(func_num),func_num);
PSO_local_gbestval
PSO_local_gbestval_hist=gbestval_hist;
eval(['save D:\SADE_TEC\PSO_local_D' int2str(D) '_' int2str(func_num) '_' int2str(i) ' PSO_local_gbestval_hist;']);
clear PSO_local_gbestval_hist
PSO_local_gbestval_res(func_num,i)=PSO_local_gbestval;
PSO_local_fit_cut_res(func_num,i)=PSO_local_fit_cut;

gbestval_hist=[];
opts=cmaes; opts.MaxFunEvals=FES;opts.StopFitness=stop_err;
[CMA_gbest,CMA_gbestval,CMA_fit_cut]= cmaes(fhd,(Xmin(func_num)+(Xmax(func_num)-Xmin(func_num)).*rand(D,1)),(Xmax(func_num)-Xmin(func_num))/2,opts,func_num);
CMA_gbestval
CMA_gbestval_hist=gbestval_hist;
eval(['save D:\SADE_TEC\CMA_D' int2str(D) '_' int2str(func_num) '_' int2str(i) ' CMA_gbestval_hist;']);
clear CMA_gbestval_hist
CMA_gbestval_res(func_num,i)=CMA_gbestval;
CMA_fit_cut_res(func_num,i)=CMA_fit_cut;

gbestval_hist=[];ps=150;
[G3_PCX_gbest,G3_PCX_gbestval,G3_PCX_fit_cut]= G3_PCX_func(fhd,FES/ps,FES,ps,D,Xmin(func_num),Xmax(func_num),func_num);
G3_PCX_gbestval
G3_PCX_gbestval_hist=gbestval_hist;
eval(['save D:\SADE_TEC\G3_PCX_D' int2str(D) '_' int2str(func_num) '_' int2str(i) ' G3_PCX_gbestval_hist;']);
clear G3_PCX_gbestval_hist
G3_PCX_gbestval_res(func_num,i)=G3_PCX_gbestval;
G3_PCX_fit_cut_res(func_num,i)=G3_PCX_fit_cut;

save D:\SADE_TEC\SADE_TEC_ljpart_509
end
end
