%********************************************************************
% Script file for the initialization and run of the differential 
% evolution optimizer.
%********************************************************************
path(path,'/home/mall/F1/SADE_TEC'); 
  
 F_VTR =  10^(-5);  % "Value To Reach".The algorithm will stop its minimization when (value of cost function) < F_VTR or MAX_FEs > prescribed value. 
      
 for I_fno = [1 2 3]
    
 for I_D=  [10 30 50]
   
 I_NP=50; 
        
  if (I_fno==1|I_fno==2|I_fno==3|I_fno==4)
      
      FVr_minbound = -100*ones(1,I_D); % vector of lower bounds for initial population.
      FVr_maxbound = 100*ones(1,I_D);  % vector of upper bounds for initial population.
      Lbound=FVr_minbound;
      Ubound=FVr_maxbound;
      
  elseif (I_fno==5|I_fno==6)
      
      FVr_minbound = -32*ones(1,I_D);
      FVr_maxbound = 32*ones(1,I_D);
      Lbound=FVr_minbound;
      Ubound=FVr_maxbound;
      
  elseif (I_fno==7|I_fno==8)
      
      FVr_minbound = 0*ones(1,I_D);
      FVr_maxbound = 600*ones(1,I_D);
      Lbound=-Inf*ones(1,I_D);
      Ubound=Inf*ones(1,I_D);

  elseif (I_fno==9|I_fno==10|I_fno==11|I_fno==13|I_fno==14)
      
      FVr_minbound = -5*ones(1,I_D);
      FVr_maxbound = 5*ones(1,I_D);
      Lbound=FVr_minbound;
      Ubound=FVr_maxbound;
      
  elseif (I_fno==12)
      
      FVr_minbound = -500*ones(1,I_D);
      FVr_maxbound = 500*ones(1,I_D);
      Lbound=FVr_minbound;
      Ubound=FVr_maxbound;
      
  end

         
      MAX_FEs  =I_D*10000; % maximum no of function evaluations required.
     
     
       
runs=30;
FVr_bestcost=[];
clear FVr_bestcost;
global initial_flag

initial_flag=0;

S_struct.I_NP         = I_NP;
S_struct.I_D          = I_D;
S_struct.FVr_minbound = FVr_minbound;
S_struct.FVr_maxbound = FVr_maxbound;
S_struct.Lbound= Lbound;
S_struct.Ubound= Ubound;
S_struct.MAX_FEs      = MAX_FEs;
S_struct.F_VTR        = F_VTR;
S_struct.I_fno          =I_fno;

%********************************************************************
% Start of optimization
%********************************************************************
for s=1:runs
S_struct.s  = s;
fprintf('Run %d',s);
[rama,FM_pop,Best_mat,FVr_bestmem,F_bestfcost,MAX_FEs]= deopt('objfun',S_struct);
eval(['save /staff2/mall/PENS/F' int2str(I_fno) '/A' int2str(I_D) '_' int2str(I_NP) '_' int2str(s) ' Best_mat;'])
FVr_bestcost(s,:)=rama;
end
eval(['save /staff2/mall/PENS/F' int2str(I_fno) '/B' int2str(I_D) '_' int2str(I_NP) ' FVr_bestcost;'])
end
end

 
 