function [rama,FM_pop,FM_costfval,FVr_bestmem,F_bestval,I_nfeval]= deopt(fname,S_struct)

FM_costfval=[];

rama=[];
I_NP         = S_struct.I_NP;
I_D          = S_struct.I_D;
FVr_minbound = S_struct.FVr_minbound;
FVr_maxbound = S_struct.FVr_maxbound;
Lbound       = S_struct.Lbound;
Ubound       = S_struct.Ubound;
MAX_FEs      = S_struct.MAX_FEs;
F_VTR        = S_struct.F_VTR;

%-----Initialize population and some arrays-------------------------------

FM_pop = zeros(I_NP,I_D); %initialize FM_pop to gain speed


FM_pop = repmat(FVr_minbound,I_NP,1) + rand(I_NP,I_D).*(repmat(FVr_maxbound,I_NP,1) - repmat(FVr_minbound,I_NP,1));


FM_popold     = zeros(size(FM_pop));  % toggle population
val           =zeros(I_NP,1);            %create and reset the "cost array"
FVr_bestmem   = zeros(1,I_D);% best population member ever
FVr_bestmemit = zeros(1,I_D);% best population member in iteration
I_nfeval      = 0;                    % number of function evaluations

%------Evaluate the best member after initialization----------------------

I_best_index   = 1;                   % start with first population member
val(1)         = feval(fname,FM_pop(I_best_index,:),S_struct);
F_bestval = val(1);                 % best objective function value so far
I_nfeval  = I_nfeval + 1;
for k=2:I_NP                          % check the remaining members
  val(k)  = feval(fname,FM_pop(k,:),S_struct);
  I_nfeval  = I_nfeval + 1;
  if (val(k) < F_bestval)

     I_best_index   = k;              % save its location
     F_bestval      = val(k);
  end   
end
FVr_bestmem = FM_pop(I_best_index,:); % best member of current iteration
             
FM_costfval(1,1)=F_bestval;
FM_costfval(1,2)=I_nfeval;


%------DE-Minimization---------------------------------------------
%------FM_popold is the population which has to compete. It is--------
%------static through one iteration. FM_pop is the newly--------------
%------emerging population.----------------------------------------
rot=(0:1:I_NP-1);
I_iter = 1;

FF=[0.4;0.5;0.6;0.7;0.8;0.9];
CR=[0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9];

spara=randperm(3)';
Para=zeros(I_NP,3);
inde=1:I_NP;
inde=inde';
RR = zeros(I_NP,1);
PPara=[];

while ( I_nfeval < MAX_FEs)

 if(I_iter==1)
    
    Para(inde,:)=[spara(randint(size(inde,1),1,[1,size(spara,1)])),CR(randint(size(inde,1),1,[1,size(CR,1)])),FF(randint(size(inde,1),1,[1,size(FF,1)]))];
 
 else
     for k=1:size(inde,1)
       if(rand <= RATE && ~isempty(PPara)) 
          
          RR(k) = randint(1,1,[1,size(PPara,1)]);
          Para(inde(k),:) = PPara(randint(1,1,[1,size(PPara,1)]),:);
          
       else

          RR(k) = 0;
          Para(inde(k),:) = [spara(randint(1,1,[1,size(spara,1)])),CR(randint(1,1,[1,size(CR,1)])),FF(randint(1,1,[1,size(FF,1)]))];
          
       end
     end
 end

 RRR = [];
 count = 0;
 FM_popold = FM_pop;
 
  for i=1:I_NP
        
        FM_mui = rand(1,I_D) < Para(i,2);
        dd=find(FM_mui==1);
        if isempty(dd)
        ddd=ceil(rand*I_D);
        FM_mui(ddd)=1;
        end
        FM_mpo = FM_mui < 0.5;  
        FM_bm  = FVr_bestmem; 
        para(i,:)=normrnd(Para(i,3),0.001,1,I_D);
        if(Para(i,1)==1)
        %DE/best/2/bin
        ind=randperm(I_NP);
        FM_pm3 = FM_popold(ind(1),:);             
        FM_pm4 = FM_popold(ind(2),:);             
        FM_pm5 = FM_popold(ind(3),:);             
        FM_pm6 = FM_popold(ind(4),:);
        FM_ui = FM_bm +( FM_pm3 - FM_pm4 + FM_pm5 - FM_pm6).*para(i,:);
        FM_ui = FM_popold(i,:).*FM_mpo + FM_ui.*FM_mui;
        end
        if(Para(i,1)==2)
        %DE/rand/1/bin 
        ind=randperm(I_NP);
        FM_pm7 = FM_popold(ind(1),:);             
        FM_pm8 = FM_popold(ind(2),:);
        FM_pm9 = FM_popold(ind(3),:);  
        FM_ui = FM_pm7 +para(i,:).*(FM_pm8 - FM_pm9);
        FM_ui = FM_popold(i,:).*FM_mpo+ FM_ui.*FM_mui;     % crossover
        end
         if(Para(i,1)==3)
       % DE/current-to-rand/1/bin/
        ind=randperm(I_NP);
        FM_pm21 = FM_popold(ind(1),:);  
        FM_pm22 = FM_popold(ind(2),:);             
        FM_pm23 = FM_popold(ind(3),:);
        FM_ui = FM_popold(i,:) + rand(1,I_D).*(FM_pm21-FM_popold(i,:)) + para(i,:).*(FM_pm22 - FM_pm23);       % differential variation
        end
         
        if(FM_ui < Lbound)
            FM_ui = FVr_minbound+(FVr_maxbound-FVr_minbound).*rand(1,I_D);
            
        end
        if(FM_ui > Ubound)
            FM_ui = FVr_minbound+(FVr_maxbound-FVr_minbound).*rand(1,I_D);
        end
        tempval = feval(fname,FM_ui,S_struct);
        I_nfeval  = I_nfeval + 1;
          if(tempval < val(i))
            FM_pop(i,:) = FM_ui; 
            val(i)   = tempval; 
            PPara=[Para(i,:);PPara]; 
            if(RR(i)~=0)
              RRR = [RRR;RR(i)];
            end
               if (tempval < F_bestval)
                      F_bestval = tempval;                    
                      FVr_bestmem = FM_ui;
                      I_best_index = i;
               end
          else
              count = count + 1;
              
          end
          
        
  end
  PPara(RRR,:)= [];
  rate(I_iter,1) = count/I_NP;
  if(I_iter>10)
  RATE = mean(rate((I_iter-10):I_iter),1);
  else
  RATE = mean(rate,1);
  end
  AAA(I_iter,1) = RATE;
  if(rem(I_nfeval,10000)==0)
      rama=[rama,[F_bestval,I_nfeval]];
      
  end
 
%----Output section----------------------------------------------------------
               
FM_costfval(I_iter+1,1)=F_bestval;
FM_costfval(I_iter+1,2)=I_nfeval;

I_iter = I_iter + 1;
  
  
end 

 F_bestval
