          clear all
           clc
          
     func='cost_trian_asym'; % fitness function name%
opts.StopFunEvals=20000;     % maximum number of function evaluations %
n=60;                        % number of variables 
% first 30 variables are real part of coupling coefficients
% the next 30 variables are imaginary part of coupling coefficients


opts.lbounds = [-0.0008*ones(n/2,1);0*ones(n/2,1)] ; % lower bound on problem variables
opts.UBounds= [0.0008*ones(n/2,1);360*ones(n/2,1)];  % upper bound on problem variables
 

xmeanw=(opts.UBounds-opts.lbounds).*rand(n,1);
 sigma=.1*(opts.UBounds-opts.lbounds);
[xbest,ff,aa,bb,tr,tt,bas_res]=cmaes_function(func,xmeanw,sigma,opts);
xx=xbest;
ff=feval(func,xbest);
[cost,w,R]=cost_trian_asym_fig(xbest)

Rmask=[zeros(1,6) 0:0.06466666666667:1 0.95 .94*exp(-[1:7]*1.25).^.9] ;
max_linearity_error=max(abs(R(8:22)-Rmask(8:22)'));

% Reference paper:
% 
% S.Baskar,P.N.Suganthan *,N.Q.Ngo,A.Alphones,R.T.Zheng," Design of triangular FBG ?lter for sensor applications using
% covariance matrix adapted evolution algorithm",Optics Communications xxx (2005)xxx �xxx,2006