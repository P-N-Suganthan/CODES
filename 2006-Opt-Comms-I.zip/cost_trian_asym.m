   function [cost]=cost_trian_asym(dd);
nn=length(dd);
slen=20/nn;
dnn=dd';

ang=dnn(nn/2+1:nn)*pi/180;
dn_pro=dnn(1:nn/2).*(cos(ang)+i*sin(ang));

% MAsk generated as per the reference paper[6]"K.Aksnes,J.Skaar,Appl.Optics
% 43 (11)(2004)2226"
% No. of samples 30
% design of wavelength window is as per the reference paper
% out of 30 smaples (8 to 22) 15 samples are used for linea portion
% first seven smaples for zeros
dw=6.6667e-005;
waveL_s=1.549;
waveL_e=1.551;
Rmask=[zeros(1,6) 0:0.06466666666667:1 0.95 .94*exp(-[1:7]*1.25).^.9] ;
w=waveL_s:dw:waveL_e;
%
neff=1.452;     
G_period=(1.55/(2*neff));
N_sample=length(dn_pro);
GG=G_period*ones(1,N_sample);
ll=round((slen*10^-3)./(GG*10^-6));
[w,R]=chirped_apodized0(dn_pro,N_sample,neff,GG,waveL_s,waveL_e,dw,ll);
Rerr=100*max(R(1:7))+700*max(abs(R(8:22)-Rmask(8:22)'))+100*max(abs(R(23:30)-Rmask(23:30)'));
cost=Rerr;
 
