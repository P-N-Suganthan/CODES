function [beta] = l2_weights(X,Y,option)

Y_temp = Y;
Y_temp(option.NL+1:end,:) = 1/size(Y_temp,2);
%%
L = laplacian2(option,X);


%% beta

change = 1;
ft = 0;
while change>0.001 && ft<option.ft_num
    if size(X,2)<size(X,2)
        beta = (X'*X + option.C1*eye(size(X,2)) + option.C2*X'*L*X)\X'*Y_temp;
    else
        beta = X'*((X*X' + option.C1*eye(size(X,1)) + option.C2*L*X*X')\Y_temp);
    end
    Y_prediction = X*beta;
    Y_prediction_semi = Y_prediction(option.NL+1:end,:);
    Y_semi_new = Y_prediction_semi;
    for i = 1:option.NU
        [Y_semi_new(i,:), ~] = EProjSimplex_new(Y_prediction_semi(i,:), 1);
    end
    change = sum((Y_temp(option.NL+1:end,:) - Y_semi_new).^2,'all');
    Y_temp(option.NL+1:end,:) = Y_semi_new;
    ft = ft+1;
%     
%     [max_prob,indx] = max(Y_semi_new,[],2);
%     [~, ind_corrClass] = max(Y,[],2);
%     ind_corrClass = ind_corrClass(41:550,:);
%     train_accuracy = mean(indx == ind_corrClass);
end

% trainACC = train_accuracy;


% [max_prob,indx] = max(Y_semi_new,[],2);
% [~, ind_corrClass] = max(Y,[],2);
% ind_corrClass = ind_corrClass(41:550,:);
% train_accuracy = mean(indx == ind_corrClass);

end

