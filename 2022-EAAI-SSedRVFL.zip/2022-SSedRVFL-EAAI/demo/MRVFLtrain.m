function [TrainingAccuracy] = MRVFLtrain(trainX,trainY,option)

[Nsample,Nfea] = size(trainX);
N = option.N;
L = option.L;
s = 1;  %scaling factor


A = cell(L,1); %for L hidden layers
beta = cell(L,1);
weights = cell(L,1);
biases = cell(L,1);
mu = cell(L,1);
sigma = cell(L,1);
TrainingAccuracy_layers = zeros(L,1);
ProbScores = cell(L,1); %depends on number of hidden layer

A_input = trainX;

for i = 1:L
    
    if i==1
        w = s*2*rand(Nfea,N)-1;
    else
        w = s*2*rand(Nfea+N,N)-1;
    end
    
    b = s*rand(1,N);
    weights{i} = w;
    biases{i} = b;
    
    A1 = A_input * w+repmat(b,Nsample,1);


    A1 = sigmoid(A1);


    mu{i} = mean(A1,1);
    sigma{i} = std(A1);
    A1 = bsxfun(@rdivide,A1-repmat(mu{i},size(A1,1),1),sigma{i}); 
    
    
    A1_temp1 = [trainX,A1,ones(Nsample,1)];
    [beta1] = l2_weights(A1_temp1,trainY,option);
    
    A{i} =  A1_temp1;
    beta{i} = beta1;
    
    %clear A1 A1_temp1 A1_temp2 beta1
    A_input = [trainX A1];
    
    
   %% Calculate the training accuracy
    trainY_temp = A1_temp1*beta1;

    %Softmax to generate probabilites
    trainY_temp = bsxfun(@minus,trainY_temp,max(trainY_temp,[],2)); %for numerical stability
    prob_scores=softmax(trainY_temp')';
    ProbScores{i,1} = prob_scores(option.NL+1:end,:);
   
    %Calculate the training accuracy for first i layers
    TrainingAccuracy_layers(i,1) = ComputeAcc(trainY(option.NL+1:end,:),ProbScores,i); %averaging prob.scores
end

TrainingAccuracy = max(TrainingAccuracy_layers);



%%
model.L = L;
model.w = weights;
model.b = biases;
model.beta = beta;
model.mu = mu;
model.sigma = sigma;

end