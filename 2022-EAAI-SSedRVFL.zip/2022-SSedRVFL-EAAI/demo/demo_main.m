clc
clear

load COIL20.mat

seed = RandStream('mcg16807','Seed',0);
RandStream.setGlobalStream(seed);

[Nsample, Nfea] = size(X);
Nclass = size(Y,2);


option.NL = 40; % The number of labeled samples
option.NU = 1400; % The number of unlabeled samples

%% Randomly create the labeled-unlabeled partition and make the labeled samples contain all the classes. Here, points are the positions of different classes.
order_L = [];
order_U = [];
multiple = 2; % NL/Nclass
for class = 1:Nclass
     order = randperm(points(class+1)-points(class))+points(class)-1;
     order_L_temp = order(1:multiple);
     order_U_temp = order(multiple+1:end);
     order_L = [order_L order_L_temp];
     order_U = [order_U order_U_temp];
end

% The first NL samples are labeled samples, followed by the unlabeled samples
 trainX = [X(order_L,:);  X(order_U,:)]; 
 trainY = [Y(order_L,:);  Y(order_U,:)];

%% Hyperparameters fixed for this dataset
option.ft_num=1;
option.N = 2000;
option.L = 10;
option.NN = 2;
option.GraphDistanceFunction = 'euclidean';
option.GraphWeights = 'binary';
option.LaplacianNormalize = 1;
option.LaplacianDegree = 1;


%% Regularization parameters tuned by the user！！
option.C1 = 10.^(-3);
option.C2 = 10.^3;


%% Training
[train_accuracy] = MRVFLtrain(trainX,trainY,option);
train_accuracy




