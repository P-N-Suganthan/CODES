function x = l2_weights(A,b,option,Nsample,W)

W1=repmat(W,1,size(A,2));
W2=repmat(W,1,size(b,2));

if size(A,2)<Nsample
   x = (eye(size(A,2))*option.lambda+A'*(W1.*A)) \ A'*(W2.*b);
else
    x = A'*((eye(size(A,1))*option.lambda+(A.*W1)*A') \ (W2.*b));
end


end
% toc

