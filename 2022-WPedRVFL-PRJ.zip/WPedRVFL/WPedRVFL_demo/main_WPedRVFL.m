clear all
clc

load Car.mat
load labels.mat
load folds.mat

dataX = car;
dataY = labels;
test_indx = logical(folds(:,1));
train_indx = logical(1-test_indx);

U_dataY = unique(dataY);
nclass = numel(U_dataY);
dataY_temp = zeros(numel(dataY),nclass);

% 0-1 coding for the target
for i=1:nclass
    idx = dataY==U_dataY(i);
    dataY_temp(idx,i)=1;
end

dataX = rescale(dataX);

trainX = dataX(train_indx,:);
trainY = dataY_temp(train_indx,:);
testX = dataX(test_indx,:);
testY = dataY_temp(test_indx,:);


seed = RandStream('mcg16807','Seed',0);
RandStream.setGlobalStream(seed);


%default values. You need to tune them for best results using the validation set.

option.N = 100; % [1-4096],'Type','integer'
option.L = 10; % [2,10],'Type','integer'
option.lambda = 2^(4); % [2^(-12), 2^(12)],'Type','decimal'
option.activation = 2;% [1,9],'Type','integer'); 1-selu, 2-relu, 3-sigmoid, 4-sin, 5-hardlim, 6-tribas, 7-radbas, 8-sign, 9-swish
option.renormal = 1;% [0,1],'Type','integer' 0-NO, 1-Yes
option.BN_k = 1; % [0.5,2],'Type','decimal'
option.BN_b = 1; % [-2,2],'Type','decimal'
option.low = 1;% (0,1],'Type','decimal' 1-No weighting
option.P_rate = 0; % [0,1],'Type','decimal' 0-No pruning
[model,train_acc,test_acc] = MRVFL(trainX,trainY,testX,testY,option);

%% ACC
train_acc
test_acc


