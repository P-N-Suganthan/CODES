# -*- coding: utf-8 -*-
"""
Created on Thu Jul 23 09:06:40 2020

@author: lenovo
"""

from ForecastLib import TsMetric
import numpy as np
import pandas as pd
import numpy.ma as ma
import collections
import matplotlib.pyplot as plt
from scipy.stats import rankdata,wilcoxon,friedmanchisquare
#ewtmedianp[:,k]
import scikit_posthocs as sp # https://pypi.org/project/scikit-posthocs/
#import stac
# Helper functions for performing the statistical tests
def generate_scores(method, method_args, data, labels):
    pairwise_scores = method(data, **method_args) # Matrix for all pairwise comaprisons
    pairwise_scores.set_axis(labels, axis='columns', inplace=True) # Label the cols
    pairwise_scores.set_axis(labels, axis='rows', inplace=True) # Label the rows, note: same label as pairwise combinations
    return pairwise_scores
def remove_minmax(x):
    xp=x.copy()
    max_=x.max()
    min_=x.min()
    # print(xp.argmax())
    xp=np.delete(xp,xp.argmax())
    xp=np.delete(xp,xp.argmin())
    return xp
def friedman(n,k,rank_matrix):
    """
    n dataset 
    k models
    """
    sumr=sum(list(map(lambda x: np.mean(x)**2,rank_matrix.T)))
    result=12*n/(k*(k+1))*(sumr-k*(k+1)** 2 /4)
    result= (n-1)*result/(n*(k-1)-result)
    return result
def compute_CD(avranks, n, alpha="0.05", test="nemenyi"):
    """
    Returns critical difference for Nemenyi or Bonferroni-Dunn test
    according to given alpha (either alpha="0.05" or alpha="0.1") for average
    ranks and number of tested datasets N. Test can be either "nemenyi" for
    for Nemenyi two tailed test or "bonferroni-dunn" for Bonferroni-Dunn test.
    """
    k = len(avranks)
    d = {("nemenyi", "0.05"): [0, 0, 1.959964, 2.343701, 2.569032, 2.727774,
                               2.849705, 2.94832, 3.030879, 3.101730, 3.163684,
                               3.218654, 3.268004, 3.312739, 3.353618, 3.39123,
                               3.426041, 3.458425, 3.488685, 3.517073,
                               3.543799],
         ("nemenyi", "0.1"): [0, 0, 1.644854, 2.052293, 2.291341, 2.459516,
                              2.588521, 2.692732, 2.779884, 2.854606, 2.919889,
                              2.977768, 3.029694, 3.076733, 3.119693, 3.159199,
                              3.195743, 3.229723, 3.261461, 3.291224, 3.319233],
         ("bonferroni-dunn", "0.05"): [0, 0, 1.960, 2.241, 2.394, 2.498, 2.576,
                                       2.638, 2.690, 2.724, 2.773],
         ("bonferroni-dunn", "0.1"): [0, 0, 1.645, 1.960, 2.128, 2.241, 2.326,
                                      2.394, 2.450, 2.498, 2.539]}
    q = d[(test, alpha)]
    cd = q[k] * (k * (k + 1) / (6.0 * n)) ** 0.5
    return cd
def get_prediction(name):
    #file_name = D:\Newbuilding price forecasting\Corrected results
    file_name = 'AdmissionResults/'+name+'.csv'
  
    dat = pd.read_csv(file_name)
    # aa=np.round(dat.values,2)
    dat = dat.fillna(method='ffill')
    # dat.values=aa
    return dat,dat.columns
def get_data(name):
    #file_name = 'C:\\Users\\lenovo\\Desktop\\FuzzyTimeSeries\\pyFTS-master\\pyFTS\\'+name+'.csv'
    file_name = name+'.csv'
    #D:\Multivarate paper program\monthly_data
    dat = pd.read_csv(file_name)
    dat = dat.fillna(method='ffill')
    # if 'AEMO' not in name:
    #     dat.values=np.round(dat.values,2)
    return dat#,dat.columns
# loc='SA'
# year='2020'
# month='PRICE_AND_DEMAND_202010_'+loc+str(1)#'PRICE_AND_DEMAND_202001_QLD1'
# dataset='D:\\AEMO\\'+loc+'\\'+ year +'\\'+month

rmse_all=[]
mape_all=[]
mase_all=[]
import warnings
warnings.filterwarnings('ignore')

data=pd.read_csv('Singapore'+'.csv')
allhos=['Public Sector Hospital Admissions',
   '  Alexandra Hospital', '  Changi General Hospital',
   '  Khoo Teck Puat Hospital', '  National University Hospital',
   '  Ng Teng Fong General Hospital', '  Sengkang General Hospital',
   '  Singapore General Hospital', '  Tan Tock Seng Hospital',
   '  Communicable Disease Centre',
   '  National Centre For Infectious Diseases',
   '  Institute Of Mental Health Woodbridge Hospital',
   '  Kandang Kerbau Women Children Hospital', '  National Heart Centre']
fidx=[1,4,7,8,9,11,12,13]
hos=[]
for f in fidx:
    hos.append(allhos[f])
test_l=24
validation_l=24
hos=['  Alexandra Hospital',
 '  National University Hospital',
 '  Singapore General Hospital',
 '  Tan Tock Seng Hospital',
  '  Communicable Disease Centre',
 '  Institute Of Mental Health Woodbridge Hospital',
 '  Kandang Kerbau Women Children Hospital',
 '  National Heart Centre']
axi=0
for ho in hos[:]:
    ho_data=data[ho].copy()
    print(ho,ho_data.shape,ho_data.min(),ho_data.max())
    # ho_data.dropna()
    np_data=ho_data.values[::-1]
    np_data=np_data[np_data!='na']
    np_data=np_data.astype(float).reshape(-1,1)

    train_l=len(np_data)-test_l-validation_l
    target=np_data[-test_l:].ravel()
    history=np_data[:-test_l].ravel()
    prediction={}
    pre_loc='AdmissionResults/'
    rmse={}
    mape={}
    mase={}
    prediction['Persistence']=np_data[-test_l-1:-1].ravel()
    models=['Persistence','SARIMA','LRdif','MLPSigmoid','SVRdif32','SARIMA_MLP32']
    
    for model in models[1:]:
        prediction[model]=get_data(pre_loc+model+ho).values[:,1:].ravel().round()
    
    metric=TsMetric()
    
    # #MAPE
    # #MASE
    
    
    
    rmse=dict(zip(models,[metric.RMSE(target,prediction[i]) for i in models]))
    mape=dict(zip(models,[metric.MAPE(target,prediction[i]) for i in models]))
    mase=dict(zip(models,[metric.MASE(target,prediction[i],history) for i in models]))
    error = collections.OrderedDict()
    
    rvfl_loc='AdmissionResults/RevisededRVFLdif1'+ho
    rvfl_loc='AdmissionResults/FRevisededRVFLdif_dif_valid_gaussian1'+ho
    #dif_valid_gaussian3
    #RevisededRVFLdif1
    #FRevisededRVFLdif_dif_valid_gaussian
    edrvfl_dtpres=pd.read_csv(rvfl_loc).values[:,1:].round()
    prediction['RVFL']=np.mean(edrvfl_dtpres,axis=1)
    edrvfl_dt_rmse=np.zeros(edrvfl_dtpres.shape[1])
    edrvfl_dt_mape=np.zeros(edrvfl_dtpres.shape[1])
    edrvfl_dt_mase=np.zeros(edrvfl_dtpres.shape[1])
    for k in range(edrvfl_dtpres.shape[1]):
        edrvfl_dt_rmse[k]=metric.RMSE(target, edrvfl_dtpres[:,k])
        edrvfl_dt_mape[k]=metric.MAPE(target, edrvfl_dtpres[:,k])
        edrvfl_dt_mase[k]=metric.MASE(target, edrvfl_dtpres[:,k],history)
    rmse['RVFL']=edrvfl_dt_rmse.mean()
    mase['RVFL']=edrvfl_dt_mase.mean()
    mape['RVFL']=edrvfl_dt_mape.mean()
    
    
    
    rvfl_loc='AdmissionResults/RevisededRVFLdif_dif_valid_gaussian8'+ho#3，7
    #dif val 8 dif_valid_gaussian
    #3 5
    edrvfl_dtpres=pd.read_csv(rvfl_loc).values[:,1:].round()
    prediction['edRVFL']=np.mean(edrvfl_dtpres,axis=1)
    edrvfl_dt_rmse=np.zeros(edrvfl_dtpres.shape[1])
    edrvfl_dt_mape=np.zeros(edrvfl_dtpres.shape[1])
    edrvfl_dt_mase=np.zeros(edrvfl_dtpres.shape[1])
    for k in range(edrvfl_dtpres.shape[1]):
        edrvfl_dt_rmse[k]=metric.RMSE(target, edrvfl_dtpres[:,k])
        edrvfl_dt_mape[k]=metric.MAPE(target, edrvfl_dtpres[:,k])
        edrvfl_dt_mase[k]=metric.MASE(target, edrvfl_dtpres[:,k],history)
    rmse['edRVFL']=edrvfl_dt_rmse.mean()
    mase['edRVFL']=edrvfl_dt_mase.mean()
    mape['edRVFL']=edrvfl_dt_mape.mean()
    
    error['RMSE']=rmse
    error['MAPE']=mape
    error['MASE']=mase
    
   
    
    
    
    
    
    error_df=pd.DataFrame.from_dict(error,orient='index')
    # e_df=error_df.reindex(['RMSE','MAPE','MASE'])
    rmse_all.append(error_df.loc['RMSE'].values.reshape(1,-1))
    mape_all.append(error_df.loc['MAPE'].values.reshape(1,-1))
    mase_all.append(error_df.loc['MASE'].values.reshape(1,-1))
    # fig, ax = plt.subplots(4,1,figsize=(10,7))
    plt.rcParams["font.family"] = "Times New Roman"
#    plt.rcParams["legend.fontsize"] = 44
    fig, ax = plt.subplots(figsize=(7,5))
    # ax=axes[axi]
    ax.set_title(hos[axi][2:], x=.5,y=1.0,fontsize=12)#'small')
    ax.grid(color='white') 
    ax.plot(prediction['SARIMA_MLP32'],label='Hybrid',linestyle='dotted',marker="s",markersize=3.5)
    ax.plot(prediction['LRdif'],label='SR',linestyle='dotted',marker="P",markersize=3.5)
    ax.plot(prediction['SARIMA'],label='SARIMA',linestyle='dotted',marker="*",markersize=3.5)  
    ax.plot(prediction['RVFL'],label='RVFL',linestyle='dotted',marker="1",markersize=3.5)      
    ax.plot(edrvfl_dtpres.mean(axis=1),label='edRVFL',linestyle='dotted',marker="o",markersize=3.5)#,markevery=9)        
   
    
    ax.plot(target,label='Raw data',linestyle='dotted',marker=">",markersize=3.5)#,markevery)
    ax.set_ylabel('Number')
    aaa=np.array([ 0,  3,  6,  9, 12, 15, 18, 21,23])
    xxx=np.array(['2019 Oct', '2020 Jan', '2020 Apr', '2020 Jul', '2020 Oct',
            '2021 Jan', '2021 Apr', '2021 Jul','2021 Sep'])
    ax.set_xticks(np.arange(0,24,3))
    ax.set_xticklabels(data['Data Series'].values[::-1][-24:][::3],rotation=15,fontsize=12)
    
    ax.set_xticks(aaa)
    ax.set_xticklabels(xxx,rotation=15,fontsize=10)
    
    
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['bottom'].set_visible(False)
    ax.spines['left'].set_visible(False)
    ax.legend(framealpha=0,fontsize=12)
    ax.set_facecolor('lightgrey')

    axi+=1
        # print(e_df)
    # fig.show()
    fig.savefig(pre_loc+'edRVFL'+ho[2:]+'.eps', dpi=1000,format='eps')
rmse_all_np=np.concatenate(rmse_all,axis=0)
mase_all_np=np.concatenate(mase_all,axis=0)
mape_all_np=np.concatenate(mape_all,axis=0)
rmsealldf=pd.DataFrame(data=rmse_all_np,columns=error_df.columns,index=hos)
masealldf=pd.DataFrame(data=mase_all_np,columns=error_df.columns,index=hos)
mapealldf=pd.DataFrame(data=mape_all_np,columns=error_df.columns,index=hos)
ranks=np.zeros(rmse_all_np.shape)
av=[]
for err in [rmse_all_np,mase_all_np,mape_all_np]:
    for i in range(err.shape[0]):
        #     print(err.values[:,1:][i,:])
        ranks[i,:]=rankdata(err[i,:])
    af1=friedmanchisquare(err[:,0],err[:,1],err[:,2],err[:,3],err[:,4],err[:,5],
                      err[:,6],err[:,7])
    print('1',af1)
    af2=friedmanchisquare(*err.T)
    print(af2)
    avranks=np.mean(ranks,axis=0).reshape(1,-1)
    cd=compute_CD(avranks.ravel(),err.shape[0])
    av.append(avranks)
    # print(avranks)
n=ranks.shape[0]
k-ranks.shape[1]
frid=friedman(n,k,ranks)
avrank=np.concatenate(av,axis=0)
avrank_df=pd.DataFrame(data=avrank,columns=error_df.columns)
print(avrank_df)
#cd 4.796
# rank(*err)
rmse_nemenyi_scores = generate_scores(sp.posthoc_nemenyi_friedman, {}, rmsealldf.values, avrank_df.columns)
mase_nemenyi_scores = generate_scores(sp.posthoc_nemenyi_friedman, {}, masealldf.values, avrank_df.columns)
mape_nemenyi_scores = generate_scores(sp.posthoc_nemenyi_friedman, {}, mapealldf.values, avrank_df.columns)