# -*- coding: utf-8 -*-
"""
Created on Wed Nov 17 10:48:25 2021

@author: ruobi
"""

from sklearn.tree import DecisionTreeRegressor
from itertools import product
import matplotlib.pyplot as plt
import ForecastLib
from sklearn import preprocessing
import numpy as np
import random
import pandas as pd
from hyperopt import fmin, tpe, hp
from sklearn.linear_model import Ridge
def compute_error(actuals,predictions,history=None):
    actuals=actuals.ravel()
    predictions=predictions.ravel()
    
    metric=ForecastLib.TsMetric()
    error={}
    error['RMSE']=metric.RMSE(actuals, predictions)
    # error['MAPE']=metric.MAPE(actuals,predictions)
    error['MAE']=metric.MAE(actuals,predictions)
    if history is not None:
        history=history.ravel()
        error['MASE']=metric.MASE(actuals,predictions,history)
        
    
    return error
def relu(X):
   return np.maximum(0,X)
def get_data(name):
    #file_name = 'C:\\Users\\lenovo\\Desktop\\FuzzyTimeSeries\\pyFTS-master\\pyFTS\\'+name+'.csv'
    file_name = name+'.csv'
    #D:\Multivarate paper program\monthly_data
    dat = pd.read_csv(file_name)
    dat = dat.fillna(method='ffill')
    return dat,dat.columns
def format_data(dat,order,idx=0):
    n_sample=dat.shape[0]-order
    x=np.zeros((n_sample,dat.shape[1]*order))
    y=np.zeros((n_sample,1))
    for i in range(n_sample):
        x[i,:]=dat[i:i+order,:].ravel()
        y[i]  =dat[i+order,idx]
    return x,y
def sigmoid(x):

    z = 1/(1 + np.exp(-x)) 
    return z
def init_layer_weight(Nu,Nh,input_scale=1):
    #Nu input size
    return np.random.uniform(-input_scale, input_scale, size=(Nu,Nh))

def compute_layer_state(input_,w):
    #n_sample,n_h
    return sigmoid(np.dot(input_,w))

def cross_validation(norm_data,Nl=3,s=0):
    # best_hypers=[]
    np.random.seed(s)
    orders=[1,2,4,8,16]
    Nhs=[2,4,8,16]#np.arange(10,100,10)#
    iss=[1]#,0.1,0.01]
    regs=[pow(2,i) for i in range(-11,0)]
    # regs.append(0)
    # regs=[0]
    hypers=list(product(orders,Nhs,iss,regs))
    val_l=24
    test_l=24
    best_hyper=[]
    for i in range(Nl):
        # print(i,layer_s)
        layer=i+1
        layer_cv_loss=[]
        if layer==1:
            
            for h in hypers:
                err=layer_cv([h],norm_data,val_l)
                # layer_h,layer_s=layer_cv(s=s,boat=boat)
                layer_cv_loss.append(err)#list(map(layer_cv,hypers[:]))
            layer_idx=layer_cv_loss.index(min(layer_cv_loss))
            layer_best_hyper= hypers[layer_idx]
            hypers=list(product([layer_best_hyper[0]],Nhs,iss,regs))
        else:
            best_=best_hyper.copy()
            for h in hypers:
                best_.append(h)
                err=layer_cv(best_,norm_data,val_l)
                # layer_h,layer_s=layer_cv(s=s,boat=boat)
                layer_cv_loss.append(err)#list(map(layer_cv,hypers[:]))
            layer_idx=layer_cv_loss.index(min(layer_cv_loss))
            layer_best_hyper= hypers[layer_idx]
        # print(layer_h)
        best_hyper.append(layer_best_hyper)
        # print(best_hyper)
    return best_hyper
def layer_cv(hypers,norm_data,val_l):
    order=hypers[0][0]
    x,y=format_data(norm_data, order)
    # print(x.shape,y.shape)
    trainx,trainy=x[:-val_l,:],y[:-val_l,:]
    layer=len(hypers)

    input_=x
    for i in range(layer):
        Nh=hypers[i][1]
        input_scale=hypers[i][2]
        reg=hypers[i][3]
        w=init_layer_weight(input_.shape[1],Nh,input_scale=input_scale)
        hidden=compute_layer_state(input_,w)
        input_=np.concatenate((x,hidden),axis=1)
        if i ==layer-1:
            reg=Ridge(alpha=reg)
            reg.fit(input_[:-val_l,:],trainy)
            pre=reg.predict(input_[-val_l:,:])
    e=compute_error(norm_data[-val_l:,:], pre)['RMSE']
    return e
def edrvfl_pre(hypers,norm_data,test_l):
    order=hypers[0][0]
    x,y=format_data(norm_data, order)
    trainx,trainy=x[:-test_l,:],y[:-test_l,:]
    layer=len(hypers)

    input_=x
    pres=np.zeros((test_l,layer))
    for i in range(layer):
        Nh=hypers[i][1]
        input_scale=hypers[i][2]
        reg=hypers[i][3]
        w=init_layer_weight(input_.shape[1],Nh,input_scale=input_scale)
        hidden=compute_layer_state(input_,w)
        input_=np.concatenate((x,hidden),axis=1)
        # if i ==layer-1:
        reg=Ridge(alpha=reg)
        reg.fit(input_[:-test_l,:],trainy)
        pre=reg.predict(input_[-test_l:,:])
        pres[:,i:i+1]=pre
    # e=compute_error(norm_data[-val_l:,:], pre)['RMSE']
    return np.mean(pres,axis=1).reshape(-1,1)#pres.mean(axis=1).reshape(-1,1)

def ed_cross_validation(hypers,data,raw_data,train_idx,val_idx,Nl,scaler=None,s=0):
    # if len(hypers)!=Nl:
    #     print('Error')
    #     return None
    # cvloss=[]
    # for i in range(1,Nl):
    #     edhyper=hypers[:i+1]
    #     test_outputs_norm=edRVFL_predict(edhyper,data,train_idx,val_idx,s)
        
    #     test_outputs=scaler.inverse_transform(test_outputs_norm)
    #     actuals=raw_data[-len(val_idx):]
    #     test_err=compute_error(actuals,test_outputs,None)
    #     cvloss.append(test_err['RMSE'])
#    print(cvloss,cvloss.index(min(cvloss)))
    return hypers#[:cvloss.index(min(cvloss))+2]
    
def main():
    Nl=10#np.arange(2,12,4)#4 7
   
    seeds=10
    
   
    data=pd.read_csv('D:\\Biomedical signal forecasting\\Singapore'+'.csv')
    allhos=['Public Sector Hospital Admissions',
       '  Alexandra Hospital', '  Changi General Hospital',
       '  Khoo Teck Puat Hospital', '  National University Hospital',
       '  Ng Teng Fong General Hospital', '  Sengkang General Hospital',
       '  Singapore General Hospital', '  Tan Tock Seng Hospital',
       '  Communicable Disease Centre',
       '  National Centre For Infectious Diseases',
       '  Institute Of Mental Health Woodbridge Hospital',
       '  Kandang Kerbau Women Children Hospital', '  National Heart Centre']
    fidx=[1,4,7,8,9,11,12,13]
    hos=[]
    for f in fidx:
        hos.append(allhos[f])
    test_l=24
    val_l=24
    for ho in hos:
        ho_data=data[ho].copy()
        # print(ho,ho_data.shape)
        # ho_data.dropna()
        np_data=ho_data.values[::-1]
        np_data=np_data[np_data!='na']
        data_=np_data.astype(float).reshape(-1,1)
       
        target_idx=0
        metric=ForecastLib.TsMetric()
       
        scaler=preprocessing.MinMaxScaler() 
        dif=data_[1:,:]-data_[:-1,:]
        scaler.fit(dif[:-test_l-val_l])
        norm_data=scaler.transform(dif)
        # print(norm_data.shape)
        test_pres_ea=[]
        for s in np.arange(seeds):
            np.random.seed(s)
            
            ed_best_hypers=cross_validation(norm_data[:-test_l],Nl,s=0)
           
            # print('Test')
            
            scaler.fit(dif[:-test_l])
            norm_data=scaler.transform(dif)
            order=ed_best_hypers[0][0]
            
            test_outputs_norm_mea=edrvfl_pre(ed_best_hypers,norm_data,test_l)
            # test_outputs_ed=scaler.inverse_transform(test_outputs_norm_med)
            test_outputs_ea=scaler.inverse_transform(test_outputs_norm_mea)+data_[-test_l-1:-1]
            # test_outputs_ea=np.round(test_outputs_ea,1)
            # print(test_outputs_ea)
            # test_pres_ed.append(test_outputs_ed)
            test_pres_ea.append(test_outputs_ea)
            actuals=data_[-test_l:]
            history=data_[:-test_l]
            # plt.figure()
            # plt.plot(actuals)
            # plt.plot(test_outputs_ea)
            # plt.show()
            naive_err=compute_error(actuals, data_[-test_l-1:-1],history)
            test_err=compute_error(actuals,test_outputs_ea,history)
        print(ho)
        print('naive',naive_err)
        print(test_err)
        print(len(ed_best_hypers))
        # test_p=np.concatenate(test_pres_ed,axis=1)
        # dfed=pd.DataFrame(test_p)
        # #D:\DeepRVFL-master\Results
        # dfed.to_csv('D:\\DeepRVFL-master\\Wind\\edRVFLmed'+loc+month_+'.csv')
    
        test_p=np.concatenate(test_pres_ea,axis=1)
        dfea=pd.DataFrame(test_p)
        #D:\Biomedical signal forecasting\Results
        #SS small ridge
        #S small hidde
        dfea.to_csv('D:\\Biomedical signal forecasting\\AdmissionResults\\SedRVFLdif'+str(Nl)+ho)

                
                
if __name__ == "__main__":
  
    main()
    
    
    