function [fit]=maga_testfn(x)
global p feval_count normal_flag xl xu gbiasflag gbias realoptima
[np,n]=size(x);
if normal_flag==1,
  xlower=repmat(xl,np,1);
  xupper=repmat(xu,np,1);
  x=xlower+(xupper-xlower).*x;
end

if gbiasflag==1
    x=x-repmat((gbias-realoptima(p,:)),np,1);
end
feval_count=feval_count+np;
%De Jong's function 1

if p==1
ff=sum(x(:,1:n).^2,2);
fit=-ff;
end

%Axis parallel hyper-ellipsoid
if p==2,
cc=repmat([1:n],np,1);
ff=sum(cc.*x(:,1:n).^2,2);
fit=-ff;
end


%rotated hyper-ellipsoid (schwefel's function)
if p==3,
sum2=zeros(np,1);
for i=1:n
sum1=zeros(np,1);
for j=1:i
sum1=sum1+x(:,j);
end
sum2=sum2+(sum1).^2;
end
ff=sum2;
fit=-ff;
xact=x;
end

% Rosenbrock's Valley (Banana function)
if p==4,
sum1=zeros(np,1);
for i=1:n-1
sum1=sum1+(100*(x(:,i+1)-x(:,i).^2).^2+(1-x(:,i)).^2);
end
ff=sum1;
fit=-ff;
end

% Griewank's function
if p==5
sum2=ones(np,1);
sum1=(1/4000)*sum(x(:,1:n).^2,2);
for i=1:n
sum2=sum2.*cos((x(:,i)/sqrt(i)));
end
ff=sum1-sum2+1;
fit=-ff;
end
 
% sum of different powers
if p==6,
sum1=zeros(np,1);
for i=1:n
sum1=sum1+(abs(x(:,i))).^(i+1);
end
ff=sum1;
fit=-ff;
end


%ellipsoid model
if p==7,
cc=repmat(1:n,np,1);
fit=-sum(cc.*x.^2,2);
end

if p==8,
fit=-sum(x.^2-10*cos(2*pi*x)+10,2);
end

if p==9,
sum1=zeros(np,1);
sum2=ones(np,1);
sum3=zeros(np,1);
sum4=ones(np,1);
sum5=zeros(np,1);

for i=1:n
sum1=sum1+cos((x(:,i))).^4;
sum2=sum2.*(cos((x(:,i))).^2);
sum3=sum3+i*x(:,i).^2;
sum4=sum4.*x(:,i);
sum5=sum5+x(:,i);
end
ff=abs((sum1-2*sum2)./sqrt(sum3));
ff=(sum4>.75).*ff;
ff=(sum5<150).*ff;
fit=-(-ff);
end

if p==10,
%Ackley's Function
%  fit=zeros(np,1);
%     for i=1:(n-1)
%         fit=fit+20+exp(1)-20.*exp(-0.2.*sqrt(0.5*(x(:,i+1).^2+x(:,i).^2)))-exp(0.5.*(cos(2*pi.*x(:,i+1))+cos(2*pi.*x(:,i))));
%     end
%     fit=fit+8.881784197001252e-016;fit=-fit;
% end
    fit=20+exp(1)-20.*exp(-0.2.*sqrt(1./n.*sum(x.^2,2)))-exp((1./n).*sum(cos(2.*pi.*x),2));
    fit=fit+8.881784197001252e-016;
    fit=-fit;
end
if p==11
%Schwefel's function
    fit=zeros(np,1);
    for i=1:n
        fit=fit-x(:,i).*sin(sqrt(abs(x(:,i))));
    end
    fit=4.189829e+002*n+fit;
    fit=fit-3.818269869952928e-004;
    fit=-fit;
end

if p==12

%-50<x<50
a=10;k=100;m=4;
y=1+x./4;
u=zeros(np,n);
u=(x>a).*(k.*(x-a).^m)+(x<-a).*(k.*(-x-a).^m);
fit=zeros(np,1);
for i=1:n-1
    fit=fit+(y(:,i)-1).^2.*(1+10.*(sin(pi.*y(:,i+1))).^2);
end
fit=fit+10*(sin(pi.*y(:,1))).^2+(y(:,n)-1).^2;
fit=fit.*pi./n;
fit=fit+sum(u,2);fit=-fit;
end

if p==13
        %-50<x<50
a=5;k=100;m=4;
fit=zeros(np,1);
u=(x>a).*(k.*(x-a).^m)+(x<-a).*(k.*(-x-a).^m);
for i=1:n-1
    fit=fit+((x(:,i)-1).^2).*(1+(sin(3.*pi.*x(:,i+1))).^2);
end
fit=fit+(sin(3.*pi.*x(:,1))).^2+(x(:,n)-1).^2.*(1+(sin(2.*pi.*x(:,n))).^2);
fit=fit./10;
fit=fit+sum(u,2);fit=-fit;
end

if p==14
    %-100,100
    fit=ones(np,1);
    for i=1:n
        fit=fit.*abs(x(:,i));
    end
    fit=fit+sum(abs(x),2);    fit=-fit;
end

if p==15

        %-100,100
fit=max(abs(x'));
fit=fit';fit=-fit;
end