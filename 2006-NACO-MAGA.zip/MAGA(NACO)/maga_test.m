
clear all
close all
warning off

global ini_pop self_pop n t F q xl xu S pm pc spm sLsize Lsize sRadius sGen po p L feval_count status fhd normal_flag fhd1 p_x gbiasflag gbias realoptima Best

tot_run=20;t0=cputime;
gbiasflag=1;% 1: shift 0:without shift

xnum=2;p_x=(1/xnum).*ones(xnum,1);
n=30;F=4;q=3;Lsize=5;S=Lsize;tmax=150;pm=.1;pc=.1;spm=.05; sLsize=3;sRadius=.2; 
sGen=10;%sGen=100 better for shift
feval_count=0;opti=0;prec=.0001;
normal_flag=0;
xuuu=[5.12*ones(1,n);5.12*ones(1,n);65.536*ones(1,n);2.048*ones(1,n);600*ones(1,n);1*ones(1,n);5.12*ones(1,n);5.12*ones(1,n);10*ones(1,n); 32.768*ones(1,n);500*ones(1,n);50*ones(1,n);]; %upper bound for all problems
xlll=[-5.12*ones(1,n);-5.12*ones(1,n);-65.536*ones(1,n);-2.048*ones(1,n);-600*ones(1,n);1*ones(1,n);-5.12*ones(1,n);-5.12*ones(1,n);zeros(1,n);-32.768*ones(1,n);-500*ones(1,n);-50*ones(1,n);]; % Lower bound for all problems

realoptima=[0;0;0;1;0;0;0;0;0;0;420;0;0];
realoptima=repmat(realoptima,1,n);
L=[1 1 1 1;1 2 2 2;1 3 3 3;2 1 2 3;2 2 3 1;2 3 1 2;3 1 3 2;3 2 1 3; 3 3 2 1];
fhd1=str2func('maga_compettion');po=.2;%po=.8 better for shift
funchoose=[4,5,8,10,11,12];%4: rosenbrock 5:griewank 8:rastrigin 10:ackley 11:schwefel
for funnum=1:6
    funnum
p=funchoose(funnum);

for runs=1:tot_run
    feval_count=0;get_flag=0;
ini_pop=[];self_pop=[];
xl=xlll(p,:);
xu=xuuu(p,:);
fhd=str2func('maga_testfn');
gbias=xl(1)+(xu(1)-xl(1)).*rand(1,n);
if gbiasflag==1
xl=max(xl,gbias-(-xl+realoptima(p,:)));
xu=min(xu,gbias+xu-realoptima(p,:));
end
S_interval=(xu-xl)/S;
xl1=xl;xll=[];ini_pop=[];
for i=1:S
    xl1=xl1+S_interval;
    xll=[xll;xl1];
end
xll=[xl;xll];

for i=1:S
    xlower=xll(i,:);
    xupper=xll(i+1,:);
    pop_range=(xupper-xlower)/(q-1);
    alpha=[];xlower1=xlower;
    for j=1:q-2
        xlower1=xlower1+pop_range;
        alpha=[alpha xlower1'];
    end
    alpha=[xlower' alpha xupper'];
    
rc=randperm(n-2)+1;
rc1=sort(rc(1:F-1));
rc1=[1 rc1 n];
pop=[];
sw=randperm(4);
for ii=1:F
    for jj=rc1(ii)+1:rc1(ii+1)
       temp_pop=ortho_pop(alpha(jj,:),L(:,sw(ii))); 
       pop=[pop temp_pop'];
   end
end
temp_pop=ortho_pop(alpha(1,:),L(:,sw(1))); 
pop=[temp_pop' pop];
rrc=randperm(9);
ini_pop=[ini_pop;pop(rrc(1:S)',:)];
end
count=0;
ini_pop=xl(1)+(xu(1)-xl(1)).*rand(Lsize*Lsize,n);
if normal_flag==1
    ini_pop=rand(Lsize*Lsize,n);
end

for j=1:Lsize
for i=1:Lsize
switch (i|j)   
    case(i==1 & j==1),list=[Lsize+1 2 Lsize*(Lsize-1)+1 Lsize];
    case(i==1 & j==Lsize),list=[ 1  (Lsize-1)*Lsize+2 (Lsize-2)*Lsize+1 Lsize*Lsize];
    case(i==Lsize &j==1),list=[ Lsize*2 1   Lsize*Lsize Lsize-1] ;
    case(i==Lsize & j==Lsize),list=[ Lsize  (Lsize-1)*Lsize+1   (Lsize-1)*Lsize Lsize*Lsize-1] ;
    case(i==1 & j~=Lsize & j~=1),list=[j*Lsize+1 (j-1)*Lsize+2 (j-2)*Lsize+1 j*Lsize];
    case (i==Lsize & j~=Lsize & j~=1),list=[(j+1)*Lsize (j-1)*Lsize+1 (j-1)*Lsize (j)*Lsize-1]  ;
    case(j==1 & i~=Lsize & i~=1),list=[j*Lsize+i i+1 (Lsize-1)*Lsize+i  i-1];
    case(j==Lsize & i~=Lsize & i~=1),list=[i (Lsize-1)*Lsize+i+1 (Lsize-2)*Lsize+i (Lsize-1)*Lsize+i-1];
    otherwise
    list=[(j)*Lsize+i (j-1)*Lsize+i+1 (j-2)*Lsize+i (j-1)*Lsize+i-1];
end
count=count+1;
ini_pop(count,n+2:n+5)=list;
end
end

ini_pop(:,n+1)=feval(fhd,ini_pop(:,1:n));
[Best_max,Best_id]=max(ini_pop(:,n+1));
Best=[ini_pop(Best_id,1:n) Best_max];
% Best_max
for t=1:tmax
for j=1:Lsize^2
    feval(fhd1,j,1);
fit_stat(j)=status;
end

fit_index=find(fit_stat==0);
if ~isempty(fit_index),
ini_pop(fit_index',n+1)=feval(fhd,ini_pop(fit_index',1:n));
end
    ini_pop(:,1:n)=(ini_pop(:,1:n)<repmat(xl,25,1)).*repmat(xl,25,1)+(ini_pop(:,1:n)>=repmat(xl,25,1)).*ini_pop(:,1:n);
    ini_pop(:,1:n)=(ini_pop(:,1:n)>repmat(xu,25,1)).*repmat(xu,25,1)+(ini_pop(:,1:n)<=repmat(xu,25,1)).*ini_pop(:,1:n);


for j=1:Lsize^2
if rand<pc,maga_ortho_crossover(j);end
if rand<pm,maga_mutation(j,1);end
end

ini_pop(:,n+1)=feval(fhd,ini_pop(:,1:n));
[CBest_max,CBest_id]=max(ini_pop(:,n+1));
CBest=[ini_pop(CBest_id,1:n) CBest_max];
self_learning(CBest_id);
[CBest_max,CBest_id]=max(ini_pop(:,n+1));
CBest=[ini_pop(CBest_id,1:n) CBest_max];


if CBest(n+1)>Best(n+1),
Best=CBest;
else
ini_pop(CBest_id,1:n+1)=Best;
end

if (abs(Best(n+1))<=prec) & (get_flag==0),fitcount_stop=feval_count;get_flag=1;end
% CBest;
%     if round(t/10)==t/10
% %     plot(pos(:,D-1),pos(:,D),'b*');
%     scatter(ini_pop(:,n-1),ini_pop(:,n),12,ini_pop(:,n+1),'filled')
%     hold on
%     plot(CBest(:,n-1),CBest(:,n),'r*');
%     hold off
%      axis([xl(1,n-1),xu(1,n-1),xl(1,n),xu(1,n)])
%     title(['MAGA: ',num2str(t),' generations, Gbestval=',num2str(CBest(1,n+1))]);  
%     drawnow
%     end
end
if abs(Best(n+1))>prec,fitcount_stop=feval_count;end
overall_res(p,runs,:)=[t feval_count fitcount_stop Best(n+1)];
overall_res(p,runs,2)
overall_res(p,runs,3)
overall_res(p,runs,4)
end
end
% cputime-t0