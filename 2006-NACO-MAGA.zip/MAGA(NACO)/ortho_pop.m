function LL=ortho_pop(quant,Lp)

for i=1:9
    if Lp(i)==1;LL(i)=quant(1);
    elseif Lp(i)==2,LL(i)=quant(2);
    else
        LL(i)=quant(3);
    end
end