function self_learning(agent_id)
global ini_pop n sLsize sRadius sGen spm xl xu self_pop status fhd normal_flag fhd1

l=ini_pop(agent_id,1:n);
low_bound=1-sRadius;
up_bound=1+sRadius;

for i=2:sLsize*sLsize
    temp=l.*(low_bound+(up_bound-low_bound).*rand(1,n));
    if normal_flag==1,
    temp=(temp<0).*0+(temp>=0).*temp;
    temp=(temp>1)+(temp<=1).*temp;  
    else
    temp=(temp<xl).*xl+(temp>=xl).*temp;
    temp=(temp>xu).*xu+(temp<=xu).*temp;
end
    self_pop(i,1:n)=temp;
end
self_pop(1,1:n+1)=ini_pop(agent_id,1:n+1);
self_pop(2:sLsize^2,n+1)=feval(fhd,self_pop(2:sLsize^2,1:n));
count=0;

for j=1:sLsize
for i=1:sLsize
switch (i|j)   
    case(i==1 & j==1),list=[sLsize+1 2 sLsize*(sLsize-1)+1 sLsize];
    case(i==1 & j==sLsize),list=[ 1  (sLsize-1)*sLsize+2 (sLsize-2)*sLsize+1 sLsize*sLsize];
    case(i==sLsize &j==1),list=[ sLsize*2 1   sLsize*sLsize sLsize-1] ;
    case(i==sLsize & j==sLsize),list=[ sLsize  (sLsize-1)*sLsize+1   (sLsize-1)*sLsize sLsize*sLsize-1] ;
    case(i==1 & j~=sLsize & j~=1),list=[j*sLsize+1 (j-1)*sLsize+2 (j-2)*sLsize+1 j*sLsize];
    case (i==sLsize & j~=sLsize & j~=1),list=[(j+1)*sLsize (j-1)*sLsize+1 (j-1)*sLsize (j)*sLsize-1]  ;
    case(j==1 & i~=sLsize & i~=1),list=[j*sLsize+i i+1 (sLsize-1)*sLsize+i  i-1];
    case(j==sLsize & i~=sLsize & i~=1),list=[i (sLsize-1)*sLsize+i+1 (sLsize-2)*sLsize+i (sLsize-1)*sLsize+i-1];
    otherwise
    list=[(j)*sLsize+i (j-1)*sLsize+i+1 (j-2)*sLsize+i (j-1)*sLsize+i-1];
end
count=count+1;
self_pop(count,n+2:n+5)=list;
end
end

 
[sBest_max,sBest_id]=max(self_pop(:,n+1));
sBest=[self_pop(sBest_id,1:n) sBest_max];

for i=1:sGen
for j=1:sLsize^2
feval(fhd1,j,2);
fit_stat(j)=status;
end

for j=1:sLsize^2
if rand < spm,fit_stat(j)=0;maga_mutation(j,2);end
end

fit_index=find(fit_stat==0);
if ~isempty(fit_index),
self_pop(fit_index',n+1)=feval(fhd,self_pop(fit_index',1:n));
end

[sCBest(n+1),sCBest_id]=max(self_pop(:,n+1));
sCBest(1:n)=self_pop(sCBest_id,1:n);

if sCBest(n+1)>sBest(n+1),
sBest=sCBest;
else
self_pop(sCBest_id,1:n+1)=sBest;
end
end

ini_pop(agent_id,1:n+1)=sBest;    
    
    


