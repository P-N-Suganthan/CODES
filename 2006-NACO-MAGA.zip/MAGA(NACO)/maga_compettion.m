function magacompettion(agent_id,lorsl)
global ini_pop xl xu n self_pop po status normal_flag
status=1;

if lorsl==1,
agent_index=ini_pop(agent_id,n+2:n+5)';
agent_fit=ini_pop(agent_index,n+1);
[max_energy,max_agent]=max(agent_fit);
max_agent_id=ini_pop(agent_id,n+1+max_agent);
if ini_pop(agent_id,n+1)<max_energy,
status=0;
m=ini_pop(max_agent_id,1:n);
l=ini_pop(agent_id,1:n);
if(rand<po)
     e=m+(-.5+1*rand(1,n)).*(m-l);
    if normal_flag==1,
    e=(e<0).*0+(e>=0).*e;
    e=(e>1)+(e<=1).*e;  
    else
    e=(e<xl).*xl+(e>=xl).*e;
    e=(e>xu).*xu+(e<=xu).*e;
end
     ini_pop(agent_id,1:n)=e;
else
 if normal_flag==1,
 mm=m;    
 else
 mm=(m-xl)./(xu-xl);
 end
 rc=randperm(n);
 rc1=sort(rc(1:2));

 while rc1(1)==1 & rc1(2)==n,
 rc=randperm(n);
 rc1=sort(rc(1:2));
 end
 
 
 if rc1(2)==n,
 new=[mm(1:rc1(1)-1) rot90(rot90(mm(rc1(1):rc1(2))))];
 elseif rc1(1)==1,
 new=[rot90(rot90(mm(1:n)))];
 else
 new=[mm(1:rc1(1)-1) rot90(rot90(mm(rc1(1):rc1(2)))) mm(rc1(2)+1:n)];
 end

if normal_flag==1,
    ini_pop(agent_id,1:n)=new;
else
e=xl+new.*(xu-xl);
ini_pop(agent_id,1:n)=e;
end
end
end
end
   
if lorsl>1,
agent_index=self_pop(agent_id,n+2:n+5)';
agent_fit=self_pop(agent_index,n+1);
[max_energy,max_agent]=max(agent_fit);
max_agent_id=self_pop(agent_id,n+1+max_agent);

if self_pop(agent_id,n+1)<max_energy,
m=self_pop(max_agent_id,1:n);
l=self_pop(agent_id,1:n);
status=0;

if (rand<po), 
e=m+(-.5+1*rand(1,n)).*(m-l);

if normal_flag==1,
    e=(e<0).*0+(e>=0).*e;
    e=(e>1)+(e<=1).*e;  
    else
    e=(e<xl).*xl+(e>=xl).*e;
    e=(e>xu).*xu+(e<=xu).*e;
end
 self_pop(agent_id,1:n)=e;
else
 if normal_flag==1,
 mm=m;    
 else
 mm=(m-xl)./(xu-xl);
 end
 rc=randperm(n);
 rc1=sort(rc(1:2));

 while rc1(1)==1 & rc1(2)==n,
 rc=randperm(n);
 rc1=sort(rc(1:2));
 end
 
 
 if rc1(2)==n,
 new=[mm(1:rc1(1)-1) rot90(rot90(mm(rc1(1):rc1(2))))];
 elseif rc1(1)==1,
 new=[rot90(rot90(mm(1:n)))];
 else
 new=[mm(1:rc1(1)-1) rot90(rot90(mm(rc1(1):rc1(2)))) mm(rc1(2)+1:n)];
 end
 
if normal_flag==1,
    ini_pop(agent_id,1:n)=new;
else
e=xl+new.*(xu-xl);
    e=(e<xl).*xl+(e>=xl).*e;
    e=(e>xu).*xu+(e<=xu).*e;
ini_pop(agent_id,1:n)=e;
end
    
    
    
end
end
end
