function maga_mutation(agent_id,lorsl)

global ini_pop n t self_pop sGen xl xu normal_flag

rand_mask=rand(1,n);
if lorsl==1,
ll=ini_pop(agent_id,1:n);
new=(ll+normrnd(0,sqrt(1/t),1,n));
if normal_flag==1,
    new=(new<0).*0+(new>=0).*new;
    new=(new>1)+(new<=1).*new;  
    else
    new=(new<xl).*xl+(new>=xl).*new;
    new=(new>xu).*xu+(new<=xu).*new;
end
ini_pop(agent_id,1:n)=new;
end

if lorsl>1,
ll=self_pop(agent_id,1:n);
if rand>.5,
new=ll+normrnd(0,sqrt(1/sGen),1,n);
else
rc=randperm(n);
new=ll;
new(1,rc(1))=xl(rc(1))+(xu(rc(1))-xl(rc(1)))*rand;
end
 if normal_flag==1,
    new=(new<0).*0+(new>=0).*new;
    new=(new>1)+(new<=1).*new;  
    else
    new=(new<xl).*xl+(new>=xl).*new;
    new=(new>xu).*xu+(new<=xu).*new;
end
self_pop(agent_id,1:n)=new;
end    
