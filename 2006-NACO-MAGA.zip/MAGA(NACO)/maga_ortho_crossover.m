function maga_ortho_crossover(agent_id)

global ini_pop n q L F xl xu fhd

agent_index=ini_pop(agent_id,n+2:n+5)';
agent_fit=ini_pop(agent_index,n+1);
[max_energy,max_agent]=max(agent_fit);
max_agent_id=ini_pop(agent_id,n+1+max_agent);

l=ini_pop(agent_id,1:n);
m=ini_pop(max_agent_id,1:n);
xlm=min(l,m);
xum=max(l,m);
cross_range=(xum-xlm)/(q-1);

beta=[];xlm1=xlm;
for j=1:q-2
xlm1=xlm1+cross_range;
beta=[beta xlm1'];
end
beta=[xlm' beta xum'];

    
rc=randperm(n-2)+1;
rc1=sort(rc(1:F-1));
rc1=[1 rc1 n];
offspring=[];
sw=randperm(F);
for ii=1:F
    for jj=rc1(ii)+1:rc1(ii+1)
       temp=ortho_pop(beta(jj,:),L(:,sw(ii))); 
       offspring=[offspring temp'];
   end
end

temp=ortho_pop(beta(1,:),L(:,sw(1))); 
offspring=[temp' offspring];
ll=length(offspring(:,1));
    offspring=(offspring<repmat(xl,ll,1)).*repmat(xl,ll,1)+(offspring>=repmat(xl,ll,1)).*offspring;
    offspring=(offspring>repmat(xu,ll,1)).*repmat(xu,ll,1)+(offspring<=repmat(xu,ll,1)).*offspring;

offspring_fit=feval(fhd,offspring);
[off_max,off_id]=max(offspring_fit);

ini_pop(agent_id,1:n+1)=[offspring(off_id,1:n) off_max];