% clear all;
% clc;
% load bounds;
position=[];
value=[];
iteration=[];
num_FES=[];
Error=[];

func_num=3; % problem
    fprintf('Problem =\t %d\n',func_num);
    for j=1:5 % runs
        fprintf('run =\t %d\n',j)
        [position(j,:), value(j),iteration(j),num_FES(j),Error(j)]=EPSO(40,10,7500,300000,func_num);      
    end 
    
% load Bounds;
% for i=1:25 % problem
%     fprintf('Problem =\t %d\n',i);
%     for j=1 % runs
%         fprintf('run =\t %d\n',j);
%         [position(i,j,:), value(i,j),iteration(i,j),num_FES(i,j),result(i,j,:),Error(i,j)]=EPSO(20,Bounds(i,:),10,5000,100000,i);      
% %       [position,value,iteration,max_FES,result,Error]= EPSO(num_particle,range,dimension,max_iteration,max_FES,func_num)
%     end 
%     file_name= [ 'EPSO_',num2str(i),'_10D.mat'];
%     save (file_name);
% end    