function [position,value,iteration,num_FES]= PSO(Particle_Number,Dimension,Max_Gen,Max_FES,func_num)


range=[-100,100];

% result_data=zeros(1,Max_FES);
% result=zeros(1,Particle_Number); % Initial fitness values
% check_vel=[];

VRmin=range(1);
VRmax=range(2);

% rand('state',sum(100*clock));
me=Max_Gen;
ps=Particle_Number;
D=Dimension;
cc=[2 2];   %acceleration constants
iwt=0.9-(1:me).*(0.5./me);
% iwt=0.5.*ones(1,me);
if length(VRmin)==1
    VRmin=repmat(VRmin,1,D);
    VRmax=repmat(VRmax,1,D);
end
mv=0.5*(VRmax-VRmin);
VRmin=repmat(VRmin,ps,1);
VRmax=repmat(VRmax,ps,1);
Vmin=repmat(-mv,ps,1);
Vmax=-Vmin;
pos=VRmin+(VRmax-VRmin).*rand(ps,D);

% for i=1:ps;
% e(i,1)=feval(fhd,pos(i,:),varargin{:});
% end

fitcount=0;
% for i=1:ps
result=benchmark_func_org(pos,func_num);
fitcount=fitcount+ps;
%      result_data(fitcount)=result(i);
% end

vel=Vmin+2.*Vmax.*rand(ps,D);%initialize the velocity of the particles
pbest=pos;
pbestval=result; %initialize the pbest and the pbest's fitness value
[gbestval,gbestid]=min(pbestval);
gbest=pbest(gbestid,:);%initialize the gbest and the gbest's fitness value
gbestrep=repmat(gbest,ps,1);
g_res(1)=gbestval;

tmp1=abs(repmat(gbest,ps,1)-pos)+abs(pbest-pos);
temp1=ones(ps,1);
temp2=ones(ps,1);

for kkk=1:D
    temp1=temp1.*tmp1(:,kkk);
    temp2=temp2.*(max(pbest(:,kkk))-min(pbest(:,kkk)));
end
R1(1)=mean(temp1);
R2(1)=mean(temp2);

i=1;
% temp_pos=[];

while i<=me 
    
    i=i+1;
    
    for k=1:ps

        aa(k,:)=cc(1).*rand(1,D).*(pbest(k,:)-pos(k,:))+cc(2).*rand(1,D).*(gbestrep(k,:)-pos(k,:));
        vel(k,:)=iwt(i).*vel(k,:)+aa(k,:); 
        vel(k,:)=(vel(k,:)>mv).*mv+(vel(k,:)<=mv).*vel(k,:); 
        vel(k,:)=(vel(k,:)<(-mv)).*(-mv)+(vel(k,:)>=(-mv)).*vel(k,:);
        pos(k,:)=pos(k,:)+vel(k,:); 
        pos(k,:)=((pos(k,:)>=VRmin(1,:))&(pos(k,:)<=VRmax(1,:))).*pos(k,:)...
                    +(pos(k,:)<VRmin(1,:)).*(VRmin(1,:)+0.25.*(VRmax(1,:)-VRmin(1,:)).*rand(1,D))+(pos(k,:)>VRmax(1,:)).*(VRmax(1,:)-0.25.*(VRmax(1,:)-VRmin(1,:)).*rand(1,D));
     if (sum(pos(k,:)>VRmax(k,:))+sum(pos(k,:)<VRmin(k,:)))==0;
        result(k)=benchmark_func_org(pos(k,:),func_num);
        fitcount=fitcount+1;
%         result_data(fitcount)=result(k);
        if fitcount>=Max_FES
            break;
        end
        tmp=(pbestval(k)<result(k));
        temp=repmat(tmp,1,D);
        pbest(k,:)=temp.*pbest(k,:)+(1-temp).*pos(k,:);
        pbestval(k)=tmp.*pbestval(k)+(1-tmp).*result(k);%update the pbest
        if pbestval(k)<gbestval
            gbest=pbest(k,:);
            gbestval=pbestval(k);
            gbestrep=repmat(gbest,ps,1);%update the gbest
        end
     end
    end

    tmp1=abs(repmat(gbest,ps,1)-pos)+abs(pbest-pos);
    temp1=ones(ps,1);
    temp2=ones(ps,1);

    for kkk=1:D
        temp1=temp1.*tmp1(:,kkk);
        temp2=temp2.*(max(pbest(:,kkk))-min(pbest(:,kkk)));
    end
    
    R1(i)=mean(temp1);
    R2(i)=mean(temp2);
    
    if fitcount>=Max_FES
        break;
    end
    if (i==me)&&(fitcount<Max_FES)
        i=i-1;
    end
end

position=gbest;
value=gbestval;
iteration=i;
num_FES=fitcount;
end


