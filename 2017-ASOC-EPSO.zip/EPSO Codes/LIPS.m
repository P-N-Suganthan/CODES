function [position,value,iteration,max_FES]= LIPS(num_particle,dimension,max_iteration,max_FES,func_num) 



range=[-100,100];

% acc=[2.05 2.05]; % acceleration coefficients
weight=0.729843788;% weight
% nsize=[2,5]; % neightborhood size

range_min=range(1)*ones(num_particle,dimension); % position range
range_max=range(2)*ones(num_particle,dimension);
interval = range_max-range_min;
v_max=interval*0.5; % velocity range
v_min=-v_max;

pos = range_min+ interval.*rand(num_particle,dimension);    % Initial position
vel = v_min+(v_max-v_min).*rand(num_particle,dimension); % Initial velocity

fitcount=0;
result=benchmark_func_org(pos,func_num);
fitcount=fitcount+num_particle;

[gbest_val,g_index]=min(result); % Initialize global best position
gbest_pos=pos(g_index,:);
pbest_pos=pos; % Initialize pbest position
pbest_val=result;
% nbest=pos; % Initialize neighborhood best position
% nbestval=result; 
k=0; 
nsize=3;


while k<max_iteration && fitcount<=max_FES
    
    k=k+1;
    
    
for i=1:num_particle
    
    % generating distance-based locally informed guidance vector for each particle
    EU_dist=dist(pbest_pos(i,:),pbest_pos'); 
    EU_dist(i)=max(EU_dist);
    [min_dist,min_index]=sort(EU_dist);
    fai=(4.1./nsize).*rand(nsize,dimension);
    lbest_pos=(sum(fai.*pbest_pos(min_index(1:nsize),:)))./sum(fai); 
     
    delta(i,:)=(sum(fai).*(lbest_pos-pos(i,:)));
    vel(i,:)=weight.*(vel(i,:)+delta(i,:));
    vel(i,:)=((vel(i,:)<v_min(i,:)).*v_min(i,:))+((vel(i,:)>v_max(i,:)).*v_max(i,:))+(((vel(i,:)<v_max(i,:))&(vel(i,:)>v_min(i,:))).*vel(i,:));
    pos(i,:)=pos(i,:)+vel(i,:);
    pos(i,:)=((pos(i,:)>=range_min(i,:))&(pos(i,:)<=range_max(i,:))).*pos(i,:)+(pos(i,:)<range_min(i,:)).*(range_min(i,:)+0.25.*(range_max(i,:)-range_min(i,:)).*rand(1,dimension))+(pos(i,:)>range_max(i,:)).*(range_max(i,:)-0.25.*(range_max(i,:)-range_min(i,:)).*rand(1,dimension));
    
end 

        for i=1:num_particle  % Evaluate Fitness
            if (sum(pos(i,:)>range_max(i,:))+sum(pos(i,:)<range_min(i,:))==0)% check if new position is within range
                result(i)=benchmark_func_org(pos(i,:),func_num); % Evaluate fitness
                fitcount=fitcount+1;
%                 result_data(fitcount)=result(i);
                if fitcount>=max_FES
                   break;
                end
            end
            if  result(i)<pbest_val(i) % update pbest value and position
                pbest_pos(i,:)=pos(i,:);   
                pbest_val(i)=result(i);
            end
            
            if  pbest_val(i)<gbest_val; % update gbest value and postion
                gbest_pos=pbest_pos(i,:); 
                gbest_val=pbest_val(i);
            end   
         end 

if fitcount>=max_FES
   break;
end 
if (k==max_iteration)&&(fitcount<max_FES)
    k=k-1;
end
end

position=gbest_pos;
value=gbest_val;
iteration=k;
max_FES=fitcount;
 end

