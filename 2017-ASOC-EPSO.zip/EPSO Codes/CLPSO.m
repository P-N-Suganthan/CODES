 function  [position,value,iteration,num_FES]= CLPSO(Particle_Number,Dimension,Max_Gen,Max_FES,func_num)

 
range=[-100,100];

% result_data=zeros(1,Max_FES);
result=zeros(1,Particle_Number); % Initial fitness values
% check_vel=[];


rand('state',sum(100*clock));
me=Max_Gen;
ps=Particle_Number;
D=Dimension;
% cc=[1 1];   %acceleration constants
t=0:1/(ps-1):1;t=10.*t;
Pc=0.0+(0.5-0.0).*(exp(t)-exp(t(1)))./(exp(t(ps))-exp(t(1)));
% Pc=0.5.*ones(1,ps);
m=0.*ones(ps,1);
iwt=0.9-(1:me)*(0.7/me);
% iwt=0.729-(1:me)*(0.0/me);
cc=[1.49445 1.49445]; 

VRmin=range(1);
VRmax=range(2);

if length(VRmin)==1
    VRmin=repmat(VRmin,1,D);
    VRmax=repmat(VRmax,1,D);
end

mv=0.2*(VRmax-VRmin);
VRmin=repmat(VRmin,ps,1);
VRmax=repmat(VRmax,ps,1);
Vmin=repmat(-mv,ps,1);
Vmax=-Vmin;
pos=VRmin+(VRmax-VRmin).*rand(ps,D);
fitcount=0;
for i=1:ps;
    result(i)=benchmark_func_org(pos(i,:),func_num);
    fitcount=fitcount+1;
%     result_data(fitcount)=result(i);
end

vel=Vmin+2.*Vmax.*rand(ps,D);%initialize the velocity of the particles
pbest=pos;
pbestval=result'; %initialize the pbest and the pbest's fitness value
[gbestval,gbestid]=min(pbestval);
gbest=pbest(gbestid,:);%initialize the gbest and the gbest's fitness value
gbestrep=repmat(gbest,ps,1);

stay_num=zeros(ps,1); 

    ai=zeros(ps,D);% omit for gbest
    f_pbest=1:ps;f_pbest=repmat(f_pbest',1,D);
    for k=1:ps       
        ar=randperm(D); % omit for gbest
        ai(k,ar(1:m(k)))=1; % omit for gbest
        fi1=ceil(ps*rand(1,D));
        fi2=ceil(ps*rand(1,D));
        fi=(pbestval(fi1)<pbestval(fi2))'.*fi1+(pbestval(fi1)>=pbestval(fi2))'.*fi2;
        bi=ceil(rand(1,D)-1+Pc(k));
        if bi==zeros(1,D),rc=randperm(D);bi(rc(1))=1;end
        f_pbest(k,:)=bi.*fi+(1-bi).*f_pbest(k,:);
   end

    i=0;

while i<me
     i=i+1;
     
 for k=1:ps
        
    if stay_num(k)>=5
        stay_num(k)=0;
        ai(k,:)=zeros(1,D);% omit for gbest
        f_pbest(k,:)=k.*ones(1,D); 
        ar=randperm(D);% omit for gbest
        ai(k,ar(1:m(k)))=1; % omit for gbest
        fi1=ceil(ps*rand(1,D));
        fi2=ceil(ps*rand(1,D));
        fi=(pbestval(fi1)<pbestval(fi2))'.*fi1+(pbestval(fi1)>=pbestval(fi2))'.*fi2;
        bi=ceil(rand(1,D)-1+Pc(k));
        if bi==zeros(1,D),rc=randperm(D);bi(rc(1))=1;end
        f_pbest(k,:)=bi.*fi+(1-bi).*f_pbest(k,:);
    end
    
    for dimcnt=1:D
        pbest_f(k,dimcnt)=pbest(f_pbest(k,dimcnt),dimcnt);
    end
    
    
 %  aa(k,:)=cc(1).*rand(1,D).*(pbest_f(k,:)-pos(k,:))+cc(2).*rand(1,D).*(gbestrep(k,:)-pos(k,:));%~~~~~~~~~~~~~~~~~~~~~~
    aa(k,:)=cc(1).*(1-ai(k,:)).*rand(1,D).*(pbest_f(k,:)-pos(k,:))+cc(2).*ai(k,:).*rand(1,D).*(gbestrep(k,:)-pos(k,:));%~~~~~~~~~~~~~~~~~~~~~~
    vel(k,:)=iwt(i).*vel(k,:)+aa(k,:); 
    vel(k,:)=(vel(k,:)>mv).*mv+(vel(k,:)<=mv).*vel(k,:); 
    vel(k,:)=(vel(k,:)<(-mv)).*(-mv)+(vel(k,:)>=(-mv)).*vel(k,:);
    pos(k,:)=pos(k,:)+vel(k,:);
       
      
    if (sum(pos(k,:)>VRmax(k,:))+sum(pos(k,:)<VRmin(k,:)))==0;
        result(k)=benchmark_func_org(pos(k,:),func_num);
        fitcount=fitcount+1;
%         result_data(fitcount)=result(k);
        if fitcount>=Max_FES
            break;
        end
   
        tmp=(pbestval(k)<=result(k));
        if tmp==1
            stay_num(k)=stay_num(k)+1;
        end
        temp=repmat(tmp,1,D);
        pbest(k,:)=temp.*pbest(k,:)+(1-temp).*pos(k,:);
        pbestval(k)=tmp.*pbestval(k)+(1-tmp).*result(k);%update the pbest
        if pbestval(k)<gbestval
           gbest=pbest(k,:);
           gbestval=pbestval(k);
           gbestrep=repmat(gbest,ps,1);%update the gbest
        end
    end
     
 end

if fitcount>=Max_FES
    break;
end
if (i==me)&(fitcount<Max_FES)
    i=i-1;
end
end

position=gbest;
value=gbestval;
iteration=i;
num_FES=fitcount;
end



