clear all;

% load D:\SaDE\SaDE\SaDE_CR2\SADECR2_50gen
% load F:\SaDEJounalResults\TEC10\Adjustlearningperiod\SADECR2_30gen.mat
% load D:\SaDEResult200702\Yaofunctions\Rand1F9CR9\Rand1f9CR920070702.mat
f_n=[1 2 3 5 6 7 8 9 10 11 12 13 14 16];
D=10;
flag_no=1;
numst=4;
F=0;
F_m=0;
F_std=1;
CR=0.9;

for func_num=f_n;
    global initial_flag gbestval_hist
    
    %     path(path,'G:\test function matlab files');
    %     fbias=[-4.5000000e+002 -4.5000000e+002 -4.5000000e+002 -4.5000000e+002 -3.1000000e+002...
    %              3.9000000e+002 -1.8000000e+002 -1.4000000e+002 -3.3000000e+002 -3.3000000e+002...
    %              9.0000000e+001 -4.6000000e+002 -1.3000000e+002 -3.0000000e+002  1.2000000e+002...
    %              1.2000000e+002  1.2000000e+002  1.0000000e+001  1.0000000e+001  1.0000000e+001...
    %              3.6000000e+002  3.6000000e+002  3.6000000e+002  2.6000000e+002  2.6000000e+002];
    path(path,'D:\SADEcodes\SADE_TEC');
    fbias=[zeros(1,22) 0.0003075 -1.0316285 0.398 -3.86 -3.32 -10.2];
    
    if D==10
        NP=50;
        Max_Gen=2000;
        Max_FES=100000;        
    else
        NP=50;     
        Max_Gen=10000;
        Max_FES=500000;
    end
    
    runs=30;    
    initial_flag=0;
    
    for iternum=1:30              
        gbestval_hist=[];
        [DE_gbest,DE_gbestval,DE_fitcount,DE_fit_cut,DE_get_flag,ccmhist,pfithist,varfhist] = runcompe(D,func_num,...
            iternum,NP,Max_Gen,Max_FES,flag_no,F,CR,numst);
        %         T1_res(func_num)=T1;
        %         T2_res(func_num)=T2;
        DE_gbestval_hist= gbestval_hist;        
        [func_num,iternum,DE_get_flag]
        DE_gbestval
        [DE_fitcount,DE_fit_cut]        
        
        %         eval(['save F:\SaDEJounalResults\TEC10\Adjustlearningperiod\SADECR2_60gen' int2str(func_num) '_' int2str(i) ' DE_gbest DE_gbestval_hist ccmhist pfithist;']);
        %                 eval(['save E:\HuangLing\SaDEJounalResults\Rand1_CR\10D\' int2str(func_num) '_' int2str(iternum) ' DE_gbest DE_gbestval_hist ccmhist pfithist;']);
        %         eval(['save E:\HuangLing\SaDEJounalResults\jDE\new10D\' int2str(func_num) '_' int2str(iternum) ' DE_gbest DE_gbestval_hist ccmhist pfithist;']);
        %         eval(['save E:\HuangLing\SaDEJounalResults\newSADE1108\new30D\' int2str(func_num) '_' int2str(iternum) ' DE_gbest DE_gbestval_hist ccmhist pfithist;']);
        %         eval(['save F:\SaDEJounalResults\TEC30\DE_rand1CR9_30D\rand1CR9_' int2str(func_num) '_' int2str(iternum) ' DE_gbest DE_gbestval_hist ccmhist pfithist;']);
        %         eval(['save E:\HuangLing\SaDEJounalResults\newSADE_LP\40G\' int2str(func_num) '_' int2str(iternum) ' DE_gbest DE_gbestval_hist ccmhist pfithist;']);
        eval(['save D:\SaDEResult200702\Yaofunctions\Rand2best1F5CR3\' int2str(func_num) '_' int2str(iternum) ' DE_gbest DE_gbestval_hist ccmhist pfithist varfhist;']);
        % %         eval(['save ' dirname int2str(func_num) '_' int2str(iternum) ' DE_gbest DE_gbestval_hist ccmhist pfithist;']);
        %         
        DE_gbestval_res(func_num,iternum)=DE_gbestval;
        DE_fit_cut_res(func_num,iternum)=DE_fit_cut;
        DE_fitcount_res(func_num,iternum)=DE_fitcount;
        DE_get_flag_res(func_num,iternum)=DE_get_flag;
        eval(['DE_gbest_res' int2str(func_num) '(iternum,:)=DE_gbest;']);     
        clear DE_gbestval_hist ccmhist pfithist varfhist DE_gbestval;
        
        %         save D:\SaDE\SaDEJounalResults\TEC10\SADE_rand2\SADErand2_0327
        %         save F:\SaDEJounalResults\TEC10\Adjustlearningperiod\60gen0413
        %         save E:\HuangLing\SaDEJounalResults\newSADE1026\10D\20061026
        %         save E:\HuangLing\SaDEJounalResults\TEC10\DE_rand1CR9_D10\20061111
        %         save E:\HuangLing\SaDEJounalResults\newSADE1108\new30D\20070116
        %         save F:\SaDEJounalResults\TEC30\DE_rand1CR9_30D\CR9_20061113
        %         save E:\HuangLing\SaDEJounalResults\jDE\new10D\jDE_20061112
        %         save E:\HuangLing\SaDEJounalResults\newSADE_LP\40G\newSaDE40g_20061116
        %     save F:\SaDE\SaDEJounalResults\TEC10\SADE_rand2\SADErand2_0327   
        %     eval(['save D:\SaDE\SaDE\SaDE_CR2_L2\50g DE_gbestval_res DE_fit_cut_res DE_fitcount_res DE_get_flag_res func_num DE_gbest_res' int2str(func_num)]);
        %eval(['load ' dirname int2str(20070205) ';'])
        %         eval(['save ' dirname int2str(20070303) ';'])
        save D:\SaDEResult200702\Yaofunctions\Rand2best1F5CR3\Rand2best1F5CR3_20070708
        %         save D:\SaDEResult200702\Yaofunctions\Zaharie_DE\ZaharieDE20070601
    end
end