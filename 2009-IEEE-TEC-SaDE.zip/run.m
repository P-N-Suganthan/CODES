% clear all;


for func_num=1;
    global initial_flag gbestval_hist
    
    %     path(path,'G:\test function matlab files');
    %     fbias=[-4.5000000e+002 -4.5000000e+002 -4.5000000e+002 -4.5000000e+002 -3.1000000e+002...
    %              3.9000000e+002 -1.8000000e+002 -1.4000000e+002 -3.3000000e+002 -3.3000000e+002...
    %              9.0000000e+001 -4.6000000e+002 -1.3000000e+002 -3.0000000e+002  1.2000000e+002...
    %              1.2000000e+002  1.2000000e+002  1.0000000e+001  1.0000000e+001  1.0000000e+001...
    %              3.6000000e+002  3.6000000e+002  3.6000000e+002  2.6000000e+002  2.6000000e+002];
    

    
    path(path,'E:\HuangLing\SADE_TEC');
    fbias=zeros(1,16);
    
    D=10;
    NP=50;
    Max_Gen=2000;
    Max_FES=100000;
    runs=5;
    initial_flag=0;
    
%         D=30;
%         NP=100;
%         Max_Gen=6000;
%         Max_FES=300000;
%         runs=30;
%         initial_flag=0;
    
    for i=1
        gbestval_hist=[];
        [DE_gbest,DE_gbestval,DE_fitcount,DE_fit_cut,DE_get_flag,ccmhist,pfithist] = runcompe(D,func_num,runs,NP,Max_Gen,Max_FES,4);
       
        DE_gbestval_hist= gbestval_hist;        
        [func_num,i,DE_get_flag]
        DE_gbestval-fbias(func_num)
        [DE_fitcount,DE_fit_cut]
        
        %   eval(['save D:\SaDE2result\10D\' int2str(func_num) '_' int2str(i) ' DE_gbest DE_gbestval_hist ccmhist pfithist;']);
        
        
        DE_gbestval_res(func_num,i)=DE_gbestval;
        DE_fit_cut_res(func_num,i)=DE_fit_cut;
        DE_fitcount_res(func_num,i)=DE_fitcount;
        DE_get_flag_res(func_num,i)=DE_get_flag;
        eval(['DE_gbest_res' int2str(func_num) '(i,:)=DE_gbest;']);     
        clear DE_gbestval_hist ccmhist pfithist DE_gbestval;
        
       
        %   save F:\SaDE\SaDEJounalResults\TEC10\SADE_rand2\SADErand2_0327   
       
    end
end