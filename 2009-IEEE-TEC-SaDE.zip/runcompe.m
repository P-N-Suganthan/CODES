function [DE_gbest,DE_gbestval,DE_fitcount,DE_fit_cut,DE_get_flag,ccmhist,pfithist,varfhist] = runcompe(D,fun,...
    iternum,NP,Max_Gen,Max_FES,flag_no,F,CR,numst)
T1=0;
T2=0;
varfhist=0;
% afile = 'SIS_novel_func';
% afile = 'benchmark_func';
 afile = 'DE_benchmark_func';
% afile = 'Aly_benchmark_func'


if strcmp(afile,'Aly_benchmark_func')
end
if strcmp(afile,'benchmark_func')
    if fun == 1 | fun==2 | fun==3 | fun==4
        XRmin = -100*ones(1,D); 
        XRmax = 100*ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;
        VTR = -450 + 10^(-5);
    end
    if fun == 5
        XRmin = -100*ones(1,D); 
        XRmax = 100*ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;
        VTR = -310 + 10^(-5);
    end
    if fun == 6
        XRmin = -2*ones(1,D); 
        XRmax = 2*ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;
        VTR = 390 + 10^(-5);
    end
    
    if fun == 7
        XRmin = 0*ones(1,D); 
        XRmax = 600*ones(1,D); 
        Lbound = -Inf*ones(1,D);
        Ubound = Inf*ones(1,D); 
        VTR = -180 + 10^(-2);
    end
    
    if fun == 8
        XRmin = -32*ones(1,D); 
        XRmax = 32*ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;
        VTR = -140 + 10^(-2);
    end
    if fun == 9 | fun==10
        XRmin = -5*ones(1,D); 
        XRmax = 5*ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;
        VTR = -330 + 10^(-2);
    end
    if fun == 11
        XRmin = -0.5*ones(1,D); 
        XRmax = 0.5*ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;
        VTR = 90 + 10^(-2);
    end
    if fun == 12
        XRmin = -100*ones(1,D); 
        XRmax = 100*ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;
        VTR = -460 + 10^(-2);
    end
    if fun == 13
        XRmin = -3*ones(1,D); 
        XRmax = 1*ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;
        VTR = -130 + 10^(-2);
    end
    if fun == 14
        XRmin = -100*ones(1,D); 
        XRmax = 100*ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;
        VTR = -300 + 10^(-2);
    end
    if fun==15 | fun==16
        XRmin = -5*ones(1,D); 
        XRmax = 5*ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;   
        VTR = 120 + 10^(-2);
    end
    if fun==17
        XRmin = -5*ones(1,D); 
        XRmax = 5*ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;   
        VTR = 120 + 10^(-1);
    end
    if fun==18 | fun==19 | fun==20
        XRmin = -5*ones(1,D); 
        XRmax = 5*ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;   
        VTR = 10 + 10^(-1);
    end
    if fun==21 | fun==22 | fun==23
        XRmin = -5*ones(1,D); 
        XRmax = 5*ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;    
        VTR = 360 + 10^(-1);
    end
    if fun==24
        XRmin = -5*ones(1,D); 
        XRmax = 5*ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;    
        VTR = 260 + 10^(-1);
    end
    if fun == 25
        XRmin = -2*ones(1,D); 
        XRmax = 5*ones(1,D); 
        Lbound = -Inf*ones(1,D);
        Ubound = Inf*ones(1,D); 
        VTR = 260 + 10^(-1);
    end 
end

if strcmp(afile,'SIS_novel_func')
    if fun == 1 | fun==2 | fun==3 | fun==4 | fun==5 | fun==6
        XRmin = -5*ones(1,D); 
        XRmax = 5*ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;
        VTR = 0 + 10^(-6);
    end
end

if strcmp(afile,'DE_benchmark_func')
    if fun == 1 | fun == 2 | fun == 3 |fun == 4 | fun==20
        XRmin = -100*ones(1,D); 
        XRmax = 100*ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;
        VTR = 10^(-5);
    end  
    if fun == 5 | fun == 6
        XRmin = -32*ones(1,D); 
        XRmax = 32*ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;
        VTR = 10^(-5);
    end
    if fun == 7 | fun == 8
        XRmin = 0*ones(1,D); 
        XRmax = 600*ones(1,D); 
        Lbound = -Inf*ones(1,D);
        Ubound = Inf*ones(1,D); 
        VTR = 10^(-5);
    end
    if fun == 9 | fun==10 | fun == 11 | fun==14 | fun == 15 | fun==16 
        XRmin = -5*ones(1,D); 
        XRmax = 5*ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;
        VTR = 10^(-5);
    end
    if fun==12 | fun == 13 
        XRmin = -500*ones(1,D); 
        XRmax = 500*ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;
        VTR = 10^(-5);
    end
      if fun==18 %11 in cec05
        XRmin = -pi*ones(1,D); 
        XRmax = pi*ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;
        VTR = 10^(-5);
    end
      if fun==17 %12 
        XRmin = -0.5*ones(1,D); 
        XRmax = 0.5*ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;
        VTR = 10^(-5);
    end
       if fun==19 %
        XRmin = -10*ones(1,D); 
        XRmax = 10*ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;
        VTR = 10^(-5);
    end
       if fun==21 | fun==22 
        XRmin = -50*ones(1,D); 
        XRmax = 50*ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;
        VTR = 10^(-5);
    end
    if fun==23 
        D=4;
        XRmin = -5*ones(1,D); 
        XRmax = 5*ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;
        VTR = 0.0003075 + 10^(-5);
    end
    if fun==24 
        D=2;
        XRmin = -5*ones(1,D); 
        XRmax = 5*ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;
        VTR = -1.0316285 + 10^(-5);
    end
     if fun==25 %
         D=2;
        XRmin = [-5 0]; 
        XRmax = [10 15]; 
        Lbound = XRmin;
        Ubound = XRmax;
        VTR = 0.398 + 10^(-5);
    end
    if fun==26 %
        D=3;
        XRmin = zeros(1,D); 
        XRmax = ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;
        VTR = -3.86+10^(-5);
    end    
    if fun==27 %
        D=6;
        XRmin = zeros(1,D); 
        XRmax = ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;
        VTR = -3.32+10^(-5);
    end 
     if fun==28 %
         D=4;
        XRmin = zeros(1,D); 
        XRmax = 10*ones(1,D); 
        Lbound = XRmin;
        Ubound = XRmax;
        VTR = -10+10^(-5);
    end 
end

global initial_flag;
initial_flag=0;
if flag_no==0
    for i=1:10000
        temp(i,:)=XRmin+(XRmax-XRmin).*rand(1,D);
    end
    tic
    for i=1:10000    
        tempval = feval(afile,temp(i,:),fun);
    end
    T1=toc;
    DE_gbest=[];
    DE_gbestval=[];
    DE_fitcount=[];
    DE_fit_cut=[];
    DE_get_flag=[];
    ccmhist=[];
    pfithist=[];
end

if flag_no == 1
    strategy = 9; 
    F=0.5;CR=0.3;
%     tic
    [DE_gbest,DE_gbestval,DE_fitcount,DE_fit_cut,DE_get_flag] = dealgorithmorigincompe(afile,...
        VTR,Max_FES,D,XRmin,XRmax,Lbound,Ubound,NP,Max_Gen,F,CR,strategy,fun);
%     T2=toc;
    ccmhist=0;pfithist=0;
end


if flag_no == 4
    strategy = 2;
%     tic
    [DE_gbest,DE_gbestval,DE_fitcount,DE_fit_cut,DE_get_flag,ccmhist,pfithist] = SaDE(afile,...
        VTR,Max_FES,D,XRmin,XRmax,Lbound,Ubound,NP,Max_Gen,0.5,0.5,strategy,numst,fun);
%     T2=toc;
end

if flag_no == 6
    strategy = 8;
    [DE_gbest,DE_gbestval,DE_fitcount,DE_fit_cut,DE_get_flag,ccmhist,pfithist] = SDE(afile,...
    VTR,Max_FES,D,XRmin,XRmax,Lbound,Ubound,NP,Max_Gen,0.5,0.5,strategy,fun);
end

if flag_no == 7
    strategy = 8; 
    [DE_gbest,DE_gbestval,DE_fitcount,DE_fit_cut,DE_get_flag] =newjDE2(afile,...
        VTR,Max_FES,D,XRmin,XRmax,Lbound,Ubound,NP,Max_Gen,F,CR,strategy,fun);
    ccmhist=0;pfithist=0;
end

if flag_no == 8 % Zaharie Aaptive DE
    lamda=0;gamma=1;
    [DE_gbest,DE_gbestval,DE_fitcount,DE_fit_cut,DE_get_flag,ccmhist,pfithist,varfhist] = DE_Zaharie(afile,...
        VTR,Max_FES,D,XRmin,XRmax,Lbound,Ubound,NP,Max_Gen,lamda,gamma,fun);
end





