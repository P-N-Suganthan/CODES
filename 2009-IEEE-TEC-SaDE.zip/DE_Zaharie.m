function [DE_gbest,DE_gbestval,DE_fitcount,DE_fit_cut,DE_get_flag,CRhist,Fhist,varfhist]  = DE_Zaharie(fname,VTR,...
    Max_FES,D,XRmin,XRmax,Lbound,Ubound,NP,Max_Gen,lamda,gamma,state_no,fun); 

DE_get_flag = 0;
DE_fit_cut = Max_FES;

Fmin=repmat(1/sqrt(NP),1,D);
Fmax=2*ones(1,D);
CRmin=0.1*ones(1,D); CRmax=ones(1,D);
F=0.5*ones(1,D); CR=0.5*ones(1,D);

%-----Initialize population and some arrays-------------------------------

pop = zeros(NP,D); %initialize pop to gain speed

%----pop is a matrix of size NPxD. It will be initialized-------------
%----with random values between the min and max values of the---------
%----parameters-------------------------------------------------------
rand('state',state_no);
for i=1:NP
    pop(i,:)=XRmin+(XRmax-XRmin).*rand(1,D);
end

popold    = zeros(size(pop));     % toggle population
val       = zeros(1,NP);          % create and reset the "cost array"
DE_gbest   = zeros(1,D);           % best population member ever
nfeval    = 0;                    % number of function evaluations

%------Evaluate the best member after initialization----------------------

ibest   = 1;                      % start with first population member
val(1)  = feval(fname,pop(ibest,:),fun); 
DE_gbestval = val(1);                 % best objective function value so far
nfeval  = nfeval + 1;
for i=2:NP                        % check the remaining members
    val(i) = feval(fname,pop(i,:),fun); 
    nfeval  = nfeval + 1;
    if (val(i) < DE_gbestval)           % if member is better
        ibest   = i;                 % save its location
        DE_gbestval = val(i);
    end   
end
DE_gbest = pop(ibest,:);         % best member of current iteration
bestvalit = DE_gbestval;              % best value of current iteration
varx=var(pop);
varf=var(val);
varfhist=[varf];
Fhist=[F];
CRhist=[CR];
%------DE-Minimization---------------------------------------------
%------popold is the population which has to compete. It is--------
%------static through one iteration. pop is the newly--------------
%------emerging population.----------------------------------------

pm1 = zeros(NP,D);              % initialize population matrix 1
pm2 = zeros(NP,D);              % initialize population matrix 2
pm3 = zeros(NP,D);              % initialize population matrix 3
pm4 = zeros(NP,D);              % initialize population matrix 4
pm5 = zeros(NP,D);              % initialize population matrix 5
bm  = zeros(NP,D);              % initialize bestmember  matrix
ui  = zeros(NP,D);              % intermediate population of perturbed vectors
mui = zeros(NP,D);              % mask for intermediate population
mpo = zeros(NP,D);              % mask for old population
rot = (0:1:NP-1);               % rotating index array (size NP)
rotd= (0:1:D-1);                % rotating index array (size D)
rt  = zeros(NP);                % another rotating index array
rtd = zeros(D);                 % rotating index array for exponential crossover
a1  = zeros(NP);                % index array
a2  = zeros(NP);                % index array
a3  = zeros(NP);                % index array
a4  = zeros(NP);                % index array
a5  = zeros(NP);                % index array
ind = zeros(4);

iter = 0;
while iter < Max_Gen-1
    popold = pop;                   % save the old population
    varxold=varx;
    ind = randperm(4);              % index pointer array
    
    a1  = randperm(NP);             % shuffle locations of vectors
    rt = rem(rot+ind(1),NP);        % rotate indices by ind(1) positions
    a2  = a1(rt+1);                 % rotate vector locations
    rt = rem(rot+ind(2),NP);
    a3  = a2(rt+1);                
    rt = rem(rot+ind(3),NP);
    a4  = a3(rt+1);               
    rt = rem(rot+ind(4),NP);
    a5  = a4(rt+1);                
    
    pm1 = popold(a1,:);             % shuffled population 1
    pm2 = popold(a2,:);             % shuffled population 2
    pm3 = popold(a3,:);             % shuffled population 3
    pm4 = popold(a4,:);             % shuffled population 4
    pm5 = popold(a5,:);             % shuffled population 5
    
    for i=1:NP                      % population filled with the best member
        bm(i,:) = DE_gbest;          % of the last iteration
    end
    
    mui = rand(NP,D) < repmat(CR,NP,1);          % all random numbers < CR are 1, 0 otherwise
    %     mui=sort(mui');	          % transpose, collect 1's in each column
    %     for i=1:NP
    %         n=floor(rand*D);
    %         if n > 0
    %             rtd = rem(rotd+n,D);
    %             mui(:,i) = mui(rtd+1,i); %rotate column i by n
    %         end
    %     end
    %     mui = mui';			  % transpose back
    
    dd=ceil(D*rand(NP,1));
    for kk=1:NP
        mui(kk,dd(kk))=1;
    end
    mpo = mui < 0.5;                % inverse mask to mui
    
    ui = lamda*bm + (1-lamda)*pm1 + repmat(F,NP,1).*(pm2 - pm3);        % differential variation
    ui = popold.*mpo + ui.*mui;     % crossover
    
    %-----Select which vectors are allowed to enter the new population------------
    for i=1:NP
        %         while ~isempty(find(ui(i,:) < Lbound)) | ~isempty(find(ui(i,:) > Ubound))
        outbind=find(ui(i,:) < Lbound);
        if size(outbind,2)~=0
            %                 % Periodica
            %                 ui(i,outbind)=2*XRmin(outbind)-ui(i,outbind);
            % Random
            ui(i,outbind)=XRmin(outbind)+(XRmax(outbind)-XRmin(outbind)).*rand(1,size(outbind,2));
            %                 % Fixed
            %                 ui(i,outbind)=XRmin(outbind);
        end            
        outbind=find(ui(i,:) > Ubound);
        if size(outbind,2)~=0
            %                 % Periodica
            %                 ui(i,outbind)=2*XRmax(outbind)-ui(i,outbind);
            % Random
            ui(i,outbind)=XRmin(outbind)+(XRmax(outbind)-XRmin(outbind)).*rand(1,size(outbind,2));
            %                 % Fixed
            %                 ui(i,outbind)=XRmax(outbind);
        end
        %         end
    end
    
    for i=1:NP
        tempval = feval(fname,ui(i,:),fun);   % check cost of competitor
        nfeval  = nfeval + 1;
        if (tempval <= val(i))  % if competitor is better than value in "cost array"
            pop(i,:) = ui(i,:);  % replace old vector with new one (for new iteration)
            val(i)   = tempval;  % save value in "cost array"
            
            %----we update DE_gbestval only in case of success to save time-----------
            if (tempval < DE_gbestval)     % if competitor better than the best one ever
                DE_gbestval = tempval;      % new best value
                DE_gbest = ui(i,:);      % new best parameter vector ever
                if DE_gbestval <= VTR & DE_get_flag == 0
                    DE_fit_cut=nfeval;
                    DE_get_flag=1;
                    if DE_gbestval <= VTR-10^(-5)+10^(-30)
                        DE_fitcount = Max_FES;
                        return;
                    end
                end
            end
        end
        if nfeval+1 > Max_FES
            DE_fitcount = Max_FES;
            return;
        end
    end %---end for imember=1:NP
    iter = iter + 1;
    varx=var(pop);
    varf=var(val);
    varfhist=[varfhist,varf];
    
    for j=1:D
        if varxold(j)<1e-12
            c(j)=gamma;
        else
            c(j)=gamma*(1e+6)*varx(j)/((1e+6)*varxold(j));
        end
    end
    if rem(iter,2)==0, %adapt F
        if lamda==0
            t = (1-CR).^2./NP + (NP-1)/NP;
        else
            t = (1-CR).^2/NP + (NP-1)/NP*(CR*(1-lamda)^2 + 1-CR + K*CR*lamda*lamda*(1-CR));
        end
        F = (c<t).*Fmin + (c>=t).*sqrt((c-t)./2*NP);               
        F = (F<Fmin).*Fmin + (F>=Fmin).*F;
        F = (F>Fmax).*Fmax + (F<=Fmax).*F;
        
    else % adapt CR
        if lamda==0,
            t=(1-NP*F.^2).^2 + NP*(c-1);
            CR=(t<0).*CRmin+(t>=0).*(1-NP*F.^2 + sqrt(t));  
        else
            t=(1-NP*F.^2).^2 + NP*(c-1)*(NP-2);
            CR=(t<0).*CRmin+(t>=0).*((NP*F.^2-1 + sqrt(t))/(NP-2));  
        end
        CR= (CR<CRmin).*CRmin + (CR>=CRmin).*CR;
        CR= (CR>CRmax).*CRmax + (CR<=CRmax).*CR;
    end
    Fhist=[Fhist;F];
    CRhist=[CRhist;CR];
    
    if rem(iter,500) == 0
        nfeval
        DE_gbestval
    end
end %---end while ((iter < Max_Gen) ...
