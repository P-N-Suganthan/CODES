function [DE_gbest,DE_gbestval,DE_fitcount,DE_fit_cut,DE_get_flag]  = dealgorithmorigincompe(fname,VTR,Max_FES,D,XRmin,XRmax,Lbound,Ubound,NP,Max_Gen,F,CR,strategy,fun); 

DE_get_flag = 0;
DE_fit_cut = Max_FES;

%-----Initialize population and some arrays-------------------------------

pop = zeros(NP,D); %initialize pop to gain speed

%----pop is a matrix of size NPxD. It will be initialized-------------
%----with random values between the min and max values of the---------
%----parameters-------------------------------------------------------

for i=1:NP
    pop(i,:)=XRmin+(XRmax-XRmin).*rand(1,D);
end

popold    = zeros(size(pop));     % toggle population
val       = zeros(1,NP);          % create and reset the "cost array"
DE_gbest   = zeros(1,D);           % best population member ever
nfeval    = 0;                    % number of function evaluations

%------Evaluate the best member after initialization----------------------

ibest   = 1;                      % start with first population member
val(1)  = feval(fname,pop(ibest,:),fun); 
DE_gbestval = val(1);                 % best objective function value so far
nfeval  = nfeval + 1;
for i=2:NP                        % check the remaining members
    val(i) = feval(fname,pop(i,:),fun); 
    nfeval  = nfeval + 1;
    if (val(i) < DE_gbestval)           % if member is better
        ibest   = i;                 % save its location
        DE_gbestval = val(i);
    end   
end
DE_gbest = pop(ibest,:);         % best member of current iteration
bestvalit = DE_gbestval;              % best value of current iteration

%------DE-Minimization---------------------------------------------
%------popold is the population which has to compete. It is--------
%------static through one iteration. pop is the newly--------------
%------emerging population.----------------------------------------

pm1 = zeros(NP,D);              % initialize population matrix 1
pm2 = zeros(NP,D);              % initialize population matrix 2
pm3 = zeros(NP,D);              % initialize population matrix 3
pm4 = zeros(NP,D);              % initialize population matrix 4
pm5 = zeros(NP,D);              % initialize population matrix 5
bm  = zeros(NP,D);              % initialize bestmember  matrix
ui  = zeros(NP,D);              % intermediate population of perturbed vectors
mui = zeros(NP,D);              % mask for intermediate population
mpo = zeros(NP,D);              % mask for old population
rot = (0:1:NP-1);               % rotating index array (size NP)
rotd= (0:1:D-1);                % rotating index array (size D)
rt  = zeros(NP);                % another rotating index array
rtd = zeros(D);                 % rotating index array for exponential crossover
a1  = zeros(NP);                % index array
a2  = zeros(NP);                % index array
a3  = zeros(NP);                % index array
a4  = zeros(NP);                % index array
a5  = zeros(NP);                % index array
ind = zeros(4);

iter = 0;
while iter < Max_Gen-1
    popold = pop;                   % save the old population
    
    ind = randperm(4);              % index pointer array
    
    a1  = randperm(NP);             % shuffle locations of vectors
    rt = rem(rot+ind(1),NP);        % rotate indices by ind(1) positions
    a2  = a1(rt+1);                 % rotate vector locations
    rt = rem(rot+ind(2),NP);
    a3  = a2(rt+1);                
    rt = rem(rot+ind(3),NP);
    a4  = a3(rt+1);               
    rt = rem(rot+ind(4),NP);
    a5  = a4(rt+1);                
    
    pm1 = popold(a1,:);             % shuffled population 1
    pm2 = popold(a2,:);             % shuffled population 2
    pm3 = popold(a3,:);             % shuffled population 3
    pm4 = popold(a4,:);             % shuffled population 4
    pm5 = popold(a5,:);             % shuffled population 5
    
    for i=1:NP                      % population filled with the best member
        bm(i,:) = DE_gbest;          % of the last iteration
    end
    
    mui = rand(NP,D) < CR;          % all random numbers < CR are 1, 0 otherwise
    
    if (strategy > 5)
        st = strategy-5;		  % binomial crossover
    else
        st = strategy;		  % exponential crossover
        mui=sort(mui');	          % transpose, collect 1's in each column
        for i=1:NP
            n=floor(rand*D);
            if n > 0
                rtd = rem(rotd+n,D);
                mui(:,i) = mui(rtd+1,i); %rotate column i by n
            end
        end
        mui = mui';			  % transpose back
    end
    dd=ceil(D*rand(NP,1));
    for kk=1:NP
        mui(kk,dd(kk))=1;
    end
    mpo = mui < 0.5;                % inverse mask to mui
    
    if (st == 1)                      % DE/best/1
        ui = bm + F*(pm1 - pm2);        % differential variation
        ui = popold.*mpo + ui.*mui;     % crossover
    elseif (st == 2)                  % DE/rand/1
        ui = pm3 + F*(pm1 - pm2);       % differential variation
        ui = popold.*mpo + ui.*mui;     % crossover
    elseif (st == 3)                  % DE/rand-to-best/1
        ui = popold + F*(bm-popold) + F*(pm1 - pm2);        
        ui = popold.*mpo + ui.*mui;     % crossover
    elseif (st == 4)                  % DE/best/2
        ui = bm + F*(pm1 - pm2 + pm3 - pm4);  % differential variation
        ui = popold.*mpo + ui.*mui;           % crossover
    elseif (st == 5)                  % DE/rand/2
        ui = pm5 + F*(pm1 - pm2 + pm3 - pm4);  % differential variation
        ui = popold.*mpo + ui.*mui;            % crossover
    end
    
    %-----Select which vectors are allowed to enter the new population------------
    for i=1:NP
%         while ~isempty(find(ui(i,:) < Lbound)) | ~isempty(find(ui(i,:) > Ubound))
            outbind=find(ui(i,:) < Lbound);
            if size(outbind,2)~=0
%                 % Periodica
%                 ui(i,outbind)=2*XRmin(outbind)-ui(i,outbind);
                % Random
                ui(i,outbind)=XRmin(outbind)+(XRmax(outbind)-XRmin(outbind)).*rand(1,size(outbind,2));
%                 % Fixed
%                 ui(i,outbind)=XRmin(outbind);
            end            
            outbind=find(ui(i,:) > Ubound);
            if size(outbind,2)~=0
%                 % Periodica
%                 ui(i,outbind)=2*XRmax(outbind)-ui(i,outbind);
                % Random
                ui(i,outbind)=XRmin(outbind)+(XRmax(outbind)-XRmin(outbind)).*rand(1,size(outbind,2));
%                 % Fixed
%                 ui(i,outbind)=XRmax(outbind);
            end
%         end
    end
        
    for i=1:NP
        tempval = feval(fname,ui(i,:),fun);   % check cost of competitor
        nfeval  = nfeval + 1;
        if (tempval <= val(i))  % if competitor is better than value in "cost array"
            pop(i,:) = ui(i,:);  % replace old vector with new one (for new iteration)
            val(i)   = tempval;  % save value in "cost array"
            
            %----we update DE_gbestval only in case of success to save time-----------
            if (tempval < DE_gbestval)     % if competitor better than the best one ever
                DE_gbestval = tempval;      % new best value
                DE_gbest = ui(i,:);      % new best parameter vector ever
                if DE_gbestval <= VTR & DE_get_flag == 0
                    DE_fit_cut=nfeval;
                    DE_get_flag=1;
%                     DE_fitcount = Max_FES;
%                     return;
                end
            end
        end
        if nfeval+1 > Max_FES
            DE_fitcount = Max_FES;
            return;
        end
    end %---end for imember=1:NP
        
    iter = iter + 1;
%     if rem(iter,500) == 0
%         nfeval
%         DE_gbestval
%     end
end %---end while ((iter < Max_Gen) ...
