clear all
%clc

addpath('C:\Users\Shi Qiushi\Desktop\Deep_RVFL') %deep RVFL

load dataX.mat
load dataY.mat
load train_indx.mat
load test_indx.mat

U_dataY = unique(dataY);
nclass = numel(U_dataY);
dataY_temp = zeros(numel(dataY),nclass);

% 0-1 coding for the target
for i=1:nclass
    idx = dataY==U_dataY(i);
    dataY_temp(idx,i)=1;
end

dataX = rescale(dataX);

trainX = dataX(train_indx,:);
trainY = dataY_temp(train_indx,:);
testX = dataX(test_indx,:);
testY = dataY_temp(test_indx,:);


s = RandStream('mcg16807','Seed',11);
RandStream.setGlobalStream(s);


%default values. you need to tune them for best results
option.N = 100;
option.L = 10;
option.C = 2^(-6);
option.scale = 2^(0.125);

              
[model,train_acc,test_acc] = MRVFL(trainX,trainY,testX,testY,option);             
                
train_acc
test_acc


