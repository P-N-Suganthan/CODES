function [TestingAccuracy,Testing_time] = MRVFLpredict(testX,testY,model,option)

tic;

[Nsample,Nfea] = size(testX);

activation = option.activation;

w = model.w;
b = model.b;
beta = model.beta;
mu = model.mu;
sigma = model.sigma;
L = model.L;

TestingAccuracy = zeros(L,1);
A1 = testX;
A_merge = testX;

tic
for i = 1:L 
    
    A1 = A1 * w{i}+ repmat(b{i},Nsample,1);
    if option.renormal == 1
        if option.normal_type ==0
            A1 = bsxfun(@rdivide,A1-repmat(mu{i},size(A1,1),1),sigma{i});
        end
    end
    if activation == 1
        A1 = selu(A1);
    elseif activation == 2
        A1 = relu(A1);
    elseif activation == 3
        A1 = sigmoid(A1);
    elseif activation == 4
        A1 = sin(A1);
    elseif activation == 5
        A1 = hardlim(A1);        
    elseif activation == 6
        A1 = tribas(A1);
    elseif activation == 7
        A1 = radbas(A1);
    elseif activation == 8
        A1 = sign(A1);
    elseif activation == 9
        A1 = swish(A1);
    end
    if option.renormal == 1
        if option.normal_type ==1
            A1 = bsxfun(@rdivide,A1-repmat(mu{i},size(A1,1),1),sigma{i});
        end
    end
    
    A_merge = [A_merge A1];   
    
    A_merge_temp = [A_merge,ones(Nsample,1)]; %bias in the output layer
    
    rawScore = A_merge_temp * beta{i};
    
    %softmax to generate probabilites
    rawScore_temp1 = bsxfun(@minus,rawScore,max(rawScore,[],2));
    num = exp(rawScore_temp1);
    dem = sum(num,2);
    prob_scores = bsxfun(@rdivide,num,dem);
    [max_prob,indx] = max(prob_scores,[],2);
    [~, ind_corrClass] = max(testY,[],2);
    TestingAccuracy(i,1) = mean(indx == ind_corrClass);

end





%% Calculate the testing accuracy
Testing_time = toc;

end