clear all
clc

load Car.mat
load labels.mat
load folds.mat

dataX = car;
dataY = labels;
test_indx = logical(folds(:,1));
train_indx = logical(1-test_indx);

U_dataY = unique(dataY);
nclass = numel(U_dataY);
dataY_temp = zeros(numel(dataY),nclass);

% 0-1 coding for the target
for i=1:nclass
    idx = dataY==U_dataY(i);
    dataY_temp(idx,i)=1;
end

dataX = rescale(dataX);

trainX = dataX(train_indx,:);
trainY = dataY_temp(train_indx,:);
testX = dataX(test_indx,:);
testY = dataY_temp(test_indx,:);


seed = RandStream('mcg16807','Seed',0);
RandStream.setGlobalStream(seed);


%default values. you need to tune them for best results
option.N = 100;
option.L = 10;
option.C = 2^(4);
option.scale = 1;
option.activation = 2;
option.renormal = 1;
option.normal_type = 1;
[model,train_acc,test_acc] = MRVFL(trainX,trainY,testX,testY,option);

%% ACC for layer 1 to L
train_acc
test_acc


