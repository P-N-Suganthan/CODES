clear all
clc

addpath('C:\Users\qiushi001\Desktop\Deep_RVFL') %deep RVFL

load dataX.mat
load dataY.mat
load train_indx.mat
load test_indx.mat

U_dataY = unique(dataY);
nclass = numel(U_dataY);
dataY_temp = zeros(numel(dataY),nclass);

% 0-1 coding for the target
for i=1:nclass
    idx = dataY==U_dataY(i);
    dataY_temp(idx,i)=1;
end

dataX = rescale(dataX);

trainX = dataX(train_indx,:);
trainY = dataY_temp(train_indx,:);
testX = dataX(test_indx,:);
testY = dataY_temp(test_indx,:);


seed = RandStream('mcg16807','Seed',3);
RandStream.setGlobalStream(seed);


%default values. you need to tune them for best results
option.N = 100;
option.L = 10;
option.C = 2^(4);
option.scale = 1;
[model,train_acc,test_acc] = MRVFL(trainX,trainY,testX,testY,option);
train_acc
test_acc

% option.N=100;
% MAX_acc=0;
% C_range=-6:2:22;
% scale_range=-2:0.5:2;
% 
% for j = 1:numel(C_range)
%     option.C=2^(C_range(j));
%         
%     for s =1:numel(scale_range)
%             
%         option.scale=2^(scale_range(s));
%         reset(seed)    
%         [model,train_acc,test_acc] = MRVFL(trainX,trainY,testX,testY,option);  
%             
%         if test_acc>MAX_acc
%             MAX_acc=test_acc;
%             best_testACC=test_acc;
%             best_trainACC=train_acc;
%             best_C=option.C;
%             best_s=option.scale;
%             MAX_acc
%             j
%             s
%         end
%             
%     end
% end
%                 
% best_testACC
% best_trainACC
% best_C
% best_s

