function [RVFLModel,TrainAcc,TestAcc]  = RVFL_Final(trainX,trainY,testX,testY,option,model)

% Requried for consistency
s = RandStream('mcg16807','Seed',0);
RandStream.setGlobalStream(s);

% Train RVFL
[RVFLModel,TrainAcc] = RVFL_train_Final(trainX,trainY,option,model);

% Using trained model, predict the testing data
TestAcc = RVFL_predict(testX,testY,RVFLModel,option);

end
%EOF