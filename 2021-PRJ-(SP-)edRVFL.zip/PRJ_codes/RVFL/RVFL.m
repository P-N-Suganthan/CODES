function [RVFLModel,TrainAcc,TestAcc]  = RVFL(trainX,trainY,testX,testY,option)

% Requried for consistency
s = RandStream('mcg16807','Seed',0);
RandStream.setGlobalStream(s);

% Train RVFL
[RVFLModel,TrainAcc] = RVFL_train(trainX,trainY,option);

% Using trained model, predict the testing data
TestAcc = RVFL_predict(testX,testY,RVFLModel,option);

end
%EOF