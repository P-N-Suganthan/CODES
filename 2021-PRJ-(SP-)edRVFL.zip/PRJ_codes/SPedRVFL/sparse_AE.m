function [w1,b1] = sparse_AE(input,HiddenSize,alpha,iter_num)
% This function is based on CS294A Lecture notes Andrew Ng Sparse autoencoder
% p represents the average activation of the hidden neurons
p_true = zeros(1,HiddenSize);

% Parameters
p = 0.05; %sparsity parameter
beta = 0.5; %weight for sparsity penatly
lamda = 0;%regularization parameter

% Sample, feature number of the input
[Nsample,Nfea] = size(input);

% Initialize the weights and the bias
w1 = rand(Nfea,HiddenSize);
b1 = rand(1,HiddenSize);
w2 = rand(HiddenSize,Nfea);
b2 = rand(1,Nfea);

% Initialize the loss and the gradient
w1_grad = size(w1);
w2_grad = size(w2);
b1_grad = size(b1);
b2_grad = size(b2);

for iter = 1:iter_num

    % forward propagation
    H = sigmoid(input*w1 + repmat(b1,[Nsample,1])); %hidden layer
    p_true = mean(H,1);
    output = sigmoid(H*w2 + repmat(b2,[Nsample,1])); %output layer
    J = 0.5 * sum((output-input).^2,'all') + 0.5*lamda*(sum(w1*w1','all')+sum(w2*w2','all'))

    % sparsity
    KLdiver = zeros(1,HiddenSize);
    for j = 1:HiddenSize
        KLdiver(1,j) = p*log(p/p_true(1,j)) + (1-p)*log((1-p)/(1-p_true(1,j)));%KL divergence
    end
    J_sparse = sum(KLdiver,2)

    % back propagation
    grad2 = (input - output).*output.*(1 - output);
    grad1 = grad2*w2'.*H.*(1 - H);
    w2_grad = H'*grad2/Nsample + lamda*w2;
    w1_grad = input'*grad1/Nsample + lamda*w1;
    b2_grad = sum(grad2,1)/Nsample;
    b1_grad = sum(grad1,1)/Nsample;

    for j = 1:HiddenSize
        grad_sparse1 = -p/(p_true(1,j)) + (1-p)/(1-p_true(1,j));
        grad_sparse2 = grad_sparse1.*H(:,j).*(H(:,j)-1);
        grad_sparse_w = beta*sum(input'*grad_sparse2,2)/Nsample;
        w1_grad(:,j) = w1_grad(:,j) + grad_sparse_w;
        b1_grad(1,j) = b1_grad(1,j) + sum(grad_sparse2)/Nsample;
    end

    % update parameters
    w2 = w2 - alpha*w2_grad;
    w1 = w1 - alpha*w1_grad;
    b2 = b2 - alpha*b2_grad;
    b1 = b1 - alpha*b1_grad;
end

end

