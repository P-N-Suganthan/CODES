function acc = ComputeAcc(trainX,Y,ProbScores,j,center)
[Nsample,Nfea] = size(trainX);
Class_dist = zeros(size(Y));

D = zeros(Nsample,j);
for n = 1:Nsample
    D_temp = zeros(1,j);
    for classifier_num = 1:j
        D_temp(classifier_num) = dist(trainX(n,:),center{classifier_num}');
    end
     D(n,:) = (D_temp/sum(D_temp)*j);
end
      
for i=1:j
    Prob_temp = ProbScores{i,1};
    [~,index] = max(Prob_temp,[],2);
    Dist_temp = zeros(size(Prob_temp));
    for k = 1:Nsample
        Dist_temp(k,index(k)) = 1;
    end
    for n = 1:Nsample
        Class_dist(n,:) = Class_dist(n,:) + Dist_temp(n,:)*D(n,i);
        %Class_dist(n,:) = Class_dist(n,:) + Dist_temp(n,:);
    end
end
    
AvgProbScores = Class_dist./length(ProbScores);                                               
[MaxProb,indx] = max(AvgProbScores,[],2);
[~, Ind_corrClass] = max(Y,[],2);
acc = mean(indx == Ind_corrClass);
show = (indx == Ind_corrClass);

end