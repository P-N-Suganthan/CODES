function result = inverse_selu(x)
%implement inverse_selu function

alpha = 1.6732632423543772848170429916717;
scale = 1.0507009873554804934193349852946;

y = @(x) (x./scale) .* (x>0) + (log(x./scale./alpha+1)) .* (x<=0);

result = y(x);

end
