Some parts of the codes have been taken from:
1. Zhang, Le, and Ponnuthurai N. Suganthan. "A comprehensive evaluation of random vector functional link networks." Information sciences 367 (2016): 1094-1105.
2. Tang, Jiexiong, Chenwei Deng, and Guang-Bin Huang. "Extreme learning machine for multilayer perceptron." IEEE transactions on neural networks and learning systems 27.4 (2015): 809-821.
3. Katuwal, Rakesh, and Ponnuthurai N. Suganthan. "Stacked autoencoder based deep random vector functional link neural network for classification." Applied Soft Computing 85 (2019): 105854.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the distribution

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
We have put a demo of edRVFL with car dataset 

You need to tune/pass the values of the following parameters to the 'option' structure. 
After setting up the environment(dataset processings, tuning), you need to call the main_edRVFL function.
For example:

%default values. you need to tune them for best results
option.N = 100; %% hidden neuron number
option.L = 10;  %% hidden layer number
option.C = 2^(4);  %% regularization parameter
option.scale = 1;  %% scaling of the hidden weights
option.activation = 2; %% activation function (1)selu;(2)relu;(3)sigmoid;(4)sign;(5)hardlim;(6)tribas;(7)radbas;(8)sign
option.renormal = 1; %% whether need to do renormalization 
option.normal_type = 1; %% renormalization type

[model,train_acc,test_acc] = MRVFL(trainX,trainY,testX,testY,option);

For two-stage tuning, you need to write the main codes for your own datasets according to our paper:
Random Vector Functional Link Neural Network based Ensemble Deep Learning
QS Shi, R Katuwal, PN Suganthan, M Tanveer
Pattern Recognition

The codes are not optimized for efficiency. The codes have been cleaned for better readability
and documented and are not exactly the same as used in our paper. We have re-run and checked the
codes only in few datasets so if you find any bugs/issues, please write to
Qiushi (qiushi001@e.ntu.edu.sg).


03-Apr-2021