function [model,TrainingAccuracy,Training_time] = MRVFLtrain_Final(trainX,trainY,option,model)

[Nsample,Nfea] = size(trainX);
N = option.N;
L = option.L;
C = option.C;
s = 1;  %scaling factor
activation = option.activation;

TrainingAccuracy = zeros(L,1);
beta = cell(L,1);
weights = model.w;
biases = model.b;
mu = model.mu;
sigma = model.sigma;
A = cell(L,1); %for L hidden layers


A1 = trainX; %initialization
A_merge = trainX;

tic

for i = 1:L
        
    w = weights{i};
    b = biases{i};  
   
    A1 = A1 * w+repmat(b,Nsample,1);
    if option.renormal == 1
        if option.normal_type ==0
            mu{i} = mean(A1,1);
            sigma{i} = std(A1);
            A1 = bsxfun(@rdivide,A1-repmat(mu{i},size(A1,1),1),sigma{i}); %;batch normalization
        end
    end  
    if activation == 1
        A1 = selu(A1);
    elseif activation == 2
        A1 = relu(A1);
    elseif activation == 3
        A1 = sigmoid(A1);
    elseif activation == 4
        A1 = sin(A1);
    elseif activation == 5
        A1 = hardlim(A1);        
    elseif activation == 6
        A1 = tribas(A1);
    elseif activation == 7
        A1 = radbas(A1);
    elseif activation == 8
        A1 = sign(A1);
    elseif activation == 9
        A1 = swish(A1);
    end
    if option.renormal == 1
        if option.normal_type ==1
            mu{i} = mean(A1,1);
            sigma{i} = std(A1);
            A1 = bsxfun(@rdivide,A1-repmat(mu{i},size(A1,1),1),sigma{i}); %;layer normalization
        end
    end
    
    A_merge = [A_merge A1];
    
    A_merge_temp = [A_merge,ones(Nsample,1)]; %bias in the output layer
    beta1  = l2_weights(A_merge_temp,trainY,C,Nsample);
    
    A{i} =  A_merge_temp;
    beta{i} = beta1;
    
    %% Calculate the training accuracy
    trainY_temp = A_merge_temp * beta1;

    %softmax to generate probabilites
    trainY_temp1 = bsxfun(@minus,trainY_temp,max(trainY_temp,[],2)); %for numerical stability
    num = exp(trainY_temp1);
    dem = sum(num,2);
    prob_scores = bsxfun(@rdivide,num,dem);
    [max_prob,indx] = max(prob_scores,[],2);
    [~, ind_corrClass] = max(trainY,[],2);

    TrainingAccuracy(i,1) = mean(indx == ind_corrClass);

    
end



Training_time = toc;



model.L = L;
model.w = weights;
model.b = biases;
model.beta = beta;
model.mu = mu;
model.sigma = sigma;

end