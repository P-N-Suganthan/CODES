% figure('DefaultAxesFontSize',9);
%  figure(1);
% 
%  pareto_values = [VarName1 VarName2];
%  MW = -pareto_values(:,1);
%  Efficiency = -pareto_values(:,2);
%  plot(MW,Efficiency,'k.');
%  set(gca,'DefaultTextFontSize',9);
%  hold on;
%  
%  xlabel('MW','Fontsize',9,'fontangle','italic');
%  ylabel('Efficiency','Fontsize',9,'fontangle','italic');
%  grid on;
%  scatter(MW,Efficiency,'k.');
%  line(MW,Efficiency)
%  set(gca,'DefaultTextFontSize',9);
%  hold on;
%  
%  xlabel('MW','Fontsize',9,'fontangle','italic');
%  ylabel('Efficiency','Fontsize',9,'fontangle','italic');
%  grid on;


 figure('DefaultAxesFontSize',9);
 
%  NOTVSPOWER = [VarName3 VarName1];
%  NOT = NOTVSPOWER(:,1);
%  Power = -NOTVSPOWER(:,2);
%  Efficiency = -VarName2;
%  
%  [hAx,hLine1,hLine2] = plotyy(NOT,Power,NOT,Efficiency);
%  
%  hold(hAx(1),'on')
%  scatter(hAx(1),NOT,Power,'k.');
%  hold(hAx(2),'on')
%  scatter(hAx(2),NOT,Efficiency,'b.');
%   
%  ylim(hAx(1),[5 60])
%  ylim(hAx(2),[0.7 1])
%  
%  ylabel(hAx(1),'Output power (MW)','Fontsize',9,'fontangle','italic') % left y-axis
%  ylabel(hAx(2),'Efficiency','Fontsize',9,'fontangle','italic') % right y-axis
%  
%  xlabel('No. of Turbines','Fontsize',9,'fontangle','italic');
%  scatter(NOT,Power,'k.');
%  line(NOT,Power);
%  hold on;
%  grid on;
%  scatter(NOT,Efficiency,'m.');
%  line(NOT,Efficiency);
%  hold on;

  wf_var_array = round(VarName24);
  x_loc = repmat((150:300:5850)',5,1);
  y_loc = kron((200:400:1800)',ones(20,1));
  wf_t = horzcat(wf_var_array,x_loc,y_loc);
  wf_temp = wf_t(all(wf_t,2),:);
  wf_var = ...
    [40 60];
%      40 67; 
%      40 60];

  wf_var_sel = wf_var(wf_temp(:,1),:);
  wf_temp(:,1)=[];
  wind_farm_opt = horzcat(wf_temp,wf_var_sel);
%   wind_farm_opt = sortrows(wind_farm_opt,[2 1]);
  N_Opt = size(wind_farm_opt,1);
 

%  fprintf('\n Cost/MW %0.7f',Optimum(1));
%  fprintf('\n Efficiency %0.4f',1/Optimum(2));
%  fprintf('\n total_power %0.4f MW',total_power);
%  %fprintf('\n Cost Mil Euro %0.2f',Optimum(1));
%  %fprintf('\n farm_power MW %0.4f',1/Optimum(2));

  figure();
%  plot_diameter = 2*wind_farm_opt(:,3);
  plot_hubheight = wind_farm_opt(:,4);
  set(gca,'DefaultTextFontSize',9);
  xtic = {'0','','','','1200','','','','2400','','','','3600','','','','4800','','','','6000'};
  set(gca,'xtick',0:300:6000);
  set(gca,'xticklabel',xtic);   
  ylim([0 2000]);
  set(gca,'ytick',0:400:2000);
  hold on;
  x = wind_farm_opt(:,1);
  y = wind_farm_opt(:,2);
  
  legend = repmat(char('kx'),N_Opt,1);
%   index1 = find(plot_hubheight==wf_var(2,2));
%   index2 = find(plot_hubheight==wf_var(3,2));
%   legend(index1,:) = repmat(char('bo'),length(index1),1);
%   legend(index2,:) = repmat(char('kx'),length(index2),1);
  
  for jj=1:N_Opt
  plot(x(jj),y(jj),legend(jj,:));
  hold on
  end
  
  set(gca,'DefaultTextFontSize',9);
%  text(x,y,num2str(plot_diameter),'VerticalAlignment','top');
%  text(x,y,num2str(plot_hubheight),'VerticalAlignment','bottom');
  xlabel('x(in m)','Fontsize',9,'Fontangle','italic');
  ylabel('y(in m)','Fontsize',9,'Fontangle','italic');
  grid on;

