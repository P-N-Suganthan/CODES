function [pareto,record_prob]= ENSmoead(mop,varargin)
%ENSMOEAD run ENSmoea/d algorithms for the given mop.
% MOP could be obtained by function 'testmop.m'.
% the controlling parameter can be passed in by varargin, the folliwing
% parameters are defined in here. More other parameters can be passed by
% modify loadparams.m problem by problem.
%   seed: the random seed.
%   popsize: The subproblem's size.
%   niche: the neighboursize, must less then the popsize.
%   evaluation: the total evaluation of the moead algorithms before finish.
%   dynamic: whether to use dynamic resource allocation.
%   selportion: the selection portion for the dynamic resource allocation

    %global variable definition.
    global subproblems params itrCounter evalCounter subp_success FE_num temp;
    %global idealpoint objDim parDim evalCounter;
    
    %load the parameters.
    params=loadparams(varargin);
    record_prob=[];

    evalCounter = 0;
    itrCounter = 5;
    
    %and Initialize the algorithm.
    init(mop);
    %FE_num=zeros(1,length(params.niche));
    FE_num = 0;
    temp=struct('subp_size',[],'neighbour',[]);
    while ~terminate()
        evolve(mop); % one generation of evaluation.
        itrCounter=itrCounter+1;
        if (rem(itrCounter,50)==0 && itrCounter>=150)
            niche_success=0;
            for ii=1:params.popsize
                %nichesizeindex=find(params.niche==subp_size(ii));
                %niche_success(nichesizeindex)=niche_success(nichesizeindex)+subp_success(ii);
                niche_success=niche_success+subp_success(ii);
            end
            %for ii=1:length(params.niche)
                if FE_num==0,
                    niche_prob=0;
                else    %niche_prob=niche_success(ii)/FE_num(ii);
                    niche_prob=niche_success/FE_num;
                end
            %end
            %niche_prob=niche_prob./sum(niche_prob);
            %nichesizebestindex=find(niche_prob==max(niche_prob));
            min_prob=0.05;
            niche_prob=max(niche_prob,min_prob);       
            reassign_prob=niche_prob;
            %Reset up the neighbourhood.
            leng=params.popsize;
            distanceMatrix=zeros(leng, leng);
            %fprintf('\n leng %d:, nichesizebestindex %d',leng,nichesizebestindex);
            %indleng=randperm(leng);
            %nichesize2ndbestindex=find(reassign_prob==max(reassign_prob));
            record_prob=[record_prob; reassign_prob];
            for i=1:leng
                for j=i+1:leng
                    A=subproblems(i).weight;B=subproblems(j).weight;
                    distanceMatrix(i,j)=(A-B)'*(A-B);
                    distanceMatrix(j,i)=distanceMatrix(i,j);
                end
%                 [~,sindex]=sort(distanceMatrix(i,:));
                %params.niche(nichesizebestindex(ceil(rand(1,1)*length(nichesizebestindex))))
                %picknichesizeindex=find(reassign_prob>=rand(1,1));
                %if isempty(picknichesizeindex)
                    %temp(i).subp_size=params.niche(nichesizebestindex(ceil(rand(1,1)*length(nichesizebestindex))));
                    %temp(i).subp_size=params.niche;
                %else minnichesizeindex=find(reassign_prob==min(reassign_prob(picknichesizeindex)));
                %    temp(i).subp_size=params.niche(minnichesizeindex(ceil(rand(1,1)*length(minnichesizeindex))));
                %end
%                 temp(i).neighbour=sindex(1:temp(i).subp_size)';
%                 subp_success(i)=0;
             end
            %FE_num=zeros(1,length(params.niche));
            %FE_num=0;
        end
               
        if (rem(itrCounter,50)==0) % updating of the utility.
            util_update(); 
            status();
        end        
    end
  
    pareto=[subproblems.curpoint];

end

% The evoluation setp in MOEA/D
function evolve(mop)
  global subproblems idealpoint params subp_size FE_num oldselindex nadir;

  % select the subproblem according to its utility.
  % if params.dynamic is not true, then no selection is used.
  if (params.dynamic)
    selindex = util_select();
  else
    selindex = 1:length(subproblems);  
  end
  
  %disp(selindex());

  global selectionSize;
  selectionSize = length(selindex);
  %disp(selectionSize)
  
  for i=1:length(selindex)
    index = selindex(i);
    r = rand;
    %disp(r)
    updateneighbour = r < params.updateprob;
    %new point generation using genetic operations, and evaluate it.
    ind = genetic_op(index, updateneighbour, mop.domain);
    
    nichesizeind=find(params.niche==subp_size(index));
    FE_num(nichesizeind)=FE_num(nichesizeind)+1;

    [obj,ind] = evaluate(mop, ind);
    %update the idealpoint.
    idealpoint = min(idealpoint, obj);
    nadir = max(nadir, obj); %PPB
    %idealpoint = [14;0.08];
    %disp(evalCounter);
    %disp(obj);
    
    %updation.
    update(index, ind, updateneighbour);

    %clear!
    clear ind obj updateneighbour;
  end
  oldselindex=selindex;
end

% update the index's neighbour with the given individual.
% index is the subproblem's index in the main population.
% ind is the individual structure.
% updatenieghbour is a bool determine whether the neighbourhood of index, or the whole population should be updated.
% this procedure is also governed by a parameter from params: params.updatenb, which determine how many subproblem
% should be updated at most by this new individual.
function update(index, ind, updateneighbour)
  global subproblems idealpoint params subp_success ;
  
  % collect the updation index
  if (updateneighbour)
    updateindex = subproblems(index).neighbour;
  else
    updateindex = 1:length(subproblems);
  end
  
  updateindex = random_shuffle(updateindex);
  time=0;
  %disp(updateindex);
  for i=1:length(updateindex)
      idx = updateindex(i);
      updateweight = subproblems(idx).weight;
      newobj=subobjective(updateweight, ind.objective,  idealpoint, 'te');
      old=subobjective(updateweight, subproblems(idx).curpoint.objective,  idealpoint, 'te');
      if newobj<old 
          subp_success(idx)=subp_success(idx)+1;
%       elseif itrCounter>=150
%           subp_size(idx)=temp(idx).subp_size;
%           subproblems(idx).neighbour=temp(idx).neighbour;
%       end
%       if (newobj<old)
          subproblems(idx).curpoint=ind;
         %disp(sprintf('UP -- ID: %d, Type: %d, T: %d, UI: %d -- %f', index-1, updateneighbour, time, idx-1, ind.parameter));
         time = time+1; 
      end
      if (time>=params.updatenb)
          return;
      end
  end

end

function y =terminate()
    global params evalCounter;
    y = evalCounter>params.evaluation;
end

function status()
    global evalCounter itrCounter selectionSize subproblems;
    %average utility
    averageutil = mean([subproblems.utility]);
    %if (~rem(itrCounter, 30))
    fprintf('\n Itr:%d\tSel:%d\tEval:%d\tUtilM:%1.4f', ...
        itrCounter, selectionSize, evalCounter, averageutil);
    %end
end