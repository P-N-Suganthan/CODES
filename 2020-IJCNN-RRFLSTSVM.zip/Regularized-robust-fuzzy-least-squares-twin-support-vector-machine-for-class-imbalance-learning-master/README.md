# Regularized-robust-fuzzy-least-squares-twin-support-vector-machine-for-class-imbalance-learning
Matlab Code

%% Written By: Mudasir Ahmad Ganaie %%
This code corresponds to the conference paper: M.A. Ganaie, M. Tanveer, and P. N. Suganthan (2020). "Regularized robust fuzzy least squares twin support vector machine for class imbalance learning", 2020 International Joint Conference on Neural Networks (IJCNN).

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the distribution

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.)


 
This code is not optimized for efficiency. It has been tested on Windows 10 with MATLAB R2017a.

Please cite the following papers if you are using this code.

Reference:  [1]. M.A. Ganaie, M. Tanveer, and P. N. Suganthan (2020). "Regularized robust fuzzy least squares twin support vector machine for class imbalance learning", 2020 International Joint Conference on Neural Networks (IJCNN).

	    [2]. B. Richhariya, and M. Tanveer. "A robust fuzzy least squares twin support vector machine for class imbalance learning." Applied Soft Computing 71 (2018): 418-432.


%%%%%%%%%%%%%%%%%%%%%%%%%
%% How to run the code %%
%%%%%%%%%%%%%%%%%%%%%%%%%
1) Dataset: This folder contains classification datasets.
2) Optimal_Parameters: This folder contains optimal parameters obtained via cross-validation.
3) Run main.m file
4) ALL_Accuracy: This variables stores the net accuracy corresponding to each dataset.

For more details please refer to the paper.

If you have problems about this software, please contact: phd1901141006@iiti.ac.in

24/04/2020
