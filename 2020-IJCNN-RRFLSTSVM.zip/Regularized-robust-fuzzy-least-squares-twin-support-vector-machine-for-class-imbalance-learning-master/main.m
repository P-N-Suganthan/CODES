clc;
clear all;
close all;
All_Accuracy=cell(15,2);
for load_file =1:15
    %% initializing variable
    switch load_file
        case 1
            file = 'ecoli-0-1_vs_5';
            test_start =121;
            cvs1=0.0001;
            cvs0=0.5;
            mus=32;
            beta=0.1;
        case 2
            file = 'ecoli-0-1-4-7_vs_5-6';
            test_start =151;
            cvs1=0.001;
            cvs0=0.5;
            mus=32;
            beta=1;
        case 3
            file = 'ecoli-0-2-3-4_vs_5';
            test_start =101;
            cvs1=0.0001;
            cvs0=2.5;
            mus=32;
            beta=0.3;
        case 4
            file = 'ecoli-0-2-6-7_vs_3-5';
            test_start =111;
            cvs1=0.001;
            cvs0=1.5;
            mus=32;
            beta=0.1;
            
        case 5
            file = 'ecoli-0-4-6_vs_5';
            test_start =101;
            cvs1=1e-005;
            cvs0=0.5;
            mus=32;
            beta=0.1;
        case 6
            file = 'ecoli-0-6-7_vs_3-5';
            test_start =111;
            cvs1=0.0001;
            cvs0=0.5;
            mus=32;
            beta=0.3;
            
            
        case 7
            file = 'segment0';
            test_start =501;
            cvs1=10;
            mus=4;
            
            
        case 8
            file = 'heart-stat';
            test_start =131;
            cvs1=0.1;
            mus=32;
            
        case 9
            file = 'ripley';
            test_start =601;
            cvs1=1;
            cvs0=1.5;
            mus=1;
            beta=1;
            
        case 10
            file = 'shuttle-c0-vs-c4';
            test_start =901;
            cvs1=1e-002;
            cvs0=0.5;
            mus=32;
            beta=0.3;
            
            
            
        case 11
            file = 'brwisconsin';
            test_start =301;
            cvs1=10;
            mus=32;
            
        case 12
            file = 'pima';
            test_start =301;
            cvs1=0.001;
            cvs0=2;
            mus=32;
            beta=0.1;
            
            
        case 13
            file = 'segment0';
            test_start =501;
            cvs1=10;
            mus=4;
            
        case 14
            file = 'aus';
            test_start =301;
            cvs1=1;
            cvs0=1;
            mus=32;
            beta=0.1;
            
        case 15
            file = 'iono';
            test_start =201;
            cvs1=0.1;
            mus=4;
            
        otherwise
            continue;
    end
    %% Data file call from folder
    try
        filename = strcat('./Dataset/',file,'.txt');
        A = load(filename);
    catch
        continue
    end
    [m,n] = size(A);
    %%
    A(A(:,end)==0,end)=-1;
    test = A(test_start:m,:);
    train = A(1:test_start-1,:);
    
    [no_input,no_col] = size(train);
    
    x1 = train(:,1:no_col-1);
    y1 = train(:,no_col);
    A=[x1 y1];    %training data
    [m,n] = size(A);
    
    [no_test,no_col] = size(test);
    xtest0 = test(:,1:no_col-1);
    ytest0 = test(:,no_col);
    A_test=[xtest0,ytest0];    %testing data
    
    p=0;
    for i=1:m
        if A(i,n)==1
            p=p+1;
        end
    end
    ir=(m-p)/(p);
    %% initializing crossvalidation variables
    [lengthA,n] = size(A);
    load(['./Optimal_Parameters/' file '.mat'])
    All_Accuracy{load_file,1}=file;
    [All_Accuracy{load_file,2},ytest,yprediction,time] = NonL_LSTWSVM(A,A_test,min_c1,min_c0,min_mu,ir,min_eps);
end