% This Program uses Epsilon Constraint to Solve Constrained Optimization Problems
clear all;
global  nfeval
format long e;

 func_num = 1;      % Function Number
 NP       = 200;    % Size of Population
 Prob_Set = 1;      %1 for CEC 2006 and 2 for New Problems
 Max_FES  = 240000; % Maximum number of function evaluations
 Max_Gen  = 1200;
 
 if(Prob_Set == 1)
    Xmin1=[0 0 0 0 0 0 0 0 0 0 0 0 0];
    Xmax1=[1 1 1 1 1 1 1 1 1 100 100 100 1];
    Xmin2=zeros(1,20)+1e-100;
    Xmax2=10.*ones(1,20);
    Xmin3=zeros(1,10);
    Xmax3=ones(1,10);
    Xmin4=[78 33 27 27 27];
    Xmax4=[102 45 45 45 45];
    Xmin5=[0 0 -0.55 -0.55];
    Xmax5=[1200 1200 0.55 0.55];
    Xmin6=[13 0];
    Xmax6=[100 100];
    Xmin7=-10.*ones(1,10);
    Xmax7=10.*ones(1,10);
    Xmin8=[0 0];
    Xmax8=[10 10];
    Xmin9=-10.*ones(1,7);
    Xmax9=10.*ones(1,7);
    Xmin10=[100 1000 1000 10 10 10 10 10];
    Xmax10=[10000 10000 10000 1000 1000 1000 1000 1000];
    Xmin11=[-1 -1];
    Xmax11=[1 1];
    Xmin12=[0 0 0];
    Xmax12=[10 10 10];
    Xmin13=[-2.3 -2.3 -3.2 -3.2 -3.2];
    Xmax13=[2.3 2.3 3.2 3.2 3.2];
    Xmin14=zeros(1,10)+1e-100;
    Xmax14=10.*ones(1,10);
    Xmin15=[0 0 0];
    Xmax15=[10 10 10];
    Xmin16=[704.4148,68.6,0,193,25];
    Xmax16=[906.3855,288.88,134.75,287.0966,84.1988];
    Xmin17=[0 0 340 340 -1000 0];
    Xmax17=[400 1000 420 420 1000 0.5236];
    Xmin18=[-10 -10 -10 -10 -10 -10 -10 -10 0];
    Xmax18=[10 10 10 10 10 10 10 10 20];
    Xmin19=zeros(1,15);
    Xmax19=10.*ones(1,15);
    Xmin20=zeros(1,24)+1e-100;
    Xmax20=10.*ones(1,24);
    Xmin21=[0 0 0 100 6.3 5.9 4.5];
    Xmax21=[1000 40 40 300 6.7 6.4 6.25];
    Xmin22=[0 0 0 0 0 0 0 100 100 100.01 100 100 0 0 0 0.01 0.01 -4.7 -4.7 -4.7 -4.7 -4.7];
    Xmax22=[20000 1e+6 1e+6 1e+6 4e+7 4e+7 4e+7 299.99 399.99 300 400 600 500 500 500 300 400 6.25 6.25 6.25 6.25 6.25];
    Xmin23=[0 0 0 0 0 0 0 0 0.01];
    Xmax23=[300 300 100 200 100 300 100 200 0.03];
    Xmin24=[0 0];
    Xmax24=[3 4];

    Dimension=[13 20 10 5 4 2 10 2 7 8 2 3 5 10 3 5 6 9 15 24 7 22 9 2];
    gn=[9,2,0,6,2,2,8,2,4,6,0,1,0,0,0,38,0,13,5,6,1,1,2,2];
    hn=[0,0,1,0,3,0,0,0,0,0,1,0,3,3,2,0,4,0,0,14,5,19,4,0];

    best_known=[-15.00000 -0.803619    -1       -30665.538672  5126.498110 -6961.813800 24.306209   -0.095825  680.630057  7049.330700...
    0.75       -1       0.0539498  -47.764411     961.715172   -1.905155   8876.980680 -0.865735   32.655593   0.096737...
    193.778349 382.902205 -400.002500 -5.508013];

        
    D=Dimension(func_num);
    gn=gn(func_num);
    hn=hn(func_num);
    
    if func_num==1,fhd='g01';
    elseif func_num==2,fhd='g02';
    elseif func_num==3,fhd='g03'; 
    elseif func_num==4,fhd='g04';
    elseif func_num==5,fhd='g05';
    elseif func_num==6,fhd='g06';
    elseif func_num==7,fhd='g07';
    elseif func_num==8,fhd='g08';
    elseif func_num==9,fhd='g09';
    elseif func_num==10,fhd='g10';
    elseif func_num==11,fhd='g11';
    elseif func_num==12,fhd='g12';
    elseif func_num==13,fhd='g13';
    elseif func_num==14,fhd='g14';
    elseif func_num==15,fhd='g15';
    elseif func_num==16,fhd='g16';
    elseif func_num==17,fhd='g17';
    elseif func_num==18,fhd='g18';
    elseif func_num==19,fhd='g19';
    elseif func_num==20,fhd='g20';
    elseif func_num==21,fhd='g21';
    elseif func_num==22,fhd='g22';
    elseif func_num==23,fhd='g23';
    elseif func_num==24,fhd='g24';
    end

    eval(['Xmin=Xmin' int2str(func_num) ';']);
    eval(['Xmax=Xmax' int2str(func_num) ';']);
 elseif(Prob_Set == 2)
     Xmin1=-50*ones(1,10);
    Xmax1=+50*ones(1,10);
    Xmin2=-5.12*ones(1,10);
    Xmax2=+5.12*ones(1,10);
    Xmin3=-100*ones(1,10);
    Xmax3=+100*ones(1,10);
    Xmin4=-100*ones(1,10);
    Xmax4=+100*ones(1,10);
    Xmin5=-100*ones(1,10);
    Xmax5=+100*ones(1,10);
    Xmin6=-100*ones(1,10);
    Xmax6=+100*ones(1,10);
    Xmin7=-100*ones(1,10);
    Xmax7=+100*ones(1,10);
    Xmin8=-500*ones(1,10);
    Xmax8=+500*ones(1,10);
    Xmin9=-500*ones(1,10);
    Xmax9=+500*ones(1,10);
    Xmin10=-10*ones(1,10);
    Xmax10=+10*ones(1,10);
    Xmin11=-5*ones(1,10);
    Xmax11=+5*ones(1,10);
    Xmin12=-50*ones(1,10);
    Xmax12=+50*ones(1,10);
    Xmin13=-100*ones(1,10);
    Xmax13=+100*ones(1,10);
    gn=[1 2 1 0+1 2   1   2  0+1 3   1    0+1 0+1 2];
    hn=[2 1 1 2   0+1 0+1 1  1   0+1 0+1  2   1   0+1];
    D=10;
    gn=gn(func_num);
    hn=hn(func_num);
    
    eval(['Xmin=Xmin' int2str(func_num) ';']);
    eval(['Xmax=Xmax' int2str(func_num) ';']); 

  
 end
     
 for runs=1:30  % Specify the number of runs
     
  fprintf('Run %d',runs);
  nfeval=0;
  
  % Initialization and Evaluation  of Population Members    
  pop=repmat(Xmin,NP,1)+repmat((Xmax-Xmin),NP,1).*rand(NP,D);
  if(Prob_Set == 1)
    [val(:,1), g, h] = mlbsuite(pop', gn, hn, fhd);
  elseif(Prob_Set == 2)
    [val(:,1), g, h] = TEC(pop,func_num);
  end
  nfeval=nfeval+NP;
 
  ub=repmat(Xmax,NP,1);
  lb=repmat(Xmin,NP,1);
 
  TOURNAMENT_SIZE=20; % Tournament size for selection
  CONV=abs(h);
  if(~isempty(CONV) & ~isempty(find(CONV>0)))
   DELTA=max(min(CONV,[],2));
   numD=10^(log10(DELTA/10^(-4))/(Max_Gen/2));
  else
   DELTA=10^(-4);
   numD=1;
  end
  cons=[(g>0).*g;((abs(h)-10^(-4))>0).*(abs(h)-10^(-4))]'; 
  cons_max=max(cons,[],1);
  nzindex=find(cons_max~=0);
  %Evalauating total constraint violation to evaluate Epsilon Value  
  if isempty(nzindex)
      tcons=zeros(NP,1);
  else
      tcons=sum(cons(:,nzindex)./repmat(cons_max(nzindex),NP,1),2)./sum(1./cons_max(nzindex));
  end 
     
  n=0.05*NP;      % The parameters of the constraint handling method
  Tc=0.5*Max_Gen;
  cp=5;
  [temp,index]=sort(tcons);
  EPSILON=tcons(index(n));
  nretry=10;

for gen=1:Max_Gen
    
   NN=min(50,ceil((gen/Max_Gen)^5*50));
  %Adaptation of delta for equality constraints
  if(gen==1)
  delta=DELTA;
  else
  delta=max(10^(-4),DELTA/(numD^gen));
  end
    % Initialization and Adaptation of neta values       
    if(gen<=10)
             
       neta=[(0.8/sqrt(D))*rand(NP,D)].*repmat((Xmax-Xmin),NP,1);
                  
    else
                       
       L=[];
        for ind=1:10
          L=[L;eval(['sneta' num2str(ind)])];
        end
          L(~any(L,2),:) = [];
          l=mean(L,1);                 
          neta=repmat(l,NP,1);

    end          
    newneta= neta.*[2*rand(NP,D)-1]+neta;
    index=randint(2,1,[1,NP]);
    newpop(1,:)=pop(1,:)+0.85*(pop(index(1),:)-pop(index(2),:));
    newpop((2:NP),:)=pop(2:NP,:)+newneta(2:NP,:).*randn((NP-1),D);
         

    I=find((newpop>ub)|(newpop<lb));
    retry=1;

    while ~isempty(I)
       newpop(I)=pop(I)+neta(I).*randn(length(I),1);
       I=find((newpop>ub)|(newpop<lb));
      if (retry>nretry)
         break; 
      end
        retry=retry+1;
    
    end 
    newpop=(newpop>repmat(Xmin,NP,1)).*newpop+(newpop<repmat(Xmin,NP,1)).*(repmat(Xmin,NP,1));
    newpop=(newpop<repmat(Xmax,NP,1)).*newpop+(newpop>repmat(Xmax,NP,1)).*(repmat(Xmax,NP,1));
    if(Prob_Set == 1)
        [newval(:,1),newg,newh]=mlbsuite(newpop', gn, hn, fhd);
    elseif(Prob_Set == 2)
        [newval(:,1),newg,newh]=TEC(newpop,func_num);
    end
    nfeval=nfeval+NP;
        
     
    A1=[pop;newpop];
    B1=[val;newval];
    F1=[neta;newneta];
    G1=[g,newg];
    H1=[h,newh];
   
    r=rem(gen,10);
    if(r==0)
        r=10;
    end
    if(gen<=60)
    ZZ1=[];
    ZZ2=[];
    ZZ3=[];
    ZZ4=[];
    ZZ5=[];
    zz=[];
    [ZZ1,zz]=unique(A1,'rows');
    ZZ2=B1(zz,:);
    ZZ3=F1(zz,:);
    ZZ4=G1(:,zz);
    ZZ5=H1(:,zz);
    A1=[];
    B1=[];
    F1=[];
    G1=[];
    H1=[];
    A1=ZZ1;
    B1=ZZ2;
    F1=ZZ3;
    G1=ZZ4;
    H1=ZZ5;
    end
    cons1=[(G1>0).*G1;((abs(H1)-delta)>0).*(abs(H1)-delta)]'; 
    cons_max=max([cons_max;cons1],[],1);
    nzindex=find(cons_max~=0);
    
    if isempty(nzindex)
       tcons1=zeros(size(A1,1),1);
    else
       tcons1=sum(cons1(:,nzindex)./repmat(cons_max(nzindex),size(A1,1),1),2)./sum(1./cons_max(nzindex));
    end 
        
    if(gen<=Tc)
      epsilon(gen)=EPSILON*((1-gen/Tc)^cp);
    else
     epsilon(gen)=0;
    end
   
    for kk=1:size(A1,1)
        win1(kk)=0;
       for i=1:TOURNAMENT_SIZE
         competitor3=ceil(rand(1)*size(A1,1));
          win1(kk)=win1(kk)-(~((tcons1(kk)<=epsilon(gen) & tcons1(competitor3)<=epsilon(gen) & B1(competitor3) <= B1(kk)) |...
                (tcons1(kk)==tcons1(competitor3) & B1(competitor3) <= B1(kk)) |(tcons1(competitor3)<tcons1(kk))));
               
       end
    end

    [sort_chd1,a] = sortrows([win1',A1,B1,F1,G1',H1',tcons1],1);
    aa=a(1:NP);
    pop=sort_chd1(1:NP,2:(D+1));
    val=sort_chd1(1:NP,(D+2));
    neta=sort_chd1(1:NP,(D+3):(D*2+2));
    win1=sort_chd1(1:NP,1)';
    g=sort_chd1(1:NP,(D*2+3):(D*2+2+gn))';
    h=sort_chd1(1:NP,(D*2+2+gn+1):(D*2+2+gn+hn))';
    tcons1=sort_chd1(1:NP,(D*2+3+gn+hn));
    if(size(find(aa>NP),1)~=0 )
      sneta1=neta(find( aa>NP),:);
    else
      sneta1=[(0.8/sqrt(D))*rand(NP,D)].*repmat((Xmax-Xmin),NP,1);
                             
    end
      
    eval(['sneta' num2str(r) '=sneta1;']);
    
   
          
   feasindex=find(tcons1==0);
  if isempty(feasindex)
    [gbesttcons,ibest]=min(tcons1);
    gbestval=val(ibest);
    gbest = pop(ibest,:);
  else
    [gbestval,ibest]=min(val(feasindex));
    gbesttcons=tcons1(feasindex(ibest));
    gbest = pop(feasindex(ibest),:);
  end

    if(gen ==1)
      thegbestval = gbestval;
      thegbesttcons = gbesttcons;
    elseif((gbesttcons < thegbesttcons) | (gbesttcons==0 & thegbesttcons ==0 & gbestval < thegbestval))
      thegbestval = gbestval;
      thegbesttcons = gbesttcons;
    end


    W(gen,1)=thegbestval;
    W(gen,2)=thegbesttcons;
    W(gen,3)=nfeval;   
    
      
end

  eval(['save /staff2/mall/TEC/DIVA' int2str(func_num) '/W_' int2str(runs) ' W;']);
  Re(runs,1)=thegbestval;
  Re(runs,2)=thegbesttcons;

 end

 Res(1)=max(Re(:,1));
 Res(2)=min(Re(:,1));
 Res(3)=median(Re(:,1));
 Res(4)=mean(Re(:,1));
 Res(5)=std(Re(:,1));   

 eval(['save /staff2/mall/TEC/DIVA' int2str(func_num) '/FUN' int2str(func_num)]);

        
