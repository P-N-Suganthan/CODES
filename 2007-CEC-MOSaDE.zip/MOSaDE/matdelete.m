function [xx,r]=matdelete(xx1,remlist)
[r,nc]=size(xx1);

rr=length(remlist);
if rr==0,xx=xx1;
else
    xx=[];
    count=0;
    for i=1:r
        if isempty(find(remlist==i)),count=count+1;xx(count,:)=xx1(i,:);end
    end
end
r=r-rr;