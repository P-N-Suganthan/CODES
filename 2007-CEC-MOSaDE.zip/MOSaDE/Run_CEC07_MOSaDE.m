clear all
warning off

NP=50;
Max_FES=500001;
Max_Gen=10000;
runs=25;

localflag=1;
drawflag=0;
F0=0.3;
CR=0.2;
strategy=2;
flag_no=5;
numst=2;
switch flag_no
%     case 1, 
%         eval([' dirname= ''D:\MOSaDE_thesis\test_result\F_analysis\F0' int2str(10*F0) '\'';' ]);
%     case 2, 
%         dirname= 'D:\MOSaDE_thesis\test_result\F_analysis\F53\';
%     case 3, 
%         eval([' dirname= ''D:\MOSaDE_thesis\test_result\St_analysis\' int2str(numst) 'st'  '\'';']);
%     case 4, 
%         eval([' dirname= ''D:\MOSaDE_thesis\test_result\F_analysis' int2str(D) 'DNP' int2str(NP) '\current2rand\K5Fn53\'';']);
    case 5, 
        dirname= '/home/ashish/huang/MOSaDE_thesis/CEC07result/CEC07_LS/';
end

for func_num=14
    switch (func_num)
        case 1
            func='OKA2';
            n=3;
            n_obj=2;
        case 2
            func='SYMPART';
            n=30;
            n_obj=2;
        case 3
            func='S_ZDT1';
            n=30;
            n_obj=2;
        case 4
            func='S_ZDT2';
            n=30;
            n_obj=2;
        case 5
            func='S_ZDT4';
            n=30;
            n_obj=2;
        case 6
            func='R_ZDT4';         
            n=10;
            n_obj=2;
        case 7   
            func='S_ZDT6';
            n=30;
            n_obj=2;
        case 8
            func='S_DTLZ2';
            n=30;
            n_obj=3;
        case 9
            func='R_DTLZ2';
            n=30;
            n_obj=3;
        case 10
            func='S_DTLZ3';
            n=30;
            n_obj=3;
        case 11
            func='WFG1';
            n=24;
            n_obj=3;
        case 12
            func='WFG8';
            n=24;
            n_obj=3;
        case 13
            func='WFG9';
            n=24;
            n_obj=3;            
        case 14
            func='S_DTLZ2';
            n=30;
            n_obj=5;
        case 15
            func='R_DTLZ2';
            n=30;
            n_obj=5;
        case 16
            func='S_DTLZ3';
            n=30;
            n_obj=5;
        case 17
            func='WFG1';
            n=28;
            n_obj=5;
        case 18
            func='WFG8';
            n=28;
            n_obj=5;
        case 19
            func='WFG9';
            n=28;
            n_obj=5;
    end
    
    if n_obj==2,
        max_rep_size=100;
    elseif n_obj==3;
        max_rep_size=150;
    else
        max_rep_size=3000;       
    end
    if (func_num==6)
        eval(['load /home/ashish/huang/MOSaDE_thesis/CEC07codes_0314/Data/' func '_bound_10D.dat;'])
        eval(['bound=' func '_bound_10D;'])   
        xl=bound(1,1:n);
        xu=bound(2,1:n);
    elseif (func_num==9)
        eval(['load /home/ashish/huang/MOSaDE_thesis/CEC07codes_0314/Data/' func '_bound_30D.dat;'])
        eval(['bound=' func '_bound_30D;'])   
        xl=bound(1,1:n);
        xu=bound(2,1:n);
    elseif (func_num==1)
        xl=[-pi -pi -pi];
        xu=[pi pi pi];
    elseif (func_num==2)
        xl=-20*ones(1,n);
        xu=20*ones(1,n);
    elseif (func_num==11 | func_num==12 | func_num==13)
        xl=zeros(1,n);
        xu=2*(1:n);
    else
        eval(['load /home/ashish/huang/MOSaDE_thesis/CEC07codes_0314/Data/' func '_bound.dat;'])
        eval(['bound=' func '_bound;'])
        xl=bound(1,1:n);
        xu=bound(2,1:n);
    end
    D=n;
    fname='mfsuite';        
    XRmin=xl;
    XRmax=xu;
    Lbound=xl;
    Ubound=xu;    
    
    eval(['fid1=fopen(''/home/ashish/huang/MOSaDE_thesis/CEC07result/CEC07_LS/ANS_' func '_M' num2str(n_obj) '_1.txt'',''w'');' ]);
    eval(['fid2=fopen(''/home/ashish/huang/MOSaDE_thesis/CEC07result/CEC07_LS/ANS_' func '_M' num2str(n_obj) '_2.txt'',''w'');' ]);
    eval(['fid3=fopen(''/home/ashish/huang/MOSaDE_thesis/CEC07result/CEC07_LS/ANS_' func '_M' num2str(n_obj) '_3.txt'',''w'');' ]);
    
    for iternum=1:runs  
        [rep1,rep2,rep3,pop,ccmhist,pfithist,outnum,n_flag,ri_count] = thesis_MOSaDE_LS(fname,...
            Max_FES,D,XRmin,XRmax,Lbound,Ubound,NP,max_rep_size,Max_Gen,F0,CR,strategy,n_obj,numst,func,localflag,drawflag);
        %         [nds,nds_val,feval_count]=MOCLPSO_func(fname,...
        %             Max_FES,D,XRmin,XRmax,NP,max_rep_size,n_obj,func)
        
        %         [parent,rep]=PADE2clusternew(fname,8,F0,CR,NP,n_obj,n,XRmin,XRmax,func)
        
        for i=1:size(rep1,1)
            switch n_obj
                case 2  
                    fprintf(fid1,'%e %e\n',rep1(i,D+1:D+n_obj));
                case 3
                    fprintf(fid1,'%e %e %e\n',rep1(i,D+1:D+n_obj));
                case 5
                    fprintf(fid1,'%e %e %e %e %e\n',rep1(i,D+1:D+n_obj));
            end           
        end
        fprintf(fid1,'\n');
        for i=1:size(rep2,1)
            switch n_obj
                case 2  
                    fprintf(fid2,'%e %e\n',rep2(i,D+1:D+n_obj));
                case 3
                    fprintf(fid2,'%e %e %e\n',rep2(i,D+1:D+n_obj));
                case 5
                    fprintf(fid2,'%e %e %e %e %e\n',rep2(i,D+1:D+n_obj));
            end  
        end
        fprintf(fid2,'\n');   
        for i=1:size(rep3,1)
            switch n_obj
                case 2  
                    fprintf(fid3,'%e %e\n',rep3(i,D+1:D+n_obj));
                case 3
                    fprintf(fid3,'%e %e %e\n',rep3(i,D+1:D+n_obj));
                case 5
                    fprintf(fid3,'%e %e %e %e %e\n',rep3(i,D+1:D+n_obj));
            end 
        end
        fprintf(fid3,'\n'); 
        eval(['save ' dirname func '_M' num2str(n_obj) '_' int2str(iternum) ' rep1 rep2 rep3 pop ccmhist pfithist outnum n_flag ri_count;']);
        clear rep1 rep2 rep3 pop ccmhist pfithist outnum n_flag ri_count
    end
    fclose(fid1);
    fclose(fid2);
    fclose(fid3);
end