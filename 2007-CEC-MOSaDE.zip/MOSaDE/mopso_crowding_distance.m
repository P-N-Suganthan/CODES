function rep=mopso_crowding_distance(rep,dim,n_obj,max_rep_size)

fxmax=max(rep(:,dim+1:dim+n_obj));    
fxmin=min(rep(:,dim+1:dim+n_obj));    
[nr,nn]=size(rep);
dd=zeros(nr,1);
for k=1:n_obj
    [y,yy]=sort(rep(:,dim+k));
    dd(yy(1),1)=10000;dd(yy(nr),1)=10000;
    range=(fxmax(k)-fxmin(k));
    if range==0,range=.00001;end
    for i=2:nr-1
        dd(yy(i),1)=dd(yy(i),1)+(y(i+1)-y(i-1))/range;
    end
end
[s,ss]=sort(-dd);
rep=rep(ss',:);

