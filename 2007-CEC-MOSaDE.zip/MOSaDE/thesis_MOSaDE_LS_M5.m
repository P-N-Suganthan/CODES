function [rep1,rep2,rep,pop,ccmhist,pfithist,outnum,n_flag,ri_count] = thesis_MOSaDE_LS(fname,...
    Max_FES,D,XRmin,XRmax,Lbound,Ubound,NP,max_rep_size,Max_Gen,F0,CR,strategy,n_obj,numst,func,localflag,drawflag);

learngen=50;
ccmhist=[];
pfithist=[];
varflag=0;
clusterflag=1;
aaaa=cell(1,numst); %CR for each strategy
lpcount=[]; 
npcount=[];
ns=[];
nf=[];
pfit=ones(1,numst);
flag1=1;
flag2=1;
rep1=[];
rep2=[];
ri_count=0;
var_theta=1e-2;
iter_theta=50;
n_flag=zeros(NP,1);
stag_flag=0;

rand('state',sum(100*clock));
ccm = CR*ones(1,numst);
if length(Lbound)==1
    Lbound=repmat(Lbound,1,D);
    Ubound=repmat(Ubound,1,D);
end
if length(XRmin)==1
    XRmin=repmat(XRmin,1,D);
    XRmax=repmat(XRmax,1,D);
end
%-----Initialize population and some arrays-------------------------------
pop = zeros(NP,D); %initialize pop to gain speed
popold    = zeros(size(pop));     % toggle population
nfeval    = 0;                    % number of function evaluations

XRRmin=repmat(XRmin,NP,1);
XRRmax=repmat(XRmax,NP,1);
pop=XRRmin+(XRRmax-XRRmin).*rand(NP,D);

for i=1:NP
    nfeval=nfeval+1;
    pop(i,D+1:D+n_obj)=feval(fname,pop(i,1:D),n_obj,func);
end
popold_var=sum(var(pop));

rep=pop;
rep(:,D+n_obj+1)=zeros(NP,1);
ccmhist = [1,ccm];
pfithist = [1,pfit/sum(pfit)];

fmin=min(rep(:,D+1:D+n_obj),[],1);
fmax=max(rep(:,D+1:D+n_obj),[],1);
err=0.00001.*(fmax-fmin);
epsilon=zeros(1,n_obj);
% 
% epsilon=0.001.*ones(1,n_obj);
% epsilon=[0.042 0.0425 0.04];


%------DE-Minimization---------------------------------------------
pm1 = zeros(NP,D);              % initialize population matrix 1
pm2 = zeros(NP,D);              % initialize population matrix 2
pm3 = zeros(NP,D);              % initialize population matrix 3
pm4 = zeros(NP,D);              % initialize population matrix 4
pm5 = zeros(NP,D);              % initialize population matrix 5
bm  = zeros(NP,D);              % initialize DE_gbestber  matrix
ui  = zeros(NP,D);              % intermediate population of perturbed vectors
mui = zeros(NP,D);              % mask for intermediate population
mpo = zeros(NP,D);              % mask for old population
rot = (0:1:NP-1);               % rotating index array (size NP)
rotd= (0:1:D-1);                % rotating index array (size D)
rt  = zeros(NP);                % another rotating index array
rtd = zeros(D);                 % rotating index array for exponential crossover
a1  = zeros(NP);                % index array
a2  = zeros(NP);                % index array
a3  = zeros(NP);                % index array
a4  = zeros(NP);                % index array
a5  = zeros(NP);                % index array
ind = zeros(4);

iter = 0;
while iter < Max_Gen
    %     if (sum(n_flag)==NP)&(stag_flag==1),
    %         stag_count=stag_count+1
    %         stag_flag=1;
    %     else
    %         stag_count=0;
    %         stag_flag=0;
    %     end
    %     pop_var=sum(var(pop));
    %     if pop_var < var_theta, % prematurely converge
    %         ri_count=ri_count+1
    %         pop=XRRmin+(XRRmax-XRRmin).*rand(NP,D);
    %         for i=1:NP
    %             nfeval=nfeval+1;
    %             pop(i,D+1:D+n_obj)=feval(fname,pop(i,1:D),n_obj,func);
    %         end
    %         % stagnation
    %     elseif stag_count>= iter_theta
    %         ri_count=ri_count+1;
    %         pop=XRRmin+(XRRmax-XRRmin).*rand(NP,D);
    %         for i=1:NP
    %             nfeval=nfeval+1;
    %             pop(i,D+1:D+n_obj)=feval(fname,pop(i,1:D),n_obj,func);
    %         end
    %     end  
    
    popold = pop(:,1:D);                   % save the old population    
    ind = randperm(4);              % index pointer array    
    a1  = randperm(NP);             % shuffle locations of vectors
    rt = rem(rot+ind(1),NP);        % rotate indices by ind(1) positions
    a2  = a1(rt+1);                 % rotate vector locations
    rt = rem(rot+ind(2),NP);
    a3  = a2(rt+1);
    rt = rem(rot+ind(3),NP);
    a4  = a3(rt+1);
    rt = rem(rot+ind(4),NP);
    a5  = a4(rt+1);
    
    pm1 = popold(a1,:);             % shuffled population 1
    pm2 = popold(a2,:);             % shuffled population 2
    pm3 = popold(a3,:);             % shuffled population 3
    pm4 = popold(a4,:);             % shuffled population 4
    pm5 = popold(a5,:);             % shuffled population 5
    
    rep_size=size(rep,1);   
    for i=1:NP
        h=ceil(rand*rep_size);
        bm(i,:)=rep(h,1:D);     
    end  
    
    if (iter>=learngen)        
        for i=1:numst
            if   ~isempty(aaaa{i}) 
                ccm(i)=median(aaaa{i}(:,1));   
                d_index=find(aaaa{i}(:,2)==aaaa{i}(1,2));
                aaaa{i}(d_index,:)=[];
            else
                ccm(i)=rand;
            end
        end
    end
    for i=1:numst
        cc_tmp=[];
        for k=1:NP
            tt=normrnd(ccm(i),0.1);
            while tt>1 | tt<0
                tt=normrnd(ccm(i),0.1);
            end
            cc_tmp=[cc_tmp;tt];;
        end
        cc(:,i)=cc_tmp;
    end
    
    % Stochastic universal sampling               %choose strategy
    rr=rand;
    spacing=1/NP;
    randnums=sort(mod(rr:spacing:1+rr-0.5*spacing,1));  
    
    normfit=pfit/sum(pfit);
    partsum=0;
    count(1)=0;
    stpool=[];
    
    for i=1:length(pfit)
        partsum=partsum+normfit(i);
        count(i+1)=length(find(randnums<partsum));
        select(i,1)=count(i+1)-count(i);
        stpool=[stpool;ones(select(i,1),1)*i];
    end
    stpool = stpool(randperm(NP));
    
    for i=1:numst
        atemp=zeros(1,NP);
        aaa{i}=atemp;
        index{i}=[];
        if ~isempty(find(stpool == i))
            index{i} = find(stpool == i);
            atemp(index{i})=1;
            aaa{i}=atemp;
        end
    end
    aa=zeros(NP,D);
    for i=1:numst
        aa(index{i},:) = rand(length(index{i}),D) < repmat(cc(index{i},i),1,D);          % all random numbers < CR are 1, 0 otherwise
    end
    
    mui=aa;
    if (strategy > 1)
        st = strategy-1;		  % binomial crossover
    else
        st = strategy;		  % exponential crossover
        mui=sort(mui');	          % transpose, collect 1's in each column
        for i=1:NP
            n=floor(rand*D);
            if n > 0
                rtd = rem(rotd+n,D);
                mui(:,i) = mui(rtd+1,i); %rotate column i by n
            end
        end
        mui = mui';			  % transpose back
    end
    dd=ceil(D*rand(NP,1));
    for kk=1:NP
        mui(kk,dd(kk))=1; 
    end
    mpo = mui < 0.5;                % inverse mask to mui
    
    for i=1:numst     
        F=[];
        m=length(index{i});       
        F=normrnd(F0,0.1,m,1);
        %         F=F0*ones(m,1);
        %         tol=0.5;
        %         F=F0.*exp(tol.*(normrnd(0,1,m,1)-tol/2));
        F=repmat(F,1,D);
        if i==1
            ui(index{i},1:D) = pm3(index{i},:) + F.*(pm1(index{i},:) - pm2(index{i},:));        % differential variation
            ui(index{i},1:D) = popold(index{i},:).*mpo(index{i},:) + ui(index{i},1:D).*mui(index{i},:);     % crossover
        end
        if i==3
            ui(index{i},1:D) = pm5(index{i},:) + F.*(pm1(index{i},:) - pm2(index{i},:) + pm3(index{i},:) - pm4(index{i},:));       % differential variation
            ui(index{i},1:D) = popold(index{i},:).*mpo(index{i},:) + ui(index{i},1:D).*mui(index{i},1:D);      % crossover
        end
        if i==2
            ui(index{i},1:D) = bm(index{i},:) + F.*(pm1(index{i},:) - pm2(index{i},:) + pm3(index{i},:) - pm4(index{i},:));       % differential variation
            ui(index{i},1:D) = popold(index{i},:).*mpo(index{i},:) + ui(index{i},1:D).*mui(index{i},1:D);      % crossover
        end
        if i==4
            F=[];
            m=length(index{i});       
            tol=0.5;
            F=0.5.*exp(tol.*(normrnd(0,1,m,1)-tol/2));
            F=repmat(F,1,D);
            ui(index{i},1:D) = popold(index{i},:) + 0.6.*(pm5(index{i},:)-popold(index{i},:)) + F.*(pm1(index{i},:) - pm2(index{i},:));       % differential variation
            %                 ui(index{i},:) = popold(index{i},:).*mpo(index{i},:) + ui(index{i},:).*mui(index{i},:);     % crossover
        end        
        if i==5
            ui(index{i},1:D) = popold(index{i},:) + F.*(bm(index{i},:)-popold(index{i},:)) + F.*(pm1(index{i},:) - pm2(index{i},:) + pm3(index{i},:) - pm4(index{i},:));       % differential variation
            ui(index{i},1:D) = popold(index{i},:).*mpo(index{i},:) + ui(index{i},1:D).*mui(index{i},1:D);     % crossover
        end
    end
    
    
    outcount=0; 
    for i=1:NP
        %         while ~isempty(find(ui(i,:) < Lbound)) | ~isempty(find(ui(i,:) > Ubound))
        outLbind=find(ui(i,1:D) < Lbound);
        if size(outLbind,2)~=0
            %                         %                Periodica
            %ui(i,outLbind)=2*XRmin(outLbind)-ui(i,outLbind);
            %             %                         % bound back
            %ui(i,outLbind)=popold(i,outLbind)+(XRmin(outLbind)-popold(i,outLbind)).*rand(1,size(outLbind,2));
            % Random
            ui(i,outLbind)=XRmin(outLbind)+(XRmax(outLbind)-XRmin(outLbind)).*rand(1,size(outLbind,2));
            %                         %fixed
            %            ui(i,outLbind)=XRmin(outLbind);
            
        end
        outUbind=find(ui(i,1:D) > Ubound);
        if size(outUbind,2)~=0
            %                         % Periodica
            %ui(i,outUbind)=2*XRmax(outUbind)-ui(i,outUbind);
            %                         % Bound back
            %ui(i,outUbind)=popold(i,outUbind)+(XRmax(outUbind)-popold(i,outUbind)).*rand(1,size(outUbind,2));
            %             %             % Random            
            ui(i,outUbind)=XRmin(outUbind)+(XRmax(outUbind)-XRmin(outUbind)).*rand(1,size(outUbind,2));
            % ui(i,outUbind)=XRmax(outUbind);
        end
        if size(outLbind,2)~=0 | size(outUbind,2)~=0
            outcount=outcount+1;         
        end
    end
    outnum(iter+1)=outcount;
    
    %----------fitness evaluation
    for i=1:NP
        ui(i,D+1:D+n_obj) = feval(fname,ui(i,1:D),n_obj,func);   % check cost of competitor
        nfeval  = nfeval + 1;
    end
    
    for i=1:NP
        dist=sum((pop(:,1:D)-repmat(ui(i,1:D),NP,1)).^2,2);
        [junk,near_idx]=min(dist);
        %         near_idx=i;
        f1=pop(near_idx,D+1:D+n_obj)-ui(i,D+1:D+n_obj)<=0;
        f2=pop(near_idx,D+1:D+n_obj)-ui(i,D+1:D+n_obj)<0;
        f3=pop(near_idx,D+1:D+n_obj)-ui(i,D+1:D+n_obj)<err;        
        
        f4=ui(i,D+1:D+n_obj)-pop(near_idx,D+1:D+n_obj)<=0;
        f5=ui(i,D+1:D+n_obj)-pop(near_idx,D+1:D+n_obj) <0;
        f6=ui(i,D+1:D+n_obj)-pop(near_idx,D+1:D+n_obj) <err;
        
        %         f7=pop(near_idx,D+1:D+n_obj)-ui(i,D+1:D+n_obj)<-err;
        %         f8=ui(i,D+1:D+n_obj)-pop(near_idx,D+1:D+n_obj)<-err;
        %         if (sum(f1)==n_obj)&(sum(f7)>0)
        if ((sum(f1)==n_obj)&(sum(f2)>0))|((sum(f3)==n_obj)&(sum(f6)<n_obj)), %parent dominates child
            n_flag(near_idx)=1;
            tnpcount=zeros(1,numst);
            for j=1:numst
                temp=aaa{j};
                tnpcount(j)=temp(i);
            end
            npcount=[npcount;tnpcount];
            %         elseif (sum(f4)==n_obj)&(sum(f8)>0)   
        elseif ((sum(f4)==n_obj)&(sum(f5)>0))|((sum(f6)==n_obj)&(sum(f3)<n_obj)),% child dominates parent
            pop(near_idx,:)=ui(i,:);     
            n_flag(near_idx)=0;
            tlpcount=zeros(1,numst);
            for j=1:numst
                temp=aaa{j};
                tlpcount(j)=temp(i);
                if tlpcount(j)==1
                    aaaa{j}=[aaaa{j};cc(i,j) iter];  
                end
            end
            lpcount=[lpcount;tlpcount];  
            %             [ins_stat,del_stat,del_list]=PADE_ins_del_con(rep,ui(i,:),D,n_obj,err_tol);
            [ins_stat,del_stat,del_list]=PADE_nondom_ins_del(rep(:,1:D+n_obj),ui(i,:),D,n_obj,epsilon,err);
            if del_stat==1,
                [rep,rep_size]=matdelete(rep,del_list(2:length(del_list)));
            end
            if ins_stat==1, %enter the rep
                rep=[rep;ui(i,:) 0];
            end
            
        else                            % nondominated
            %[lp,np]=fuzzy_non_dom(pop(i,D+1:D+n_obj),ui(i,D+1:D+n_obj),n_obj);
            f=crowding_dis_rep(pop(near_idx,:),ui(i,:),rep(:,1:D+n_obj),D,n_obj,Lbound,Ubound,err);
            %             f=crowded_rep2(pop(i,:),ui(i,:),rep(:,1:D+n_obj),D,n_obj);            
            if f==1,                    
                pop(near_idx,:)=ui(i,:);  
                n_flag(near_idx)=0;
                tlpcount=zeros(1,numst);
                for j=1:numst
                    temp=aaa{j};
                    tlpcount(j)=temp(i);
                    if tlpcount(j)==1
                        aaaa{j}=[aaaa{j};cc(i,j) iter];  
                    end
                end
                lpcount=[lpcount;tlpcount]; 
            else
                tnpcount=zeros(1,numst);
                for j=1:numst
                    temp=aaa{j};
                    tnpcount(j)=temp(i);
                end
                npcount=[npcount;tnpcount];
            end
            %[ins_stat,del_stat,del_list]=PADE_ins_del_con(rep,ui(i,:),D,n_obj,err_tol);
            [ins_stat,del_stat,del_list]=PADE_nondom_ins_del(rep(:,1:D+n_obj),ui(i,:),D,n_obj,epsilon,err);
            if del_stat==1,
                [rep,rep_size]=matdelete(rep,del_list(2:length(del_list)));
            end
            if ins_stat==1, %enter the rep
                rep=[rep;ui(i,:) 0];
            end
        end        
        
        if nfeval+1 > Max_FES
            pfithist = [pfithist;[iter+2,pfit/sum(pfit)]];
            ccmhist = [ccmhist;[iter+2,ccm]];
            return;
        end
        
    end %---end for imember=1:NP
    
    fmin=min(rep(:,D+1:D+n_obj),[],1);
    fmax=max(rep(:,D+1:D+n_obj),[],1);
    %     epsilon=0.00001.*(fmax-fmin);
    err=0.0001.*(fmax-fmin);    
    
    if size(rep,1)>1
        f_range=fmax-fmin;
    else
        f_range=rand(1,n_obj);
    end
    ls_r=f_range./sum(f_range);
    
    if (rem(iter,200) == 0) & (iter>0)&(localflag==1)
        %         localpoolsize = ceil(0.2*rep_size);
        localpoolsize = 10;
        idx=[];
        zero_idx=[];
        if sum(1-rep(:,D+n_obj+1))~=0
            zero_idx = find(rep(:,D+n_obj+1)==0);
            if length(zero_idx)>=localpoolsize,
                junk=randperm(length(zero_idx));
                idx=zero_idx(junk(1:localpoolsize));
                localpool=rep(idx,1:D+n_obj);
                rep(idx,D+n_obj+1)=1;
            else
                other=localpoolsize-length(zero_idx);
                junk2=randperm(NP);
                pop_idx=junk2(1:other);
                localpool=[rep(zero_idx,1:D+n_obj);pop(pop_idx,:)];
                rep(zero_idx,D+n_obj+1)=1;
            end
        else
            rep(:,D+n_obj+1)
            junk3=randperm(NP);
            pop_idx=junk3(1:localpoolsize);
            localpool=pop(pop_idx,:);
        end
        
        rr=rand;
        spacing=1/localpoolsize;
        randnums=sort(mod(rr:spacing:1+rr-0.5*spacing,1));  
        
        psum=0;
        count(1)=0;
        stpool=[];
        for i=1:length(ls_r)
            psum=psum+ls_r(i);
            count(i+1)=length(find(randnums<psum));
            select(i,1)=count(i+1)-count(i);
            stpool=[stpool;ones(select(i,1),1)*i];
        end
        stpool = stpool(randperm(localpoolsize));
        
        for i=1:n_obj
            atemp=zeros(1,localpoolsize);
            aaa{i}=atemp;
            index{i}=[];
            if ~isempty(find(stpool == i))
                index{i} = find(stpool == i);
                atemp(index{i})=1;
                aaa{i}=atemp;
            end
        end
        L_arch=[];
        for i=1:n_obj
            for j=1:length(index{i})
                ls_ind=index{i}(j); 
                [temppop,tempnf,kcount] = MOlocalsearch2(fname,localpool(ls_ind,1:D),n_obj,func,i,XRmin,XRmax);
                nfeval = nfeval + tempnf;                    
                
                f1=localpool(ls_ind,D+1:D+n_obj)-temppop(D+1:D+n_obj)<=0;
                f2=localpool(ls_ind,D+1:D+n_obj)-temppop(D+1:D+n_obj)<0;
                f3=localpool(ls_ind,D+1:D+n_obj)-temppop(D+1:D+n_obj)<err;
                f4=temppop(D+1:D+n_obj)-localpool(ls_ind,D+1:D+n_obj)<err;
                
                if((sum(f1)==n_obj)&(sum(f2)>0))|((sum(f3)==n_obj)&(sum(f4)<n_obj)),
                else                        
                    L_arch=[L_arch;temppop];
                end
            end
        end
        for i=1:size(L_arch,1);
            [ins_stat,del_stat,del_list]=PADE_nondom_ins_del(rep(:,1:D+n_obj),L_arch(i,:),D,n_obj,epsilon,err);
            if del_stat==1,
                [rep,rep_size]=matdelete(rep,del_list(2:length(del_list)));
            end
            if ins_stat==1, %enter the rep
                rep=[rep;L_arch(i,:) 0];
            end
        end                          
    end   
    
    if (size(rep,1)>max_rep_size)        
        %         Indexvalue=DBDCD_MOGA22(rep(:,D+1:D+n_obj),3,max_rep_size);
        %         rep=rep(Indexvalue(1:max_rep_size),:);
        rep=mopso_crowding_distance(rep,D,n_obj,max_rep_size);
        rep=rep(1:max_rep_size,:);        
    end
    if (nfeval>3e+3 & nfeval<5e+3)|(nfeval>4e+4 & nfeval<5e+4)|(nfeval>4.9e+5 & nfeval<5e+5)
        max_rep_size=800;
    else
        max_rep_size=300;
    end
    if nfeval>=5e+3 & flag1==1
        rep1=rep;
        flag1=0;         
    elseif nfeval>=5e+4 & flag2==1
        rep2=rep;
        flag2=0;
    end 
    
    pfithist = [pfithist;[iter+2,pfit/sum(pfit)]];
    ccmhist = [ccmhist;[iter+2,ccm]];
    ns=[ns;sum(lpcount,1)];
    nf=[nf;sum(npcount,1)];    
    
    if iter >= learngen;        
        for i=1:numst            
            if (sum(ns(:,i))+sum(nf(:,i))) == 0
                pfit(i) = 0.01;
            else
                pfit(i) = sum(ns(:,i))/(sum(ns(:,i))+ sum(nf(:,i))) + 0.01;
            end
        end
        if ~isempty(ns), ns(1,:)=[];   end
        if ~isempty(nf), nf(1,:)=[];   end
    end   
    
    iter = iter + 1;
    
    if (round(iter/50)==iter/50) & (drawflag==1),
        subplot(2,1,1);
        if n_obj==2
            plot(rep(:,D+1),rep(:,D+2),'r.');
        else
            plot3(rep(:,D+1),rep(:,D+2),rep(:,D+3),'r.');
        end        
        title(['lp:',num2str(sum(lpcount(:,1))) ' np:',num2str(sum(npcount(:,1))) ' generation:',num2str(iter)])
        subplot(2,1,2);
        plot(pop(:,1),pop(:,2),'b*');            
        drawnow
    end
end %---end while ((iter < Max_Gen) ...
% PF=rep(:,n+1:n+n_obj);
% % plot3(PF(:,1),PF(:,2),PF(:,3),'r.');
% % xlabel('f1');ylabel('f2');zlabel('f3');
% plot(PF(:,1),PF(:,2),'r.');