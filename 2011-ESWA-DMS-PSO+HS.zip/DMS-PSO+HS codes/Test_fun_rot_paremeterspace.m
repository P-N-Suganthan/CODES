%test_frame
clear all
% close all
global orthm best_f best_keep initial_flag
rand('state',sum(100*clock));
warning off
fhd=str2func('TEC_test_function');%fun,VRmin,VRmax,gbias,norm_flag,shift_flag

me=2000;
ps=50;
Max_FES=ps*me;
D=10;
norm_flag=0;
shift_flag=0;

orthm=diag(ones(1,D));

VRmin=[-100,-2.048,-32.768,-600,-5.12,-5.12,-500,-0.5,-2.048,-100,-1,-5,-5,-5,-5];
VRmax=-VRmin;
if norm_flag==1;
    VRminn=zeros(1,D);
    VRmaxn=ones(1,D)
else
    VRminn=VRmin;VRmaxn=VRmax;
end
funchoose=[3,4,6];
for funnum=1:3%length(funchoose)
fun=funchoose(funnum);
initial_flag=0;
for run=1:30
   orthm=orthm_generator(D); 
if shift_flag==1
    gbias=0.8.*(VRmin(fun)+(VRmax(fun)-VRmin(fun)).*rand(1,D));
    if fun==2
        gbias=-1+(1+1).*rand(1,D);
    end
    if fun==7
        gbias=-500+(0+500).*rand(1,D);
    end
else
    gbias=zeros(1,D);
end
fun,run
[DMS_PSO_HS_func_gbest,DMS_PSO_HS_func_gbestval,DMS_PSO_HS_func_fitcount]= DMS_PSO_HS_func(fhd,fun,err0,err1,Max_FES,group_num,Particle_Number,D,VRminn(fun),VRmaxn(fun),fun,VRmin(fun),VRmax(fun),gbias,norm_flag,shift_flag);
DMS_PSO_HS_func_gbestval
DMS_PSO_HS_func_fitcount_res(fun,run)=DMS_PSO_HS_func_fitcount;DMS_PSO_HS_func_gbestval_res(fun,run)=DMS_PSO_HS_func_gbestval;DMS_PSO_HS_func_gbest_res(fun,run,:)=DMS_PSO_HS_func_gbest;
end

end
mean(DMS_PSO_HS_func_gbestval_res')
