function OPE_MOEA(Global)
% <algorithm> <A-G>
    % load the parameters for evolution
    [paramsMOEAD, Population] = loadMOEADparams(Global);
    
    iteration = 0;
    memoryNum = 8; % F3: 12
    forwardDistanceMatrix = ones(paramsMOEAD.popuSize, memoryNum);
    
    switch class(Global.problem)
        case {'DTLZ1'}
            CW = 5;
        case {'DTLZ2'}
            CW = 0.5;
        case {'DTLZ3'}
            CW = 10;
        case {'DTLZ4'}
            CW = 0.5;
        otherwise
            CW = 0.5;  
    end
    
    %% Optimization
    Population = Population(1: paramsMOEAD.popuSize);
    IGDA = []; % Record the change of IGD values
    while Global.NotTermination(Population)
        
         % The evolve probability for each subarea
        totalForwardDistanceArray = sum(forwardDistanceMatrix, 2); % The forward distance of a subarea  
        forwardIndex = find(totalForwardDistanceArray > 0);    
        nonZeroNum = numel(forwardIndex);  
        if nonZeroNum == 0
            totalForwardDistanceArray(1: end) = 1;
            averageDistance = 1;
        else
            averageDistance = sum(totalForwardDistanceArray)/nonZeroNum;
        end
        
        
        switch class(Global.problem)
            case {'MOEADDE_F1'}
                factor = 0.02;  % 0.05
            case {  'MOEADDE_F4', 'MOEADDE_F5', 'MOEADDE_F6', 'MOEADDE_F7',  'MOEADDE_F8', 'MOEADDE_F9' }  %  F3 0.2 0.1
                factor = 0.1;
            case { 'MOEADDE_F2' }
                factor = 0.07; % + 0.1*(iteration/ceil(paramsMOEAD.evaluationUpper/paramsMOEAD.popuSize)); % 0.13
            case { 'MOEADDE_F3' }
                factor = 0.08;
            otherwise
                factor = 0.04 + 0.6*(1 - iteration/ceil(paramsMOEAD.evaluationUpper/paramsMOEAD.popuSize)); % 0.13
        end        
        
        defaultDistance = averageDistance*factor;  % Improtant F3 0.2 0.1 F1 0.05
        nonForwardIndex = find(totalForwardDistanceArray <= 0);
        totalForwardDistanceArray(nonForwardIndex) = repmat(defaultDistance, numel(nonForwardIndex), 1);
        
        probability = totalForwardDistanceArray'./sum(totalForwardDistanceArray); % Probability for each subarea
        cdfArray = cumsum(probability, 2); % Accumulative probability
        
        %% Evolve each subarea
        paramsMOEAD.iteration = iteration + 1;
        forwardDistanceArray = zeros(paramsMOEAD.popuSize, 1); %Record the forward distacne of each sub-space
        newObjMatrix = zeros(paramsMOEAD.popuSize, Global.M);
        defaultDiverDistance = 1; % 0.1*sum(forwardDistanceMatrix(:, 1+mod(paramsMOEAD.iteration-1, memoryNum))); % Default distance for solutions entering new sub-space
        for subInteIndex = 1: paramsMOEAD.popuSize
            %% Select a sub-space
            randomNum = rand();
            selectedSubAreaIndex = 1; % Index of the subarea
            for index = 1: size(cdfArray, 2)
                if cdfArray(index) >= randomNum
                    selectedSubAreaIndex = index;
                    break;
                end
            end
            
            %% Select parents
            useneighbour = true; % ????false
            %parentPositionMatrix = mateSelection(selectedSubAreaIndex, 3, useneighbour, paramsMOEAD);
            parentNum = 3;
            if strcmp(class(Global.problem), 'MOEADDE_F3')
                parentNum = 4;
            end
            parentPositionMatrix = MateSelection(selectedSubAreaIndex, parentNum, useneighbour, paramsMOEAD); % F3: 4            
            if size(parentPositionMatrix, 1) < parentNum
                continue;
            end
                        
            %% Apply DE to evolve the solution
            newpoint = DE_PM(Global, parentPositionMatrix, paramsMOEAD.CR);
            newSolution = INDIVIDUAL(newpoint); % Obtain the objective vector
            newpoint = newSolution.dec;            
            realObjArray = newSolution.obj; %tempObjA';
            
            newObjMatrix(subInteIndex, :) = realObjArray;
            
            %% The ideal point
            idealPoint = zeros(1, Global.M); %???
            if strcmp(class(Global.problem), 'ZDT3')
                idealPoint = [0 -2]; %????ZDT3
            end
            
            %% Associate the new solution to a sub-space
            objArray = realObjArray - idealPoint;
            angleArray = acos(1-pdist2(objArray, paramsMOEAD.subProbWeight, 'cosine'));
            [~, subAreaIndex] = min(angleArray);
            
            existSolutionNum = size(paramsMOEAD.population(subAreaIndex).SubAreaIndexArray, 1);
            paramsMOEAD.population(subAreaIndex).SubAreaIndexArray = ones(existSolutionNum, 1) * -1;
            
            paramsMOEAD.population(subAreaIndex).PositionMatrix = [paramsMOEAD.population(subAreaIndex).PositionMatrix
                newpoint]; % Add the decision vector
            paramsMOEAD.population(subAreaIndex).ObjectiveMatrix = [paramsMOEAD.population(subAreaIndex).ObjectiveMatrix
                realObjArray]; % Add the objective vector
            
            paramsMOEAD.population(subAreaIndex).SubPop = [paramsMOEAD.population(subAreaIndex).SubPop, newSolution]; % Record the solution
            
            paramsMOEAD.population(subAreaIndex).SubAreaIndexArray = [paramsMOEAD.population(subAreaIndex).SubAreaIndexArray
                selectedSubAreaIndex]; % Add the index of source sub-space
            
            %% Calculate the forward distance
            distanceForNewArea = defaultDiverDistance; %1; % Default forward distance for enterring empty sub-space 
            subAreaObjMatrix = paramsMOEAD.population(subAreaIndex).ObjectiveMatrix; %Obtain the objective vectors
            objNum = size(subAreaObjMatrix, 1); % 
            
            weight = paramsMOEAD.subProbWeight(subAreaIndex, :);
            
            if objNum == 1 % The sub-space only has one solution
                
                tempObjs = subAreaObjMatrix - repmat(idealPoint, objNum, 1);
                CosVectorOri = 1-pdist2(tempObjs, weight, 'cosine');
                SinVectorOri = sqrt(1 - CosVectorOri.^2);
                Fitness = sqrt(sum(tempObjs.^2, 2)).*CosVectorOri + CW*sqrt(sum(tempObjs.^2, 2)).*SinVectorOri;
                paramsMOEAD.population(subAreaIndex).Distance = min(Fitness);
                
                forwardDistanceArray(selectedSubAreaIndex) = forwardDistanceArray(selectedSubAreaIndex) + distanceForNewArea;

            elseif objNum >= 2 % The sub-space only has at least two solutions
                %% Identify the dominated solutions
                dominatedTag = false(1, objNum); %
                for objIndex = 1: objNum-1
                    if dominatedTag(objIndex)
                        continue;
                    end
                    
                    for compObjIndex = 2: objNum
                        firstObjArray = subAreaObjMatrix(objIndex, :);
                        secondObjArray = subAreaObjMatrix(compObjIndex, :);
                        
                        if all(firstObjArray >= secondObjArray) && any(firstObjArray > secondObjArray)
                            dominatedTag(objIndex) = true;
                            break;
                        end
                        
                        if all(firstObjArray <= secondObjArray) && any(firstObjArray < secondObjArray)
                            dominatedTag(compObjIndex) = true;
                        end
                    end
                end
                
                %% Removed the dominated solutions
                dominatedIndexArray = find(dominatedTag == true);
                paramsMOEAD.population(subAreaIndex).ObjectiveMatrix(dominatedIndexArray, :) = [];
                paramsMOEAD.population(subAreaIndex).PositionMatrix(dominatedIndexArray, :) = [];
                
                tempSubPop = paramsMOEAD.population(subAreaIndex).SubPop;
                paramsMOEAD.population(subAreaIndex).SubPop = tempSubPop(~dominatedTag);
                
                paramsMOEAD.population(subAreaIndex).SubAreaIndexArray(dominatedIndexArray, :) = [];
                
                %% Remove the surplus solutions and calculated the forward distance
                nonDominatedNum = size(paramsMOEAD.population(subAreaIndex).ObjectiveMatrix, 1); % Number of non-dominated solutions
                if nonDominatedNum > paramsMOEAD.maxNonDomiSoluNum  % Number of retained solutions is larger than a threshold
                    
                    subAreaObjMatrix = paramsMOEAD.population(subAreaIndex).ObjectiveMatrix;
                    tempObjs = subAreaObjMatrix - repmat(idealPoint, nonDominatedNum, 1);
                    CosVectorOri = 1-pdist2(tempObjs, weight, 'cosine');
                    SinVectorOri = sqrt(1 - CosVectorOri.^2);
                    distanceArray = sqrt(sum(tempObjs.^2, 2)).*CosVectorOri + CW*sqrt(sum(tempObjs.^2, 2)).*SinVectorOri;
                    
                    
                    [~, rank] = sort(distanceArray);
                    paramsMOEAD.population(subAreaIndex).ObjectiveMatrix = paramsMOEAD.population(subAreaIndex).ObjectiveMatrix(rank(1: paramsMOEAD.maxNonDomiSoluNum), :);
                    paramsMOEAD.population(subAreaIndex).PositionMatrix = paramsMOEAD.population(subAreaIndex).PositionMatrix(rank(1: paramsMOEAD.maxNonDomiSoluNum), :);
                    
                    tempSubPop = paramsMOEAD.population(subAreaIndex).SubPop;
                    paramsMOEAD.population(subAreaIndex).SubPop = tempSubPop(rank(1: paramsMOEAD.maxNonDomiSoluNum));
                    
                    paramsMOEAD.population(subAreaIndex).SubAreaIndexArray = paramsMOEAD.population(subAreaIndex).SubAreaIndexArray(rank(1: paramsMOEAD.maxNonDomiSoluNum), :);
                    
                    oldDistance = paramsMOEAD.population(subAreaIndex).Distance;
                    
                    % % Re-write !!!!  Current distance
                    paramsMOEAD.population(subAreaIndex).Distance = min(distanceArray); %sqrt(sum((paramsMOEAD.population(subAreaIndex).ObjectiveMatrix(1, :) - idealPoint).^2));                    
                    sourceSubAreaIndex = paramsMOEAD.population(subAreaIndex).SubAreaIndexArray(1);
                    
                    if sourceSubAreaIndex ~= -1
                        if isempty(oldDistance)
                            forwardDistance = distanceForNewArea;
                        else
                            forwardDistance = oldDistance - paramsMOEAD.population(subAreaIndex).Distance;
                        end
                        
                        if sourceSubAreaIndex ~= selectedSubAreaIndex
                            error('this is an error'); %???????????????
                        end
                        
                        if forwardDistance > 0
                            forwardDistanceArray(sourceSubAreaIndex) = forwardDistanceArray(sourceSubAreaIndex) + forwardDistance; 
                        end
                    end
                    
                else
                    oldDistance = paramsMOEAD.population(subAreaIndex).Distance;
                    
                    subAreaObjMatrix = paramsMOEAD.population(subAreaIndex).ObjectiveMatrix;
                    tempObjs = subAreaObjMatrix - repmat(idealPoint, nonDominatedNum, 1);
                    CosVectorOri = 1-pdist2(tempObjs, weight, 'cosine');
                    SinVectorOri = sqrt(1 - CosVectorOri.^2);
                    distanceArray = sqrt(sum(tempObjs.^2, 2)).*CosVectorOri + CW*sqrt(sum(tempObjs.^2, 2)).*SinVectorOri;
                    paramsMOEAD.population(subAreaIndex).Distance = min(distanceArray);
                    [~, rank] = sort(distanceArray);
                    
                    sourceSubAreaIndex = paramsMOEAD.population(subAreaIndex).SubAreaIndexArray(rank(1));
                    if sourceSubAreaIndex ~= -1
                        if isempty(oldDistance)
                            forwardDistance = distanceForNewArea;
                        else
                            forwardDistance = oldDistance - paramsMOEAD.population(subAreaIndex).Distance;
                        end
                        
                        
                        if sourceSubAreaIndex ~= selectedSubAreaIndex
                            error('this is an error');
                        end
                        
                        if forwardDistance > 0
                            forwardDistanceArray(sourceSubAreaIndex) = forwardDistanceArray(sourceSubAreaIndex) + forwardDistance;
                        end
                        
                    end
                end
            end
            
        end
        % Update the forward distance matrix
        updateIndex = mod(iteration, memoryNum);
        forwardDistanceMatrix(:, updateIndex+1) = forwardDistanceArray; % Record the current forward distance
        iteration = iteration + 1;
        
        
        %% Select a population from each sub-space
        Population = []; % Record the selected solutions        
        CanSolutionSet = []; % Record the un-selected solutions
        for Index = 1: numel(paramsMOEAD.population)
            SubPop = paramsMOEAD.population(Index).SubPop;
            if ~isempty(SubPop)                
                tempObjs = SubPop.objs;
                weight = paramsMOEAD.subProbWeight(Index, :);
                CosVectorOri = 1-pdist2(tempObjs, weight, 'cosine');
                SinVectorOri = sqrt(1 - CosVectorOri.^2);
                distanceArray = sqrt(sum(tempObjs.^2, 2)).*CosVectorOri + CW*sqrt(sum(tempObjs.^2, 2)).*SinVectorOri;
                [~, I] = sort(distanceArray);
                
                Population = [Population, SubPop(I(1))];
                if numel(I) > 1
                    CanSolutionSet = [CanSolutionSet, SubPop(I(2: end))];
                end
            end
        end
        % Remove dominated solution
        CombinePop = [Population, CanSolutionSet];
        [FrontNo, ~] = NDSort(CombinePop.objs, Global.N);
        CanI = FrontNo==1; % Index of candidate solutions
        SelI = CanI + [ones(1, numel(Population)), zeros(1, numel(CanSolutionSet))];
        RealCanI = CanI + [zeros(1, numel(Population)), ones(1, numel(CanSolutionSet))];
        
        Population = CombinePop(SelI == 2);
        RealCandidateSet = CombinePop(RealCanI == 2);
        
        CanCombinePop = [Population, RealCandidateSet];
        if numel(CanCombinePop) <= Global.N
            Population = CanCombinePop;
        else % Select solutions based on acute angle
            PopObj = CanCombinePop.objs;
            % Normalization
            Zmin   = min(PopObj, [], 1);
            Zmax   = max(PopObj, [], 1);
            PopObj = (PopObj-repmat(Zmin,size(PopObj,1),1))./repmat(Zmax-Zmin,size(PopObj,1),1);
            
            Next = [true(1, numel(Population)), false(1, numel(RealCandidateSet))];
            % Select remaining solutions based on angle
            angle = acos(1-pdist2(PopObj, PopObj, 'cosine'));
            while sum(Next) < Global.N || sum(Next) == length(Next)
                Select  = find(Next);
                Remain  = find(~Next);
                [~, rho] = max(min(angle(Remain, Select), [], 2));
                Next(Remain(rho)) = true;
            end
            Population = CanCombinePop(Next);
        end       
    end
end