% select the candidate for evoluationary mating, i.e. finding the DE parent.
function selectedParentsPositionMatrix = MateSelection(selectedSubAreaIndex, parentSize, useNeighbour, paramsMOEAD)
    % Ϊ������ѡ������ĸ��ڵ�
    selectedParentsPositionMatrix = []; %��ʼ��ѡ���ĸ��ڵ��������
    selectedObjArray = [];
    
    if useNeighbour        
        bigPositionMatrix = []; 
        bigObjectiveMatrix = [];
        
        
        allindex = paramsMOEAD.neighborRelation(1: paramsMOEAD.Tm, selectedSubAreaIndex);        
        for neighbourIndex = 1: numel(allindex)
            neighbourSubAreaIndex = allindex(neighbourIndex);
            
%             A = [1 0]; B = [0 1];
%             if any(paramsMOEAD.subProbWeight(neighbourSubAreaIndex, :) == A) || all(paramsMOEAD.subProbWeight(neighbourSubAreaIndex, :) == B)
%                 continue; %MOP1 �������������Ч����Щ
%             end
%              
            subAreaObjectiveMatrix = paramsMOEAD.population(neighbourSubAreaIndex).ObjectiveMatrix;
            if neighbourSubAreaIndex == selectedSubAreaIndex && size(subAreaObjectiveMatrix, 1) ~= 0 %�����������Ⱦɫ��Ϊ��ѡ                
                fitnessArray = subAreaObjectiveMatrix * paramsMOEAD.subProbWeight(neighbourSubAreaIndex, :)';
                %fitnessArray = 2.^fitnessArray;
                probability = fitnessArray./sum(fitnessArray); %��ʼ��ѡ��ÿ��������ĸ���  
                cdfArray = cumsum(probability, 2); %�ۼƸ���
                randomNum = rand();               
                solutionIndex = 1;
                for index = 1: size(subAreaObjectiveMatrix, 1)
                    if randomNum < cdfArray(index)
                        solutionIndex = index;
                    end
                end
                selectedParentsPositionMatrix  = paramsMOEAD.population(neighbourSubAreaIndex).PositionMatrix(solutionIndex, :);
                selectedObjArray = subAreaObjectiveMatrix(solutionIndex, :);
            end
            
            bigPositionMatrix = [bigPositionMatrix
                paramsMOEAD.population(neighbourSubAreaIndex).PositionMatrix];
            bigObjectiveMatrix = [bigObjectiveMatrix 
                paramsMOEAD.population(neighbourSubAreaIndex).ObjectiveMatrix];
           


            
%             subAreaObjectiveMatrix = paramsMOEAD.population(neighbourSubAreaIndex).ObjectiveMatrix;
%             if size(subAreaObjectiveMatrix, 1) > 0
%                 fitnessArray = subAreaObjectiveMatrix * paramsMOEAD.subProbWeight(neighbourSubAreaIndex, :)';
%                 fitnessArray = 2.^fitnessArray;
%                 probability = fitnessArray./sum(fitnessArray); %��ʼ��ѡ��ÿ��������ĸ���  
%                 cdfArray = cumsum(probability, 2); %�ۼƸ���
%                 randomNum = rand();               
%                 solutionIndex = 1;
%                 for index = 1: size(subAreaObjectiveMatrix, 1)
%                     if randomNum < cdfArray(index)
%                         solutionIndex = index;
%                     end
%                 end
% 
%                 %[~, solutionIndex] = min(fitnessArray);
%                 
%                 if neighbourSubAreaIndex == selectedSubAreaIndex %�����������Ⱦɫ��Ϊ��ѡ
%                     selectedParentsPositionMatrix = paramsMOEAD.population(neighbourSubAreaIndex).PositionMatrix(solutionIndex, :);
%                     selectedObjArray = paramsMOEAD.population(neighbourSubAreaIndex).ObjectiveMatrix(solutionIndex, :);
%                 else
%                     bigPositionMatrix = [bigPositionMatrix
%                         paramsMOEAD.population(neighbourSubAreaIndex).PositionMatrix(solutionIndex, :)];
%                     bigObjectiveMatrix = [bigObjectiveMatrix
%                         paramsMOEAD.population(neighbourSubAreaIndex).ObjectiveMatrix(solutionIndex, :)];
%                 end                
%             end  
            
        end        
        %[candidatePosition, ~, ~] = unique(bigPositionMatrix,'rows','first');   
    else        
        parentindex = 1: paramsMOEAD.popuSize; %%���������Ƿ���������
    end
    
    % ֱ���ҳ�parentSize��Ⱦɫ��
    if isempty(selectedObjArray) && ~isempty(bigObjectiveMatrix) % ���ѡ���������Ϊ�գ���ѡ�������һ����
        selectedObjArray = bigObjectiveMatrix(1, :);
        selectedParentsPositionMatrix = bigPositionMatrix(1, :);
        
        bigObjectiveMatrix = bigObjectiveMatrix(2: size(bigObjectiveMatrix, 1), :); 
        bigPositionMatrix = bigPositionMatrix(2: size(bigPositionMatrix, 1), :);
    end
    
    % �ѱ�selectedObjArray֧��Ľⶼȥ��
    dominatedTag = false(size(bigPositionMatrix, 1), 1);
    initEcluDistanceArray = ones(size(bigPositionMatrix, 1), 1); %ѡ����Ŀ������ �� ����Ŀ�������ľ���
    for bigMatrixIndex = 1: size(bigPositionMatrix, 1)
        if all(selectedObjArray <= bigObjectiveMatrix(bigMatrixIndex, :) ) && any(selectedObjArray < bigObjectiveMatrix(bigMatrixIndex, :) )
            dominatedTag(bigMatrixIndex) = true;
            
            initEcluDistanceArray(bigMatrixIndex) = sqrt(sum((selectedObjArray-bigObjectiveMatrix(bigMatrixIndex, :)).^2));
            
        end
    end
    surviveIndexArray = dominatedTag == false;
    candidatePosition = bigPositionMatrix(surviveIndexArray, :);
    initEcluDistanceArray = initEcluDistanceArray(surviveIndexArray);
    
    
    initEcluDistanceArray = 3.^initEcluDistanceArray; %�Ƿ���Ҫ�޸ģ�����
    
    
    
    probArray = initEcluDistanceArray./sum(initEcluDistanceArray);
    cdfArray = cumsum(probArray, 1)'; %�ۼƸ���
    
    selectedParentsIndex = [];
    while (length(selectedParentsIndex) < (parentSize-1)) && size(candidatePosition, 1) >= (parentSize - 1) 
        randomNum = rand;
        
        parentIndex = 1; %�����ӿռ������                                                      
        for index = 1: size(cdfArray, 2)                                                                            
            if cdfArray(index) >= randomNum                                                                                                
                parentIndex = index;                                                                                               
                break;                                                                            
            end            
        end
        
        %parentIndex = ceil(size(candidatePosition, 1)*r);
        if ~any(ismember(parentIndex, selectedParentsIndex)) %ѡ�����ظ��ĸ���Ⱦɫ��         
             selectedParentsIndex = [selectedParentsIndex parentIndex];
        end     
    end
    
    selectedParentsPositionMatrix = [selectedParentsPositionMatrix
        candidatePosition(selectedParentsIndex', :)];
    
%     if size(candidatePosition, 1) < parentSize
%         selectedParentsPositionMatrix = [selectedParentsPositionMatrix
%             rand(parentSize-size(selectedParentsPositionMatrix, 1), size(paramsMOEAD.varDomain, 2))];
%     end
    
    
end