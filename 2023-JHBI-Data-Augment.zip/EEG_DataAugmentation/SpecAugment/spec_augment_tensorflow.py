# Copyright 2019 RnD at Spoon Radio
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
"""SpecAugment Implementation for Tensorflow.
Related paper : https://arxiv.org/pdf/1904.08779.pdf
"""

import librosa
import librosa.display
import tensorflow as tf
from tensorflow_addons.image import sparse_image_warp
import numpy as np
import matplotlib.pyplot as plt


def sparse_warp(data, time_warping_para=30):
    fbank_size = tf.shape(data)
    n, v = fbank_size[1], fbank_size[2]
    pt = v

    src_ctr_pt_freq = tf.range(n//2)  # control points on freq-axis
    src_ctr_pt_time = tf.ones_like(src_ctr_pt_freq) * pt  # control points on time-axis
    # src_ctr_pts = tf.stack((src_ctr_pt_time, src_ctr_pt_freq), -1)
    src_ctr_pts = tf.stack((src_ctr_pt_freq, src_ctr_pt_time), -1)
    src_ctr_pts = tf.cast(src_ctr_pts, dtype=tf.float32)

    # Destination
    w = tf.random.uniform([], -time_warping_para, time_warping_para, tf.int32)  # distance
    print('w: {}'.format(w))
    # w = 10
    dest_ctr_pt_freq = src_ctr_pt_freq
    dest_ctr_pt_time = src_ctr_pt_time + w
    # dest_ctr_pts = tf.stack((dest_ctr_pt_time, dest_ctr_pt_freq), -1)
    dest_ctr_pts = tf.stack((dest_ctr_pt_freq, dest_ctr_pt_time), -1)
    dest_ctr_pts = tf.cast(dest_ctr_pts, dtype=tf.float32)

    # clamp the left side edge
    clamp_left_edge = True
    if clamp_left_edge:
        pt_clamp = 0
        src_ctr_pt_time_clamp = tf.ones_like(src_ctr_pt_freq) * pt_clamp
        src_ctr_pts_clamp = tf.stack((src_ctr_pt_freq, src_ctr_pt_time_clamp), -1)
        src_ctr_pts_clamp = tf.cast(src_ctr_pts_clamp, dtype=tf.float32)

        dest_ctr_pt_time_clamp = src_ctr_pt_time_clamp
        dest_ctr_pts_clamp = tf.stack((dest_ctr_pt_freq, dest_ctr_pt_time_clamp), -1)
        dest_ctr_pts_clamp = tf.cast(dest_ctr_pts_clamp, dtype=tf.float32)

        src_ctr_pts = tf.concat((src_ctr_pts, src_ctr_pts_clamp), 0)
        dest_ctr_pts = tf.concat((dest_ctr_pts, dest_ctr_pts_clamp), 0)

    # warp
    source_control_point_locations = tf.expand_dims(src_ctr_pts, 0)  # (1, v//2, 2)
    dest_control_point_locations = tf.expand_dims(dest_ctr_pts, 0)  # (1, v//2, 2)

    warped_image, _ = sparse_image_warp(data,
                                        source_control_point_locations,
                                        dest_control_point_locations,
                                        num_boundary_points=0)
    # for debug: aaa = np.squeeze(np.array(tf.reshape(floors[1], [1, 256, 572])))
    return warped_image



