import os
import numpy as np

import tensorflow as tf
from SpecAugment import spec_augment_tensorflow

import matplotlib.pyplot as plt


def PMB_time_wrap_aug(data_path, save_path, para):
    '''
    the implementation of PMB time warp is based on the Specaugment: https://arxiv.org/pdf/1904.08779.pdf
    Thanks for the SpecAugment implementation in TensorFlow and Pytorch by https://github.com/DemisEom/SpecAugment
    '''
    npys = os.listdir(data_path)

    ## for saving data
    # save_path = save_path + os.sep + 'TimeWarpSingle_' + str(para)
    # if not os.path.exists(save_path):
    #     os.makedirs(save_path)

    np.random.seed(10)
    tf.random.set_seed(10)

    # for npy in npys:
    #     print(npy)
    data = np.load(os.path.join(data_path, npys[0]))
    # data = io.loadmat(os.path.join(data_path, npy))['eeg_data']
    eeg_data = tf.convert_to_tensor(data)
    eeg_data = tf.cast(tf.expand_dims(tf.expand_dims(eeg_data, -1), 0), dtype=tf.float32)
    wrap_data = spec_augment_tensorflow.sparse_warp(eeg_data, time_warping_para=para)
    wrap_data = tf.squeeze(wrap_data)
    # np.save(save_path + os.sep + 'warp_' + npy, wrap_data)

    # plt.subplot(1, 2, 1)
    plt.plot(data[0], label='1')
    plt.title("Original data")
    # plt.subplot(1, 2, 2)
    plt.plot(wrap_data[0], label='2')
    plt.title("Comparison between original data and augmented data")
    plt.legend(('Origin', 'Augmented'), loc='best')

    plt.show()
    print(1)


def freq_masking_aug(data_path, save_path, para1=100, para2=1, data_points=384):
    npys = os.listdir(data_path)
    ## for save the augmented data
    # save_path = save_path + os.sep + 'FreqMasking_' + str(para1) + '_' + str(para2)
    # if not os.path.exists(save_path):
    #     os.makedirs(save_path)

    ## iterate all samples
    # for npy in npys:
    # print(npy)
    np.random.seed(10)
    tf.random.set_seed(10)

    data = np.load(os.path.join(data_path, npys[0]))
    eeg_data = tf.convert_to_tensor(data)
    eeg_data = tf.cast(eeg_data, dtype=tf.float32)
    tau = eeg_data.shape[1]
    fft_eeg_data = np.fft.fft(eeg_data, n=data_points, axis=1)
    fft_eeg_data = tf.convert_to_tensor(fft_eeg_data)
    mask_data = frequency_masking(fft_eeg_data, tau, 'zero', para1, para2)
    b = np.fft.ifft(mask_data, n=data_points, axis=1)
    aug_data = np.real(b)
    # np.save(save_path + os.sep + 'freqmasking_' + npy, aug_data)

    # plt.subplot(1, 2, 1)
    plt.plot(data[0], label='1')
    plt.title("Original data")
    # plt.subplot(1, 2, 2)
    plt.plot(aug_data[0], label='2')
    plt.title("Comparison between original data and augmented data")
    plt.legend(('Origin', 'Augmented'), loc='best')

    plt.show()
    print(1)


def freq_additive_gaussion_noise(data_path, save_path, para=0.01, data_points=384):
    npys = os.listdir(data_path)
    # for saving data
    # save_path = save_path + os.sep + 'FreqAdditiveGaussionNoise_' + str(para)
    # if not os.path.exists(save_path):
    #     os.makedirs(save_path)
    # for npy in npys:
    #     print(npy)

    np.random.seed(10)
    tf.random.set_seed(10)

    data = np.load(os.path.join(data_path, npys[0]))
    aug_data = []
    for i in range(data.shape[0]):
        a = np.fft.fft(data[i], n=data_points)
        dc_real = np.random.normal(0, para, 1)
        dc_imag = np.array([0])
        noise_real_1 = np.random.normal(0, para, data_points//2-1)
        noise_imag_1 = np.random.normal(0, para, data_points//2-1)
        noise_real_3 = np.random.normal(0, para, 1)
        noise_imag_3 = np.random.normal(0, para, 1)
        noise_real_2 = np.flipud(noise_real_1)
        noise_imag_2 = np.flipud(noise_imag_1)
        noise_real = np.concatenate((dc_real, noise_real_1, noise_real_3, noise_real_2))
        noise_imag = np.concatenate((dc_imag, noise_imag_1, noise_imag_3, noise_imag_2))
        noise = noise_real + 1j * noise_imag
        a += noise
        b = np.fft.ifft(a, n=data_points)
        c = np.real(b)
        aug_data.append(c)
    # np.save(save_path + os.sep + 'FreqNoise_' + npy, np.array(aug_data))

    # plt.subplot(1, 2, 1)
    plt.plot(data[0], label='1')
    plt.title("Original data")
    # plt.subplot(1, 2, 2)
    plt.plot(aug_data[0], label='2')
    plt.title("Comparison between original data and augmented data")
    plt.legend(('Origin', 'Augmented'), loc='best')

    plt.show()
    print(1)


def frequency_masking(eeg_data, v, mode, frequency_masking_para=27, frequency_mask_num=2):
    fbank_size = tf.shape(eeg_data)
    # for zero:
    mag = eeg_data
    n, v = fbank_size[0], fbank_size[1]

    for i in range(frequency_mask_num):
        f = tf.random.uniform([], minval=0, maxval=frequency_masking_para, dtype=tf.int32)
        v = tf.cast(v, dtype=tf.int32)
        f0 = tf.random.uniform([], minval=0, maxval=v//2-f, dtype=tf.int32)

        if f != 0:
            if mode == 'zero':
                mask_1 = tf.concat((tf.ones(shape=(n, v // 2 - f0 - f)),
                                    tf.zeros(shape=(n, f)),
                                    tf.ones(shape=(n, f0)),
                                    ), 1)
                mask_2 = tf.concat((tf.ones(shape=(n, f0)),
                                    tf.zeros(shape=(n, f)),
                                    tf.ones(shape=(n, v // 2 - f0 - f))
                                    ), 1)
                mask = tf.concat((mask_1, mask_2), 1)
                mask = tf.cast(mask, dtype=tf.complex128)
                mag = mag * mask
                eeg_data = mag
        else:
            pass

    return eeg_data


if __name__ == '__main__':
    ## This file introduces the implementation of PMB TW, FreqMasking, FreqNoiseAddition.
    ## For the model used for situation awareness recognition and the driving data without segmentation, you can refer
    ## to our previous work: https://ieeexplore.ieee.org/abstract/document/9714736.
    ## For other models, the codes are available in the corresponding references of our paper.

    data_path = 'drivedata'
    save_path = 'your save path'
    # for para in [3]:
    PMB_time_wrap_aug(data_path, save_path, para=70)

    # frequency masking
    freq_masking_aug(data_path, save_path, para1=50, para2=1, data_points=384)
    # frequency additive gaussion noise
    freq_additive_gaussion_noise(data_path, save_path, para=20, data_points=384)


