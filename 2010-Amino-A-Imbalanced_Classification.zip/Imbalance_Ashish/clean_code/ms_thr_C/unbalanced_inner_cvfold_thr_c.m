function [best_param] = unbalanced_inner_cvfold_thr_c(data,labels,trainpindex,trainnindex,indx_mat,cvfold,codedir,svmdir,wt_flag,data_flag,method_flag)


no_pos_samples = size(trainpindex,1);
no_neg_samples = size(trainnindex,1);
pindx = randperm(no_pos_samples);
nindx = randperm(no_neg_samples);

fname1 = sprintf('data%d_new_method_model_selection_avgacc_wt%d.txt',data_flag,wt_flag);
fname7 = sprintf('data%d_new_method_model_selection_gmean_wt%d.txt',data_flag,wt_flag);
fparam = sprintf('data%d_new_method_model_selection_params_wt%d.txt',data_flag,wt_flag);

%User can change the c_val and g_val here
c_val = [0.01,0.1,1,2]; 
g_val = 0.01;
max_thr = floor(no_neg_samples/no_pos_samples)

%User can change the Imbalance ratio (thr_val) values here
if max_thr <= 20
    thr_val = (1:1:max_thr-1);
elseif max_thr > 20 && max_thr <= 50
    thr_val = (1:1:max_thr-5);
else
    thr_val = (1:10:max_thr-5);
end


param_sets = [c_val,g_val,thr_val];

auc_flag = 2; % 1: auc; 2: g_mean

dlmwrite(fparam,param_sets,'delimiter','\t','-append');

for thr_i = 1:size(thr_val,2)
    for c_i = 1:size(c_val,2)
        cvacc = zeros(1,cvfold);
        cv_TP = zeros(1,cvfold);
        cv_TN = zeros(1,cvfold);
        cv_FP = zeros(1,cvfold);
        cv_gmean = zeros(1,cvfold);        
        for i=1:cvfold
            tv1 = ones(1,no_pos_samples);
            tv1(pindx(floor(no_pos_samples/cvfold)*(i-1)+1:floor(no_pos_samples/cvfold)*i)) = zeros(1,floor(no_pos_samples/cvfold));
            testpindx = trainpindex(find(tv1==0));
            trainpindx = trainpindex(find(tv1==1));

            tv2 = ones(1,no_neg_samples);
            tv2(nindx(floor(no_neg_samples/cvfold)*(i-1)+1:floor(no_neg_samples/cvfold)*i)) = zeros(1,floor(no_neg_samples/cvfold));
            testnindx = trainnindex(find(tv2==0));            
            trainnindx = trainnindex(find(tv2==1));
            
            [selected_neg_indx] = new_selection_strategy_v6(indx_mat,trainpindx,trainnindx,thr_val(thr_i));
            size(selected_neg_indx,2)

            traindata = [data(trainpindx,:);data(selected_neg_indx,:)];
            trainlabel = [labels(trainpindx);labels(selected_neg_indx)];
            testdata = [data(testpindx,:);data(testnindx,:)];
            testlabel = [labels(testpindx);labels(testnindx)];

            if wt_flag == 0
                strng = sprintf('-t 2 -c %f -g %f',c_val(c_i),g_val);
            else
                pos_frac = (size(selected_neg_indx,2)+size(trainpindx,1))/size(trainpindx,1);
                neg_frac = (size(selected_neg_indx,2)+size(trainpindx,1))/size(selected_neg_indx,2);
                strng = sprintf('-t 2 -c %f -g %f -w1 %f -w-1 %f',c_val(c_i),g_val,pos_frac,neg_frac);
            end
            
            cd(eval('svmdir'));
            model = svmtrain(trainlabel,traindata,eval('strng'));
            [plabel,acc,dvals] = svmpredict(testlabel,testdata,model);
            pred_pos_samples = plabel(1:size(testpindx,1));
            pred_neg_samples = plabel(size(testpindx,1)+1:size(testlabel,1));
            cd(eval('codedir'));
            
            cvacc(i) = acc(1);
            cv_TP(i) = size(find(testlabel(1:size(testpindx,1))-pred_pos_samples == 0),1);
            cv_TP(i) = cv_TP(i)/size(testpindx,1);
            cv_TN(i) = size(find(testlabel(size(testpindx,1)+1:size(testlabel,1))-pred_neg_samples == 0),1);
            cv_TN(i) = cv_TN(i)/size(testnindx,1);
            cv_gmean(i) = sqrt(cv_TP(i)*cv_TN(i));

        end %cvfold loop
        cv_avg_acc(thr_i,c_i) = mean(cvacc);
        TP(thr_i,c_i) = mean(cv_TP);
        TN(thr_i,c_i) = mean(cv_TN);
        FP(thr_i,c_i) = mean(cv_FP);
        gmean(thr_i,c_i) = mean(cv_gmean);
    end %c_val loop
end %thr_val loop

dlmwrite(fname1,cv_avg_acc','delimiter','\t','-append');
dlmwrite(fname7,gmean','delimiter','\t','-append');

if auc_flag == 1
       [x,I] = max(auc);
       [y,I1] = max(x);
       best_param = [thr_val(I(I1)),c_val(I1)];
else
        [x,I] = max(gmean);
        [y,I1] = max(x);
        best_param = [thr_val(I(I1)),c_val(I1)];
end
