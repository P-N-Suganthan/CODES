function [fname,logfile] = getfilename(data_flag,method_flag,wt_flag)

if data_flag == 1
    if method_flag == 1
        fname = sprintf('active_site_random_method_CV_wt%d.txt',wt_flag);
        logfile = sprintf('active_site_random_method_bestparam_gmean_wt%d.txt',wt_flag);
    else
        fname = sprintf('active_site_new_method_CV_wt%d.txt',wt_flag);
        logfile = sprintf('active_site_new_method_bestparam_gmean_wt%d.txt',wt_flag);
    end
elseif data_flag == 2
    if method_flag == 1
        fname = sprintf('cysteine_randmom_method_CV_wt%d.txt',wt_flag);
        logfile = sprintf('cysteine_random_method_bestparam_gmean_wt%d.txt',wt_flag);
    else
        fname = sprintf('cysteine_new_method_CV_wt%d.txt',wt_flag);
        logfile = sprintf('cysteine_new_method_bestparam_gmean_wt%d.txt',wt_flag);
    end
elseif data_flag == 3
    if method_flag ==1
	fname = sprintf('xwchen_random_method_CV_wt%d.txt',wt_flag);
	logfile = sprintf('xwchen_random_method_bestparam_gmean_wt%d.txt',wt_flag);
    else
	fname = sprintf('xwchen_new_method_CV_wt%d.txt',wt_flag);
	logfile = sprintf('xwchen_new_method_bestparam_gmean_wt%d.txt',wt_flag);
    end
elseif data_flag == 4
    if method_flag == 1
	fname = sprintf('alltrain6_random_method_CV_wt%d.txt',wt_flag);
	logfile = sprintf('alltrain6_random_method_bestparam_gmean_wt%d.txt',wt_flag);
    else
	fname = sprintf('alltrain6_new_method_CV_wt%d.txt',wt_flag);
	logfile = sprintf('alltrain6_new_method_bestparam_gmean_wt%d.txt',wt_flag);
    end
elseif data_flag == 5
    if method_flag == 1
	fname = sprintf('micropred_random_method_CV_wt%d.txt',wt_flag);
	logfile = sprintf('micropred_random_method_bestparam_gmean_wt%d.txt',wt_flag);
    else
	fname = sprintf('micropred_new_method_CV_wt%d.txt',wt_flag);
	logfile = sprintf('micropred_new_method_bestparam_gmean_wt%d.txt',wt_flag);
    end
elseif data_flag == 6
    if method_flag == 1
	fname = sprintf('cel_random_method_CV_wt%d.txt',wt_flag);
	logfile = sprintf('cel_random_method_bestparam_gmean_wt%d.txt',wt_flag);
    else
	fname = sprintf('cel_new_method_CV_wt%d.txt',wt_flag);
	logfile = sprintf('cel_new_method_bestparam_gmean_wt%d.txt',wt_flag);
    end
else
    if method_flag == 1
	fname = sprintf('mmu_pos_and_neg10k_random_method_CV_wt%d.txt',wt_flag);
	logfile = sprintf('mmu_pos_and_neg10k_random_method_bestparam_gmean_wt%d.txt',wt_flag);
    else
	fname = sprintf('mmu_pos_and_neg10k_new_method_CV_wt%d.txt',wt_flag);
	logfile = sprintf('mmu_pos_and_neg10k_new_method_bestparam_gmean_wt%d.txt',wt_flag);
    end
end
