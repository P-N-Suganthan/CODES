function [tmpdist] = cal_dist(sample1,sample2)
tmpdist = sqrt(sum((sample1-sample2).^2));
