function [cv_avg_acc,TP,TN] = unbalanced_svm_model_selection_generalized_ms_thr_c_radius(data,labels,cvfold,inner_cvfold,method_flag,wt_flag,data_flag,radius_flag)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs are as follows:
% data: samples by feature matrix
% labels: labels
% thr: imbalance ratio between selected negative and positive samples in training
% data
% cvfold: n-fold experiment
% inner_cvfold: inner n-fold for model selection
% method_flag: 1 for random sampling and 2 for proposed selection strategy
% wt_flag: 0 for classical SVM (w/o weight) and 1 for weighted SVM
% radius: radius parameter to remove nearest neighbour samples

% data_flag: 1 for active_site; 2 for cysteine
%User will have to change it according to their own data.


%Author: Ashish Anand
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if size(labels,1) == 1
    labels = labels';
end
%Get basic information of data
[no_samples,no_feats] = size(data);
pos_indx = find(labels == 1);
neg_indx = find(labels == -1);
no_pos_samples = size(pos_indx,1);
no_neg_samples = size(neg_indx,1);

% Modify the codedir and svmdir according to your own setup. Codedir is the
% directory where all these codes are stored. svmdir is the directory where
% you have saved the libsvm codes.
%Alternate way is to use addpath command to add all directories where matlab should look for your codes.

codedir = sprintf('clean_code/ms_thr_C/radius_code');
svmdir = sprintf('libsvm/libsvm-mat-2.88-1');

% Get auxilliary file names to store some outputs.
fname = sprintf('data%d_new_method_CV_wt%d.txt',data_flag,wt_flag);
logfile = sprintf('data%d_new_method_bestparam_gmean_wt%d.txt',data_flag,wt_flag);

rand('state',0);
pindx = randperm(no_pos_samples);
nindx = randperm(no_neg_samples);
t0 = cputime;
cv_acc = zeros(1,cvfold);
cv_TP = zeros(1,cvfold);
cv_TN = zeros(1,cvfold);
cv_gmean = zeros(1,cvfold);

%Loading the sorted negative indices...... User will have to change the
%file name according to where they have stored the matrix
if method_flag == 2
    if data_flag == 1
        load actual_sorted_indx.mat;
    elseif data_flag == 2
        load cysteine_sorted_pos_by_actual_neg_indx.mat;
    elseif data_flag == 3
        load xwchen_sorted_pos_by_actual_neg_indx.mat;
    elseif data_flag == 4
        load all_train6_sorted_pos_by_actual_neg_indx.mat;
    elseif data_flag == 5
        load micropred_sorted_pos_by_actual_neg_indx.mat;
    else
        load cel_pos_and_neg10k_pos_by_sorted_actual_neg_indx.mat;
    end
    feats_wt=cal_fisher_wt(data,labels);
end

for j = 1:10
        j
        % get test and training data
        tv1 = ones(1,no_pos_samples);
        tv1(pindx(floor(no_pos_samples/cvfold)*(j-1)+1:floor(no_pos_samples/cvfold)*j)) = zeros(1,floor(no_pos_samples/cvfold));
        testpindex = pos_indx(find(tv1==0));
        trainpindex = pos_indx(find(tv1==1));
        
        tv2 = ones(1,no_neg_samples);
        tv2(nindx(floor(no_neg_samples/cvfold)*(j-1)+1:floor(no_neg_samples/cvfold)*j)) = zeros(1,floor(no_neg_samples/cvfold));
        testnindex = neg_indx(find(tv2==0));
        trainnindex = neg_indx(find(tv2==1));

        testdata = [data(testpindex,:);data(testnindex,:)];
        testlabel = [labels(testpindex);labels(testnindex)];
        
        %new selection strategy
        
        [best_param] = unbalanced_inner_cvfold_thr_c_radius1(data,labels,trainpindex,trainnindex,indx_mat,inner_cvfold,codedir,svmdir,wt_flag,data_flag,method_flag,radius_flag,no_pos_samples,feats_wt);

        x1 = [j,best_param];
        dlmwrite(logfile,x1,'delimiter','\t','-append');
        clear x1;
        thr = best_param(1);
        pnn = 1+best_param(2);
        c_val = best_param(3);
        [selected_neg_indx] = new_selection_strategy_v4(data,indx_mat,trainpindex,trainnindex,thr,pnn,feats_wt,no_pos_samples);

        ntraindata = [data(trainpindex,:);data(selected_neg_indx,:)];
        ntrainlabel = [labels(trainpindex);labels(selected_neg_indx)];

        if wt_flag == 0
            strng = sprintf('-t 2 -c %f -g 0.01',c_val);
        else
            pos_frac = size(ntraindata,1)/size(trainpindex,1);
            neg_frac = size(ntraindata,1)/size(selected_neg_indx,2);
            strng = sprintf('-t 2 -c %f -g 0.01 -w1 %f -w-1 %f',c_val,pos_frac,neg_frac);
        end

        cd(eval('svmdir'));
        model = svmtrain(ntrainlabel,ntraindata,eval('strng'));
        [pred_label,acc,dec_vals] = svmpredict(testlabel,testdata,model);
        pred_pos_samples = pred_label(1:size(testpindex,1));
        pred_neg_samples = pred_label(size(testpindex,1)+1:size(testlabel,1));
        cv_acc(j)= acc(1);
        cv_TP(j)= size(find(testlabel(1:size(testpindex,1))-pred_pos_samples == 0),1);
        cv_TP(j) = cv_TP(j)/size(testpindex,1);
        cv_TN(j)= size(find(testlabel(size(testpindex,1)+1:size(testlabel,1))-pred_neg_samples == 0),1);
        cv_TN(j) = cv_TN(j)/size(testnindex,1);
        cv_gmean(j) = sqrt(cv_TP(j)*cv_TN(j));
        cd(eval('codedir'));
end
t1=cputime-t0;
cv_avg_acc = mean(cv_acc);
TP = mean(cv_TP);
TN = mean(cv_TN);
gmean = mean(cv_gmean);
x = [cv_acc,cv_avg_acc;cv_TP,TP;cv_TN,TN;cv_gmean,gmean];
dlmwrite(fname,x,'delimiter','\t','-append');
dlmwrite(fname,t1,'delimiter','\t','-append');
