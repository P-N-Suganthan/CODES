function [best_param] = unbalanced_inner_cvfold_thr_c_radius1(data,labels,trainpindex,trainnindex,indx_mat,cvfold,codedir,svmdir,wt_flag,data_flag,method_flag,radius_flag,no_pos_samples1,feats_wt)
% This function implements inner fold cross-validation for model selection

no_pos_samples = size(trainpindex,1);
no_neg_samples = size(trainnindex,1);

pindx = randperm(no_pos_samples);
nindx = randperm(no_neg_samples);

%Auxilliary files to store the model selection intermediate values
fname1 = sprintf('data%d_new_method_model_selection_avgacc_wt%d.txt',data_flag,wt_flag);
fname7 = sprintf('data%d_new_method_model_selection_gmean_wt%d.txt',data_flag,wt_flag);
fparam = sprintf('data%d_new_method_model_selection_params_wt%d.txt',data_flag,wt_flag);


max_thr = floor(no_neg_samples/no_pos_samples);

%SVM Model Parameters. User can change the c_val and g_val here
%for different data
c_val = [0.1,1,2];
g_val = 0.01;

%Imbalance Ratio (thr_val) can be changed here
if max_thr <= 20
    thr_val = (2:3:max_thr-1);
elseif max_thr > 20 && max_thr <= 50
    thr_val = (2:5:max_thr-5);
else
    thr_val = (2:10:max_thr-5);
end

%Radius (radius_val) can be changed here
if radius_flag == 1
    radius_val = [0.05,0.1];
    param_sets = [c_val,g_val,thr_val,radius_val];
else
    param_sets = [c_val,g_val,thr_val];
end


%Model Evaluation by performance measure. Keep it always 2.
auc_flag = 2; % 1: auc; 2: g_mean

dlmwrite(fparam,param_sets,'delimiter','\t','-append');

for thr_i = 1:size(thr_val,2)
    for radius_i = 1:size(radius_val,2)
        for c_i = 1:size(c_val,2)
            for fold_i = 1:cvfold
                tv1 = ones(1,no_pos_samples);
                tv1(pindx(floor(no_pos_samples/cvfold)*(fold_i-1)+1:floor(no_pos_samples/cvfold)*fold_i)) = zeros(1,floor(no_pos_samples/cvfold));
                testpindx = trainpindex(find(tv1==0));
                trainpindx = trainpindex(find(tv1==1));

                tv2 = ones(1,no_neg_samples);
                tv2(nindx(floor(no_neg_samples/cvfold)*(fold_i-1)+1:floor(no_neg_samples/cvfold)*fold_i)) = zeros(1,floor(no_neg_samples/cvfold));
                testnindx = trainnindex(find(tv2==0));
                trainnindx = trainnindex(find(tv2==1));

                if c_i == 1
                    pnn = 1+radius_val(radius_i);
                    [selected_neg_indx] = new_selection_strategy_v4(data,indx_mat,trainpindx,trainnindx,thr_val(thr_i),pnn,feats_wt,no_pos_samples1);
                    store_neg_indx = sprintf('stored_neg_indx_fold%d_thr%d_pnn%.2f.txt',fold_i,thr_val(thr_i),radius_val(radius_i));
                    dlmwrite(store_neg_indx,selected_neg_indx,'delimiter','\t','precision','%d','-append');
                else
                    store_neg_indx = sprintf('stored_neg_indx_fold%d_thr%d_pnn%.2f.txt',fold_i,thr_val(thr_i),radius_val(radius_i));
                    [selected_neg_indx] = load(store_neg_indx);
                    size(selected_neg_indx)
                end

                ntraindata = [data(trainpindx,:);data(selected_neg_indx,:)];
                ntrainlabel = [labels(trainpindx);labels(selected_neg_indx)];
                testdata = [data(testpindx,:);data(testnindx,:)];
                testlabel = [labels(testpindx);labels(testnindx)];

                if wt_flag == 0
                    strng = sprintf('-t 2 -c %f -g %f',c_val(c_i),g_val);
                else
                    pos_frac = (size(selected_neg_indx,2)+size(trainpindx,1))/size(trainpindx,1);
                    neg_frac = (size(selected_neg_indx,2)+size(trainpindx,1))/size(selected_neg_indx,2);
                    strng = sprintf('-t 2 -c %f -g %f -w1 %f -w-1 %f',c_val(c_i),g_val,pos_frac,neg_frac);
                end

                cd(eval('svmdir'));
                model = svmtrain(ntrainlabel,ntraindata,eval('strng'));
                [plabel,acc,dvals] = svmpredict(testlabel,testdata,model);
                pred_pos_samples = plabel(1:size(testpindx,1));
                pred_neg_samples = plabel(size(testpindx,1)+1:size(testlabel,1));
                cd(eval('codedir'));

                cvacc(fold_i) = acc(1);
                cv_TP(fold_i) = size(find(testlabel(1:size(testpindx,1))-pred_pos_samples == 0),1);
                cv_TP(fold_i) = cv_TP(fold_i)/size(testpindx,1);
                cv_TN(fold_i) = size(find(testlabel(size(testpindx,1)+1:size(testlabel,1))-pred_neg_samples == 0),1);
                cv_TN(fold_i) = cv_TN(fold_i)/size(testnindx,1);
                cv_gmean(fold_i) = sqrt(cv_TP(fold_i)*cv_TN(fold_i));
            end %end of cvfold loop
            cv_avg_acc(thr_i,radius_i,c_i) = mean(cvacc);
            TP(thr_i,radius_i,c_i) = mean(cv_TP);
            TN(thr_i,radius_i,c_i) = mean(cv_TN);
            gmean(thr_i,radius_i,c_i) = mean(cv_gmean);
        end %end of c_val loop
        mycmd = sprintf('rm stored_neg_indx_fold*.txt');
        system(eval('mycmd'));
    end %end of radius_val loop
end %end of thr_val loop
dlmwrite(fname1,cv_avg_acc,'delimiter','\t','-append');
dlmwrite(fname7,gmean,'delimiter','\t','-append');

if auc_flag == 2
    thindx=zeros(1,size(c_val,2));
    radindx=zeros(1,size(c_val,2));
    maxval=zeros(1,size(c_val,2));
    for c_i=1:size(c_val,2)
        [y,I1] = max(gmean(:,:,c_i));
        [y1,I2] = max(y);
        thindx(c_i) = I1(I2);
        radindx(c_i) = I2;
        maxval(c_i) =y1;
    end   
    [mval,mval_I]=max(maxval);
    best_param(1) = thr_val(thindx(mval_I));
    best_param(2) = radius_val(radindx(mval_I));
    best_param(3) = c_val(mval_I);
end
