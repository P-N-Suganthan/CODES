function [select_neg_indx] = new_selection_strategy_v4(data,indx_mat,trainpindx,trainnindx,thr,pnn,feats_wt,no_pos_samples)
%%%%Input description
%indx_mat: pos_samples_indx * sorted_neg_samples_indx (each row is indx of
%sorted distance b/w pos and neg samples. indices of neg samples are actual indices with respect to whole data)
%trainpindx: training indices of pos samples
%trainnindx: training indices of neg samples
%thr: ratio between neg_samples and pos_samples
%pnn: parameter for nearest neighbour removal
%feats_wt: fisher's wt of features

%%%%Output description
indx_flag=zeros(1,size(indx_mat,2));
select_neg_indx = [];
prev_col_indx = ones(1,size(trainpindx,1));
%size(trainpindx)
%size(trainnindx)
%keyboard
for i=1:size(trainpindx,1)
    %i
    indx = trainpindx(i);
    [indx_mat1,I1] = intersect(indx_mat(indx,:),trainnindx);
    I1=sort(I1,'ascend');
    %   keyboard
    col_indx = prev_col_indx(i);
    tmp_flag = zeros(1,size(I1,2));
    for j=1:thr
        if j == 1
            while indx_flag(indx_mat(indx,I1(col_indx))-no_pos_samples) == 1
                col_indx = col_indx+1;
            end
            select_neg_indx = [select_neg_indx,indx_mat(indx,I1(col_indx))];
            indx_flag(indx_mat(indx,I1(col_indx))-no_pos_samples) = 1;
            prev_col_indx(i) = col_indx;
        else
            tmp_sample1 = feats_wt.*data(indx,:);
            tmp_sample2 = feats_wt.*data(indx_mat(indx,I1(prev_col_indx(i))),:);
            D = cal_dist(tmp_sample1,tmp_sample2);
            D_thr = D*pnn;
            new_col_indx = prev_col_indx(i)+1;
            tmp_sample3 = feats_wt.*data(indx_mat(indx,I1(new_col_indx)),:);
            nbhd_flag = 0;
            nbhd_indx = [];
            selection_flag = 0;
            %selection of nearest neighbour negative samples within D_thr distance from the positive sample
            while cal_dist(tmp_sample3, tmp_sample1) <= D_thr
                nbhd_indx = [nbhd_indx,new_col_indx];
                new_col_indx = new_col_indx+1;
                tmp_sample3 = feats_wt.*data(indx_mat(indx,I1(new_col_indx)),:);
                nbhd_flag = 1;
            end
            %[j,nbhd_indx]
            %keyboard
            %select negative sample from these nearesest neighbour if its not within radius of already selected negative sample
            if nbhd_flag == 1
                for k=1:size(nbhd_indx,2)
                    new_col_indx=nbhd_indx(k);
                    tmp_sample3 = feats_wt.*data(indx_mat(indx,I1(new_col_indx)),:);
                    if cal_dist(tmp_sample3,tmp_sample2) < (pnn-1)
                        tmp_flag(new_col_indx) = 1;
                    else
                        select_neg_indx = [select_neg_indx,indx_mat(indx,I1(new_col_indx))];
                        indx_flag(indx_mat(indx,I1(new_col_indx))-no_pos_samples)=1;
                        prev_col_indx(i) = new_col_indx;
                        selection_flag = 1;
                        break;
                    end
                end
            else %otherwise select the next one which has not be already selected or in the nbhd of already selected negative sample
                while tmp_flag(new_col_indx) == 1 || indx_flag(indx_mat(indx,I1(new_col_indx))-no_pos_samples) == 1
                    new_col_indx = new_col_indx+1;
                end
                select_neg_indx = [select_neg_indx,indx_mat(indx,I1(new_col_indx))];
                indx_flag(indx_mat(indx,I1(new_col_indx))-no_pos_samples)=1;
                prev_col_indx(i) = new_col_indx;
                selection_flag = 1;
            end
            if selection_flag == 0 %all neareast nbh negative samples of positive samples are in nvhd of already selected negative sample
                new_col_indx =new_col_indx+1;
                while tmp_flag(new_col_indx) == 1 || indx_flag(indx_mat(indx,I1(new_col_indx))-no_pos_samples) == 1
                    new_col_indx = new_col_indx+1;
                end
                select_neg_indx = [select_neg_indx,indx_mat(indx,I1(new_col_indx))];
                indx_flag(indx_mat(indx,I1(new_col_indx))-no_pos_samples)=1;
                prev_col_indx(i) = new_col_indx;
                selection_flag = 1;
            end
        end %End of j if-else loop
    end % End of thr for loop
end % End of positive sample indx loop
%size(select_neg_indx)
%size(intersect(select_neg_indx,trainnindx))
select_neg_indx=intersect(select_neg_indx,trainnindx);
