function [feats_wt] = cal_fisher_wt(data, labels)

%This function calculates Fisher's weight for each feature
%Input: data should be samples*features format
%Lables should be given separately
%Assumption: features are already scaled or normalized
%Output: A vector giving Fisher's weight for all features.

%Author: Ashish Anand
%University: Nanyang Technological University, Singapore

[m,n]=size(labels);
%make labels as column vector
if m==1
    labels=labels';
end
[no_samples,no_feats]=size(data);
pos_samples=find(labels==1);
neg_samples=find(labels==-1);

for i=1:no_feats
    num_x = (mean(data(pos_samples,i))-mean(data(neg_samples,i)))^2;
    denm_y = std(data(pos_samples,i))^2+std(data(neg_samples,i))^2;
    if denm_y ==0
        feats_wt(i) = 0;
    else
        feats_wt(i) = num_x/denm_y;
    end
end
disp('fisher wt calculation finished');

