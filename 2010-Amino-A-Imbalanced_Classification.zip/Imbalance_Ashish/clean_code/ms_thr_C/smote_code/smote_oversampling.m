function [new_minority_sample] = smote_oversampling(data,pos_indx,no_smote,pos_nn_indx,nn_k)

%no_smote = no of artificial sample generated per positive samples or minority samples
%pos_nn_indx = index matrix for nearest neighbours for positive samples or minority samples
%nn_k = no of nearest neighbours considered

no_pos_samples = size(pos_indx,1);
k=1;
new_minority_sample = zeros(no_pos_samples*no_smote,size(data,2));
for i=1:no_pos_samples
	nn_i = pos_nn_indx(i,1:nn_k);
	for j = 1:no_smote
		nn_ik = nn_i(floor(1+(nn_k-1)*rand));
		new_minority_sample(k,:) = data(pos_indx(i),:)+(rand*data(pos_indx(nn_ik),:)-data(pos_indx(i),:));
		k=k+1;
	end
end

