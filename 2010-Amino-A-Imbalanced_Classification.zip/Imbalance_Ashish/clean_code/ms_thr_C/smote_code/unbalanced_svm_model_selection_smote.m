function [cv_avg_acc,TP,TN] = unbalanced_svm_model_selection_smote(data,labels,cvfold,inner_cvfold,method_flag,wt_flag,data_flag)

% Inputs are as follows:
% data: samples by feature matrix
% labels: labels
% thr: ratio between selected negative and positive samples in training
% data
% cvfold: n-fold experiment
% inner_cvfold: inner n-fold for model selection
% method_flag: 1 for random sampling and 2 for proposed selection strategy
% wt_flag: 0 for classical SVM (w/o weight) and 1 for weighted SVM
% data_flag: 1 for active_site; 2 for cysteine


if size(labels,1) == 1
	labels=labels';
end
%Get basic information
[no_samples,no_feats] = size(data);
pos_indx = find(labels == 1);
neg_indx = find(labels == -1);
no_pos_samples = size(pos_indx,1);
no_neg_samples = size(neg_indx,1);
nn_k = 2;
codedir = sprintf('ms_thr_C/smote_code');
svmdir = sprintf('libsvm/libsvm-mat-2.88-1');
[fname,logfile] = getfilename(data_flag,method_flag,wt_flag);

rand('state',0);
pindx = randperm(no_pos_samples);
nindx = randperm(no_neg_samples);
t0 = cputime;
cv_acc = zeros(1,cvfold);
cv_TP = zeros(1,cvfold);
cv_TN = zeros(1,cvfold);
cv_gmean = zeros(1,cvfold);

if method_flag == 2
    if data_flag == 1
	load actual_sorted_indx.mat;
    elseif data_flag == 2
	load cysteine_sorted_pos_by_actual_neg_indx.mat;
    elseif data_flag == 3
        load xwchen_sorted_pos_by_actual_neg_indx.mat;
    elseif data_flag == 4
	load all_train6_sorted_pos_by_actual_neg_indx.mat;
    else
	load micropred_sorted_pos_by_actual_neg_indx.mat;
    end
end

for j = 1:cvfold
	j
	tv1 = ones(1,no_pos_samples);
	tv1(pindx(floor(no_pos_samples/cvfold)*(j-1)+1:floor(no_pos_samples/cvfold)*j)) = zeros(1,floor(no_pos_samples/cvfold));
	testpindex = pos_indx(find(tv1==0));
	trainpindex = pos_indx(find(tv1==1));

	tv2 = ones(1,no_neg_samples);
	tv2(nindx(floor(no_neg_samples/cvfold)*(j-1)+1:floor(no_neg_samples/cvfold)*j)) = zeros(1,floor(no_neg_samples/cvfold));
	testnindex = neg_indx(find(tv2==0));
	trainnindex = neg_indx(find(tv2==1));

	traindata = [data(trainpindex,:);data(trainnindex,:)];
	trainlabel = [labels(trainpindex);labels(trainnindex)];
	testdata = [data(testpindex,:);data(testnindex,:)];
	testlabel = [labels(testpindex);labels(testnindex)];
	
	[best_param] = unbalanced_inner_cvfold_smotepar_c(data,labels,trainpindex,trainnindex,pos_nn_indx,inner_cvfold,codedir,svmdir,wt_flag,data_flag,method_flag);
	x1 = [j,best_param];
	dlmwrite(logfile,x1,'delimiter','\t','-append');
	clear x1;
	smotepar = best_param(1);
	[new_minority_sample] = smote_oversampling(data,pos_indx,smotepar,pos_nn_indx,nn_k);
	ntraindata = [data(trainpindex,:);new_minority_sample;data(trainnindex,:)];
	ntrainlabel = [labels(trainpindex);ones(size(new_minority_sample,1),1);labels(trainnindex)];

	if wt_flag == 0
		strng = sprintf('-t 2 -c %f -g 0.01', best_param(2));
	else
		pos_frac = size(ntraindata,1)/(size(trainpindex,1)+size(new_minority_sample,1));
		neg_frac = size(ntraindata,1)/(size(trainnindex,1));
		strng = sprintf('-t 2 -c %f -g 0.01 -w1 %f -w-1 %f',best_param(2),pos_frac,neg_frac);
	end

	cd(eval('svmdir'));
	model = svmtrain(ntrainlabel,ntraindata,eval('strng'));
	[pred_label,acc,dec_vals] = svmpredict(testlabel,testdata,model);
	pred_pos_samples = pred_label(1:size(testpindex,1));
	pred_neg_samples = pred_label(size(testpindex,1)+1:size(testlabel,1));
	cv_acc(j) = acc(1);
	cv_TP(j) = size(find(testlabel(1:size(testpindex,1))-pred_pos_samples == 0),1);
	cv_TP(j) = cv_TP(j)/size(testpindex,1);
	cv_TN(j) = size(find(testlabel(size(testpindex,1)+1:size(testlabel,1))-pred_neg_samples == 0),1);
	cv_TN(j) = cv_TN(j)/size(testnindex,1);
	cv_gmean(j) = sqrt(cv_TP(j)*cv_TN(j));
	cd(eval('codedir'));
end
t1=cputime-t0;
cv_avg_acc = mean(cv_acc);
TP = mean(cv_TP);
TN = mean(cv_TN);
gmean = mean(cv_gmean);

x = [cv_acc,cv_avg_acc;cv_TP,TP;cv_TN,TN;cv_gmean,gmean];
dlmwrite(fname,x,'delimiter','\t','-append');
dlmwrite(fname,t1,'delimiter','\t','-append');

