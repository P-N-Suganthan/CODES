function [best_param] = unbalanced_inner_cvfold_smotepar_c(data,labels,trainpindex,trainnindex,pos_nn_indx,cvfold,codedir,svmdir,wt_flag,data_flag,method_flag)

no_pos_samples = size(trainpindex,1);
no_neg_samples = size(trainnindex,1);
pindx = randperm(no_pos_samples);
nindx = randperm(no_neg_samples);
pos_indx = find(labels==1);
nn_k = 2;
[fname1,fname7,fparam] = get_auxfnames(data_flag,method_flag,wt_flag);

c_val = [0.001,0.01,0.1];
g_val = 0.01;
max_smote = floor(no_neg_samples/no_pos_samples);

if max_smote <= 20
	smote_val = (1:4:max_smote-1);
elseif max_smote > 20 && max_smote <=50
	smote_val = (1:10:max_smote-5);
else
	smote_val = (1:10:max_smote-5);
end

param_sets = [c_val,g_val,smote_val];
auc_flag = 2;

dlmwrite(fparam,param_sets,'delimiter','\t','-append');

for smote_i = 1:size(smote_val,2)
	for c_i = 1:size(c_val,2)
		cvacc = zeros(1,cvfold);
		cv_TP = zeros(1,cvfold);
		cv_TN = zeros(1,cvfold);
		cv_FP = zeros(1,cvfold);
		cv_gmean = zeros(1,cvfold);
		for i = 1:cvfold
			i
			tv1 = ones(1,no_pos_samples);
			tv1(pindx(floor(no_pos_samples/cvfold)*(i-1)+1:floor(no_pos_samples/cvfold)*i)) = zeros(1,floor(no_pos_samples/cvfold));
			testpindx = trainpindex(find(tv1==0));
			trainpindx = trainpindex(find(tv1==1));

			tv2 = ones(1,no_neg_samples);
			tv2(nindx(floor(no_neg_samples/cvfold)*(i-1)+1:floor(no_neg_samples/cvfold)*i)) = zeros(1,floor(no_neg_samples/cvfold));
			testnindx = trainnindex(find(tv2==0));
			trainnindx = trainnindex(find(tv2==1));

			[new_minority_sample] = smote_oversampling(data,pos_indx,smote_val(smote_i),pos_nn_indx,nn_k);
			ntraindata = [data(trainpindex,:);new_minority_sample;data(trainnindex,:)];
			ntrainlabel = [labels(trainpindex);ones(size(new_minority_sample,1),1);labels(trainnindex)];
			testdata = [data(testpindx,:);data(testnindx,:)];
			testlabel = [labels(testpindx);labels(testnindx)];

			if wt_flag == 0
				strng = sprintf('-t 2 -c %f -g 0.01',c_val(c_i));
			else
				pos_frac = size(ntraindata,1)/(size(trainpindex,1)+size(new_minority_sample,1));
				neg_frac = size(ntraindata,1)/(size(trainnindex,1));
				strng = sprintf('-t 2 -c %f -g 0.01 -w1 %f -w-1 %f',c_val(c_i),pos_frac,neg_frac);
			end

			cd(eval('svmdir'));
			model = svmtrain(ntrainlabel,ntraindata,eval('strng'));
			[pred_label,acc,dec_vals] = svmpredict(testlabel,testdata,model);
			pred_pos_samples = pred_label(1:size(testpindx,1));
			pred_neg_samples = pred_label(size(testpindx,1)+1:size(testlabel,1));
			cvacc(i) = acc(1);
			cv_TP(i) = size(find(testlabel(1:size(testpindx,1))-pred_pos_samples == 0),1);
			cv_TP(i) = cv_TP(i)/size(testpindx,1);
			cv_TN(i) = size(find(testlabel(size(testpindx,1)+1:size(testlabel,1))-pred_neg_samples == 0),1);
			cv_TN(i) = cv_TN(i)/size(testnindx,1);
			cv_gmean(i) = sqrt(cv_TP(i)*cv_TN(i));
			cd(eval('codedir'));
		end
		cv_avg_acc(smote_i,c_i) = mean(cvacc);
		TP(smote_i,c_i) = mean(cv_TP);
		TN(smote_i,c_i) = mean(cv_TN);
		FP(smote_i,c_i)	= mean(cv_FP);
		gmean(smote_i,c_i) = mean(cv_gmean);
	end
end

dlmwrite(fname1,cv_avg_acc','delimiter','\t','-append');
dlmwrite(fname7,gmean','delimiter','\t','-append');

if auc_flag == 1
	if size(auc,1) > 1
		[x,I] = max(auc);
		[y,I1] = max(x);
		best_param = [smote_val(I(I1)),c_val(I1)];
	else
		[x,I] = max(auc);
		best_param = [smote_val(1),c_val(i)];
	end
else
	if size(gmean,1) > 1
		[x,I] = max(gmean);
		[y,I1] = max(x);
		best_param = [smote_val(I(I1)),c_val(I1)];
	else
		[x,I] = max(gmean);
		best_param = [smote_val(1),c_val(I)];
	end
end

