%%data dependent variable to load data, labels and other data dependent %things
%load the labels and scaled data
load labels.mat; %labels 
load scaled_data.mat; %scaled data: samples by feature matrix;
data_flag = 5; %to load data dependent other variables

%define problem variables
cvfold = 10; %Number of cross-validation for Outer loop
inner_cvfold = 5; %Number of cross-validation for inner loop
method_flag = 2; % No need to worry about this variable here

% put wt_flag to 0 if you don't want to use weighted-SVM
wt_flag = 1; 

[cv_avg_acc,TP,TN] = unbalanced_svm_model_selection_smote(data,labels,cvfold,inner_cvfold,method_flag,wt_flag,data_flag);
