function [fname1,fname7,fparam] = get_auxfnames(data_flag,method_flag,wt_flag)

if data_flag == 1
    if method_flag == 1
        fname1 = sprintf('active_site_random_method_model_selection_avgacc_wt%d.txt',wt_flag);
        fname7 = sprintf('active_site_random_method_model_selection_gmean_wt%d.txt',wt_flag);
        fparam = sprintf('active_site_random_method_model_selection_params_wt%d.txt',wt_flag);
    else
        fname1 = sprintf('active_site_new_method_model_selection_avgacc_wt%d.txt',wt_flag);
        fname7 = sprintf('active_site_new_method_model_selection_gmean_wt%d.txt',wt_flag);
        fparam = sprintf('active_site_new_method_model_selection_params_wt%d.txt',wt_flag);
    end
elseif data_flag == 2
    if method_flag == 1
        fname1 = sprintf('cysteine_random_method_model_selection_avgacc_wt%d.txt',wt_flag);
        fname7 = sprintf('cysteine_random_method_model_selection_gmean_wt%d.txt',wt_flag);
        fparam = sprintf('cysteine_random_method_model_selection_params_wt%d.txt',wt_flag);
    else
        fname1 = sprintf('cysteine_new_method_model_selection_avgacc_wt%d.txt',wt_flag);
        fname7 = sprintf('cysteine_new_method_model_selection_gmean_wt%d.txt',wt_flag);
        fparam = sprintf('cysteine_new_method_model_selection_params_wt%d.txt',wt_flag);
    end
elseif data_flag == 3
    if method_flag == 1
        fname1 = sprintf('xwchen_random_method_model_selection_avgacc_wt%d.txt',wt_flag);
        fname7 = sprintf('xwchen_random_method_model_selection_gmean_wt%d.txt',wt_flag);
        fparam = sprintf('xwchen_random_method_model_selection_params_wt%d.txt',wt_flag);
    else
        fname1 = sprintf('xwchen_new_method_model_selection_avgacc_wt%d.txt',wt_flag);
        fname7 = sprintf('xwchen_new_method_model_selection_gmean_wt%d.txt',wt_flag);
        fparam = sprintf('xwchen_new_method_model_selection_params_wt%d.txt',wt_flag);
    end
elseif data_flag == 4
    if method_flag == 1
        fname1 = sprintf('alltrain6_random_method_model_selection_avgacc_wt%d.txt',wt_flag);
        fname7 = sprintf('alltrain6_random_method_model_selection_gmean_wt%d.txt',wt_flag);
        fparam = sprintf('alltrain6_random_method_model_selection_params_wt%d.txt',wt_flag);
    else
        fname1 = sprintf('alltrain6_new_method_model_selection_avgacc_wt%d.txt',wt_flag);
        fname7 = sprintf('alltrain6_new_method_model_selection_gmean_wt%d.txt',wt_flag);
        fparam = sprintf('alltrain6_new_method_model_selection_params_wt%d.txt',wt_flag);
    end
elseif data_flag == 5
    if method_flag == 1
        fname1 = sprintf('micropred_random_method_model_selection_avgacc_wt%d.txt',wt_flag);
        fname7 = sprintf('micropred_random_method_model_selection_gmean_wt%d.txt',wt_flag);
        fparam = sprintf('micropred_random_method_model_selection_params_wt%d.txt',wt_flag);
    else
        fname1 = sprintf('micropred_new_method_model_selection_avgacc_wt%d.txt',wt_flag);
        fname7 = sprintf('micropred_new_method_model_selection_gmean_wt%d.txt',wt_flag);
        fparam = sprintf('micropred_new_method_model_selection_params_wt%d.txt',wt_flag);
    end
elseif data_flag == 6
    if method_flag == 1
        fname1 = sprintf('cel_pos_and_neg10k_random_method_model_selection_avgacc_wt%d.txt',wt_flag);
        fname7 = sprintf('cel_pos_and_neg10k_random_method_model_selection_gmean_wt%d.txt',wt_flag);
        fparam = sprintf('cel_pos_and_neg10k_random_method_model_selection_params_wt%d.txt',wt_flag);
    else
        fname1 = sprintf('cel_pos_and_neg10k_new_method_model_selection_avgacc_wt%d.txt',wt_flag);
        fname7 = sprintf('cel_pos_and_neg10k_new_method_model_selection_gmean_wt%d.txt',wt_flag);
        fparam = sprintf('cel_pos_and_neg10k_new_method_model_selection_params_wt%d.txt',wt_flag);
    end
else
    if method_flag == 1
        fname1 = sprintf('mmu_pos_and_neg10k_random_method_model_selection_avgacc_wt%d.txt',wt_flag);
        fname7 = sprintf('mmu_pos_and_neg10k_random_method_model_selection_gmean_wt%d.txt',wt_flag);
        fparam = sprintf('mmu_pos_and_neg10k_random_method_model_selection_params_wt%d.txt',wt_flag);
    else
        fname1 = sprintf('mmu_pos_and_neg10k_new_method_model_selection_avgacc_wt%d.txt',wt_flag);
        fname7 = sprintf('mmu_pos_and_neg10k_new_method_model_selection_gmean_wt%d.txt',wt_flag);
        fparam = sprintf('mmu_pos_and_neg10k_new_method_model_selection_params_wt%d.txt',wt_flag);
    end
end

