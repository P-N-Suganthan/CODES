function [select_neg_indx] = new_selection_strategy_v6(indx_mat,trainpindx,trainnindx,thr)
%%%%Input description
%indx_mat: pos_samples_indx * sorted_neg_samples_indx (each row is indx of
%sorted distance b/w pos and neg samples. indices of neg samples are actual indices with respect to whole data)
%trainpindx: training indices of pos samples
%trainnindx: training indices of neg samples
%thr: ratio between neg_samples and pos_samples
%pnn: parameter for nearest neighbour removal
%feats_wt: fisher's wt of features

%modified to consider without radius case 
%modified to consider first "thr" number of negative samples corresponding to each positive sample and finally select unique samples.

%%%%Output description
select_neg_indx = [];
for i=1:size(trainpindx,1)
    indx = trainpindx(i);
    [indx_mat1,I1] = intersect(indx_mat(indx,:),trainnindx);
    I1=sort(I1,'ascend');
    select_neg_indx = [select_neg_indx,indx_mat(indx,I1(1:thr))];
end % End of positive sample indx loop
select_neg_indx = unique(select_neg_indx);
