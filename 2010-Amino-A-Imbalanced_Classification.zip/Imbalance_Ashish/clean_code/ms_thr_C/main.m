%%data dependent variable to load data, labels and other data dependent %things
%load the labels and scaled data
load scaled_data.mat; %scaled data: samples by feature matrix;
load labels.mat; %labels
data_flag = 7; %data_flag: to load other data dependent variable

%define problem variables
cvfold = 10; %Number of cross-validation for Outer loop
inner_cvfold = 5; %Number of cross-validation for inner loop
method_flag = 2; % No need to worry about this variable here

% put wt_flag to 0 if you don't want to use weighted-SVM
wt_flag = 1; 
[cv_avg_acc,TP,TN] = unbalanced_svm_model_selection_generalized_ms_thr_c(data,labels,cvfold,inner_cvfold,method_flag,wt_flag,data_flag);
