function [tdata,rm_indx] = scale_data(data,labels,nmax,nmin)
%function takes new max (nmax), new min (nmin), data and labels as input
%and scale all features of data into range [nmin,nmax].
%data should be samples by feature matrix
%labels should be column vector

%Output description
%tdata: is scaled data (samples by feature matrix). Each col has min -1 and max 1.
%rm_indx: indices with respect to input data matrix if original data has some features with same values for all samples

%Author: Ashish Anand
%Any bug you can email to anand.ashish@pmail.ntu.edu.sg

[no_samples,no_feats]=size(data);

omin=min(data); %omin stands for old min
omax=max(data);
rm_indx=[];
tmp = omax-omin;
if size(find(tmp)) < no_feats
    rm_indx=find(tmp==0);
    tmp1=ones(1,no_feats);
    tmp1(rm_indx)=0;
    tdata=data(:,find(tmp1));
else
    tdata=data;
end
omin=min(tdata); %omin stands for old min
omax=max(tdata);

tdata = (nmax-nmin)*(tdata-ones(no_samples,1)*omax);
tdata = 1+tdata./(ones(no_samples,1)*(omax-omin));
unique(max(tdata))
unique(min(tdata))
