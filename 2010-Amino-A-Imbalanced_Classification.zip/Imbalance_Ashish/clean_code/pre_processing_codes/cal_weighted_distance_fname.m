function cal_weighted_distance_fname(data,labels,fname)

%This function calculates weighted distance between negative and positive
%samples and saves the weighted distance into file "fname".
%Fisher's score is used as feature weights.

%Author: Ashish Anand

[m,n]=size(labels);
if m==1
    labels=labels';
end
[no_samples,no_feats]=size(data);
pos_samples=find(labels==1);
neg_samples=find(labels==-1);

feats_wt = cal_fisher_wt(data,labels);
data = repmat(feats_wt,no_samples,1).*data;
for i=1:size(neg_samples,1)
    i
    neg_x=data(neg_samples(i),:);
    tdist = sqrt(sum((repmat(neg_x,size(pos_samples,1),1)-data(pos_samples,:)).^2,2))';
    dlmwrite(fname,tdist,'delimiter','\t','-append','precision','%4.5f');
end

