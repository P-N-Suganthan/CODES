function get_sorted_indx(dist_mat)
%Takes input the dist_matrix calculated by using cal_weighted_distance_fname.m function
%dist_mat is distance between negative samples and positive sample, i.e., #_negative_sample by #_positive_sample matrix
%saves the indices of sorted negative samples for each positive sample.

t0=cputime;
for i = 1:size(dist_mat,2)
	i
	[y,I]=sort(dist_mat(:,i),'ascend');
	I=I+size(dist_mat,2);
	dlmwrite('actual_sorted_indx.txt',I','delimiter','\t','precision','%d','-append');
end
t1=cputime-t0
	
	
