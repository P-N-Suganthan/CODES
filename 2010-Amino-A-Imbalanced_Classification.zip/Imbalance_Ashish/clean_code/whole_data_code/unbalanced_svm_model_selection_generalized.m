function [cv_avg_acc,TP,TN] = unbalanced_svm_model_selection_generalized(data,labels,thr,cvfold,inner_cvfold,method_flag,wt_flag,data_flag,start_fold,end_fold)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get whole data, cvfold, no_runs, inner_cvfold
% Get method_flag: 1 for whole data
% fisher_seln, fisher_seln with different penalty weights
%data_flag: cysteine or active site data
%wt_flag: same or different penalty weight
%start_fold and end_fold if you want to run the code separately for different range of folds.
%It will help in getting the results faster as each outer-fold is independent to each other once
%partition is determined.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if size(labels,1) == 1
    labels = labels';
end
[no_samples,no_feats] = size(data);
pos_indx = find(labels == 1);
neg_indx = find(labels == -1);
no_pos_samples = size(pos_indx,1);
no_neg_samples = size(neg_indx,1);

codedir = sprintf('clean_code/whole_data_code');
svmdir = sprintf('libsvm/libsvm-mat-2.88-1/');

fname = sprintf('data%d_wholedata_CV_wt%d_fold%dto%d.txt',data_flag,wt_flag,start_fold,end_fold);
logfile = sprintf('data%d_wholedata_bestparam_gmean_wt%d_fold%dto%d.txt',data_flag,wt_flag,start_fold,end_fold);

rand('state',0);
pindx = randperm(no_pos_samples);
nindx = randperm(no_neg_samples);
t0 = cputime;
cv_acc = zeros(1,cvfold);
cv_TP = zeros(1,cvfold);
cv_TN = zeros(1,cvfold);
cv_gmean = zeros(1,cvfold);
for j = start_fold:end_fold
        j
        % get test and training data
        tv1 = ones(1,no_pos_samples);
        tv1(pindx(floor(no_pos_samples/cvfold)*(j-1)+1:floor(no_pos_samples/cvfold)*j)) = zeros(1,floor(no_pos_samples/cvfold));
        testpindex = pos_indx(find(tv1==0));
        trainpindex = pos_indx(find(tv1==1));
        
        tv2 = ones(1,no_neg_samples);
        tv2(nindx(floor(no_neg_samples/cvfold)*(j-1)+1:floor(no_neg_samples/cvfold)*j)) = zeros(1,floor(no_neg_samples/cvfold));
        testnindex = neg_indx(find(tv2==0));
        trainnindex = neg_indx(find(tv2==1));

        traindata = [data(trainpindex,:);data(trainnindex,:)];
        trainlabel = [labels(trainpindex);labels(trainnindex)];
        testdata = [data(testpindex,:);data(testnindex,:)];
        testlabel = [labels(testpindex);labels(testnindex)];
        
        if method_flag == 1            
            [best_param] = unbalanced_inner_cvfold_auc_generalized(traindata,trainlabel,method_flag,inner_cvfold,codedir,svmdir,wt_flag,data_flag,thr,start_fold,end_fold);

            x1 = [j,best_param];
            dlmwrite(logfile,x1,'delimiter','\t','-append');
            clear x1;
            if size(best_param,2) == 2
                if wt_flag == 0
                    strng = sprintf('-t 2 -c %f -g %f',best_param(1),best_param(2));
                else
                    pos_frac = (size(trainnindex,1)+size(trainpindex,1))/size(trainpindex,1);
                    neg_frac = (size(trainnindex,1)+size(trainpindex,1))/size(trainnindex,1);
                    strng = sprintf('-t 2 -c %f -g %f -w1 %f -w-1 %f',best_param(1),best_param(2),pos_frac,neg_frac);
                end
            else
                if wt_flag == 0
                    strng = sprintf('-t 2 -c %f',best_param(1));
                else
                    pos_frac = (size(trainnindex,1)+size(trainpindex,1))/size(trainpindex,1);
                    neg_frac = (size(trainnindex,1)+size(trainpindex,1))/size(trainnindex,1);
                    strng = sprintf('-t 2 -c %f -w1 %f -w-1 %f',best_param(1),pos_frac,neg_frac);
                end
            end
            cd(eval('svmdir'));
            model = svmtrain(trainlabel,traindata,eval('strng'));
	end

        [pred_label,acc,dec_vals] = svmpredict(testlabel,testdata,model);
        pred_pos_samples = pred_label(1:size(testpindex,1));
        pred_neg_samples = pred_label(size(testpindex,1)+1:size(testlabel,1));
        cv_acc(j) = acc(1);
        cv_TP(j) = size(find(testlabel(1:size(testpindex,1))-pred_pos_samples == 0),1);
        cv_TP(j) = cv_TP(j)/size(testpindex,1);
        cv_TN(j) = size(find(testlabel(size(testpindex,1)+1:size(testlabel,1))-pred_neg_samples == 0),1);
        cv_TN(j) = cv_TN(j)/size(testnindex,1);
	cv_gmean(j) = sqrt(cv_TP(j)*cv_TN(j));
        cd(eval('codedir'));
end
t1=cputime-t0;
cv_avg_acc = mean(cv_acc);
TP = mean(cv_TP);
TN = mean(cv_TN);
gmean = mean(cv_gmean);
x = [cv_acc,cv_avg_acc;cv_TP,TP;cv_TN,TN;cv_gmean,gmean];
dlmwrite(fname,x,'delimiter','\t','-append');
dlmwrite(fname,t1,'delimiter','\t','-append');

