%%data dependent variable to load data, labels and other data dependent %things
%load the labels and data
load scaled_data.mat; %scaled data: samples by feature matrix;
load labels.mat; %labels
data_flag = 6; %data_flag: to load other data dependent variable

%define problem variables
thr = 0; % No need to worry about this variable here
cvfold = 10; %Number of cross-validation for Outer loop
inner_cvfold = 5; %Number of cross-validation for inner loop
method_flag = 1; % No need to worry about this variable here
% you can change wt_flag to 0 if you don't want to use weighted-SVM
wt_flag = 1;
% indicate start_fold and end_fold if you want to run different outer %%% folds separately if one fold is taking too much time.
start_fold = 1;
end_fold = 10;
[cv_avg_acc,TP,TN] = unbalanced_svm_model_selection_generalized(data,labels,thr,cvfold,inner_cvfold,method_flag,wt_flag,data_flag,start_fold,end_fold);
