function [best_param] = unbalanced_inner_cvfold_auc_generalized(data,labels,method_flag,cvfold,codedir,svmdir,wt_flag,data_flag,thr,start_fold,end_fold)

[no_samples,no_feats] = size(data);
pos_indx = find(labels==1);
neg_indx = find(labels==-1);
no_pos_samples = size(pos_indx,1);
no_neg_samples = size(neg_indx,1);

pindx = randperm(no_pos_samples);
nindx = randperm(no_neg_samples);

fname1 = sprintf('data%d_wholedata_model_selection_avgacc_wt%d_fold%dto%d.txt',data_flag,wt_flag,start_fold,end_fold);
fname7 = sprintf('data%d_wholedata_model_selection_gmean_wt%d_fold%dto%d.txt',data_flag,wt_flag,start_fold,end_fold);
fparam = sprintf('data%d_wholedata_model_selection_params_wt%d_fold%dto%d.txt',data_flag,wt_flag,start_fold,end_fold);

c_val = [0.1,1,2,4,8]; 
g_val = [0.001,0.01,0.1];

param_sets = [c_val,g_val,thr];
auc_flag = 1; % 1: gmean

dlmwrite(fparam,param_sets,'delimiter','\t','-append');

for c_i = 1:size(c_val,2)
    for g_i = 1:size(g_val,2)
        cvacc = zeros(1,cvfold);
        cv_TP = zeros(1,cvfold);
        cv_TN = zeros(1,cvfold);
	cv_gmean = zeros(1,cvfold);
        for i=1:cvfold
            i
            tv1 = ones(1,no_pos_samples);
            tv1(pindx(floor(no_pos_samples/cvfold)*(i-1)+1:floor(no_pos_samples/cvfold)*i)) = zeros(1,floor(no_pos_samples/cvfold));
            testpindex = pos_indx(find(tv1==0));
            trainpindex = pos_indx(find(tv1==1));

            tv2 = ones(1,no_neg_samples);
            tv2(nindx(floor(no_neg_samples/cvfold)*(i-1)+1:floor(no_neg_samples/cvfold)*i)) = zeros(1,floor(no_neg_samples/cvfold));
            testnindex = neg_indx(find(tv2==0));
            trainnindex = neg_indx(find(tv2==1));

            traindata = [data(trainpindex,:);data(trainnindex,:)];
            trainlabel = [labels(trainpindex);labels(trainnindex)];
            testdata = [data(testpindex,:);data(testnindex,:)];
            testlabel = [labels(testpindex);labels(testnindex)];
                     
            if wt_flag == 0
                strng = sprintf('-t 2 -c %f -g %f',c_val(c_i),g_val(g_i));
            else
                pos_frac = (size(trainnindex,1)+size(trainpindex,1))/size(trainpindex,1);
                neg_frac = (size(trainnindex,1)+size(trainpindex,1))/size(trainnindex,1);
                strng = sprintf('-t 2 -c %f -g %f -w1 %f -w-1 %f',c_val(c_i),g_val(g_i),pos_frac,neg_frac);
            end
            
            cd(eval('svmdir'));
            model = svmtrain(trainlabel,traindata,eval('strng'));
            [plabel,acc,dvals] = svmpredict(testlabel,testdata,model);
            pred_pos_samples = plabel(1:size(testpindex,1));
            pred_neg_samples = plabel(size(testpindex,1)+1:size(testlabel,1));
            tpindx=find(testlabel==1);
            tnindx=find(testlabel==-1);
            cd(eval('codedir'));

            cvacc(i) = acc(1);
            cv_TP(i) = size(find(testlabel(1:size(testpindex,1))-pred_pos_samples == 0),1);
            cv_TP(i) = cv_TP(i)/size(testpindex,1);
            cv_TN(i) = size(find(testlabel(size(testpindex,1)+1:size(testlabel,1))-pred_neg_samples == 0),1);
            cv_TN(i) = cv_TN(i)/size(testnindex,1);
	    cv_gmean(i) = sqrt(cv_TP(i)*cv_TN(i));
        end %cvfold loop
        cv_avg_acc(c_i,g_i) = mean(cvacc);
        TP(c_i,g_i) = mean(cv_TP);
        TN(c_i,g_i) = mean(cv_TN);
	gmean(c_i,g_i) = mean(cv_gmean);
    end %g_val loop
end %c_val loop

dlmwrite(fname1,cv_avg_acc','delimiter','\t','-append');
dlmwrite(fname7,gmean','delimiter','\t','-append');

if auc_flag == 0
        [x,I] = max(TP);
        [y,I1] = max(x);
        best_param = [c_val(I(I1)),g_val(I1)];
else
	[x,I] = max(gmean);
	[y,I1] = max(x);
	best_param = [c_val(I(I1)),g_val(I1)];
end


