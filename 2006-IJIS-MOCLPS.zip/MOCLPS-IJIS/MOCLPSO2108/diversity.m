function delta=diversity(PF,PFt)
[NP,nn]=size(PF);
%[NPt,nnt]=size(PFt);
% [y,I]=sort(PF(:,1));
% for i=1:NP     PFc(i,:)=PF(I(i),:); end

for i=1:NP-1   d(i)=norm(PF(i,:)-PF(i+1,:)); end
md=mean(d);

[y1,I1]=max(PFt(:,1));
[y2,I2]=max(PFt(:,2));
df=norm(PF(1,:)-PFt(I2,:));
dl=norm(PF(NP,:)-PFt(I1,:));

for i=1:NP-1 x(i)=abs(d(i)-md); end
delta=(df+dl+sum(x))/(df+dl+(NP-1).*md);