function [ins_stat,del_stat,del_list]=non_dominate_ins_del_hl(xx1,x1,dim,n_obj)
global max_rep_size err

ins_stat=0;del_stat=0;del_list=[1];
[np,nn]=size(xx1);
ins_stat=0;
ff=repmat(x1(1,dim+1:dim+n_obj),np,1);
f1=(xx1(:,dim+1:dim+n_obj)-ff<=err);
f2=(xx1(:,dim+1:dim+n_obj)-ff<err);
f4=(ff-xx1(:,dim+1:dim+n_obj)<=err);
f5=(ff-xx1(:,dim+1:dim+n_obj)<err);
f3=sum(f1+f2,2); 
f6=sum(f4+f5,2);
stat2=find((sum(f1,2)==n_obj)&(sum(f2,2)>0));
stat1=find((sum(f4,2)==n_obj)&(sum(f5,2)>0));

if(~isempty(stat2)),%some member of rep dom x1
    ins_stat=0;del_stat=0;del_list=[1];
elseif (~isempty(stat1)), %no rep dom x1 and x1 dom some member of rep 
    del_stat=1;del_list=[1 stat1'];ins_stat=1;
else % non-dom each other
    ins_stat=1;
end