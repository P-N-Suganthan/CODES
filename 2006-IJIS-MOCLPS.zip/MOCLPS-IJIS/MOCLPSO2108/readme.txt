This program is for MOCLPSO.

The Main function file is MOCLPSO_func.m.


function [nds,nds_val,feval_count]=MOCLPSO_func(p,NP,max_rep_size,feval_max)

 ----------------
 Output arguments:
 ----------------
 nds:           non_dominated solutions
 nds_val:       fitness of non_dominated solutions
 feval_count:   fitness evaluations
 
 ---------------
 Input arguments:  
 ---------------
 p:         No. of Test problem
       8: SCH    
       9: FON
       11:ZDT1


 NP: population size
 max_rep_size:  archive size
 feval_max:  max fitness evaluations


Example: 
[nds,nds_val,feval_count]=MOCLPSO_func(11,50,100,10000)



 