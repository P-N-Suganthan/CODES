function [ins_stat,del_stat,del_list,xx1]=non_dominate_ins_del_con_hl(xx1,x1,dim,n_obj,err_tol)%
global xl xu
% xx1=[0 0 0 0 0 1 0;0 0 0 0 0 1 0;0 0 0 0 0 1 0;0 0 0 0 0 1 0];x1=[0.123 0.236 0.2 0 0.1 0.9 0];
% dim=4;n_obj=2;err_tol=0;

[np,nn]=size(xx1);
ins_stat=0;
if np==0,ins_stat=1;del_stat=0;del_list=[1];
else      
    feas_i=x1(1,dim+n_obj+1)<=err_tol;
    feas_others=find(xx1(:,dim+n_obj+1)<=err_tol);
    not_feas_others=find(xx1(:,dim+n_obj+1)>err_tol);
    
    if feas_i==1 & isempty(feas_others),ins_stat=1;del_stat=1;del_list=[1 1:np];end
    
    if feas_i==1 & ~isempty(feas_others),
        
        [ins_stat,del_stat,del_list1]=non_dominate_ins_del_hl(xx1(feas_others,:),x1,dim,n_obj);
        del_list=[1 feas_others(del_list1(2:length(del_list1))')' not_feas_others'];
    end
    
    if feas_i==0 & isempty(feas_others),r=find(xx1(:,dim+n_obj+1)>x1(1,dim+n_obj+1));
        del_list=[1];del_stat=0;
        if ~isempty(r),del_stat=1;del_list=[1 r'];ins_stat=1;end
    end
    
    if feas_i==0 & ~isempty(feas_others),del_stat=0;del_list=[1];end
end