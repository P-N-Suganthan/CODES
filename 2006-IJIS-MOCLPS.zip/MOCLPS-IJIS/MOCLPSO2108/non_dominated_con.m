function nIndex=non_dominated_con(xx1,dim,n_obj,err_tol)
%  xx1=[0.081468	0	0	0	0	0	0	0	0	0.092776 0.28078	3.8474	0
%       1	0	0	0	0	0	0	0	0	        0	      1	        0  	    0
%      0.081468	0	0	0	0	0	0	0	0	0.011604 0.28078	2.6763	0
%      0.081469	0	0	0	0	0	0	0	0   0	     0.28078 	0.92117	0
%     0.081468	0	0	0	0	0	0	0	0	0.079343 0.28078	3.7368	0
%     0.081468	0	0	0	0	0	0	0	0	0.022442 0.28078	2.985	0
%     0.081468	0	0	0	0	0	0	0	0	0.015939 0.28078	2.8186	0];
% x1=[0.081469	0	0	0	0	0	0	0	0	0	     0.28078	0.92117	0];
% 
%  dim=9;
%  n_obj=3;err_tol=0;

[np,nn]=size(xx1);

e=find(xx1(:,dim+n_obj+1)<=err_tol);
e1=find(xx1(:,dim+n_obj+1)>err_tol);
xx1=[xx1(e,:);xx1(e1,:)];
nIndex=[1];

for i=1:np
    not_i=find((1:np)'~=i);
    feas_i=xx1(i,dim+n_obj+1)<=err_tol; 
    feas_others=find(xx1(:,dim+n_obj+1)<=err_tol);
    feas_others=find(feas_others~=i);
    
    if feas_i==1 & isempty(feas_others),nIndex=[nIndex i];end
    if feas_i==1 & ~isempty(feas_others),
        ff=repmat(xx1(i,dim+1:dim+n_obj),length(feas_others),1);
        f1=find(sum(xx1(feas_others,dim+1:dim+n_obj)<ff,2)-n_obj*ones(length(feas_others),1)==0);
        f2=find((sum(xx1(feas_others,dim+1:dim+n_obj)>ff,2)==0));
        f3=any(sum(xx1(feas_others,dim+1:dim+n_obj)==ff,2)-n_obj*ones(length(feas_others),1)==0);
        
        stat=(isempty(f1) & isempty(f2))| f3;
        if stat==1,nIndex=[nIndex i];end
    end
    
    if feas_i==0 & isempty(feas_others),
        if all(xx1(not_i,dim+n_obj+1)>=xx1(i,dim+n_obj+1)),nIndex=[nIndex i];end    
    end
end




    
    
    
    
    
    
    
    
    
    





