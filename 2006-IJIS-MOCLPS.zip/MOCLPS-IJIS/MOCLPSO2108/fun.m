function [n,n_obj,xl,xu,mm,PFt]=fun(M,p)
%  n:     problem dimension
%  n_obj: number of problem objective
%  xl:    low bound
%  xu:    up bound
%  mm = 1  minmize  
%       0  maxmize
%  PFt:    True Pareto front
 
if p==8,n=1;n_obj=2;xl=-1000;xu=1000;mm=1; load SCH; PFt=SCH;end   %SCH
if p==9,n=3;n_obj=2;xl=[-4 -4 -4];xu=[4 4 4];mm=1; load FON; PFt=FON; end   %FON
if p==11,n=30;n_obj=2;xl=zeros(1,n);xu=ones(1,n);mm=1; load ZDT1; PFt=ZDT1;end   %ZDT1
