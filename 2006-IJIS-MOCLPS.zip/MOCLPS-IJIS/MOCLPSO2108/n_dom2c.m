function [p,count]=n_dom2c(p1,p2,rep,dim,n_obj,err_tol,count,err)
if p1(1,dim+n_obj+1)<=err_tol & p2(1,dim+n_obj+1)<=err_tol,
    
    f1=p1(dim+1:dim+n_obj)-p2(dim+1:dim+n_obj)<=err;
    f2=p1(dim+1:dim+n_obj)-p2(dim+1:dim+n_obj)<err;
    f4=p2(dim+1:dim+n_obj)-p1(dim+1:dim+n_obj)<=err;
    f5=p2(dim+1:dim+n_obj)-p1(dim+1:dim+n_obj)<err;   
    
    if (sum(f1)==n_obj)&(sum(f2)>0),p=p1;
    elseif ((sum(f4)==n_obj)&(sum(f5)>0)),p=p2;count=count+1;
    else
        f=rand<0.5;
       
        if f==1,p=p2;count=count+1;
        else p=p1;
        end

    end
elseif(p1(1,dim+n_obj+1)>err_tol & p2(1,dim+n_obj+1)>err_tol)
    if p1(1,dim+n_obj+1)>p2(1,dim+n_obj+1),p=p2;count=count+1; else p=p1;end
elseif(p1(1,dim+n_obj+1)<=err_tol & p2(1,dim+n_obj+1)>err_tol);
    p=p1;
else
    p=p2;count=count+1;
end
