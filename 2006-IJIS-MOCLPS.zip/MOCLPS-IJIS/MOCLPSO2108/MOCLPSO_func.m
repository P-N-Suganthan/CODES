%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MOCLPSO
%Huang Ling   August 2005
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [nds,nds_val,feval_count]=MOCLPSO_func(p,NP,max_rep_size,feval_max)
%  ----------------
%  Output arguments:
%  ----------------
%  nds:           non_dominated solutions
%  nds_val:       fitness of non_dominated solutions
%  feval_count:   fitness evaluations
%  
%  ---------------
%  Input arguments:  
%  ---------------
%  p:         No. of Test problem
%        8:  SCH    
%        9:  FON
%        11: ZDT1

%  NP: population size
%  max_rep_size:  archive size
%  feval_max:  max fitness evaluations
% 
% Example: 
% [nds,nds_val,feval_count]=MOCLPSO_func(11,50,100,10000)

global xl xu n n_obj err
maxgen=ceil(feval_max/NP);
Pc=0.1;   % learning probability
m=0.4;    %elitism probability
m=m*ones(1,maxgen);
err=10^-5;
[n,n_obj,xl,xu,mm,PFt]=fun(2,p);
m=round(m.*n);
Pc=Pc*ones(1,NP);
yeta=0.729;
cc=[2.05 2.05];
vmax=0.25*ones(maxgen,n);

rep=[];err_tol=0;
fname='moclpso_testfn';
feval_count=0;
vv=zeros(NP,n);
count=zeros(1,NP); 
con=0; % error tolerance for equality constraints
if con==0,    err_tol=0;else    err_tol=10^-3;end

%initialize particle
for i=1:NP     particle(i,:)=xl+(xu-xl).*rand(1,n);end

for i=1:NP
    feval_count=feval_count+1;
    particle(i,n+1:n+n_obj+1)=feval(fname,particle(i,1:n),n,p);
end

Index=non_dominated_con(particle,n,n_obj,err_tol);
rep=particle(Index',:); rep_size=length(Index);
pbest=particle;
ai=zeros(NP,n);
f_pbest=1:NP;f_pbest=repmat(f_pbest',1,n);
for k=1:NP       
    ar=randperm(n);
    ai(k,ar(1:m(1)))=1;
    fi=ceil(NP*rand(1,n));
    bi=ceil(rand(1,n)-1+Pc(k));
    if bi==zeros(1,n),rc=randperm(n);bi(rc(1))=1;end
    f_pbest(k,:)=bi.*fi+(1-bi).*f_pbest(k,:);
end

for gcount=2:maxgen     
    for k=1:NP        
        if count(k)>=2
            count(k)=0;
            ai(k,:)=zeros(1,n);
            f_pbest(k,:)=k.*ones(1,n); 
            ar=randperm(n);
            ai(k,ar(1:m(gcount)))=1;
            fi=ceil(NP*rand(1,n));
            bi=ceil(rand(1,n)-1+Pc(k));
            if bi==zeros(1,n),rc=randperm(n);bi(rc(1))=1;end
            f_pbest(k,:)=bi.*fi+(1-bi).*f_pbest(k,:);
        end
    end
    
    for j=1:NP    
        for jj=1:n
            pbest_f(j,jj)=pbest(f_pbest(j,jj),jj);
        end
        [repsize,repd]=size(rep);
        h=ceil(rand*rep_size);
        if h>repsize,h=repsize;            end
        vv(j,:)=yeta*(vv(j,:)+cc(1).*(1-ai(j,:)).*rand(1,n).*(pbest_f(j,1:n)-particle(j,1:n))+cc(2).*ai(j,:).*rand(1,n).*(rep(h,1:n)-particle(j,1:n))); 
        vv(j,1:n)=(vv(j,1:n)<-vmax(j,:)).*(-vmax(j,:))+(vv(j,1:n)>=-vmax(j,:)).*vv(j,1:n);
        vv(j,1:n)=(vv(j,1:n)>vmax(j,:)).*vmax(j,:)+(vv(j,1:n)<=vmax(j,:)).*vv(j,1:n);
        particle_old(j,1:n)=particle(j,1:n);
        particle(j,1:n)=vv(j,:)+particle(j,1:n);
        xerr=sum(abs(min(particle(j,1:n)-xl,0))+abs(min(xu-particle(j,1:n),0)),2);
        if xerr~=0,
            particle(j,1:n)=(particle(j,1:n)<xl).*xl+(particle(j,1:n)>=xl).*particle(j,1:n);
            particle(j,1:n)=(particle(j,1:n)>xu).*xu+(particle(j,1:n)<=xu).*particle(j,1:n);
            vv(j,1:n)=(particle(j,1:n)<xl).*(-vv(j,1:n))+(particle(j,1:n)>=xl).*vv(j,1:n);
            vv(j,1:n)=(particle(j,1:n)>xu).*(-vv(j,1:n))+(particle(j,1:n)<=xu).*vv(j,1:n);
        end
        feval_count=feval_count+1;
        particle(j,n+1:n+n_obj+1)=feval(fname,particle(j,1:n),n,p);
        [pbest(j,:),count(j)]=n_dom2c(particle(j,:),pbest(j,:),rep,n,n_obj,err_tol,count(j),err);
    end  
    
    non_index=non_dominated_con(particle,n,n_obj,err_tol);
    no_non_index=length(non_index);
    if no_non_index>1,         
        for ii=1:no_non_index-1
            [ins_stat,del_stat,del_list]=non_dominate_ins_del_con_hl(rep,particle(non_index(ii+1),:),n,n_obj,err_tol);
            if del_stat==1,
                [rep,rep_size]=matdelete(rep,del_list(2:length(del_list)));
            end
            if ins_stat==1,         
                rep=[rep;particle(non_index(ii+1),:)];
                rep_size=rep_size+1;
            end
        end 
    end
    if rep_size>max_rep_size,
        rep=mopso_crowding_distance(rep,n,n_obj,max_rep_size);
    end
    
    if feval_count>feval_max,break, end
end
nds=rep(:,1:n);
if mm==1,nds_val=rep(:,n+1:n+n_obj);
else nds_val=-rep(:,n+1:n+n_obj);
end