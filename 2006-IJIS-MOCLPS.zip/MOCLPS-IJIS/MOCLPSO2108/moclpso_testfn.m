function f=moclpso_testfn(x,n,p)
% test problem

%problem8------SCH-----------------------------
if p==8,
    f(1,1)=x^2;
    f(1,2)=(x-2)^2;
    f(1,3)=0;
end
%problem9------FON-----------------------------
if p==9,
    for i=1:n fit1(i)=(x(i)-1/sqrt(n))^2; fit2(i)=(x(i)+1/sqrt(n))^2;end
    f(1,1)=1-exp(-sum(fit1));
    f(1,2)=1-exp(-sum(fit2));
    f(1,3)=0;
end

%problem11------ZDT1-----------------------------
if p==11,
    f(1,1)=x(1);
    for i=2:n
        fit(i)=x(i);
    end
    g=1+9*sum(fit)/(n-1);
    f(1,2)=g*(1-sqrt(f(1,1)/g));
    f(1,3)=0;
end
