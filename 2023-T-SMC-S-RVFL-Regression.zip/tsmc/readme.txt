
The python code using cupy to speed up the training

-----------------------

For very large dataset that couldn't fit into GPU, can consider using the cpu code and train using cpu ram. 

Armadillo library is required for the cpu code.

----------------------

The python and cpp code given are for the "Two-stage edRVFL-RSC" mentioned in paper. 




