import os

for root, dirs, files in os.walk("./", topdown=False):
    if("data/" in root):
        cdir = root[7:]
        f = open(os.path.join(root,cdir+".txt"), "r")
        info = f.read().split()
        lengthSize = int(info[1])
        if (not os.path.exists(os.path.join(root,"resultensembleEdRVFL+REnsembleTwice_fernandez_"+cdir+".csv"))) and lengthSize<10000:
            try:
                print("opening "+cdir)
                os.system("python fernandez_ensemble_twice_combined_edrvfl+.py "+root+" "+cdir+" "+info[-1])
            except:
                print("fail to run "+cdir)
        else:
            print("skipping "+cdir)
