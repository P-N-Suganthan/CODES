import os
import pandas as pd
import numpy as np

for root, dirs, files in os.walk("./", topdown=False):
    if("data/" in root):
        cdir = root[7:]
        print("writing to "+cdir)
        try:
            f = open(os.path.join(root,cdir+".txt"), "r")
            info = f.read().split()[-1]
            if info == "T" or info == "F":
                print("eixsted")
                continue
            f.close()
        
            with open(os.path.join(root,cdir+"_R.dat")) as f:
                first_line = f.readline()
                print(first_line)
            ans = input("decision?\n")
            f=open(os.path.join(root,cdir+".txt"), "a+")
            if ans == "t":
                f.write("T")
            else:
                f.write("F")
            f.close()
        except:
            print("something wrong")
