import os
import shutil
count = 0

for root, dirs, files in os.walk("./", topdown=False):
    if("data/" in root):
        cdir = root[7:]
        try:
            f = open(os.path.join(root,cdir+".txt"), "r")
            info = f.read().split()
            lengthSize = int(info[1])
            if lengthSize>=10000:
                try:
                    count+=1
                    print("moving "+cdir)
                    dest = shutil.move(root,"/home/JHerng/fernandez_large/data/")
                except:
                    count-=1
                    print("fail to move "+cdir)
            else:
                print("skipping "+cdir)
        except:
            print("nothing")
