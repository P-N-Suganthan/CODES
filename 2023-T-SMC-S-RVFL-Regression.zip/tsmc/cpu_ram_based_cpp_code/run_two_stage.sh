echo "start two_stage" && g++ two_stage.cpp -o two_stage -std=c++17 -larmadillo && ./two_stage
