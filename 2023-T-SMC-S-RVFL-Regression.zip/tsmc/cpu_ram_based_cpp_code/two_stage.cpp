#include<iostream>
#include<armadillo>
#include<string>
#include<vector>
#include<cmath>
#include<algorithm>
#include<tuple>
#include<chrono>
#include <fstream>
#include <set>
#include <iterator>
#include<numeric>
#include<cstdlib>

using namespace std;


double Average(vector<double> v)
{      double sum=0;
       for(int i=0;i<v.size();i++)
               sum+=v[i];
       return sum/v.size();
}
double Deviation(vector<double>data)
{
    double sum = 0.0, mean, standardDeviation = 0.0;

	int length = data.size();

    for(int i = 0; i < length; i++)
    {
        sum += data[i];
    }

    mean = sum/length;

    for(int i = 0; i < length; i++){
        standardDeviation += pow(data[i] - mean, 2);
	}	

    return sqrt(standardDeviation / length);
}

template<typename T> std::vector<int> argsort(const std::vector<T>& array)
{
	const double array_len(array.size());
	std::vector<int> array_index(array_len, 0);
	for (int i = 0; i < array_len; ++i)
		array_index[i] = i;

	std::sort(array_index.begin(), array_index.end(),
		[&array](int pos1, int pos2) {return (array[pos1] < array[pos2]);});

	return array_index;

}

class CSVWriter
{
	std::string fileName;
	std::string delimeter;
	int linesCount;
 
public:
	CSVWriter(std::string filename, std::string delm = ",") :
			fileName(filename), delimeter(delm), linesCount(0)
	{}

	template<typename T>
	void addDatainRow(T first, T last);
};
 

template<typename T>
void CSVWriter::addDatainRow(T first, T last)
{
	std::fstream file;
	file.open(fileName, std::ios::app | (linesCount ? std::ios::app : std::ios::trunc));
 
	for (; first != last; )
	{
		file << *first;
		if (++first != last)
			file << delimeter;
	}
	file << "\n";
	linesCount++;
 
	file.close();
}


struct optionChoice{
	int N;
	int L2;
	unsigned long C;
	float scale;
	int act;
	bool norm;

};

struct modelTrained{
	int L2;
	vector<arma::mat> w;
	vector<arma::mat> b;
	vector<arma::mat> beta;
	int act;
	bool norm;
	vector<int> luckyStore;


};


double relu(double x){
	return max(x,0.0);
}

double sigmoid(double x){
	return 1.0/(1.0 + exp(-1*x));
}

double tribas(double x){
	return max(1.0-abs(x),0.0);
}

double tansig(double x){
	return (exp(x) - exp(-1*x))/(exp(x)+exp(-1*x));
}

double setThres1(double x){
	return max(x,0.000001);
}

arma::mat normalization(arma::mat A1_train, arma::mat w, arma::mat b){
	A1_train = A1_train*w;
	arma::mat mean = arma::mean(A1_train, 0);
	arma::mat std = arma::stddev(A1_train);
	// arma::mat newStd(size(std));
	std.transform(setThres1);
	// std::transform (std.begin(), std.end(), std.begin(), setThres1);
	A1_train = (A1_train - (arma::mat(A1_train.n_rows,1,arma::fill::ones))*mean) / ((arma::mat(A1_train.n_rows,1,arma::fill::ones))*std);
	A1_train = A1_train + (arma::mat(A1_train.n_rows,1,arma::fill::ones))*b;
	return A1_train;


}



tuple<int,double,struct modelTrained,int> MRVFLtrain_val(arma::mat trainX, arma::mat trainY, arma::mat validX, arma::mat validY, optionChoice *option){

	unsigned long Nsample_train = trainX.n_rows;
	int Nfea = trainX.n_cols;
	unsigned long Nsample_valid = validX.n_rows;
	int lucky = 0;
	arma::mat A1_train = trainX;
	arma::mat A1_valid = validX;
	arma::mat A_input = trainX;
	arma::mat A_input_valid = validX;

	vector<int> luckyStore;
	arma::arma_rng::set_seed_random();
	vector<arma::mat> weights;
	vector<arma::mat>biases;
	vector<arma::mat> beta_computed;
	vector<arma::mat> A_store;
	vector<arma::mat> A_valid_store;
	vector<arma::mat> A_computed;
	vector<arma::mat> A_valid_computed;
	arma::cube trainY_computed;
	arma::cube  validY_computed;

	typedef std::chrono::high_resolution_clock Time;
	typedef std::chrono::duration<float> fsec;
    auto t0 = Time::now();
	for(unsigned int i = 0; i < (option->L2);i++){
		arma:: mat w;
		if (i == 0){
			w = (option->scale)*(2*arma::mat(Nfea,option->N,arma::fill::randu)-1);
		}else if(i >= 3){
			w = (option->scale)*(2*arma::mat(Nfea+2*option->N,option->N,arma::fill::randu)-1);
		}
		else{
			w = (option->scale)*(2*arma::mat(Nfea+option->N,option->N,arma::fill::randu)-1);
		}
		arma::mat b = arma::mat(1,option->N,arma::fill::randu)*option->scale;

		weights.push_back(w);
		biases.push_back(b);
		if(i>1){
			srand (time(NULL));
			lucky = rand()%(i-1);
			luckyStore.push_back(lucky);
		}else{
			luckyStore.push_back(-1);
		}
		if(option->norm){
			A1_train = normalization(A_input,w,b);
		}else{
			A1_train = A_input*w;
			A1_train = A1_train + (arma::mat(A1_train.n_rows,1,arma::fill::ones))*b;
		}
		switch(option->act){

			case 2:
				A1_train.transform(relu);
				// transform (A1_train.begin(),A1_train.end(), A1_train.begin(), relu);
				break;

			case 1:
				A1_train.transform(tansig);
				// transform (A1_train.begin(),A1_train.end(), A1_train.begin(), tansig);
				break;

			case 3:
				A1_train.transform(tribas);
				// transform (A1_train.begin(),A1_train.end(), A1_train.begin(), tribas);
				break;

			default:
				A1_train.transform(sigmoid);
				// transform (A1_train.begin(),A1_train.end(), A1_train.begin(), sigmoid);
				break;
		}
		A_store.push_back(A1_train);
		arma::mat A_train_output = arma::join_horiz(A_input,A1_train,arma::mat(Nsample_train,1,arma::fill::ones));
		arma::mat beta;
		if(A_train_output.n_cols<Nsample_train){
			try
			{
				beta = arma::solve((arma::mat(A_train_output.n_cols,A_train_output.n_cols,arma::fill::eye)/(option->C) + A_train_output.t()*A_train_output),A_train_output.t()*trainY,arma::solve_opts::no_approx);

			}
			catch(const std::exception& e)
			{
				std::cerr << e.what() << '\n';
				exit(-1);
			}
			
		}else{

			try
			{
				beta = A_train_output.t()*arma::solve((arma::mat(A_train_output.n_rows,A_train_output.n_rows,arma::fill::eye)/(option->C) + A_train_output*A_train_output.t()),trainY,arma::solve_opts::no_approx);
			}
			catch(const std::exception& e)
			{
				std::cerr << e.what() << '\n';
				exit(-1);
			}
			
		}
		beta_computed.push_back(beta);
		A_computed.push_back(A_train_output);

		if(i>1){
			A_input = arma::join_horiz(trainX,A_store[lucky],A1_train);
		}else{
			A_input = arma::join_horiz(trainX,A1_train);
		}
		//validation starts here

		if(option->norm){
			A1_valid = normalization(A_input_valid,w,b);
		}else{
			A1_valid = (A_input_valid*w);
			A1_valid = A1_valid+(arma::mat(A1_valid.n_rows,1,arma::fill::ones)*b);
	
		}
		switch(option->act){

			case 2:
				A1_valid.transform(relu);
				// transform (A1_valid.begin(),A1_valid.end(), A1_valid.begin(), relu);
				break;

			case 1:
				A1_valid.transform(tansig);
				//transform (A1_valid.begin(),A1_valid.end(), A1_valid.begin(), tansig);
				break;

			case 3:
				A1_valid.transform(tribas);
				//transform (A1_valid.begin(),A1_valid.end(), A1_valid.begin(), tribas);
				break;

			default:
				A1_valid.transform(sigmoid);
				//transform (A1_valid.begin(),A1_valid.end(), A1_valid.begin(), sigmoid);
				break;
		}

		A_valid_store.push_back(A1_valid);


		A_valid_computed.push_back(arma::join_horiz(A_input_valid,A1_valid,arma::mat(Nsample_valid,1,arma::fill::ones)));
		
		if(i>1){
			A_input_valid = arma::join_horiz(validX,A_valid_store[lucky],A1_valid);
		}else{

			A_input_valid = arma::join_horiz(validX,A1_valid);
		}
		


	}
	

	vector<double> TrainingRMSE_temp_median;
	vector<double> ValidationRMSE_temp_median;

	for(unsigned int k =0; k<option->L2; k++){
		trainY_computed = arma::join_slices(trainY_computed,((A_computed[k])*(beta_computed[k])));
		validY_computed = arma::join_slices(validY_computed,((A_valid_computed[k])*(beta_computed[k])));

		arma::mat trainY_temp(size(trainY_computed.slice(0)));
		arma::mat validY_temp(size(validY_computed.slice(0)));
		for(unsigned int r = 0; r<trainY_temp.n_rows; r++){
			for(unsigned int c = 0; c< trainY_temp.n_cols; c++){
				trainY_temp(r,c) = (double)arma::as_scalar(arma::median(arma::mat(trainY_computed.subcube(arma::span(r), arma::span(c), arma::span::all )),1));

			}

		}

		for(unsigned int r = 0; r<validY_temp.n_rows; r++){
			for(unsigned int c = 0; c< validY_temp.n_cols; c++){
				validY_temp(r,c) = (double)arma::as_scalar(arma::median(arma::mat(validY_computed.subcube(arma::span(r), arma::span(c), arma::span::all )),1));

			}

		}



		TrainingRMSE_temp_median.push_back((double)arma::as_scalar(arma::sqrt(arma::mean(arma::pow(trainY-trainY_temp,2)))));
		ValidationRMSE_temp_median.push_back((double)arma::as_scalar(arma::sqrt(arma::mean(arma::pow(validY-validY_temp,2)))));
	}

	int bestValidMedianL = (int)(min_element(ValidationRMSE_temp_median.begin(),ValidationRMSE_temp_median.end()) - ValidationRMSE_temp_median.begin());

    auto t1 = Time::now();
    fsec fs = t1 - t0;
	int duration = int(fs.count());
	struct modelTrained bestModel = {bestValidMedianL,weights,biases,beta_computed,option->act,option->norm,luckyStore};
	

	return make_tuple(bestValidMedianL,(double)arma::as_scalar(*min_element(ValidationRMSE_temp_median.begin(),ValidationRMSE_temp_median.end())),bestModel,duration);
	

}


arma::mat MRVFLpredict(arma::mat testX, arma::mat testY, struct modelTrained model){

	unsigned long Nsample = testX.n_rows;
	int Nfea = testX.n_cols;
	int L = model.L2+1;
	arma::cube testY_computed;

	arma::mat A_input = testX;
	vector<arma::mat> A_store;
	vector<arma::mat> A;

	for(unsigned int i =0; i<L;i++){
		arma::mat A1;
		if(model.norm){
			A1 = normalization(A_input,model.w[i],model.b[i]);
		}else{
			A1 = (A_input*model.w[i]);
			A1 = A1 + arma::mat(A1.n_rows,1,arma::fill::ones)*(model.b[i]);
		}
		switch(model.act){

			case 2:
				A1.transform(relu);
				//transform (A1.begin(),A1.end(), A1.begin(), relu);
				break;

			case 1:
				A1.transform(tansig);
				//transform (A1.begin(),A1.end(), A1.begin(), tansig);
				break;

			case 3:
				A1.transform(tribas);
				//transform (A1.begin(),A1.end(), A1.begin(), tribas);
				break;

			default:
				A1.transform(sigmoid);
				//transform (A1.begin(),A1.end(), A1.begin(), sigmoid);
				break;
		}

		A_store.push_back(A1);
		arma::mat A1_temp1 = arma::join_horiz(A_input,A1,arma::mat(Nsample,1,arma::fill::ones));
		A.push_back(A1_temp1);

		if(i>1){
			A_input = arma::join_horiz(testX,A_store[model.luckyStore[i]],A1);
		}else{
			A_input = arma::join_horiz(testX,A1);
		}


	}


	for(unsigned int k =0; k<L; k++){
		testY_computed = arma::join_slices(testY_computed,(A[k]*model.beta[k]));

	}

	arma::mat testY_temp(size(testY_computed.slice(0)));
	for(unsigned int r = 0; r<testY_temp.n_rows; r++){
		for(unsigned int c = 0; c< testY_temp.n_cols; c++){
			testY_temp(r,c) = (double)arma::as_scalar(arma::median(arma::mat(testY_computed.subcube(arma::span(r), arma::span(c), arma::span::all )),1));

		}
	}

	return testY_temp;



}




int main(int argc, char * argv[]){
	int topK = 3;
	int num_folds = 5;
	arma::mat data;
	data.load("cleaned_data1.csv",arma::csv_ascii);
	vector<int> number_of_neurons = {300,250,200,150,100,50};

	CSVWriter writer("result_of_two_stage_edRVFL+R.csv");

	// if !argc > 1 {
	// 	return -1;
	// }
	arma::arma_rng::set_seed_random();
	data = arma::shuffle(data);
	// cout<<"data"<<endl<<data.rows(3)<<endl;
	arma::mat features = data.submat(1,0,data.n_rows-1,data.n_cols-2);
	arma::mat target = data.submat(1,data.n_cols-1,data.n_rows-1,data.n_cols-1);
	// cout<<"features"<<endl<<features.rows(3)<<endl;
	// cout<<"target"<<endl<<target.rows(3)<<endl;
	float frac  = 0.3;
	arma::mat testX = features.submat((unsigned long)((1-frac)*features.n_rows),0,features.n_rows-1,features.n_cols-1);
	arma::mat testY = target.submat((unsigned long)((1-frac)*target.n_rows),target.n_cols-1,target.n_rows-1,target.n_cols-1);
	arma::mat trainX = features.submat(0,0,(unsigned long)((1-frac)*features.n_rows)-1,features.n_cols-1);
	arma::mat trainY = target.submat(0,target.n_cols-1,(unsigned long)((1-frac)*target.n_rows)-1,target.n_cols-1);


	struct optionChoice option;
	option.L2 = 51;
	option.scale = 1;

	long int span = (long int)(trainX.n_rows / num_folds);
	for(unsigned int a =0;a<2;a++){
		option.act = a;
		for(auto n:number_of_neurons){
			option.N = n;
			for(int i =0; i<31; i++){

				option.C = pow(2,i);

				cout<<"N = "<<option.N<<" C = "<<option.C<<" act= "<<option.act<<" , starts now"<<endl;
				vector<double> totalTrainTime;
				vector<double> totalTestTime;
				vector<double>trainMedianRMSEArray;
				vector<double>testMedianRMSEArray;

				for(unsigned int r =0; r<10; r++){

					vector<double> RMSECollections;
					vector<modelTrained> modelList;
					vector<double>TrainTime;
					for(int s =0; s<num_folds;s++){
						
						long int first = min( (long int)(span*(s+1)-1),(long int)(trainX.n_rows-1));
						long int third = min((long int)(span*(s+1)),(long int)(trainX.n_rows-1));
						long int fourth = max((long int)(span*(s)-1),(long int)0);

						arma::mat X_valid = trainX.submat(span*s,0,first,trainX.n_cols-1);
						arma::mat y_valid = trainY.submat(span*s,trainY.n_cols-1,first,trainY.n_cols-1);
						arma::mat X_train = arma::join_vert(trainX.submat(0,0,fourth,trainX.n_cols-1),trainX.submat(third,0,trainX.n_rows-1,trainX.n_cols-1));
						arma::mat y_train = arma::join_vert(trainY.submat(0,trainY.n_cols-1,fourth,trainY.n_cols-1),trainY.submat(third,trainY.n_cols-1,trainX.n_rows-1,trainY.n_cols-1));

						option.norm = false;
						auto[bestValidMedianL,validRMSE,model,trainTime] = MRVFLtrain_val(X_train,y_train,X_valid,y_valid,&option);
						// cout<<bestValidMedianL<<" "<<validRMSE<<endl;
						option.norm = true;
						auto[bestValidMedianLNorm,validRMSENorm,modelNorm, trainTimeNorm] = MRVFLtrain_val(X_train,y_train,X_valid,y_valid,&option);
						// cout<<bestValidMedianLNorm<<" "<<validRMSENorm<<endl;
						if(validRMSE<validRMSENorm){
							modelList.push_back(model);
							RMSECollections.push_back(validRMSE);
							TrainTime.push_back(trainTime);
						}else{
							modelList.push_back(modelNorm);
							RMSECollections.push_back(validRMSENorm);
							TrainTime.push_back(trainTimeNorm);
						}
						
					}

					totalTrainTime.push_back(std::accumulate(TrainTime.begin(), TrainTime.end(),decltype(TrainTime)::value_type(0)));
					// for(auto cc:RMSECollections){
					// 	cout<<cc<<" ";
					// }

					vector<int> index = argsort(RMSECollections);
					// cout << std::endl;
					// for (int item : index){
					// 	std::cout << item << "\t";
					// }

					// cout << std::endl;

					double rmse_temp =0;
					arma::cube predictionList;
					typedef std::chrono::high_resolution_clock Time;
					typedef std::chrono::duration<float> fsec;
					auto t0 = Time::now();
					for(unsigned int ra =0; ra<topK; ra++){
						rmse_temp += RMSECollections[index[ra]];
						arma::mat prediction = MRVFLpredict(testX,testY,modelList[index[ra]]);
						predictionList = arma::join_slices(predictionList,prediction);
					}

					trainMedianRMSEArray.push_back(rmse_temp/topK);	
					arma::mat predictionMedian(size(predictionList.slice(0)));
					for(unsigned int rowN = 0; rowN <predictionList.slice(0).n_rows; rowN ++){
						for(unsigned int colN = 0; colN < predictionList.slice(0).n_cols; colN ++){
							predictionMedian(rowN ,colN ) = (double)arma::as_scalar(arma::median(arma::mat(predictionList.subcube(arma::span(rowN ), arma::span(colN ), arma::span::all )),1));

						}

					}

					double TestingMedianRMSE = (double)arma::as_scalar(arma::sqrt(arma::mean(arma::pow(testY-predictionMedian,2))));
					testMedianRMSEArray.push_back(TestingMedianRMSE);
					auto t1 = Time::now();
					fsec fs = t1 - t0;
					int duration = int(fs.count());
					totalTestTime.push_back(duration);


		

				}


				for(auto cc:testMedianRMSEArray){
						cout<<cc<<" ";
				}
				cout<<endl;
				double avgTrainMedianRMSE = accumulate( trainMedianRMSEArray.begin(), trainMedianRMSEArray.end(), 0.0) / trainMedianRMSEArray.size();
				double avgTestMedianRMSE = accumulate( testMedianRMSEArray.begin(), testMedianRMSEArray.end(), 0.0) / testMedianRMSEArray.size();

				double testSTD = Deviation(testMedianRMSEArray);
				double avgTrainTime = Average(totalTrainTime);
				double avgTestTime = Average(totalTestTime);

				cout<<"Avg train RMSE is "<<avgTrainMedianRMSE<<", avg test RMSE is "<<avgTestMedianRMSE<<", testSTD is "<<testSTD<<", avg train time is "<<avgTrainTime<<", avg Test time is "<<avgTestTime<<endl;
				vector<string> dataList_1 = {to_string(option.N),to_string(option.C),to_string(option.act),to_string(avgTrainMedianRMSE),to_string(avgTestMedianRMSE),to_string(testSTD),to_string(avgTrainTime),to_string(avgTestTime)};

				writer.addDatainRow(dataList_1.begin(), dataList_1.end());


		 

			}

		}
	
	}





	

	return 0;

}


