function ECHT_EP_F(Prob_Set_Par, func_num_Par)

global  nfeval
format long e;

 func_num = func_num_Par;    % Function Number
 NP       = 50;    % Size of Population
 Prob_Set = Prob_Set_Par;     % 1 for CEC 2006 and 2 for New Problems
 Max_FES  = 240000;% Maximum number of function evaluations
 Max_Gen  = 1200;  % Maximum number of generations
 initialDelta = 10^(-4);
 num_Run = 1;    % Maximum number of runs

 best_known=[-15.00000 -0.803619    -1       -30665.538672  5126.498110 -6961.813800 24.306209   -0.095825  680.630057  7049.330700...
     0.75       -1       0.0539498  -47.764411     961.715172   -1.905155   8876.980680 -0.865735   32.655593   0.096737...
     193.778349 382.902205 -400.002500 -5.508013];
 
 defined_value_one = best_known;
 mark = best_known < 0;
 defined_value_one = defined_value_one.*(0.99*mark) + defined_value_one.*(1-mark);
 defined_value_one = defined_value_one.*(1.01*(1-mark)) + defined_value_one.*mark;
 
 defined_value_two = defined_value_one([3,14,5,11,13,15,17,21,22,23]);
 
 if(Prob_Set == 1)
    Xmin1=[0 0 0 0 0 0 0 0 0 0 0 0 0];
    Xmax1=[1 1 1 1 1 1 1 1 1 100 100 100 1];
    Xmin2=zeros(1,20)+1e-100;
    Xmax2=10.*ones(1,20);
    Xmin3=zeros(1,10);
    Xmax3=ones(1,10);
    Xmin4=[78 33 27 27 27];
    Xmax4=[102 45 45 45 45];
    Xmin5=[0 0 -0.55 -0.55];
    Xmax5=[1200 1200 0.55 0.55];
    Xmin6=[13 0];
    Xmax6=[100 100];
    Xmin7=-10.*ones(1,10);
    Xmax7=10.*ones(1,10);
    Xmin8=[0 0];
    Xmax8=[10 10];
    Xmin9=-10.*ones(1,7);
    Xmax9=10.*ones(1,7);
    Xmin10=[100 1000 1000 10 10 10 10 10];
    Xmax10=[10000 10000 10000 1000 1000 1000 1000 1000];
    Xmin11=[-1 -1];
    Xmax11=[1 1];
    Xmin12=[0 0 0];
    Xmax12=[10 10 10];
    Xmin13=[-2.3 -2.3 -3.2 -3.2 -3.2];
    Xmax13=[2.3 2.3 3.2 3.2 3.2];
    Xmin14=zeros(1,10)+1e-100;
    Xmax14=10.*ones(1,10);
    Xmin15=[0 0 0];
    Xmax15=[10 10 10];
    Xmin16=[704.4148,68.6,0,193,25];
    Xmax16=[906.3855,288.88,134.75,287.0966,84.1988];
    Xmin17=[0 0 340 340 -1000 0];
    Xmax17=[400 1000 420 420 1000 0.5236];
    Xmin18=[-10 -10 -10 -10 -10 -10 -10 -10 0];
    Xmax18=[10 10 10 10 10 10 10 10 20];
    Xmin19=zeros(1,15);
    Xmax19=10.*ones(1,15);
    Xmin20=zeros(1,24)+1e-100;
    Xmax20=10.*ones(1,24);
    Xmin21=[0 0 0 100 6.3 5.9 4.5];
    Xmax21=[1000 40 40 300 6.7 6.4 6.25];
    Xmin22=[0 0 0 0 0 0 0 100 100 100.01 100 100 0 0 0 0.01 0.01 -4.7 -4.7 -4.7 -4.7 -4.7];
    Xmax22=[20000 1e+6 1e+6 1e+6 4e+7 4e+7 4e+7 299.99 399.99 300 400 600 500 500 500 300 400 6.25 6.25 6.25 6.25 6.25];
    Xmin23=[0 0 0 0 0 0 0 0 0.01];
    Xmax23=[300 300 100 200 100 300 100 200 0.03];
    Xmin24=[0 0];
    Xmax24=[3 4];

    Dimension=[13 20 10 5 4 2 10 2 7 8 2 3 5 10 3 5 6 9 15 24 7 22 9 2];
    gn=[9,2,0,6,2,2,8,2,4,6,0,1,0,0,0,38,0,13,5,6,1,1,2,2];
    hn=[0,0,1,0,3,0,0,0,0,0,1,0,3,3,2,0,4,0,0,14,5,19,4,0];
        
    D=Dimension(func_num);
    gn=gn(func_num);
    hn=hn(func_num);
    
    if func_num==1,fhd='g01';
    elseif func_num==2,fhd='g02';
    elseif func_num==3,fhd='g03'; 
    elseif func_num==4,fhd='g04';
    elseif func_num==5,fhd='g05';
    elseif func_num==6,fhd='g06';
    elseif func_num==7,fhd='g07';
    elseif func_num==8,fhd='g08';
    elseif func_num==9,fhd='g09';
    elseif func_num==10,fhd='g10';
    elseif func_num==11,fhd='g11';
    elseif func_num==12,fhd='g12';
    elseif func_num==13,fhd='g13';
    elseif func_num==14,fhd='g14';
    elseif func_num==15,fhd='g15';
    elseif func_num==16,fhd='g16';
    elseif func_num==17,fhd='g17';
    elseif func_num==18,fhd='g18';
    elseif func_num==19,fhd='g19';
    elseif func_num==20,fhd='g20';
    elseif func_num==21,fhd='g21';
    elseif func_num==22,fhd='g22';
    elseif func_num==23,fhd='g23';
    elseif func_num==24,fhd='g24';
    end

    eval(['Xmin=Xmin' int2str(func_num) ';']);
    eval(['Xmax=Xmax' int2str(func_num) ';']);
 elseif(Prob_Set == 2)
%      Xmin1=-50*ones(1,10);
%     Xmax1=+50*ones(1,10);
    Xmin1=zeros(1,10);
    Xmax1=ones(1,10);
    Xmin2=zeros(1,10);
    Xmax2=+10*ones(1,10);
    Xmin3=[0,0,-0.55,-0.55];
    Xmax3=[1200,1200,0.55,0.55];
    Xmin4=-1*ones(1,2);
    Xmax4=+1*ones(1,2);
    Xmin5=[-2.3*ones(1,2),-3.2*ones(1,3)];
    Xmax5=[+2.3*ones(1,2),+3.2*ones(1,3)];
    Xmin6=zeros(1,3);
    Xmax6=+10*ones(1,3);
    Xmin7=[0,0,340,340,-1000,0];
    Xmax7=[400,1000,420,420,1000,0.5236];
    Xmin8=zeros(1,24);
    Xmax8=+10*ones(1,24);
    Xmin9= [0,0,0,100,6.3,5.9,4.5];
    Xmax9=[1000,40,40,300,6.7,6.4,6.25];
    Xmin10=[0,0,0,0,0,0,0,100,100,100.01,100,100,0,0,0,0.01,0.01,-4.7,-4.7,-4.7,-4.7,-4.7];
    Xmax10=[2*10^4, 10^6,10^6,10^6,4*10^7,4*10^7,4*10^7,299.99,399.99,300,400,600,500, 500,500,300,400,6.25,6.25,6.25,6.25,6.25];
    Xmin11=[0,0,0,0,0,0,0,0,0.01];
    Xmax11=[300,300,100,200,100,300,100,200,0.03];
    Xmin12=-50*ones(1,10);
    Xmax12=+50*ones(1,10);
    Xmin13=-100*ones(1,10);
    Xmax13=+100*ones(1,10);
%     gn=[1 2 1 0+1 2   1   2  0+1 3   1    0+1 0+1 2];
%     hn=[2 1 1 2   0+1 0+1 1  1   0+1 0+1  2   1   0+1];
    gn=[1   6   8   1     6   4   8    10   11  39   10    2     2];
    hn=[0+1 0+1 0+1 0+1   0+1 0+1 0+1  12   0+1 0+1  0+1   0+1   0+1];
    
    Dimension=[10 10 4 2 5,3,6,24,7,22,9,40,140];
    D=Dimension(func_num);
    
    gn=gn(func_num);
    hn=hn(func_num);
    
    eval(['Xmin=Xmin' int2str(func_num) ';']);
    eval(['Xmax=Xmax' int2str(func_num) ';']); 

  
 end
     
 for runs=1:num_Run % Number of runs
     
   fprintf('Run %d',runs);
   nfeval=0;
   
   nCountBetter = 0;
   
 for k=1:4     
    
   pop=repmat(Xmin,NP,1)+repmat((Xmax-Xmin),NP,1).*rand(NP,D);
   if(Prob_Set == 1)
    [val(:,1), g, h] = mlbsuite(pop', gn, hn, fhd);
   elseif(Prob_Set == 2)
    [val(:,1), g, h] = TEC_reduction(pop,func_num);
   end
   nfeval=nfeval+NP;
   
   eval(['pop' num2str(k) '=pop;']);
   eval(['val' num2str(k) '=val;']);
   eval(['g' num2str(k) '=g;']);
   eval(['h' num2str(k) '=h;']);
   
 end 

 ub=repmat(Xmax,NP,1);
 lb=repmat(Xmin,NP,1);
 
 TOURNAMENT_SIZE=20; 
 CONV=abs([h1,h2,h3,h4]);
 if(~isempty(CONV) & ~isempty(find(CONV>0)))
 DELTA=median(median(CONV,2));
 numD=10^(log10(DELTA/initialDelta)/(Max_Gen/2));
 else
 DELTA=initialDelta;
 numD=1;
 end
 cons=[(g3>0).*g3;((abs(h3)-DELTA)>0).*(abs(h3)-DELTA)]'; 
 cons_max=max(cons,[],1);
 nzindex=find(cons_max~=0);
    
 if isempty(nzindex)
   tcons=zeros(NP,1);
 else

  tcons=sum(cons(:,nzindex)./repmat(cons_max(:,nzindex),NP,1),2)./sum(1./cons_max(:,nzindex));
 end 

n=0.05*4*NP;    % Parameters of Epsilon Constraint handling Method
Tc=0.5*Max_Gen;
cp=5;
[temp,index]=sort(tcons);
EPSILON=tcons(index(n),:);

Sr(1)=0.475;    % Parameters of Stochastic Ranking
dSr=(Sr(1)-0.025)/Max_Gen;

nretry=10;

for gen=1:Max_Gen
    
  NN=min(50,ceil((gen/Max_Gen)^5*50));
  %Adaptation of delta for equality constraint
  if(gen==1)
  delta=DELTA;
  else
  delta=max(initialDelta,DELTA/(numD^gen));
  end
  for k=1:4
    pop=eval(['pop' num2str(k)]);
    val=eval(['val' num2str(k)]);
    g=eval(['g' num2str(k)]);
    h=eval(['h' num2str(k)]);
                      
   if(gen<=10)
             
      neta=[(0.8/sqrt(D))*rand(NP,D)].*repmat((Xmax-Xmin),NP,1);
                  
   else
                       
      L=[];
        for ind=1:10
           L=[L;eval(['sneta' num2str(k) '_' num2str(ind)])];
        end
           L(~any(L,2),:) = [];
           l=mean(L,1);                 
           neta=repmat(l,NP,1);

    end

    eval(['neta' num2str(k) '=neta;']);
                 
    newneta= neta.*[2*rand(NP,D)-1]+neta;
    index=randint(NN,2,[1,NP]);
    newpop(1:NN,:)=repmat(pop(1,:),NN,1)+0.85*(pop(index(1:NN,1),:)-pop(index(1:NN,2),:));
    newpop((NN+1:NP),:)=pop(NN+1:NP,:)+newneta(NN+1:NP,:).*randn((NP-NN),D);
       
    
    I=find((newpop>ub)|(newpop<lb));
    retry=1;
    % Retrying to produce an offspring within the bounds
    while ~isempty(I)
        newpop(I)=pop(I)+newneta(I).*randn(length(I),1);
        I=find((newpop>ub)|(newpop<lb));
      if (retry>nretry)
         break; 
      end
        retry=retry+1;
    
    end

         
    newpop=(newpop>repmat(Xmin,NP,1)).*newpop+(newpop<repmat(Xmin,NP,1)).*(repmat(Xmin,NP,1));
    newpop=(newpop<repmat(Xmax,NP,1)).*newpop+(newpop>repmat(Xmax,NP,1)).*(repmat(Xmax,NP,1));
     
    if(Prob_Set == 1)
        [newval(:,1),newg,newh]=mlbsuite(newpop', gn, hn, fhd);
    elseif(Prob_Set == 2)
        [newval(:,1),newg,newh]=TEC_reduction(newpop,func_num);
    end
    nfeval=nfeval+NP;
        
    eval(['newpop' num2str(k) '=newpop;']);
    eval(['newval' num2str(k) '=newval;']);
    eval(['newg' num2str(k) '=newg;']);
    eval(['newh' num2str(k) '=newh;']);
    eval(['newneta' num2str(k) '=newneta;']);
          
    
 end
   
    for ii=1:4
        A=[];
        B=[];
        F=[];
        G=[];
        H=[];
        A=eval(['pop' num2str(ii)]);
        B=eval(['val' num2str(ii)]);
        F=eval(['neta' num2str(ii)]);
        G=eval(['g' num2str(ii)]);
        H=eval(['h' num2str(ii)]);
        for jj=1:4 
            
            A=[A;eval(['newpop' num2str(jj)])];
            B=[B;eval(['newval' num2str(jj)])];
            F=[F;eval(['newneta' num2str(jj)])];
            G=[G,eval(['newg' num2str(jj)])];
            H=[H,eval(['newh' num2str(jj)])];
          
        end
        eval(['A' num2str(ii) '=A;']);
        eval(['B' num2str(ii) '=B;']);
        eval(['F' num2str(ii) '=F;']);
        eval(['G' num2str(ii) '=G;']);
        eval(['H' num2str(ii) '=H;']);
    end
            
      
    r=rem(gen,10);
    if(r==0)
        r=10;
    end
    
    if(gen<=60)
    ZZ=[];
    ZZ1=[];
    ZZ2=[];
    ZZ3=[];
    ZZ4=[];
    ZZ5=[];
    zz=[];
    [ZZ,zz]=unique(A1,'rows');
    ZZ1=A1(zz,:);
    ZZ2=B1(zz,:);
    ZZ3=F1(zz,:);
    ZZ4=G1(:,zz);
    ZZ5=H1(:,zz);
    A1=[];
    B1=[];
    F1=[];
    G1=[];
    H1=[];
    A1=ZZ1;
    B1=ZZ2;
    F1=ZZ3;
    G1=ZZ4;
    H1=ZZ5;
    end
   % Superiority of Feasible Solutions
    cons1=[(G1>0).*G1;((abs(H1)-delta)>0).*(abs(H1)-delta)]'; 
    cons_max=max([cons_max;cons1],[],1);
    nzindex1=find(cons_max~=0);
    
    if isempty(nzindex1)
        tcons1=zeros(size(A1,1),1);
    else

        tcons1=sum(cons1(:,nzindex1)./repmat(cons_max(:,nzindex1),size(A1,1),1),2)./sum(1./cons_max(:,nzindex1));
    end 
        
    for kk=1:size(A1,1)
        win1(kk)=0;
       for i=1:TOURNAMENT_SIZE
           competitor1=ceil(rand(1)*size(A1,1));
               win1(kk)=win1(kk)-(~((tcons1(competitor1)<tcons1(kk)) | ((tcons1(competitor1)==0) & (tcons1(kk)==0) & (B1(competitor1)<=B1(kk)))));
               
       end
    end

    [sort_chd1,a] = sortrows([win1',A1,B1,F1,G1',H1',tcons1],1);
    aa=a(1:NP);
    pop1=sort_chd1(1:NP,2:(D+1));
    val1=sort_chd1(1:NP,(D+2));
    neta1=sort_chd1(1:NP,(D+3):(D*2+2));
    win1=sort_chd1(1:NP,1)';
    g1=sort_chd1(1:NP,(D*2+3):(D*2+2+gn))';
    h1=sort_chd1(1:NP,(D*2+2+gn+1):(D*2+2+gn+hn))';
    tcons1=sort_chd1(1:NP,(D*2+3+gn+hn));
    if(size(find(aa>NP),1)~=0 )
       sneta1=neta1(find( aa>NP),:);
        
    else
       sneta1=[(0.8/sqrt(D))*rand(NP,D)].*repmat((Xmax-Xmin),NP,1);
                             
    end
      
    eval(['sneta1' '_' num2str(r) '=sneta1;']);
    
    if(gen<=60)
    ZZ=[];
    ZZ1=[];
    ZZ2=[];
    ZZ3=[];
    ZZ4=[];
    ZZ5=[];
    zz=[];
    [ZZ,zz]=unique(A2,'rows');
    ZZ1=A2(zz,:);
    ZZ2=B2(zz,:);
    ZZ3=F2(zz,:);
    ZZ4=G2(:,zz);
    ZZ5=H2(:,zz);
    A2=[];
    B2=[];
    F2=[];
    G2=[];
    H2=[];
    A2=ZZ1;
    B2=ZZ2;
    F2=ZZ3;
    G2=ZZ4;
    H2=ZZ5;
    end
    %Self-Adaptive Penalty
    cons2=[(G2>0).*G2;((abs(H2)-delta)>0).*(abs(H2)-delta)]'; 
    cons_max=max([cons_max;cons2],[],1);
    nzindex2=find(cons_max~=0);
    
    if isempty(nzindex2)
        tcons2=zeros(size(A2,1),1);
    else

        tcons2=sum(cons2(:,nzindex2)./repmat(cons_max(:,nzindex2),size(A2,1),1),2)./sum(1./cons_max(:,nzindex2));
    end 
        
        f2=SaPenalty(B2,tcons2,A2);
   
    for kk=1:size(A2,1)
        win2(kk)=0;
          for i=1:TOURNAMENT_SIZE
              competitor2=ceil(rand(1)*size(A2,1));
               win2(kk)=win2(kk)-(~(f2(competitor2)<=f2(kk)));
               
          end
    end

    [sort_chd2,b] = sortrows([win2',A2,B2,F2,G2',H2',tcons2],1);
    bb=b(1:NP);
    pop2=sort_chd2(1:NP,2:(D+1));
    val2=sort_chd2(1:NP,(D+2));
    neta2=sort_chd2(1:NP,(D+3):(D*2+2));
    win2=sort_chd2(1:NP,1)';
    g2=sort_chd2(1:NP,(D*2+3):(D*2+2+gn))';
    h2=sort_chd2(1:NP,(D*2+2+gn+1):(D*2+2+gn+hn))';
    tcons2=sort_chd2(1:NP,(D*2+3+gn+hn));
    if(size(find( bb>NP ),1)~=0 )
      sneta2=neta2(find( bb>NP ),:);
       
    else
          
      sneta2=[(0.8/sqrt(D))*rand(NP,D)].*repmat((Xmax-Xmin),NP,1);
           
    end
    eval(['sneta2' '_' num2str(r) '=sneta2;']);
    
    if(gen<=60)
    ZZ=[];
    ZZ1=[];
    ZZ2=[];
    ZZ3=[];
    ZZ4=[];
    ZZ5=[];
    zz=[];
    [ZZ,zz]=unique(A3,'rows');
    ZZ1=A3(zz,:);
    ZZ2=B3(zz,:);
    ZZ3=F3(zz,:);
    ZZ4=G3(:,zz);
    ZZ5=H3(:,zz);
    A3=[];
    B3=[];
    F3=[];
    G3=[];
    H3=[];
    A3=ZZ1;
    B3=ZZ2;
    F3=ZZ3;
    G3=ZZ4;
    H3=ZZ5;
    end
    %Epsilon Constraint   
    cons3=[(G3>0).*G3;((abs(H3)-delta)>0).*(abs(H3)-delta)]'; 
    cons_max=max([cons_max;cons3],[],1);
    nzindex3=find(cons_max~=0);
    
    if isempty(nzindex3)
        tcons3=zeros(size(A3,1),1);
    else

        tcons3=sum(cons3(:,nzindex3)./repmat(cons_max(:,nzindex3),size(A3,1),1),2)./sum(1./cons_max(:,nzindex3));
    end 
        
    if(gen<=Tc)
      epsilon(gen)=EPSILON*((1-gen/Tc)^cp);
    else
      epsilon(gen)=0;
    end
   
    for kk=1:size(A3,1)
         win3(kk)=0;
       for i=1:TOURNAMENT_SIZE
          competitor3=ceil(rand(1)*size(A3,1));
               win3(kk)=win3(kk)-(~((tcons3(kk)<=epsilon(gen) & tcons3(competitor3)<=epsilon(gen) & B3(competitor3) <= B3(kk))|(tcons3(competitor3)<tcons3(kk))));
               
       end
           
    end

    [sort_chd3,c] = sortrows([win3',A3,B3,F3,G3',H3',tcons3],1);
    cc=c(1:NP);
    pop3=sort_chd3(1:NP,2:(D+1));
    val3=sort_chd3(1:NP,(D+2));
    neta3=sort_chd3(1:NP,(D+3):(D*2+2));
    win3=sort_chd3(1:NP,1)';
    g3=sort_chd3(1:NP,(D*2+3):(D*2+2+gn))';
    h3=sort_chd3(1:NP,(D*2+2+gn+1):(D*2+2+gn+hn))';
    tcons3=sort_chd3(1:NP,(D*2+3+gn+hn));
    if(size(find( cc>NP ),1)~=0 )
      sneta3=neta3(find(cc>NP ),:);
       
    else
         
      sneta3=[(0.8/sqrt(D))*rand(NP,D)].*repmat((Xmax-Xmin),NP,1);
       
    end
    eval(['sneta3' '_' num2str(r) '=sneta3;']);
    
    if(gen<=60)
    ZZ=[];
    ZZ1=[];
    ZZ2=[];
    ZZ3=[];
    ZZ4=[];
    ZZ5=[];
    zz=[];
    [ZZ,zz]=unique(A4,'rows');
    ZZ1=A4(zz,:);
    ZZ2=B4(zz,:);
    ZZ3=F4(zz,:);
    ZZ4=G4(:,zz);
    ZZ5=H4(:,zz);
    A4=[];
    B4=[];
    F4=[];
    G4=[];
    H4=[];
    A4=ZZ1;
    B4=ZZ2;
    F4=ZZ3;
    G4=ZZ4;
    H4=ZZ5;
   end
    %Stochastic Ranking
    cons4=[(G4>0).*G4;((abs(H4)-delta)>0).*(abs(H4)-delta)]'; 
    cons_max=max([cons_max;cons4],[],1);
    nzindex4=find(cons_max~=0);
    
    if isempty(nzindex4)
        tcons4=zeros(size(A4,1),1);
    else

        tcons4=sum(cons4(:,nzindex4)./repmat(cons_max(:,nzindex4),size(A4,1),1),2)./sum(1./cons_max(:,nzindex4));
    end 
       
    if gen>1 & gen< Max_Gen
        Sr(gen)=Sr(gen-1)-dSr;
    elseif(gen>=Max_Gen)
        Sr(gen)=0.025;
    end
   
    for kk=1:size(A4,1)
        win4(kk)=0; 
           
       for i=1:TOURNAMENT_SIZE
           competitor4=ceil(rand(1)*size(A4,1));
                
          if((tcons4(competitor4)==0 & tcons4(kk)==0)|rand<Sr(gen))
                   
             win4(kk)=win4(kk)-(~(B4(competitor4) < B4(kk)));  
          else
                   
             win4(kk)=win4(kk)-(~(tcons4(competitor4)<tcons4(kk)));
                   
                   
          end
               
                             
       end
            
    end
    [sort_chd4,d] = sortrows([win4',A4,B4,F4,G4',H4',tcons4],1);
    dd=d(1:NP);
    pop4=sort_chd4(1:NP,2:(D+1));
    val4=sort_chd4(1:NP,(D+2));
    neta4=sort_chd4(1:NP,(D+3):(D*2+2));
    win4=sort_chd4(1:NP,1)';
    g4=sort_chd4(1:NP,(D*2+3):(D*2+2+gn))';
    h4=sort_chd4(1:NP,(D*2+2+gn+1):(D*2+2+gn+hn))';
    tcons4=sort_chd4(1:NP,(D*2+3+gn+hn));
    if(size(find(dd>NP),1)~=0 )
       sneta4=neta4(find( dd>NP),:);
      
    else
           
       sneta4=[(0.8/sqrt(D))*rand(NP,D)].*repmat((Xmax-Xmin),NP,1);
           
    end
    eval(['sneta4' '_' num2str(r) '=sneta4;']);
       
             
     totalpop=[pop1;pop2;pop3;pop4];
     totalval=[val1;val2;val3;val4];
     totalg=[g1,g2,g3,g4];
     totalh=[h1,h2,h3,h4];
     totaltcons=[tcons1;tcons2;tcons3;tcons4];
     
      
               
    feasindex=find(totaltcons==0);
  if isempty(feasindex)
    [gbesttcons,ibest]=min(totaltcons);
    gbestval=totalval(ibest);
    gbest = totalpop(ibest,:);
  else
    [gbestval,ibest]=min(totalval(feasindex));
    gbesttcons=totaltcons(feasindex(ibest));
    gbest = totalpop(feasindex(ibest),:);
  end

    if(gen ==1)
      thegbestval = gbestval;
      thegbesttcons = gbesttcons;
  elseif((gbesttcons < thegbesttcons) | (gbesttcons==0 & thegbesttcons ==0 & gbestval < thegbestval))
      thegbestval = gbestval;
      thegbesttcons = gbesttcons;
  end


    W(gen,1)=thegbestval;
    W(gen,2)=thegbesttcons;
    W(gen,3)=nfeval;  
    
    if(Prob_Set == 1)
        [thegbestval,newg_xyz,newh_xyz]=mlbsuite(gbest', gn, hn, fhd);
        %         [newval(:,1), newg, newh] = TEC_ReduceEQ(pop,gn, hn, fhd);
    elseif(Prob_Set == 2)
        [thegbestval,newg_xyz,newh_xyz]=TEC_reduction (gbest,func_num);
    end
    
    if(Prob_Set == 1)
        [thegbestval,newg_xyz,newh_xyz]=mlbsuite(gbest', gn, hn, fhd);
        %         [newval(:,1), newg, newh] = TEC_ReduceEQ(pop,gn, hn, fhd);
        markEqu = 0;
        markInequ = 0;
        %%%%%%%%%%%%%%%%%%%
        if (isempty(newg_xyz))
            markInequ = 1;
        elseif (~isempty(newg_xyz)& max(newg_xyz)<=0)
            markInequ = 1;            
        end
        %**************
        if (isempty(newh_xyz))
            markEqu = 1;
        elseif (~isempty(newh_xyz)& max(abs(newh_xyz))<= initialDelta)
            markEqu = 1;
        end
        %%%%%%%%%%%%%%%%%%%%%%%
        if (nCountBetter == 0 & thegbestval < defined_value_one(func_num) & markEqu & markInequ )
            nCountBetter = nfeval;
        end
    elseif(Prob_Set == 2)
        [thegbestval,newg_xyz,newh_xyz]=TEC_reduction (gbest,func_num);
        markEqu = 0;
        markInequ = 0;
        %%%%%%%%%%%%%%%%%%%
        if (isempty(newg_xyz))
            markInequ = 1;
        elseif (~isempty(newg_xyz)& max(newg_xyz)<=0)
            markInequ = 1;
        end
        %**************
        if (isempty(newh_xyz))
            markEqu = 1;
        elseif (~isempty(newh_xyz)& max(abs(newh_xyz))<= initialDelta)
            markEqu = 1;
        end
        if (nCountBetter == 0 & thegbestval < defined_value_two(func_num) & markEqu & markInequ)
            nCountBetter = nfeval;
        end
    end
    
end

if (Prob_Set == 1)  
    eval(['save D:\ResultsOfECVRS\EP-Result\ECHT-EP' '\F' int2str(func_num),'_R' int2str(runs) ' W;']);
elseif(Prob_Set == 2)
   eval(['save D:\ResultsOfECVRS\EP-Result\ECHT-EP-ECVRS' '\F' int2str(func_num),'_R' int2str(runs) ' W;']);
end
% eval(['save /staff2/mall/TEC/DIVA' int2str(func_num) '/W_' int2str(runs) ' W;']);
Re(runs,1)=thegbestval;
Re(runs,2)=thegbesttcons;

Count(runs) = nCountBetter;

end

Res(1)=max(Re(:,1));
Res(2)=min(Re(:,1));
Res(3)=median(Re(:,1));
Res(4)=mean(Re(:,1));
Res(5)=std(Re(:,1));   

if (Prob_Set == 1)  
    eval(['save D:\ResultsOfECVRS\EP-Result\ECHT-EP' '/FUN_' int2str(func_num) 'problems']);
elseif(Prob_Set == 2)
   eval(['save D:\ResultsOfECVRS\EP-Result\ECHT-EP-ECVRS' '/FUN_' int2str(func_num) 'problems']);
end
% eval(['save /staff2/mall/TEC/DIVA' int2str(func_num) '/FUN' int2str(func_num)]);