function [f,g,h] = TEC(x,I_fno)

 [ps,D]=size(x);
 
 if (I_fno ==1)
% Problem 1 [-50,50]
%   f = sum(x.^2,2);
%   g = sum(-x.*cos(sqrt(abs(x))),2)/D;
%   h1 = zeros(ps,1);
%   h2 = zeros(ps,1);
%   for i=1:D/2
%       
%       h1 = h1+ (-x(:,2*i-1).*cos(sqrt(abs(x(:,2*i-1)))));
%       h2 = h2+ (-x(:,2*i).*cos(sqrt(abs(x(:,2*i)))));
%       
%   end
%   h = [h1,h2];

  c = [-6.089,-17.164,-34.054,-5.914,-24.721,-14.986,-24.1,-10.708,-26.662,-22.179];
  RepC = repmat(c,ps,1);
  f = 0;
%   h1 = 1- x(:,7)- x(:,8)- 2*x(:,9)- x(:,10)-x(:,3);
%   h2 = 1- 2*x(:,5)-x(:,6)- x(:,7)-x(:,4);
%   h3 = 2-2*x(:,2)- 2*x(:,3)- x(:,6)- x(:,10)-x(:,1);
  
  x(:,3) = 1- x(:,7)- x(:,8)- 2*x(:,9)- x(:,10);
  g1= x(:,3)-10;
  g2= -x(:,3);
  x(:,4) = 1- 2*x(:,5)-x(:,6)- x(:,7);
  g3=x(:,4)-10;
  g4=-x(:,4);
  x(:,1) = 2-2*x(:,2)- 2*x(:,3)- x(:,6)- x(:,10);
  g5=x(:,1)-10;
  g6=-x(:,1);
  
%   mark3 = ( x(:,3)<=0 )+ ( x(:,3)>= 10) + ( x(:,4)<=0 )+ (x(:,4)>= 10)+ ( x(:,1)<=0 )+ (x(:,1)>= 10) ;
%   mark3 = (x(:,3)<=0);
%   x(:,3)=(-mark3.*x(:,3))+ x(:,3) + mark3.*0.001;
%   mark3 = (x(:,3)>=10);
%  x(:,3)=(-mark3.*x(:,3))+ x(:,3) + mark3.*9.99;
%   
%    mark3 = (x(:,4)<=0);
%   x(:,4)=(-mark3.*x(:,4))+ x(:,4) + mark3.*0.001;
%   mark3 = (x(:,4)>=10);
%   x(:,4)=(-mark3.*x(:,4))+ x(:,4) + mark3.*9.99;
%   
%    mark3 = (x(:,1)<=0);
%   x(:,1)=(-mark3.*x(:,1))+ x(:,1) + mark3.*0.001;
%    mark3 = (x(:,1)>=10);
%   x(:,1)=(-mark3.*x(:,1))+ x(:,1) + mark3.*9.99;
  
  for i=1:10
      temp = x(:,i)./(sum(x'))';
      mark = temp<zeros(ps,1);
      temp = (mark.*100000)+((-mark).*temp + temp);
%       f = f+ x(:,i).*(RepC(:,i)+ log(x(:,i)./(sum(x'))'));     
      f = f+ x(:,i).*(RepC(:,i)+ log(temp)); 
  end
%   f = f + (-f.*mark3)+ mark3.*1000;
  g = [g1,g2,g3,g4,g5,g6];
  h = zeros(ps,1);
%   h2 = zeros(ps,1);
%   h3 = zeros(ps,1);
%   h = [h1,h2,h3]; 
 end
 
 if (I_fno ==2)
 % Problem 2 [-5.12,5.12]
   f = max(x,[],2);
   y = x-0.5;
   g1= 10-sum(x.^2-10.*cos(2.*pi.*x)+10,2)/D;
   g2= sum(x.^2-10.*cos(2.*pi.*x)+10,2)/D-15;
   g = [g1,g2];
   h = sum(y.^2-10.*cos(2.*pi.*y)+10,2)/D-20;
 end
 if(I_fno ==3) 
% Probem 3 [-100,100]
  f = sum(x.^2,2);
  g = zeros(ps,1);
  h = zeros(ps,1);
  for i=1:D/2
      
      g = g+ (x(:,2*i).*sin(sqrt(abs(x(:,2*i)))));
      h = h+ (-x(:,2*i-1).*cos(sqrt(abs(x(:,2*i-1)))));
      
  end
 end
 if (I_fno ==4)
% Probem 4 [-100,100]
  f = sum(x.^2,2);
  h1 = zeros(ps,1);
  h2 = zeros(ps,1);
  for i=1:D/2
      
      h2 = h2+ (x(:,2*i).*sin(sqrt(abs(x(:,2*i)))));
      h1 = h1+ (-x(:,2*i-1).*cos(sqrt(abs(x(:,2*i-1)))));
      
  end
  g = zeros(ps,1);
  h = [h1,h2];
 end
 if(I_fno ==5)
%   Problem 5 [-100,100]
    f = sum(-x.*sin(sqrt(abs(x))),2)/D;
    y = x-100;
    z = x+50;
    g1  = 10+sum(-y.*sin(sqrt(abs(y))),2)/D;
    g2  = 10+sum(-z.*sin(sqrt(abs(z))),2)/D;
    g = [g1,g2];
    h = zeros(ps,1);
 end
 if (I_fno ==6)
% Problem 6 [-100,100]
  f = sum(-x.*sin(sqrt(abs(x))),2)/D;
  g = -100+sum((x(:,1:D-1).^2-x(:,2:D)).^2+(x(:,1:D-1)-1).^2,2);
  h = zeros(ps,1);
 end
 if(I_fno ==7)
% Problem 7 [-100,100]
  f = sum(-x.*sin(sqrt(abs(x))),2)/D;
  g1 = -100+sum((x(:,1:D-1).^2-x(:,2:D)).^2+(x(:,1:D-1)-1).^2,2);
  g2=ones(ps,1);
  for i=1:D
    g2=g2.*cos(x(:,i)./sqrt(i));
  end
  g2 = -20+sum(x.^2,2)./4000-g2+1;
  g  = [g1,g2]; 
  h = sum((x(:,1:D-1).^2-x(:,2:D)).^2,2);
 end
if(I_fno ==8)
% Problem 8 [-500,500]
  f = max(x,[],2);
  g = zeros(ps,1);
  h = sum(-x.*sin(sqrt(abs(x))),2)/D;
end
if(I_fno ==9)
% Problem 9 [-500,500]
  f=sum(-x.*sin(sqrt(abs(x))),2)/D;
  g3=ones(ps,1);
  for i=1:D
     g3=g3.*cos(x(:,i)./sqrt(i));
  end
  g3=(75-50*(sum(x.^2,2)./4000-g3+1));
  g = [-50+sum(x.^2,2)/(D*100),50*sum(sin(1/50*pi*x),2)/D,g3];
  h = zeros(ps,1);
end
if(I_fno ==10)
%Problem 10 [-10,10]
  f = sum(100*(x(:,1:D-1).^2-x(:,2:D)).^2+(x(:,1:D-1)-1).^2,2);
  g = sum(x.*cos(2*sqrt(abs(x))),2);
  h = zeros(ps,1);
end
if(I_fno ==11)
% Problem 11 [-5,5]
  z = x-10;
  f = sum(z.^2-10.*cos(2.*pi.*z)+10,2);
  h1= sum(-x.*sin(2*sqrt(abs(x))),2)/D;
  h2= sum(x.*sin(2*sqrt(abs(x))),2)/D;
  h = [h1,h2];
  g =zeros(ps,1);
end
if(I_fno ==12)  
  %Problem 12 [-50,50]
   f = max(abs(x),[],2);
   g = zeros(ps,1);
   h = sum(-x.*sin(sqrt(abs(x))),2)/D;
end
if(I_fno ==13)
 %Problem 13 [-100,100]
 f = max(x,[],2);
 g1 = sum(-x.*sin(sqrt(abs(x))),2)/D;
 g2 = sum(x.*cos(sqrt(abs(x))),2)/D;
 g  = [g1,g2];
 h= zeros(ps,1);
end

 g = g';
 h = h';
