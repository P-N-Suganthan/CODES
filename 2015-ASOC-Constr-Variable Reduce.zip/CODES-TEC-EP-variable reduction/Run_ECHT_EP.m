
Pro_set_one = [3,14,5,11,13,15,17,21,22,23];
Pro_set_two = [1,2,3,4,5,6,7,9,10,11];

for i=1:10
    
    Pro_set =1
    run = i
    ECHT_EP_F(1,Pro_set_one(i));   
    
end

for i=1:10
    
    Pro_set =2
    run = i
    ECHT_EP_F(2,Pro_set_one(i));   
    
end