 % The Ensemble of SF SR EC and SP constraint handling methods
clear all;
global  nfeval
format long e;

 func_num = 1;    % Function Number
 NP       = 50;    % Size of Population
 Prob_Set = 1;     % 1 for CEC 2006 and 2 for New Problems
 Max_FES  = 240000;% Maximum number of function evaluations
 Max_Gen  = 1200;  % Maximum number of generations
 
 if(Prob_Set == 1)
    Xmin1=[0 0 0 0 0 0 0 0 0 0 0 0 0];
    Xmax1=[1 1 1 1 1 1 1 1 1 100 100 100 1];
    Xmin2=zeros(1,20)+1e-100;
    Xmax2=10.*ones(1,20);
    Xmin3=zeros(1,10);
    Xmax3=ones(1,10);
    Xmin4=[78 33 27 27 27];
    Xmax4=[102 45 45 45 45];
    Xmin5=[0 0 -0.55 -0.55];
    Xmax5=[1200 1200 0.55 0.55];
    Xmin6=[13 0];
    Xmax6=[100 100];
    Xmin7=-10.*ones(1,10);
    Xmax7=10.*ones(1,10);
    Xmin8=[0 0];
    Xmax8=[10 10];
    Xmin9=-10.*ones(1,7);
    Xmax9=10.*ones(1,7);
    Xmin10=[100 1000 1000 10 10 10 10 10];
    Xmax10=[10000 10000 10000 1000 1000 1000 1000 1000];
    Xmin11=[-1 -1];
    Xmax11=[1 1];
    Xmin12=[0 0 0];
    Xmax12=[10 10 10];
    Xmin13=[-2.3 -2.3 -3.2 -3.2 -3.2];
    Xmax13=[2.3 2.3 3.2 3.2 3.2];
    Xmin14=zeros(1,10)+1e-100;
    Xmax14=10.*ones(1,10);
    Xmin15=[0 0 0];
    Xmax15=[10 10 10];
    Xmin16=[704.4148,68.6,0,193,25];
    Xmax16=[906.3855,288.88,134.75,287.0966,84.1988];
    Xmin17=[0 0 340 340 -1000 0];
    Xmax17=[400 1000 420 420 1000 0.5236];
    Xmin18=[-10 -10 -10 -10 -10 -10 -10 -10 0];
    Xmax18=[10 10 10 10 10 10 10 10 20];
    Xmin19=zeros(1,15);
    Xmax19=10.*ones(1,15);
    Xmin20=zeros(1,24)+1e-100;
    Xmax20=10.*ones(1,24);
    Xmin21=[0 0 0 100 6.3 5.9 4.5];
    Xmax21=[1000 40 40 300 6.7 6.4 6.25];
    Xmin22=[0 0 0 0 0 0 0 100 100 100.01 100 100 0 0 0 0.01 0.01 -4.7 -4.7 -4.7 -4.7 -4.7];
    Xmax22=[20000 1e+6 1e+6 1e+6 4e+7 4e+7 4e+7 299.99 399.99 300 400 600 500 500 500 300 400 6.25 6.25 6.25 6.25 6.25];
    Xmin23=[0 0 0 0 0 0 0 0 0.01];
    Xmax23=[300 300 100 200 100 300 100 200 0.03];
    Xmin24=[0 0];
    Xmax24=[3 4];

    Dimension=[13 20 10 5 4 2 10 2 7 8 2 3 5 10 3 5 6 9 15 24 7 22 9 2];
    gn=[9,2,0,6,2,2,8,2,4,6,0,1,0,0,0,38,0,13,5,6,1,1,2,2];
    hn=[0,0,1,0,3,0,0,0,0,0,1,0,3,3,2,0,4,0,0,14,5,19,4,0];

    best_known=[-15.00000 -0.803619    -1       -30665.538672  5126.498110 -6961.813800 24.306209   -0.095825  680.630057  7049.330700...
    0.75       -1       0.0539498  -47.764411     961.715172   -1.905155   8876.980680 -0.865735   32.655593   0.096737...
    193.778349 382.902205 -400.002500 -5.508013];

        
    D=Dimension(func_num);
    gn=gn(func_num);
    hn=hn(func_num);
    
    if func_num==1,fhd='g01';
    elseif func_num==2,fhd='g02';
    elseif func_num==3,fhd='g03'; 
    elseif func_num==4,fhd='g04';
    elseif func_num==5,fhd='g05';
    elseif func_num==6,fhd='g06';
    elseif func_num==7,fhd='g07';
    elseif func_num==8,fhd='g08';
    elseif func_num==9,fhd='g09';
    elseif func_num==10,fhd='g10';
    elseif func_num==11,fhd='g11';
    elseif func_num==12,fhd='g12';
    elseif func_num==13,fhd='g13';
    elseif func_num==14,fhd='g14';
    elseif func_num==15,fhd='g15';
    elseif func_num==16,fhd='g16';
    elseif func_num==17,fhd='g17';
    elseif func_num==18,fhd='g18';
    elseif func_num==19,fhd='g19';
    elseif func_num==20,fhd='g20';
    elseif func_num==21,fhd='g21';
    elseif func_num==22,fhd='g22';
    elseif func_num==23,fhd='g23';
    elseif func_num==24,fhd='g24';
    end

    eval(['Xmin=Xmin' int2str(func_num) ';']);
    eval(['Xmax=Xmax' int2str(func_num) ';']);
 elseif(Prob_Set == 2)
     Xmin1=-50*ones(1,10);
    Xmax1=+50*ones(1,10);
    Xmin2=-5.12*ones(1,10);
    Xmax2=+5.12*ones(1,10);
    Xmin3=-100*ones(1,10);
    Xmax3=+100*ones(1,10);
    Xmin4=-100*ones(1,10);
    Xmax4=+100*ones(1,10);
    Xmin5=-100*ones(1,10);
    Xmax5=+100*ones(1,10);
    Xmin6=-100*ones(1,10);
    Xmax6=+100*ones(1,10);
    Xmin7=-100*ones(1,10);
    Xmax7=+100*ones(1,10);
    Xmin8=-500*ones(1,10);
    Xmax8=+500*ones(1,10);
    Xmin9=-500*ones(1,10);
    Xmax9=+500*ones(1,10);
    Xmin10=-10*ones(1,10);
    Xmax10=+10*ones(1,10);
    Xmin11=-5*ones(1,10);
    Xmax11=+5*ones(1,10);
    Xmin12=-50*ones(1,10);
    Xmax12=+50*ones(1,10);
    Xmin13=-100*ones(1,10);
    Xmax13=+100*ones(1,10);
    gn=[1 2 1 0+1 2   1   2  0+1 3   1    0+1 0+1 2];
    hn=[2 1 1 2   0+1 0+1 1  1   0+1 0+1  2   1   0+1];
    D=10;
    gn=gn(func_num);
    hn=hn(func_num);
    
    eval(['Xmin=Xmin' int2str(func_num) ';']);
    eval(['Xmax=Xmax' int2str(func_num) ';']); 

  
 end
     
 for runs=1:1 % Number of runs
     
   fprintf('Run %d',runs);
   nfeval=0;
   
 for k=1:4     
    
   pop=repmat(Xmin,NP,1)+repmat((Xmax-Xmin),NP,1).*rand(NP,D);
   if(Prob_Set == 1)
    [val(:,1), g, h] = mlbsuite(pop', gn, hn, fhd);
   elseif(Prob_Set == 2)
    [val(:,1), g, h] = TEC(pop,func_num);
   end
   nfeval=nfeval+NP;
   
   eval(['pop' num2str(k) '=pop;']);
   eval(['val' num2str(k) '=val;']);
   eval(['g' num2str(k) '=g;']);
   eval(['h' num2str(k) '=h;']);
   
 end 

 ub=repmat(Xmax,NP,1);
 lb=repmat(Xmin,NP,1);
 Tc=0.2*Max_Gen;
 cp=5;
 CONV=abs([h1,h2,h3,h4]);
 if(~isempty(CONV) & ~isempty(find(CONV>0)))
 DELTA=median(median(CONV,2));
 numD=10^(log10(DELTA/10^(-4))/600);
 else
 DELTA=10^(-4);
 numD=1;
 end
 Sr(1)=0.475;    % Parameters of Stochastic Ranking
 dSr=(Sr(1)-0.025)/Max_Gen;
 rot=(0:1:NP-1); 


for gen=1:Max_Gen
   
  %Adaptation of delta for equality constraint
  if(gen==1)
  delta=DELTA;
  else
  delta=max(10^(-4),DELTA/(numD^gen));
  end

  for k=1:4
    pop=eval(['pop' num2str(k)]);
    val=eval(['val' num2str(k)]);
    g=eval(['g' num2str(k)]);
    h=eval(['h' num2str(k)]);
    FM_mui = rand(NP,D) < 0.9; 
    FM_mpo = FM_mui < 0.5;   
    ind=randperm(2);
    FVr_a1 = randperm(NP); 
    rt=rem(rot+ind(1),NP);
    FVr_a2 = FVr_a1(rt+1);
    rt=rem(rot+ind(2),NP);
    FVr_a3 = FVr_a2(rt+1);
                      
    newpop(1:NP,:)=pop(FVr_a1,:)+ 0.7*(pop(FVr_a2,:)-pop(FVr_a3,:));
    for i=1:NP
      
        for kk=1:D
            if(newpop(i,kk) < Xmin(kk))
                newpop(i,kk)= Xmin(kk)+( Xmax(kk)- Xmin(kk)).*rand;
            end
            if(newpop(i,kk) > Xmax(kk))
               newpop(i,kk)= Xmin(kk)+( Xmax(kk)- Xmin(kk)).*rand;
           end
        end
    end
    newpop = pop.*FM_mpo + newpop.*FM_mui;   
               
    if(Prob_Set == 1)
        [newval(:,1),newg,newh]=mlbsuite(newpop', gn, hn, fhd);
    elseif(Prob_Set == 2)
        [newval(:,1),newg,newh]=TEC(newpop,func_num);
    end
    nfeval=nfeval+NP;
        
    eval(['newpop' num2str(k) '=newpop;']);
    eval(['newval' num2str(k) '=newval;']);
    eval(['newg' num2str(k) '=newg;']);
    eval(['newh' num2str(k) '=newh;']);
              
    
 end
   
    for ii=1:4
        A=[];
        B=[];
        G=[];
        H=[];
        
        A=eval(['pop' num2str(ii)]);
        B=eval(['val' num2str(ii)]);
        G=eval(['g' num2str(ii)]);
        H=eval(['h' num2str(ii)]);
              
        A=[A;eval(['newpop' num2str(ii)])];
        B=[B;eval(['newval' num2str(ii)])];
        G=[G,eval(['newg' num2str(ii)])];
        H=[H,eval(['newh' num2str(ii)])];
        
       for jj=1:4
           if(jj~=ii)
               A=[A;eval(['newpop' num2str(jj)])];
               B=[B;eval(['newval' num2str(jj)])];
               G=[G,eval(['newg' num2str(jj)])];
               H=[H,eval(['newh' num2str(jj)])];
           end
       end
       
        eval(['A' num2str(ii) '=A;']);
        eval(['B' num2str(ii) '=B;']);
        eval(['G' num2str(ii) '=G;']);
        eval(['H' num2str(ii) '=H;']);
    end
            
   
   
   % Superiority of Feasible Solutions
    cons1=[(G1>0).*G1;((abs(H1)-delta)>0).*(abs(H1)-delta)]'; 
    cons_max1=max(cons1,[],1);
    nzindex1=find(cons_max1~=0);
    
    if isempty(nzindex1)
        tcons1=zeros(size(A1,1),1);
    else

        tcons1=sum(cons1(:,nzindex1)./repmat(cons_max1(:,nzindex1),size(A1,1),1),2)./sum(1./cons_max1(:,nzindex1));
    end 
    
    for i=2*NP+1:5*NP
        
       for kk=NP+1:2*NP
            
            DIST(kk-NP,1)=sum((A1(i,:)-A1(kk,:)).^2,2);
           
       end
       [vinde,inde]=min(DIST,[],1);
       
           if(((tcons1(i)<tcons1(NP+inde)) | ((tcons1(i)==0) & (tcons1(NP+inde)==0) & (B1(i)<=B1(NP+inde)))))
            A1(NP+inde,:)= A1(i,:);
            B1(NP+inde,:)= B1(i,:);
            G1(:,NP+inde)  = G1(:,i);
            H1(:,NP+inde)  = H1(:,i);
            tcons1(NP+inde)=tcons1(i,:);
           end
    end
 
    for kk=1:NP
        
        if(((tcons1(NP+kk)<tcons1(kk)) | ((tcons1(NP+kk)==0) & (tcons1(kk)==0) & (B1(NP+kk)<=B1(kk)))))
        
            pop1(kk,:)= A1(NP+kk,:);
            val1(kk,:)= B1(NP+kk,:);
            g1(:,kk)  = G1(:,NP+kk);
            h1(:,kk)  = H1(:,NP+kk);
            
        end
       
       
    end
        
     
    %Self-Adaptive Penalty
    cons2=[(G2>0).*G2;((abs(H2)-delta)>0).*(abs(H2)-delta)]'; 
    cons_max2=max(cons2,[],1);
    nzindex2=find(cons_max2~=0);
    
    if isempty(nzindex2)
        tcons2=zeros(size(A2,1),1);
    else

        tcons2=sum(cons2(:,nzindex2)./repmat(cons_max2(:,nzindex2),size(A2,1),1),2)./sum(1./cons_max2(:,nzindex2));
    end 
   
        f2=SaPenalty(B2,tcons2,A2);
    for i=2*NP+1:5*NP
        
       for kk=NP+1:2*NP
            
            DIST(kk-NP,1)=sum((A2(i,:)-A2(kk,:)).^2,2);
            
       end
       [vinde,inde]=min(DIST,[],1);
           if((f2(i)<=f2(NP+inde)))
            A2(NP+inde,:)= A2(i,:);
            B2(NP+inde,:)= B2(i,:);
            G2(:,NP+inde)  = G2(:,i);
            H2(:,NP+inde)  = H2(:,i);
            f2(NP+inde,:) = f2(i,:);
           end
    end

    for kk=1:NP
        
           if((f2(NP+kk)<=f2(kk)))
            pop2(kk,:)= A2(NP+kk,:);
            val2(kk,:)= B2(NP+kk,:);
            g2(:,kk)  = G2(:,NP+kk);
            h2(:,kk)  = H2(:,NP+kk);   
               
           end


    end
     
    
    %Epsilon Constraint   
    cons3=[(G3>0).*G3;((abs(H3)-delta)>0).*(abs(H3)-delta)]'; 
    cons_max3=max(cons3,[],1);
    nzindex3=find(cons_max3~=0);
    
    if isempty(nzindex3)
        tcons3=zeros(size(A3,1),1);
    else

        tcons3=sum(cons3(:,nzindex3)./repmat(cons_max3(:,nzindex3),size(A3,1),1),2)./sum(1./cons_max3(:,nzindex3));
    end 
        
    if(gen==1)
     n=ceil(0.05*size(A3,1));   
     [temp,index]=sort(tcons3);
     EPSILON=tcons3(index(n),:);
     epsilon(gen)=EPSILON;
    elseif(gen>1 && gen<=Tc)
      epsilon(gen)=EPSILON*((1-gen/Tc)^cp);
    elseif(gen>Tc)
      epsilon(gen)=0;
    end
    for i=2*NP+1:5*NP
        
       for kk=NP+1:2*NP
            
            DIST(kk-NP,1)=sum((A3(i,:)-A3(kk,:)).^2,2);
           
       end
       [vinde,inde]=min(DIST,[],1);
           if(((tcons3(NP+inde)<=epsilon(gen) & tcons3(i)<=epsilon(gen) & B3(i) <= B3(inde))|(tcons3(i)<tcons3(NP+inde))))
            A3(NP+inde,:)= A3(i,:);
            B3(NP+inde,:)= B3(i,:);
            G3(:,NP+inde)  = G3(:,i);
            H3(:,NP+inde)  = H3(:,i);
            tcons3(NP+inde,:)=tcons3(i,:);
           end
    end
    for kk=1:NP
         if(((tcons3(kk)<=epsilon(gen) & tcons3(NP+kk)<=epsilon(gen) & B3(NP+kk) <= B3(kk))|(tcons3(NP+kk)<tcons3(kk))))
            pop3(kk,:)= A3(NP+kk,:);
            val3(kk,:)= B3(NP+kk,:);
            g3(:,kk)  = G3(:,NP+kk);
            h3(:,kk)  = H3(:,NP+kk);     
         end


    end
     
    %Stochastic Ranking
    cons4=[(G4>0).*G4;((abs(H4)-delta)>0).*(abs(H4)-delta)]'; 
    cons_max4=max(cons4,[],1);
    nzindex4=find(cons_max4~=0);
    
    if isempty(nzindex4)
        tcons4=zeros(size(A4,1),1);
    else

        tcons4=sum(cons4(:,nzindex4)./repmat(cons_max4(:,nzindex4),size(A4,1),1),2)./sum(1./cons_max4(:,nzindex4));
    end 
       
    if gen>1 & gen< Max_Gen
        Sr(gen)=Sr(gen-1)-dSr;
    elseif(gen>=Max_Gen)
        Sr(gen)=0.025;
    end
   for i=2*NP+1:5*NP
        
       for kk=NP+1:2*NP
            
            DIST(kk-NP,1)=sum((A4(i,:)-A4(kk,:)).^2,2);
            
       end
       [vinde,inde]=min(DIST,[],1);
           
                   
             if(rand<Sr(gen))
                 if((B4(i) < B4(NP+inde)))
                  A4(NP+inde,:)= A4(i,:);
                  B4(NP+inde,:)= B4(i,:);
                  G4(:,NP+inde)  = G4(:,i);
                  H4(:,NP+inde)  = H4(:,i);
                  tcons4(NP+inde,:)=tcons4(i,:);
                 end
             else
                 if((tcons4(i)<tcons4(NP+inde)) |((tcons4(i)==0 & tcons4(NP+inde)==0) & (B4(i) < B4(NP+inde))))
                  A4(NP+inde,:)= A4(i,:);
                  B4(NP+inde,:)= B4(i,:);
                  G4(:,NP+inde)  = G4(:,i);
                  H4(:,NP+inde)  = H4(:,i);
                  tcons4(NP+inde,:)=tcons4(i,:);
                 end
             end
                            
       
    end
    
    for kk=1:NP
         
             if(rand<Sr(gen))
                 if((B4(NP+kk) < B4(kk)))
                  pop4(kk,:)= A4(NP+kk,:);
                  val4(kk,:)= B4(NP+kk,:);
                  g4(:,kk)  = G4(:,NP+kk);
                  h4(:,kk)  = H4(:,NP+kk);
                 end
             else
                 if((tcons4(NP+kk) < tcons4(kk)) | ((tcons4(NP+kk)==0 & tcons4(kk)==0) & (B4(NP+kk) < B4(kk))))
                  pop4(kk,:)= A4(NP+kk,:);
                  val4(kk,:)= B4(NP+kk,:);
                  g4(:,kk)  = G4(:,NP+kk);
                  h4(:,kk)  = H4(:,NP+kk);
                 end
                                         
          end

    end
                  
    totalpop=[pop1;pop2;pop3;pop4];
    totalval=[val1;val2;val3;val4];
    totalg=[g1,g2,g3,g4];
    totalh=[h1,h2,h3,h4];
    cons5=[(totalg>0).*totalg;((abs(totalh)-10^(-4))>0).*(abs(totalh)-10^(-4))]'; 
    cons_max5=max(cons5,[],1);
    nzindex5=find(cons_max5~=0);
    
    if isempty(nzindex5)
        tcons5=zeros(4*NP,1);
    else

        tcons5=sum(cons5(:,nzindex5)./repmat(cons_max5(:,nzindex5),4*NP,1),2)./sum(1./cons_max5(:,nzindex5));
    end 
        
                 
  feasindex=find(tcons5==0);
  if isempty(feasindex)
    [gbesttcons,ibest]=min(tcons5);
    gbestval=totalval(ibest);
    gbest = totalpop(ibest,:);
  else
    [gbestval,ibest]=min(totalval(feasindex));
    gbesttcons=tcons5(feasindex(ibest));
    gbest = totalpop(feasindex(ibest),:);
  end
  
  if(gen ==1)
      thegbestval = gbestval;
      thegbesttcons = gbesttcons;
  elseif((gbesttcons < thegbesttcons) | (gbesttcons==0 & thegbesttcons ==0 & gbestval < thegbestval))
      thegbestval = gbestval;
      thegbesttcons = gbesttcons;
  end


    W(gen,1)=thegbestval;
    W(gen,2)=thegbesttcons;
    W(gen,3)=nfeval;        
    
end

eval(['save /home/mall/TEC/DIVA' int2str(func_num) '/W_' int2str(runs) ' W;']);
Re(runs,1)=thegbestval;
Re(runs,2)=thegbesttcons;

end

Res(1)=max(Re(:,1));
Res(2)=min(Re(:,1));
Res(3)=median(Re(:,1));
Res(4)=mean(Re(:,1));
Res(5)=std(Re(:,1));   

eval(['save /home/mall/TEC/DIVA' int2str(func_num) '/FUN' int2str(func_num)]);

        
