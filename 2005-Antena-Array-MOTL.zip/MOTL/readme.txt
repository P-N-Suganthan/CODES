[best,best_val]=G3_GA_main(fname,NP,n,Xmin,Xmax,Feval_max)

% Program for G3model_GA
% NP-Number of population individuals
% n-Dimension
% Xmin-lower bound on problem variables
% Xmax-Upper bound on problem variables
% fname =function name 'dual_fit' or 'dual_quan_fit'
% Feval_max -Maximum function evaluations (stopping criteria);
% best- optimum problem variables
%best_val- fitness value corresponding to best
 

Typical function call :

[best,best_val]=G3_GA_main('dual_fit',200,20,zeros(1,20),ones(1,20),20000)

For quantized phase excitations
 
[best,best_val]=G3_GA_main('dual_quan_fit',200,20,zeros(1,20),ones(1,20),20000)


Reference:

S. BASKAR, A. Alphones, P. N. Suganthan, �Genetic Algorithm Based Design of Reconfigurable Antenna Array 
with Discrete Phase Shifters�, Microwave and optical Technology Letters, Vol.45, No.6, pp.461-465, June 2005