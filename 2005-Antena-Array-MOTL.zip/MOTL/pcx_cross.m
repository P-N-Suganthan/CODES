function best_child=pcx_cross(parent,lamda,rep_size,n,xl,xu,fname,pb)
  
[rr,cc]=size(parent);
centroid=mean(parent);

for ii=1:lamda
    rc_parent=randperm(rr);
    rc=rc_parent(1);
    d=centroid-parent(rc,:);
    dist=sqrt(sum(d.^2));
    
    if dist~=0;
        for j=2:rr
            diff(j,:)=parent(j,:)-parent(rc,:);
        end
        
        rrcount=0;
        for j=2:rr
            if  (diff(j,:)*diff(j,:)'~=0),
                rrcount=rrcount+1;
                temp1=diff(j,:)*d';
                temp2=sqrt(sum(diff(j,:).^2))*dist;
                temp22=temp1/temp2;
                temp3=sqrt(abs(1-temp22^2));
                dd(j)=sqrt(sum(diff(j,:).^2))*temp3;
            end
        end
        
        d_not=sum(dd)/(rrcount);
        
        
        tempar1=normrnd(0,(d_not*pb),1,cc); 
        
        tempar2=tempar1;
        for j=1:cc
            tempar2(j)=tempar1(j)-(((tempar1*d')*d(j))/(dist^2));
        end
        tempar1=tempar2;
        
        child=parent(rc,:)+tempar1;
        
        tempvar=normrnd(0,pb,1,1);
        child=child+tempvar*d;
            
    else
        child=parent(rc,:)+normrnd(0,.1,1,cc);
    end
    child=(child<xl).*xl+(child>=xl).*child;
    child=(child>xu).*xu+(child<=xu).*child;
    child1(ii,:)=child;
end


for i=1:lamda
child1(i,n+1)=feval(fname,child1(i,1:n));
end
[y,yy]=sort(child1(:,n+1));

for i=1:rep_size
best_child(i,:)=child1(yy(i),:);
end
