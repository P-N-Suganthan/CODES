 function cost=dual_quan_fit(aa)
% this function is used to find fitness value of reconfigurable antenna design with qunatized phase values
% twenty element antenna design
% Number of elements - n
% aa is 1x20 vector of normalised amplitude and phase excitations
% The first 10 elements of aa gives amplitude excitations and the last 10 elements corresponds to phase excitations  
% cost is the fitness value of this function
% ADR -Amplitude excitation dynamic range
% Select suitable cost equation with or without ADR
% % test solution
%aa=[ 0.9392    0.9411    0.8616    0.7272    0.5264    0.4971    0.3654    0.2509    0.2151    0.1375    0.4781    0.4052    0.3946    0.3599  0.6372    0.1087    0.8312    0.7260    0.7008    0.1711];
% cost=0.6181

n=length(aa);  

xl=zeros(1,n);
xu=[ones(1,n/2) 64*ones(1,n/2)];
aa=xl+(xu-xl).*aa;
aa(:,.5*n+1:n)=-180+((360/63)*round((aa(:,.5*n+1:n))));
step=.1;ed=90/step;

xll=[zeros(1,n/2) -180*ones(1,n/2)];
xuu=[ones(1,n/2) 180*ones(1,n/2)];

xerr=sum(abs(min(aa-xll,0))+abs(min(xuu-aa,0)),2);
if xerr==0,
   a=aa;jj=0;
       arr=a(n/2+1:n)*pi/180;
        a(1:n/2)=a(1:n/2).*cos(arr);
        a(n/2+1:n)=a(1:n/2).*sin(arr);
    for theta=0:step:90
        jj=jj+1; 
         for ii=1:n/2
              dk=.5*(2*(ii-1)+1)*pi;
             pencil(ii)=aa(ii)*cos(dk*sin(theta*pi/180));
             sector(ii)=a(ii)*cos(dk*sin(theta*pi/180))-a(.5*n+ii)*sin(dk*sin(theta*pi/180));
          end
        pencil_array(jj)=abs(2*sum(pencil));
        sector_array(jj)=abs(2*sum(sector));
    end
    npencil_array=0.00000000001+(pencil_array/(max(pencil_array)+0.00000000001));
    nsector_array=0.00000000001+(sector_array/(max(sector_array)+0.00000000001));
    
    db_npencil_array=20*log10(npencil_array);
    db_nsector_array=20*log10(nsector_array);
      
    
    hpbw=find(db_npencil_array<=-3);
    
    if isempty(hpbw);hpbwer=100;
    else hpbwer=abs(2*step*hpbw(1)-6.8);
    end
    
    sllbw=find(db_npencil_array<=-30);
    if isempty(sllbw),
        sllbwer=100;
        sllmax=0;
    else  
        sllbwer=abs(2*step*sllbw(1)-20);
        sllmax=(max(db_npencil_array(sllbw(1)+1:ed+1)));
    end
    
    if sllmax <-30,sler=0;else sler=abs(sllmax+30);end
    
        hpbw1=find(db_nsector_array<=-3);
    
    if isempty(hpbw1),
        hpbwer1=180;
        ppripmin=abs(min(db_nsector_array));
    else 
        hpbwer1=abs(2*step*hpbw1(1)-24);
        a1=db_nsector_array(1:hpbw1(1));
        la=length(a1);
        tw1=sign(a1(1:la-1)-a1(2:la));
        pp1=(tw1(1:la-2)-tw1(2:la-1));
        bb1=find(pp1~=0);sb=length(bb1);
        if isempty(bb1), ppripmin=0;
        elseif(sb==1),ppripmin=abs(a1(1))-abs(a1(bb1));
        else
        bb1=[1 bb1];
        ppripmin=abs(abs(max(a1(bb1)))-abs(min(a1(bb1))));
        end
    end
   
    
    sllbw1=find(db_nsector_array<=-25);
    
    if isempty(sllbw1),
        sllbwer1=180;
        sllmax1=0;
    else 
        sllbwer1=abs(2*step*sllbw1(1)-40);
        sllmax1=(max(db_nsector_array(sllbw1(1)+1:ed+1)));
    end
    
    
   if ppripmin<.5,pp_rip_er=0;else pp_rip_er=abs(ppripmin-.5);end
    

    if sllmax1 <-25,sler1=0;else sler1=abs(sllmax1+25);endADR=max(aa(1:10))/min(aa(1:10));
% cost without ADR
   cost=[hpbwer^2+sllbwer^2+sler^2+hpbwer1^2+sllbwer1^2+sler1^2+pp_rip_er^2];
% cost with ADR
%   cost=[hpbwer^2+sllbwer^2+sler^2+hpbwer1^2+sllbwer1^2+sler1^2+pp_rip_er^2]+ADR;
else
    cost=10000000;
end

% To draw excitation plot execute the following commands
%-----------------------------------------------------
%  excit=[rot90(rot90(aa(1:10))) aa(1:10)];
%  angl=[rot90(rot90(aa(11:20))) aa(11:20)];
%  subplot(2,1,1);
%  plot(1:20,excit);
%  subplot(2,1,2);
%  plot(1:20,angl);
%-----------------------------------------------------


% To draw beam pattern execute the following commands
%------------------------------------------------------
% theta1=0:step:180;
% pencil_beam=rot90(rot90(db_npencil_array));
% pencil_beam1=[pencil_beam(1:ed) db_npencil_array];
% sector_beam=rot90(rot90(db_nsector_array));
% sector_beam1=[sector_beam(1:ed) db_nsector_array];
% plot(theta1,pencil_beam1,'--',theta1,sector_beam1,'-');
% axis ([0 180 -50 5])
%-------------------------------------------------------