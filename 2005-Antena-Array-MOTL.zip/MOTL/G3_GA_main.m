function [best,best_val]=G3_GA_main(fname,NP,n,Xmin,Xmax,Feval_max)

%miu, lamda and rep_size -- G3model_GA parameters
% PCX -Parent centric crossover method is used for offspring generation

%fname='dual_fit';
%n=20;
%Xmin=zeros(1,n);
%Xmax=ones(1,n);
%NP=200;
%Feval_max=400;
% miu ,lamda and rep_size are pcx crossover parameters
% Recommended values are used in the simulations

miu=3;
lamda=9;
rep_size=2;
feval_count=NP;

pb=.3;
for i=1:NP
ww(i,1:n)=Xmin+(Xmax-Xmin).*rand(1,n); %initial population
[ww(i,n+1)]=feval(fname,ww(i,1:n)); 
end

[min_ww,pos_min]=sort(ww(:,n+1)');

count=0;

while (feval_count<Feval_max),
stat=1;
while (stat==1)
rc=randperm(NP);
pos_index=sort([pos_min(1) rc(1:miu-1)]');
s2=pos_index(1:2)-pos_index(2:3);
stat=any(s2==0);
end
ww_parent=ww(pos_index,:);
ww_off=pcx_cross(ww_parent(:,1:n),lamda,rep_size,n,Xmin,Xmax,fname,pb);

feval_count=feval_count+lamda;
rc1=randperm(NP);
ww_combined=[ww_off;ww(rc1(1:rep_size)',:)];
[min_ww,pos_min]=sort(ww_combined(:,n+1));
ww(rc1(1:rep_size)',:)=ww_combined(pos_min(1:rep_size)',:);
[min_ww,pos_min]=sort(ww(:,n+1));
count=count+1;
res(count)=min_ww(1);
best_val=min_ww(1);
best=ww(pos_min(1),1:n);
end


