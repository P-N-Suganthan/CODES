% Load current test sets
load fotf_examples

disp('All test sets loaded successfully.');