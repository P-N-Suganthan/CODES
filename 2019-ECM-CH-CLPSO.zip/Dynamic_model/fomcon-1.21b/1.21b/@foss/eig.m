function eigvals = eig(S)
%EIG Eigenvalues and eigenvectors

eigvals = eig(S.A);

end

