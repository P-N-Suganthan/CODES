function out = varname(var)
%VARNAME Returns input argument workspace name
    out = inputname(1);
end

