  function [fit,err]=asian_Distillation_MIMO_fit(x)
  global weight run

  x=x';

B2=vec2mat(x(1:4),2);
B1=vec2mat(x(5:8),2);
B0=vec2mat(x(9:12),2);

s=tf('s');

%State space model of distillation column system
 G=[-33.98/((98.02*s+1)*(0.42*s+1)) 32.63/((99.6*s+1)*(0.35*s+1));
    -18.85/((75.43*s+1)*(0.30*s+1)) 34.84/((110.5*s+1)*(0.03*s+1))];


% PID Controller for Distillation Column
%      B2=[-10.938 -0.853;-1.563 -0.0002]
%     B1=[-79.688 -39.063;-12.696 18.360]
%      B0=[-100.000 -100.196;-0.0006 1.775]

    contr=(B2*s^2+B1*s+B0)/s;
% contr=[-(21.526+(5.906/s)+2.074*s) 3.925+(0.574/s);(0.318/s) 24.196+(7.0654/s)]


%Weighting function for Distil Column plant perturbation 
W1=(100*s+1)/(s+1000);
I2=eye(2);
WW1=W1*I2;


%Weighting function for Distil Column load attenuation
W2=(s+1000)/(1000*s+1);
I2=eye(2);
WW2=W2*I2;


%Sensitivity function
sys = series(contr,G);
S=feedback(I2,sys);
WS=WW2*S;
norm_WS=norm(WS,inf);

 % %Complementary sensitivity function
T=I2-S;
% T=feedback(sys,F);
% grid on
% y=step(T);
WT=WW1*T;
norm_WT=norm(WT,inf);
% con_err(1)=(norm_WS>1)*(norm_WS-1)+(norm_WT>1)*(norm_WT-1);
con_err(1)=(norm_WS>0.999)*(norm_WS-0.999);
con_err(2)=(norm_WT>0.999)*(norm_WT-0.999);

% NT=norm(T);
% con_err(2)= (NT==inf)*100; 

% Calculation of ISE
Ts=0.01;
t=0:Ts:20;
y=step(T,t);
y1=y(:,1,1)+y(:,1,2);
y2=y(:,2,1)+y(:,2,2);
E1=1-y1;
E2=1-y2;
ISE=(E1'*E1+E2'*E2);%*Ts;

con_err(3)=((isnan(ISE)||(ISE==inf)||(ISE>=1e5))*1e5);
if (isnan(ISE)||(ISE==inf)||(ISE>=1e5)),ISE=1e5 ;end 
 fit=ISE+sqrt(norm_WS^2+norm_WT^2);
 err=sum(con_err);