function [count]=count_updation(p1,chromosome,dim,n_obj,count,err);

max_rank=max(chromosome(:,dim+n_obj+1));
index=find(chromosome(:,dim+n_obj+1)==max_rank);
p2=chromosome(index,:);
[N,m]=size(p2);
clear m
c=0;
for i=1:N
    f1=p1(1,dim+1:dim+n_obj)-p2(i,dim+1:dim+n_obj)<=err;
    f2=p1(1,dim+1:dim+n_obj)-p2(i,dim+1:dim+n_obj)<err;
    f4=p2(i,dim+1:dim+n_obj)-p1(1,dim+1:dim+n_obj)<=err;
    f5=p2(i,dim+1:dim+n_obj)-p1(1,dim+1:dim+n_obj)<err;   
    
    if ((sum(f4)==n_obj)&(sum(f5)>0)),c=c+1;end
end
    
if c~=0,count=count+1;
else  count=0;
end

