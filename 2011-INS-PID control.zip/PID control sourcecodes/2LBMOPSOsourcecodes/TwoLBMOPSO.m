
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%2LBMOPSO Matlab codes
%Zhao Shizheng   APR 2010
%School of EEE
%Nanyang Technological University
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [nds,nds_val,feval_count]=TwoLBMOPSO(fname,func,feval_max,n,XRmin,XRmax,NP,max_chromosome_size,n_obj,noofcon,xl,xu,mm,run,no_count,no_bins,func_num)
%  ----------------
%  Output arguments:
%  ----------------
%  nds:           non_dominated solutions
%  nds_val:       fitness of non_dominated solutions
%  feval_count:   fitness evaluations

global xl xu n n_obj err
maxgen=ceil(feval_max/NP);
err=10^-5;
yeta=0.729;
cc=[2.05 2.05];
range=xu-xl;
vmax=ones(NP,1)*(0.25.*range);
Index=[];
chromosome=[];
feval_count=0;
vv=(2*rand(NP,1)-1)*(0.25.*range);
count=zeros(1,NP); 
con=0; % error tolerance for equality constraints

%initialize particle
for i=1:max_chromosome_size    particle(i,:)=xl+(xu-xl).*rand(1,n);end
for i=1:max_chromosome_size
    feval_count=feval_count+1;
%     particle(i,n+1:n+n_obj)=feval(fname,particle(i,1:n),n_obj,func);
    particle(i,n+1:n+n_obj+6+noofcon+n_obj)=feval(fname,particle(i,1:n),n_obj,func);
    particle(i,n+n_obj+1)=0;
end
rep=particle;

% epsilon constrain hanlding method
if noofcon~=0
    checker=0;
    genk=1;
    cp=5;
    Tc=0.2*feval_max; 

    vilation1(:,1:noofcon)=rep(:,n+n_obj+7:n+n_obj+6+noofcon);
    zeroobj_index=[];                       
    for i=1:noofcon
        maxvilation(i)=max(vilation1(:,i));
        if maxvilation(i)==0
            zeroobj_index=[zeroobj_index,i];
        end        
    end

    if isempty(zeroobj_index)==1
        W=1./maxvilation;
    else
        for i=1:noofcon
            if maxvilation(i)==0
                W(i)=0;
            else
                W(i)=1/maxvilation(i);
            end
        end
    end
    vilation=(W*vilation1')';
    if checker==0
        infeasiableindex=find(vilation~=0);
        if isempty(infeasiableindex)==1
            epsilon(genk)=0;
        else
        [hh,kk]=sort(vilation(infeasiableindex));
        epsilon(genk)=hh(ceil(0.2*length(infeasiableindex)));
        end
        checker=1;
    end
    feasiableindex=find(vilation<=epsilon(genk));
    length(feasiableindex)
    for i=1:n_obj
        fmax(i)=max(rep(:,n+n_obj+6+noofcon+i));
        fmin(i)=min(rep(:,n+n_obj+6+noofcon+i));
        f(:,i)=(rep(:,n+n_obj+6+noofcon+i)-fmin(i))/(fmax(i)-fmin(i));        
    end
    feasiableset=f(feasiableindex,:);
    for i=1:n_obj
        maxobj(i)=max(feasiableset(:,i));
    end
    for i=1:length(rep)
       if vilation(i)>epsilon(genk)
         rep(i,n+1:n+n_obj)=maxobj+vilation(i);
       else
         rep(i,n+1:n+n_obj)=f(i,:);
       end
    end
    rep(:,n+n_obj+1:n+n_obj+6)=0;
    genk=genk+1;
    if feval_count>Tc
        epsilon(genk)=0;
    else
        epsilon(genk)=epsilon(1)*(1-feval_count/Tc)^cp;
    end
    vilation=[];
    f=[];
    vilation1=[];
    maxvilation=[];
    maxobj=[];
    feasiableindex=[];
    infeasiableindex=[];
    W=[];
    sumW=[];
end
chromosome = non_domination_sort_mod_2NOe(rep,n,n_obj);
particle=particle(1:NP,:);
n_bins=no_bins;
n_count=no_count;
lbest=[];
assign=[];
if noofcon~=0
for k=1:n_obj
    chromosome(:,n+k)=chromosome(:,n+n_obj+6+noofcon+k);
end
end
[lbest,assign]=binning_initail(chromosome(:,1:n+n_obj+2),NP,n,n_obj,n_bins);

for gcount=2:feval_max
    for j=1:NP 
        if gcount>=3
        NO=1;
            if count(j)>n_count
                count(j)=0;
                [lbest1,assign1]=binning_reinitail(chromosome(:,1:n+n_obj+2),NO,n,n_obj,n_bins);
                lbest(j,:)=lbest1(1,:);
                lbest(j+NP,:)=lbest1(2,:);
                assign(j,:)=assign1(1,:);
                assign(j+NP,:)=assign1(2,:);
                n_count=no_count;
            else  [lbest1,assign1]=binning_continuous(chromosome(:,1:n+n_obj+2),NO,n,n_obj,n_bins,assign(j,:),assign(j+NP,:),lbest(j,:));%(1:N_top,:)  
                lbest(j,:)=lbest1(1,:);
                lbest(j+NP,:)=lbest1(2,:);
                if (assign(j,:)~=assign1(1,:))&(assign(j+NP,:)~=assign1(2,:)),count(j)=0;n_count=3;end
                assign(j,:)=assign1(1,:);
                assign(j+NP,:)=assign1(2,:);
            end
        end
        vv(j,:)=yeta*(vv(j,:)+cc(1).*rand(1,n).*(lbest(j,1:n)-particle(j,1:n))+cc(2).*rand(1,n).*(lbest(j+NP,1:n)-particle(j,1:n))); 
        vv(j,1:n)=(vv(j,1:n)<-vmax(j,:)).*(-vmax(j,:))+(vv(j,1:n)>=-vmax(j,:)).*vv(j,1:n);
        vv(j,1:n)=(vv(j,1:n)>vmax(j,:)).*vmax(j,:)+(vv(j,1:n)<=vmax(j,:)).*vv(j,1:n);
        particle_old(j,1:n)=particle(j,1:n);
        particle(j,1:n)=vv(j,:)+particle(j,1:n);
        if (feval_count<0.5*feval_max)
            keep_d=rand(1,n)<0.5;
            particle(j,1:n)=keep_d.*lbest(j,1:n)+(1-keep_d).*particle(j,1:n);
        end       
        xerr=sum(abs(min(particle(j,1:n)-xl,0))+abs(min(xu-particle(j,1:n),0)),2);
        if xerr~=0,
            particle(j,1:n)=(particle(j,1:n)<xl).*xl+(particle(j,1:n)>=xl).*particle(j,1:n);
            particle(j,1:n)=(particle(j,1:n)>xu).*xu+(particle(j,1:n)<=xu).*particle(j,1:n);
            vv(j,1:n)=(particle(j,1:n)<xl).*(-vv(j,1:n))+(particle(j,1:n)>=xl).*vv(j,1:n);
            vv(j,1:n)=(particle(j,1:n)>xu).*(-vv(j,1:n))+(particle(j,1:n)<=xu).*vv(j,1:n);
        end
        feval_count=feval_count+1;
%         particle(j,n+1:n+n_obj)=feval(fname,particle(j,1:n),n_obj,func);
        particle(j,n+1:n+n_obj+6+noofcon+n_obj)=feval(fname,particle(j,1:n),n_obj,func);
        particle(j,n+n_obj+1)=0;
        % counts updation
        [count(j)]=count_updation(particle(j,:),chromosome,n,n_obj,count(j),err);
    end
%     chromosome_mix=[chromosome(:,1:n+n_obj+1);particle(:,1:n+n_obj+1)];
    chromosome_mix=[chromosome;particle];
    rep=chromosome_mix;
    if noofcon~=0
    cp=5;
    Tc=0.2*feval_max; 

    vilation1(:,1:noofcon)=rep(:,n+n_obj+7:n+n_obj+6+noofcon);
    zeroobj_index=[];                       
    for i=1:noofcon
        maxvilation(i)=max(vilation1(:,i));
        if maxvilation(i)==0
            zeroobj_index=[zeroobj_index,i];
        end        
    end

    if isempty(zeroobj_index)==1
        W=1./maxvilation;
    else
        for i=1:noofcon
            if maxvilation(i)==0
                W(i)=0;
            else
                W(i)=1/maxvilation(i);
            end
        end
    end
    vilation=(W*vilation1')';
    if checker==0
        infeasiableindex=find(vilation~=0);
        if isempty(infeasiableindex)==1
            epsilon(genk)=0;
        else
        [hh,kk]=sort(vilation(infeasiableindex));
        epsilon(genk)=hh(ceil(0.2*length(infeasiableindex)));
        end
        checker=1;
    end
    feasiableindex=find(vilation<=epsilon(genk));
    length(feasiableindex)
    for i=1:n_obj
        fmax(i)=max(rep(:,n+n_obj+6+noofcon+i));
        fmin(i)=min(rep(:,n+n_obj+6+noofcon+i));
        f(:,i)=(rep(:,n+n_obj+6+noofcon+i)-fmin(i))/(fmax(i)-fmin(i));        
    end
    if isempty(feasiableindex)==1
        for i=1:length(rep)
            rep(i,n+1:n+n_obj)=vilation(i);
        end  
    else
        feasiableset=f(feasiableindex,:);   
        for i=1:n_obj
            maxobj(i)=max(feasiableset(:,i));
        end
        for i=1:length(rep)
            if vilation(i)>epsilon(genk)
                rep(i,n+1:n+n_obj)=maxobj+vilation(i);
            else
                rep(i,n+1:n+n_obj)=f(i,:);
            end
        end
    end
    rep(:,n+n_obj+1:n+n_obj+6)=0;
    genk=genk+1;
    if feval_count>Tc
        epsilon(genk)=0;
    else
        epsilon(genk)=epsilon(1)*(1-feval_count/Tc)^cp;
    end
    vilation=[];
    f=[];
    vilation1=[];
    maxvilation=[];
    maxobj=[];
    feasiableindex=[];
    infeasiableindex=[];
    W=[];
    sumW=[];
    end
    
    chromosome = non_domination_sort_mod_2NOe(rep,n,n_obj);
    if noofcon~=0
    for k=1:n_obj
        chromosome(:,n+k)=chromosome(:,n+n_obj+6+noofcon+k);
    end
    end
    [N_chro MM]=size(chromosome);
    clear MM
    chromosome_size = N_chro;
    if chromosome_size>max_chromosome_size,
        chromosome=crowding_distance(chromosome,n,n_obj,max_chromosome_size);
    end
    feval_count
    [max(chromosome(:,n+1:n+n_obj));min(chromosome(:,n+1:n+n_obj))]
    if feval_count>feval_max,break, end
end % for gcount=2:maxgen

nds=chromosome(:,1:n);
if mm==1,nds_val=chromosome(:,n+1:n+n_obj);
else nds_val=-chromosome(:,n+1:n+n_obj);
end

max_rank = max(chromosome(:,n + n_obj + 1))
color=0;
for i=1:max_rank
    temp_chromosome=[];temp_index=[];
    temp_index=find(chromosome(:,n + n_obj + 1) == i);
    for j=1:size(temp_index,1)
        temp_chromosome=[temp_chromosome;chromosome(temp_index(j),:)];
    end
    if color==0,
        scatter(temp_chromosome(:,n+1),temp_chromosome(:,n+2),'r');hold on;
    elseif color==1,
        scatter(temp_chromosome(:,n+1),temp_chromosome(:,n+2),'b');hold on;
    elseif color==2,
        scatter(temp_chromosome(:,n+1),temp_chromosome(:,n+2),'y');hold on;
    else scatter(temp_chromosome(:,n+1),temp_chromosome(:,n+2),'g');hold on;
    end    
    color=color+1;
    if color>3,color=0;end
end