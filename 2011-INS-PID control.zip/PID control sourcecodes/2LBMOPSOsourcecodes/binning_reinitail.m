function [lbest1,assign1]=binning_reinitail(chromosome,NO,n,n_obj,n_bins);

assign2=[ceil(rand(NO,1)*n_obj),  ceil(rand(NO,1)*n_bins)];
assign3=[assign2(:,1)];
assign3t=zeros(NO,2);
lowestfront=[];
lowestfront1=[];
lowestfront2=[];
for i = 1 : NO
    bin_size=(max(chromosome(:, n+assign2(i,1)))-min(chromosome(:, n+assign2(i,1))))/n_bins;
    min_bin_val(i)=(min(chromosome(:, n+assign2(i,1))))+ bin_size*(assign2(i,2)-1);
    max_bin_val(i)=(min(chromosome(:, n+assign2(i,1))))+ bin_size*(assign2(i,2));
    flagg=0;
    while (isempty(find(min_bin_val(i)<= chromosome(:, n+assign2(i,1))  &   chromosome(:, n+assign2(i,1)) < min(max_bin_val(i),max(chromosome(:, n+assign2(i,1))))+0.0001)))
        if flagg==0
        assign2(i,2)=assign2(i,2)+1;
        if assign2(i,2)>=n_bins+1,
            flagg=1;
        end
        else assign2(i,2)=assign2(i,2)-1;
        end
        min_bin_val(i)=(min(chromosome(:, n+assign2(i,1))))+ bin_size*(assign2(i,2)-1);
        max_bin_val(i)=(min(chromosome(:, n+assign2(i,1))))+ bin_size*(assign2(i,2));
    end
    flagg=0;
    assign3(i,2)=assign2(i,2);
    index=find(min_bin_val(i)<= chromosome(:, n+assign2(i,1))  &   chromosome(:, n+assign2(i,1)) < min(max_bin_val(i),max(chromosome(:, n+assign2(i,1))))+0.0001);   
    if length(index)~=1
        in_chro=chromosome(index,:);
        index_min_front_chro = find(in_chro(:,n+n_obj+1) == min(in_chro(:,n+n_obj+1)));
        if length(index_min_front_chro) ~= 1
            min_front_chro=in_chro(index_min_front_chro,:);
            inex_max_dist_chro = find(min_front_chro(:,n+n_obj+2) == max(min_front_chro(:,n+n_obj+2)));
            lbest1(i,:) = min_front_chro(inex_max_dist_chro(1),:);
        else
            lbest1(i,:) = in_chro(index_min_front_chro,:);
        end
    else
        lbest1(i,:) = chromosome(index,:);
    end
    
    if assign3(i,2)>=n_bins+1 
        assign3(i,2)=n_bins+1;
        min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
        max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));    
        while (isempty(find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001)))
            assign3(i,2)=assign3(i,2)-1;
            min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
            max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));
        end
        index=find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001);
        in_chro=chromosome(index,:);
        index_min_front_chro = find(in_chro(:,n+n_obj+1) == min(in_chro(:,n+n_obj+1)));
        min_front_chro=in_chro(index_min_front_chro,:);
        [S1,S11]=size(min_front_chro);
        D1 = sqrt(sum(abs( repmat(permute(min_front_chro(:,1:n), [1 3 2]), [1 1 1])- repmat(permute(lbest1(i,1:n), [3 1 2]), [S1 1 1]) ).^2, 3));
%         [pp1,p1]=sort(D1);
%         ppp1=find(D1(p1,1)~=0);
        ppp1=find(D1~=0);
        while length(ppp1)==0
            assign3(i,2)=assign3(i,2)-1;
            min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
            max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));    
            while (isempty(find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001)))
                assign3(i,2)=assign3(i,2)-1;
                min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
                max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));
            end
            index=find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001);
            in_chro=chromosome(index,:);
            index_min_front_chro = find(in_chro(:,n+n_obj+1) == min(in_chro(:,n+n_obj+1)));
            min_front_chro=in_chro(index_min_front_chro,:);
            [S1,S11]=size(min_front_chro);
            D1 = sqrt(sum(abs( repmat(permute(min_front_chro(:,1:n), [1 3 2]), [1 1 1])- repmat(permute(lbest1(i,1:n), [3 1 2]), [S1 1 1]) ).^2, 3));
%             [pp1,p1]=sort(D1);
%             ppp1=find(D1(p1,1)~=0);
            ppp1=find(D1~=0);
        end
        lowestfront1 = min_front_chro(ppp1,:);
        lowestfront1 (:,n+n_obj+3)=assign3(i,1);
        lowestfront1 (:,n+n_obj+4)=assign3(i,2);
    else
        min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
        max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));    
        while (isempty(find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001)))
            if flagg==0
                assign3(i,2)=assign3(i,2)+1;
                if assign3(i,2)>=n_bins+1 
                    flagg=1;
                end
            else 
                assign3(i,2)=assign3(i,2)-1;               
            end
            min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
            max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));
        end
        flagg=0;
        if assign3(i,2)>=n_bins+1 
            assign3(i,2)=n_bins+1;
            min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
            max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));    
            while (isempty(find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001)))
                assign3(i,2)=assign3(i,2)-1;
                min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
                max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));
            end
            index=find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001);
            in_chro=chromosome(index,:);
            index_min_front_chro = find(in_chro(:,n+n_obj+1) == min(in_chro(:,n+n_obj+1)));
            min_front_chro=in_chro(index_min_front_chro,:);
            [S1,S11]=size(min_front_chro);
            D1 = sqrt(sum(abs( repmat(permute(min_front_chro(:,1:n), [1 3 2]), [1 1 1])- repmat(permute(lbest1(i,1:n), [3 1 2]), [S1 1 1]) ).^2, 3));
%             [pp1,p1]=sort(D1);
%             ppp1=find(D1(p1,1)~=0);
            ppp1=find(D1~=0);
            while length(ppp1)==0
                assign3(i,2)=assign3(i,2)-1;
                min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
                max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));    
                while (isempty(find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001)))
                    assign3(i,2)=assign3(i,2)-1;
                    min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
                    max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));
                end
                index=find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001);
                in_chro=chromosome(index,:);
                index_min_front_chro = find(in_chro(:,n+n_obj+1) == min(in_chro(:,n+n_obj+1)));
                min_front_chro=in_chro(index_min_front_chro,:);
                [S1,S11]=size(min_front_chro);
                D1 = sqrt(sum(abs( repmat(permute(min_front_chro(:,1:n), [1 3 2]), [1 1 1])- repmat(permute(lbest1(i,1:n), [3 1 2]), [S1 1 1]) ).^2, 3));
%                 [pp1,p1]=sort(D1);
%                 ppp1=find(D1(p1,1)~=0);
                ppp1=find(D1~=0);
            end
            lowestfront1 = min_front_chro(ppp1,:);
            lowestfront1 (:,n+n_obj+3)=assign3(i,1);
            lowestfront1 (:,n+n_obj+4)=assign3(i,2);           
        else
            index=find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001);
            in_chro=chromosome(index,:);
            index_min_front_chro = find(in_chro(:,n+n_obj+1) == min(in_chro(:,n+n_obj+1)));
            min_front_chro=in_chro(index_min_front_chro,:);
            [S1,S11]=size(min_front_chro);
            D1 = sqrt(sum(abs( repmat(permute(min_front_chro(:,1:n), [1 3 2]), [1 1 1])- repmat(permute(lbest1(i,1:n), [3 1 2]), [S1 1 1]) ).^2, 3));
%             [pp1,p1]=sort(D1);
%             ppp1=find(D1(p1,1)~=0);
            ppp1=find(D1~=0);
            while length(ppp1)==0
                if flagg==0
                    assign3(i,2)=assign3(i,2)+1;
                else assign3(i,2)=assign3(i,2)-1;
                end
                min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
                max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));    
                while (isempty(find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001)))
                    if flagg==0
                        assign3(i,2)=assign3(i,2)+1;
                        if assign3(i,2)>=n_bins+1 
                            flagg=1;
                        end
                    else 
                        assign3(i,2)=assign3(i,2)-1;                    
                    end
                    min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
                    max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));
                end
                index=find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001);
                in_chro=chromosome(index,:);
                index_min_front_chro = find(in_chro(:,n+n_obj+1) == min(in_chro(:,n+n_obj+1)));
                min_front_chro=in_chro(index_min_front_chro,:);
                [S1,S11]=size(min_front_chro);
                D1 = sqrt(sum(abs( repmat(permute(min_front_chro(:,1:n), [1 3 2]), [1 1 1])- repmat(permute(lbest1(i,1:n), [3 1 2]), [S1 1 1]) ).^2, 3));
%                 [pp1,p1]=sort(D1);
%                 ppp1=find(D1(p1,1)~=0);
                ppp1=find(D1~=0);
            end
            lowestfront1 = min_front_chro(ppp1,:);
            lowestfront1 (:,n+n_obj+3)=assign3(i,1);
            lowestfront1 (:,n+n_obj+4)=assign3(i,2);
        end
    end
    flagg=0;
    assign3t(i,1)=ceil(rand(1,1)*n_obj);
    while (assign3t(i,1)==assign3(i,1))
        assign3t(i,1)=ceil(rand(1,1)*n_obj);
    end
    bin_size=(max(chromosome(:, n+assign3t(i,1)))-min(chromosome(:, n+assign3t(i,1))))/n_bins;
    assign3t(i,2)=ceil((lbest1(i,n+assign3t(i,1))-min(chromosome(:,n+assign3t(i,1))))/bin_size);
    if assign3t(i,2)>=n_bins+1 
        assign3t(i,2)=n_bins+1;
        min_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2)-1);
        max_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2));    
        while (isempty(find(min_bin_value(i)<= chromosome(:, n+assign3t(i,1))  &   chromosome(:, n+assign3t(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3t(i,1))))+0.0001)))
            assign3t(i,2)=assign3t(i,2)-1;
            min_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2)-1);
            max_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2));
        end
        index=find(min_bin_value(i)<= chromosome(:, n+assign3t(i,1))  &   chromosome(:, n+assign3t(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3t(i,1))))+0.0001);
        in_chro=chromosome(index,:);
        index_min_front_chro = find(in_chro(:,n+n_obj+1) == min(in_chro(:,n+n_obj+1)));
        min_front_chro=in_chro(index_min_front_chro,:);
        [S1,S11]=size(min_front_chro);
        D2 = sqrt(sum(abs( repmat(permute(min_front_chro(:,1:n), [1 3 2]), [1 1 1])- repmat(permute(lbest1(i,1:n), [3 1 2]), [S1 1 1]) ).^2, 3));
%         [pp2,p2]=sort(D2);
%         ppp2=find(D2(p2,1)~=0);
        ppp2=find(D2~=0);
        while length(ppp2)==0
            assign3t(i,2)=assign3t(i,2)-1;
            min_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2)-1);
            max_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2));    
            while (isempty(find(min_bin_value(i)<= chromosome(:, n+assign3t(i,1))  &   chromosome(:, n+assign3t(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3t(i,1))))+0.0001)))
                assign3t(i,2)=assign3t(i,2)-1;
                min_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2)-1);
                max_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2));
            end
            index=find(min_bin_value(i)<= chromosome(:, n+assign3t(i,1))  &   chromosome(:, n+assign3t(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3t(i,1))))+0.0001);
            in_chro=chromosome(index,:);
            index_min_front_chro = find(in_chro(:,n+n_obj+1) == min(in_chro(:,n+n_obj+1)));
            min_front_chro=in_chro(index_min_front_chro,:);
            [S1,S11]=size(min_front_chro);
            D2 = sqrt(sum(abs( repmat(permute(min_front_chro(:,1:n), [1 3 2]), [1 1 1])- repmat(permute(lbest1(i,1:n), [3 1 2]), [S1 1 1]) ).^2, 3));
%             [pp2,p2]=sort(D2);
%             ppp2=find(D2(p2,1)~=0);
            ppp2=find(D2~=0);
        end
        lowestfront2 = min_front_chro(ppp2,:);
        lowestfront2 (:,n+n_obj+3)=assign3(i,1);
        lowestfront2 (:,n+n_obj+4)=assign3(i,2);
    else
        min_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2)-1);
        max_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2));    
        while (isempty(find(min_bin_value(i)<= chromosome(:, n+assign3t(i,1))  &   chromosome(:, n+assign3t(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3t(i,1))))+0.0001)))
            if flagg==0
                assign3t(i,2)=assign3t(i,2)+1;
                if assign3t(i,2)>=n_bins+1 
                    flagg=1;
                end
            else 
                assign3t(i,2)=assign3t(i,2)-1;               
            end
            min_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2)-1);
            max_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2));
        end
        flagg=0;
        if assign3t(i,2)>=n_bins+1 
            assign3t(i,2)=n_bins+1;
            min_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2)-1);
            max_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2));    
            while (isempty(find(min_bin_value(i)<= chromosome(:, n+assign3t(i,1))  &   chromosome(:, n+assign3t(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3t(i,1))))+0.0001)))
                assign3t(i,2)=assign3t(i,2)-1;
                min_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2)-1);
                max_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2));
            end
            index=find(min_bin_value(i)<= chromosome(:, n+assign3t(i,1))  &   chromosome(:, n+assign3t(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3t(i,1))))+0.0001);
            in_chro=chromosome(index,:);
            index_min_front_chro = find(in_chro(:,n+n_obj+1) == min(in_chro(:,n+n_obj+1)));
            min_front_chro=in_chro(index_min_front_chro,:);
            [S1,S11]=size(min_front_chro);
            D2 = sqrt(sum(abs( repmat(permute(min_front_chro(:,1:n), [1 3 2]), [1 1 1])- repmat(permute(lbest1(i,1:n), [3 1 2]), [S1 1 1]) ).^2, 3));
%             [pp2,p2]=sort(D2);
%             ppp2=find(D2(p2,1)~=0);
            ppp2=find(D2~=0);
            while length(ppp2)==0
                assign3t(i,2)=assign3t(i,2)-1;
                min_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2)-1);
                max_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2));    
                while (isempty(find(min_bin_value(i)<= chromosome(:, n+assign3t(i,1))  &   chromosome(:, n+assign3t(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3t(i,1))))+0.0001)))
                    assign3t(i,2)=assign3t(i,2)-1;
                    min_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2)-1);
                    max_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2));
                end
                index=find(min_bin_value(i)<= chromosome(:, n+assign3t(i,1))  &   chromosome(:, n+assign3t(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3t(i,1))))+0.0001);
                in_chro=chromosome(index,:);
                index_min_front_chro = find(in_chro(:,n+n_obj+1) == min(in_chro(:,n+n_obj+1)));
                min_front_chro=in_chro(index_min_front_chro,:);
                [S1,S11]=size(min_front_chro);
                D2 = sqrt(sum(abs( repmat(permute(min_front_chro(:,1:n), [1 3 2]), [1 1 1])- repmat(permute(lbest1(i,1:n), [3 1 2]), [S1 1 1]) ).^2, 3));
%                 [pp2,p2]=sort(D2);
%                 ppp2=find(D2(p2,1)~=0);
                ppp2=find(D2~=0);
            end
            lowestfront2 = min_front_chro(ppp2,:);
            lowestfront2 (:,n+n_obj+3)=assign3(i,1);
            lowestfront2 (:,n+n_obj+4)=assign3(i,2);           
        else
            index=find(min_bin_value(i)<= chromosome(:, n+assign3t(i,1))  &   chromosome(:, n+assign3t(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3t(i,1))))+0.0001);
            in_chro=chromosome(index,:);
            index_min_front_chro = find(in_chro(:,n+n_obj+1) == min(in_chro(:,n+n_obj+1)));
            min_front_chro=in_chro(index_min_front_chro,:);
            [S1,S11]=size(min_front_chro);
            D2 = sqrt(sum(abs( repmat(permute(min_front_chro(:,1:n), [1 3 2]), [1 1 1])- repmat(permute(lbest1(i,1:n), [3 1 2]), [S1 1 1]) ).^2, 3));
%             [pp2,p2]=sort(D2);
%             ppp2=find(D2(p2,1)~=0);
            ppp2=find(D2~=0);
            while length(ppp2)==0
                if flagg==0
                    assign3t(i,2)=assign3t(i,2)+1;
                else assign3t(i,2)=assign3t(i,2)-1;
                end;
                min_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2)-1);
                max_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2));    
                while (isempty(find(min_bin_value(i)<= chromosome(:, n+assign3t(i,1))  &   chromosome(:, n+assign3t(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3t(i,1))))+0.0001)))
                    if flagg==0
                        assign3t(i,2)=assign3t(i,2)+1;
                        if assign3t(i,2)>=n_bins+1 
                            flagg=1;
                        end
                    else 
                        assign3t(i,2)=assign3t(i,2)-1;                        
                    end
                    min_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2)-1);
                    max_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2));
                end
                index=find(min_bin_value(i)<= chromosome(:, n+assign3t(i,1))  &   chromosome(:, n+assign3t(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3t(i,1))))+0.0001);
                in_chro=chromosome(index,:);
                index_min_front_chro = find(in_chro(:,n+n_obj+1) == min(in_chro(:,n+n_obj+1)));
                min_front_chro=in_chro(index_min_front_chro,:);
                [S1,S11]=size(min_front_chro);
                D2 = sqrt(sum(abs( repmat(permute(min_front_chro(:,1:n), [1 3 2]), [1 1 1])- repmat(permute(lbest1(i,1:n), [3 1 2]), [S1 1 1]) ).^2, 3));
%                 [pp2,p2]=sort(D2);
%                 ppp2=find(D2(p2,1)~=0);
                ppp2=find(D2~=0);
            end
            lowestfront2 = min_front_chro(ppp2,:);
            lowestfront2 (:,n+n_obj+3)=assign3(i,1);
            lowestfront2 (:,n+n_obj+4)=assign3(i,2);
        end
    end
    lowestfront=[lowestfront1;lowestfront2];
    index_lowestfront=find(lowestfront(:,n+n_obj+1)==min(lowestfront(:,n+n_obj+1)));
    lowestfront=lowestfront(index_lowestfront,:);
    [S1,S11]=size(lowestfront);
    DD = sqrt(sum(abs( repmat(permute(lowestfront(:,1:n), [1 3 2]), [1 1 1])- repmat(permute(lbest1(i,1:n), [3 1 2]), [S1 1 1]) ).^2, 3));
    index_2ndlbs=find(DD>=(mean(DD)-0.000001));
    [qq,q]=sort(DD(index_2ndlbs,1));
    lbest1(NO+i,:)=lowestfront(index_2ndlbs(q(1),1),1:n+n_obj+2);
    assign3(i,:)=lowestfront(index_2ndlbs(q(1),1),n+n_obj+3:n+n_obj+4);
end
lbest1=lbest1(1:2*NO,:);
assign1=[assign2;assign3];