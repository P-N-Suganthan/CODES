         function [fit,err]=F18_FIGHTER_AIRCRAFT_Multi(x)


s=tf('s');

% State space model of F18HARV FIGHTER AIRCRAFT system
A=[-0.0750 -24.0500 0 -36.1600;-0.0009 -0.1959 0.9896 0;-0.0002 -0.1454 -0.1677 0;0 0 1 0];
B=[-0.023 0 -0.0729 0.0393 -0.0411 0.1600;-0.0002 -0.0001 -0.0004 0 -0.0003 -0.0003;-0.0067 -0.0007 -0.0120 0.0006 0.0007 0.0005;0 0 0 0 0 0];
C=[1 0 0 0;0 -1 0 1;0 0 0 1];
Bv=[1 0 0;0 1 0;0 0 1;0 0 0];
D=0;
sys=ss(A,Bv,C,D);
G=tf(sys);

% PID Controller for F18HARV FIGHTER AIRCRAFT system
%Result given in OSA 2004, PID controller
%   B2=[-19788.38 -18237.71 -1347.88; -12517.98 8483.12 622.55; 11498.13 917.12 3375.39];
%   B1=[19185.69 -12519.68 19960.12; -20000 7084.61 -18786.01; -10107.62 19360.44 5944.56];
%   B0=[-19060.26 18026.98 20000; 4194.82 -2302.57 6856.19; -5180.15 11857.10 -2348.46];
 %Result given in IGA 2005, PID controller
% B2=[-10512.57 5906.282 588.742; -10745.92 -10313.56 473.919; 401.402 692.921 15328.36];
% B1=[-19779.82 -976.048 -341.244; -5920.244 -644.055 161.190; 850.621 401.478 8434.246];
% B0=[-15838.73 188.618 155.049; -17755.43 -17.452 -596.600; -709.592
% 1232.053 -933.705];
B2=vec2mat(x(1:9),3);
B1=vec2mat(x(10:18),3);
B0=vec2mat(x(19:27),3);

contr=((B2*s^2)+(B1*s)+B0)/s;

%Sensitivity function
sys = series(contr,G);
I3=eye(3);
S=feedback(I3,sys);
W2=(0.25*s+0.025)/(s^2+0.4*s+10000000);
I3=eye(3);
WW2=W2*I3;
WS=WW2*S;
norm_WS=norm(WS,inf);

%Complementary sensitivity function
T=I3-S;
W1=(0.0125*s^2+1.2025*s+1.25)/(s^2+20*s+100);
I3=eye(3);
WW1=W1*I3;
WT=WW1*T;
norm_WT=norm(WT,inf);

con_err(1)=(norm_WS>0.999)*(norm_WS-0.999);
con_err(2)=(norm_WT>0.999)*(norm_WT-0.999);

% Calculation of H2 norm for error E(S)
Ts=0.01;
t=(0:Ts:10)';
r(:,1)=zeros(length(t),1);
r(:,2)=1-exp(-3*t);
r(:,3)=1-exp(-6*t);
yr=lsim(T,r,t);
E1=r(:,1)-yr(:,1);
E2=r(:,2)-yr(:,2);
E3=r(:,3)-yr(:,3);
ISE=(E1'*E1+E2'*E2+E3'*E3);
if (isnan(ISE) ||(ISE>1e3)),ISE=1e3 ;end 
con_err(3)=(isnan(ISE) ||(ISE>1e5))*1e5;
 % J infinity function 
 err=sum(con_err); % combining all the three constriant errors
 
 fit=[ISE  sqrt(norm_WS^2+norm_WT^2) err] ;