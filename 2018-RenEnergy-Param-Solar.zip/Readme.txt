MATLAB Code: "Parameter estimation of solar cells using datasheet information with the 
application of an adaptive differential evolution algorithm." 
Renewable Energy (2018): DOI-10.1016/j.renene.2018.07.152

The author can be contacted at parthapr001@e.ntu.edu.sg