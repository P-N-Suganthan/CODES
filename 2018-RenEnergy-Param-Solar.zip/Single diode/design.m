function Error = design(x)

%xx = Result(:,1:3); Is = []; Iph = [];
% for jj = 1:30
%     x = xx(jj,:); 
q = 1.60217646*10^-19; % charge of an electron
k = 1.38064852*10^-23; % Boltzman's constant
T0 = 273.15; % absolute temperature 0 deg C
T = 25; % design temp

% %% Polycrystaline KC200GT
% Voc = 32.9;
% Isc = 8.21;
% Vm = 26.3; % voltage at max power
% Im = 7.61;
% Nc = 54;

% %% Monocrystalline Shell SQ85
% Voc = 22.2;
% Isc = 5.45;
% Vm = 17.2; % voltage at max power
% Im = 4.95;
% Nc = 36;

%% Thin film ST40
Voc = 23.3;
Isc = 2.68;
Vm = 16.6; % voltage at max power
Im = 2.41;
Nc = 36;

%%
a = x(1); Rs = x(2); Rp = x(3);

Is = (Isc+Rs*Isc/Rp-Voc/Rp)/(exp(q*Voc/(a*k*Nc*(T0+T)))-exp(q*Rs*Isc/(a*k*Nc*(T0+T))));
%Iph = (Isc+Rs*Isc/Rp-Voc/Rp)*(exp(q*Voc/(a*k*Nc*(T0+T)))-1)/(exp(q*Voc/(a*k*Nc*(T0+T)))-exp(q*Rs*Isc/(a*k*Nc*(T0+T))))+Voc/Rp;
Iph = Is*(exp(q*Voc/(a*k*Nc*(T0+T)))-1)+Voc/Rp;

eps1 = Is*(exp(q*Voc/(a*k*Nc*(T+T0)))-1)+Voc/Rp-Iph;
eps2 = Isc+Is*(exp(q*Rs*Isc/(a*k*Nc*(T+T0)))-1)+Rs*Isc/Rp-Iph;
eps3 = Iph-Is*(exp(q*(Vm+Rs*Im)/(a*k*Nc*(T+T0)))-1)-(Vm+Rs*Im)/Rp-Im;

eps = eps1^2+eps2^2+eps3^2;
Error = eps;
%Isrec(jj) = Is;
%Iphrec(jj) = Iph;
%end
