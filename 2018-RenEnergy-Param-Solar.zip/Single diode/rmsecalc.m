global a_o Rs_o Rp_o meas_idx V_meas

sol = Result(:,1:3);

q = 1.60217646*10^-19; % charge of an electron
k = 1.38064852*10^-23; % Boltzman's constant
T0 = 273.15; % absolute temperature 0 deg C
T = 25; % design temp
Is = zeros(); Iph = zeros();

%% Polycrystaline KC200GT
% Voc = 32.9;
% Isc = 8.21;
% Vm = 26.3; % voltage at max power
% Im = 7.61;
% Nc = 54;

%% Monocrystalline Shell SQ85
% Voc = 22.2;
% Isc = 5.45;
% Vm = 17.2; % voltage at max power
% Im = 4.95;
% Nc = 36;

%% Thin film ST40
Voc = 23.3;
Isc = 2.68;
Vm = 16.6; % voltage at max power
Im = 2.41;
Nc = 36;

%%
fun = @soldgn;
f0 = 0;
options = optimoptions('fsolve','Display','off');
V_meas = sort([0,1:floor(Voc),Vm,Voc]);
IL_calc = zeros(size(sol,1),length(V_meas));

for j = 1:size(sol,1)
x_opt = sol(j,1:3);
a_o = x_opt(1); Rs_o = x_opt(2); Rp_o = x_opt(3);
for jj = 1:length(V_meas)
meas_idx = jj;
IL_calc(j,jj) = fsolve(fun,f0,options);
end
Is(j) = (Isc+Rs_o*Isc/Rp_o-Voc/Rp_o)/(exp(q*Voc/(a_o*k*Nc*(T0+T)))-exp(q*Rs_o*Isc/(a_o*k*Nc*(T0+T))));
Iph(j) = (Isc+Rs_o*Isc/Rp_o-Voc/Rp_o)*(exp(q*Voc/(a_o*k*Nc*(T0+T)))-1)/(exp(q*Voc/(a_o*k*Nc*(T0+T)))-exp(q*Rs_o*Isc/(a_o*k*Nc*(T0+T))))+Voc/Rp_o;
end
Is = Is'; Iph = Iph';
V_plot = V_meas;

figure(1)
for j = 1:size(sol,1)
plot(V_plot,IL_calc(j,:));
hold on
end
xlabel('Voltage, V (volt)');
ylabel('Current, I (amp)');

[~,idxRs] = max(Result(:,2));
[~,idxRp] = max(Result(:,3));
figure(2)
for j = 1:2
I_Y = [IL_calc(idxRs,:);IL_calc(idxRp,:)];
plot(V_plot,I_Y(j,:));
hold on
end
xlabel('Voltage, V (volt)');
ylabel('Current, I (amp)');
legend(num2str(Result(idxRs,1:3)),num2str(Result(idxRp,1:3)));

figure(3)
scatter3(Result(:,1),Result(:,2),Result(:,3));
xlabel('a');
ylabel('R_s (ohm)');
zlabel('R_p (ohm)');