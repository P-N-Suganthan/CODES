function Error = design(x)

% xx = Result(:,1:5); Is = []; Iph = [];
% for jj = 1:30
%     x = xx(jj,:);
q = 1.60217646*10^-19; % charge of an electron
k = 1.38064852*10^-23; % Boltzman's constant
T0 = 273.15; % absolute temperature 0 deg C
T = 25; % design temp

% %% Polycrystaline KC200GT
% Voc = 32.9;
% Isc = 8.21;
% Vm = 26.3; % voltage at max power
% Im = 7.61;
% Nc = 54;

%% Monocrystalline Shell SQ85
% Voc = 22.2;
% Isc = 5.45;
% Vm = 17.2; % voltage at max power
% Im = 4.95;
% Nc = 36;

%% Thin film ST40
Voc = 23.3;
Isc = 2.68;
Vm = 16.6; % voltage at max power
Im = 2.41;
Nc = 36;


Is1 = x(1); a1 = x(2); a2 = x(3); Rs = x(4); Rp = x(5);

num = Isc+Rs*Isc/Rp-Voc/Rp-Is1*(exp(q*Voc/(a1*k*Nc*(T0+T)))-exp(q*Rs*Isc/(a1*k*Nc*(T0+T))));
den = exp(q*Voc/(a2*k*Nc*(T0+T)))-exp(q*Rs*Isc/(a2*k*Nc*(T0+T)));
Is2 = abs(num/den);
Iph = Is1*(exp(q*Voc/(a1*k*Nc*(T0+T)))-1)+Is2*(exp(q*Voc/(a2*k*Nc*(T0+T)))-1)+Voc/Rp;

eps1 = Is1*(exp(q*Voc/(a1*k*Nc*(T0+T)))-1)+Is2*(exp(q*Voc/(a2*k*Nc*(T0+T)))-1)+Voc/Rp-Iph;
eps2 = Isc+Is1*(exp(q*Rs*Isc/(a1*k*Nc*(T0+T)))-1)+Is2*(exp(q*Rs*Isc/(a2*k*Nc*(T0+T)))-1)+Rs*Isc/Rp-Iph;
eps3 = Iph-Is1*(exp(q*(Vm+Rs*Im)/(a1*k*Nc*(T+T0)))-1)-Is2*(exp(q*(Vm+Rs*Im)/(a2*k*Nc*(T+T0)))-1)-(Vm+Rs*Im)/Rp-Im;

eps = eps1^2+eps2^2+eps3^2;
Error = eps;
% Isrec(jj) = Is2;
% Iphrec(jj) = Iph;
% end




