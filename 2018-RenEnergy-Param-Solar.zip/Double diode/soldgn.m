function F = soldgn(IL)

global Is1_o a1_o a2_o Rs_o Rp_o meas_idx V_meas

q = 1.60217646*10^-19; % charge of an electron
k = 1.38064852*10^-23; % Boltzman's constant
T0 = 273.15; % absolute temperature 0 deg C
T = 25; % design temp

% %% Polycrystaline KC200GT
% Voc = 32.9;
% Isc = 8.21;
% Nc = 54;

%% Monocrystalline Shell SQ85
% Voc = 22.2;
% Isc = 5.45;
% Nc = 36;

%% Thin film ST40
Voc = 23.3;
Isc = 2.68;
Nc = 36;

num = Isc+Rs_o*Isc/Rp_o-Voc/Rp_o-Is1_o*(exp(q*Voc/(a1_o*k*Nc*(T0+T)))-exp(q*Rs_o*Isc/(a1_o*k*Nc*(T0+T))));
den = exp(q*Voc/(a2_o*k*Nc*(T0+T)))-exp(q*Rs_o*Isc/(a2_o*k*Nc*(T0+T)));
Is2 = num/den;
Iph = Is1_o*(exp(q*Voc/(a1_o*k*Nc*(T0+T)))-1)+Is2*(exp(q*Voc/(a2_o*k*Nc*(T0+T)))-1)+Voc/Rp_o;

F = Iph-Is1_o*(exp(q*(V_meas(meas_idx)+Rs_o*IL)/(a1_o*k*Nc*(T0+T)))-1)-...
    Is2*(exp(q*(V_meas(meas_idx)+Rs_o*IL)/(a2_o*k*Nc*(T0+T)))-1)-(V_meas(meas_idx)+Rs_o*IL)/Rp_o-IL;
