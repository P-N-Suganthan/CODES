global Is1_o a1_o a2_o Rs_o Rp_o meas_idx V_meas

sol = Result(:,1:5);
q = 1.60217646*10^-19; % charge of an electron
k = 1.38064852*10^-23; % Boltzman's constant
T0 = 273.15; % absolute temperature 0 deg C
T = 25; % design temp
Is2 = zeros(); Iph = zeros();

% %% Polycrystaline KC200GT
% Voc = 32.9;
% Isc = 8.21;
% Vm = 26.3; % voltage at max power
% Im = 7.61;
% Nc = 54;

%% Monocrystalline Shell SQ85
% Voc = 22.2;
% Isc = 5.45;
% Vm = 17.2; % voltage at max power
% Im = 4.95;
% Nc = 36;

%% Thin film ST40
Voc = 23.3;
Isc = 2.68;
Vm = 16.6; % voltage at max power
Im = 2.41;
Nc = 36;

fun = @soldgn;
f0 = 0;
options = optimoptions('fsolve','Display','off');
V_meas = sort([0,1:floor(Voc),Vm,Voc]);
IL_calc = zeros(size(sol,1),length(V_meas));

for j = 1:size(sol,1)
x_opt = sol(j,1:5);
Is1_o = x_opt(1); a1_o = x_opt(2); a2_o = x_opt(3); Rs_o = x_opt(4); Rp_o = x_opt(5);
for jj = 1:length(V_meas)
meas_idx = jj;
IL_calc(j,jj) = fsolve(fun,f0,options);
end
num = Isc+Rs_o*Isc/Rp_o-Voc/Rp_o-Is1_o*(exp(q*Voc/(a1_o*k*Nc*(T0+T)))-exp(q*Rs_o*Isc/(a1_o*k*Nc*(T0+T))));
den = exp(q*Voc/(a2_o*k*Nc*(T0+T)))-exp(q*Rs_o*Isc/(a2_o*k*Nc*(T0+T)));
Is2(j) = num/den;
Iph(j) = Is1_o*(exp(q*Voc/(a1_o*k*Nc*(T0+T)))-1)+Is2(j)*(exp(q*Voc/(a2_o*k*Nc*(T0+T)))-1)+Voc/Rp_o;
end
Is2 = Is2'; Iph = Iph';
V_plot = V_meas;

figure(1)
for j = 1:size(sol,1)
plot(V_plot,IL_calc(j,:));
hold on
end
xlabel('Voltage, V (volt)');
ylabel('Current, I (amp)');

[~,idxRs] = max(Result(:,4));
[~,idxRp] = max(Result(:,5));
figure(2)
for j = 1:2
I_Y = [IL_calc(idxRs,:);IL_calc(idxRp,:)];
plot(V_plot,I_Y(j,:));
hold on
end
xlabel('Voltage, V (volt)');
ylabel('Current, I (amp)');
legend(num2str(Result(idxRs,1:5)),num2str(Result(idxRp,1:5)));

figure(3)
Resultplot = [(Result(:,1)-10^-12)./(10^-6-10^-12),(Result(:,2)-0.5)./(2-0.5),(Result(:,3)-0.5)./(2-0.5),(Result(:,4)-0.001)./(1-0.001),(Result(:,5)-50)./(200-50)];
labels = {'I_o_1','a_1','a_2','R_s','R_p'};
parallelcoords(Resultplot,'Labels',labels);

