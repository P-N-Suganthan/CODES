plot_res = Result(:,1:5);
plot_res(:,1) = (plot_res(:,1)-10^-12)./(10^-6-10^-12);
plot_res(:,2) = (plot_res(:,2)-0.5)./(2-0.5);
plot_res(:,3) = (plot_res(:,3)-0.5)./(2-0.5);
plot_res(:,4) = (plot_res(:,4)-0.001)./(1-0.001);
plot_res(:,5) = (plot_res(:,5)-50)./(200-50);

figure(1)
parallelcoords(plot_res);
labels = {'I_O_1','a_1','a_2','R_S','R_P'};
parallelcoords(plot_res,'Labels',labels);
ylabel('Normalised value')