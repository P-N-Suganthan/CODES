# how to cite
# @INPROCEEDINGS{Ren2013FUZZ,
#                author = {Ye Ren and P. N. Suganthan and N. Srikanth and S. Sarkar},
#                title = {A Hybrid {ARIMA-DENFIS} Method for Wind Speed Forecasting},
#                booktitle = {Proc. IEEE International Conference on Fuzzy Systems (FUZZ'13)},
#   year = {2013},
#   address = {Hyderabad, India},
#   month = jul
# }

