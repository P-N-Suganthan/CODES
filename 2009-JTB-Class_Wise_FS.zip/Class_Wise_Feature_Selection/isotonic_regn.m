function [tmp_dec_vals,ghat] = isotonic_regn(trng_data,trng_label,cvfold)

%take trng data and corresponding labels
no_trdata=size(trng_data,1);
%generate 5-fold cv
[index]=generate_strat_kfold(trng_label,cvfold);

%using cv get dec_vals for all training data
%dec_vals : no_trngdata*1 matrix
store_dec_vals=zeros(1,no_trdata);
for i=1:cvfold
    tmp_trindex=find(index~=i);
    tmp_tstindex=find(index==i);
    tmp_trndata=trng_data(tmp_trindex,:);
    tmp_trnlabel=trng_label(tmp_trindex,:);

    tmp_tstdata=trng_data(tmp_tstindex,:);
    tmp_tstlabel=trng_label(tmp_tstindex,:);
    
    model=svmtrain(tmp_trnlabel,tmp_trndata,'-c 1.0 -t 0');
    [predicted_label, accuracy, dec_values] = svmpredict(tmp_tstlabel,tmp_tstdata,model);
    store_dec_vals(tmp_tstindex)=model.Label(1)*dec_values';
end

%a = max(abs(dec_vals));
%remap dec_vals in [0,1]: tmp_dec_vals
%rank training data according to tmp_dec_vals in increasing order of
%corresponding tmp_dec_vals
%transform -1 -> 0 and 1 -> 1
%initial g : sorted_trngdata(cls_labels), cls_labels -1 -> 0 and +1 -> 1
tmp_a = max(abs(store_dec_vals));
tmp_dec_vals = (store_dec_vals+tmp_a)/(2*tmp_a);
[y,tmp_I] = sort(tmp_dec_vals);
tmp_label = trng_label(tmp_I);
tmp_label(tmp_label<0) = 0;
tmp_dec_vals = y; %sorted tmo_dec_vals

%get isotonic regressed form ghat, ghat = IsoMeans(g)
ghat=IsoMeans(tmp_label);





    
    
