function [] = chng_directory(data_flag)

switch data_flag
    case 1
        cd gcm;
    case 2
        cd cancer11;
end
