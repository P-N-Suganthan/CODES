function [] = ova_rfe(data,myindex,labels,class_id,cvfold,no_runs,data_flag,No_Feats_Selected,codedir)

%% This file selects class-wise features and store them in a file. Size of each feature subset is also
%% stored in another file.

%% Inputs:-
%% data: sample by feature matrix
%% myindex: indices of pre-partitioned data.
%% labels: labels of each sample
%% class_id: vector containing all classes
%% cvfold: Outer cvfold
%% no_runs: No of multiple runs. For each run different partition of data will be used
%% data_flag: if you have multiple data files, you can give flag to automatically indicates data file. helpful for storing outputs of program
%% NO_Feats_Selected: No of features to be selected

data=[data,labels'];
[no_rows,no_cols] = size(data) %no_rows = no_samples and no_cols = no_genes+1

no_class = size(class_id,2);
total_count=0;
count_feat=zeros(no_class,no_cols-1);
% Storing the no of feats selected
fname1 = sprintf('No_Feats_Selected_%d.txt',data_flag);

tic
for runs = 1:no_runs
    runs
    CVerror = zeros(cvfold,1);
    for i=1:cvfold
        i
        total_count=total_count+1;
        trainindex = find(myindex(runs,:)~=i);
                
        for j=1:no_class
            j
            traindata = data(trainindex,:);
            exp_trainlabel = traindata(:,no_cols);
            
            neg_index = find(exp_trainlabel ~= class_id(j));
            pos_index = find(exp_trainlabel == class_id(j));
            traindata(neg_index,no_cols) = -1;
            traindata(pos_index,no_cols) = 1;
            trainlabel = traindata(:,no_cols);
            traindata = traindata(:,1:no_cols-1);
            
            %SVM RFE Feature Selection Framework            
            tmp_p=[1:no_cols-1];
            while size(tmp_p,2)~=No_Feats_Selected
                model = svmtrain(trainlabel,traindata,'-c 0.1 -t 0');
                tmp_wt = model.sv_coef'*model.SVs;
                [val,I]=sort(abs(tmp_wt),'descend');
                q = min(floor(0.1*size(tmp_p,2)),(size(tmp_p,2)-No_Feats_Selected));
                tmp_p=tmp_p(I(1:size(I,2)-q));
                tmp_size=size(tmp_p,2);               
                %fname
                chng_directory(data_flag);
                cd selected_feats;
                dlmwrite(fname1,tmp_size,'delimiter','\t','-append');
                fname=sprintf('feats%d_class%d.txt',tmp_size,j);
                %dlmwrite to store features rowwise
                dlmwrite(fname,tmp_p,'delimiter','\t','-append');
                traindata=data(trainindex,tmp_p);
		cd(eval('codedir'));
            end % End of feature selection
            count_feat(j,tmp_p)=count_feat(j,tmp_p)+1;
        end % End of class loop
    end %End of fold loop
end % End of runs loop

chng_directory(data_flag);
cd selected_feats;
fname=sprintf('freq_features%d_data%d_ovarfe.mat',No_Feats_Selected,data_flag);
save(fname,'count_feat');
toc
