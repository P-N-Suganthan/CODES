function [err] = ova_rfe_svm_duan(data,myindex,labels,class_id,cvfold,no_runs,data_flag,No_Feats_Selected,codedir)

%performs ova svm using selected features by ova rfe procedure. Features
%obtained by ova rfe are used w/o any unification ova svm
%was performed for final classification.

%Decision: probability decision values are considered for final
%decision

%Method Used: Duan

%Author: Ashish Anand

data=[data,labels'];
[no_rows,no_cols] = size(data) %no_rows = no_samples and no_cols = no_genes+1

no_class = size(class_id,2);
err = zeros(1,no_runs);
store_flag = 1;

rand('state',0);
chng_directory(data_flag);
cd selected_feats;
for i=1:no_class
    fname=sprintf('feats%d_class%d.txt',No_Feats_Selected,i);
    load(fname);
end
cd(eval('codedir'));

total_count = 0;

tic
for runs = 1:no_runs
    runs
    CVerror = zeros(cvfold,1);
    for i=1:cvfold
        i
        total_count = total_count+1;
        testindex = find(myindex(runs,:)==i);
        no_test_data=size(testindex,2);
        trainindex = find(myindex(runs,:)~=i);
        no_train_data=size(trainindex,2);
        
        store_prob_estimates=zeros(no_class,no_test_data);
        tmp_dec_values=zeros(no_class,no_train_data);
                
        for j=1:no_class
            traindata = data(trainindex,:);
            exp_trainlabel = traindata(:,no_cols);
            
            neg_index = find(exp_trainlabel ~= class_id(j));
            pos_index = find(exp_trainlabel == class_id(j));
            traindata(neg_index,no_cols) = -1;
            traindata(pos_index,no_cols) = 1;
            trainlabel = traindata(:,no_cols);
            traindata = traindata(:,1:no_cols-1);           
            
            fname=sprintf('feats%d_class%d',No_Feats_Selected,j);
            x=eval(fname);
            [selectindex] = x(:,total_count)';
                                
            newtraindata = traindata(:,selectindex);
            
            %SVM model training
            model = svmtrain(trainlabel,newtraindata,'-c 0.1 -t 0');
	    fname=sprintf('model_cls%d.mat',j);
            save(fname,'model');
                        
            tmp_dec_values(j,:) = duan_intermediate(trainlabel,newtraindata,3);
        end
        [wt_values] = duan_softmax(tmp_dec_values,exp_trainlabel);
        clear model;

                
        for j=1:no_class
            fname=sprintf('model_cls%d.mat',j);
            load(fname);
            
            testdata = data(testindex,:);
            exp_testlabel = testdata(:,no_cols);
            neg_index = find(exp_testlabel ~= class_id(j));
            pos_index = find(exp_testlabel == class_id(j));
            testdata(neg_index,no_cols) = -1;
            testdata(pos_index,no_cols) = 1;
            testlabel = testdata(:,no_cols);
            testdata = testdata(:,1:no_cols-1);
            
            fname=sprintf('feats%d_class%d',j);
            x=eval(fname);
            [selectindex] = x(:,total_count)';
            testdata = testdata(:,selectindex);
            [predicted_label, accuracy, dec_values] = svmpredict(testlabel,testdata,model);

            dec_values = model.Label(1)*dec_values';
            store_prob_estimates(j,:)=exp(wt_values(j,2)*dec_values+wt_values(j,1));
            clear model;
        end
        sum_prob_estimates = sum(store_prob_estimates);
        store_prob_estimates = store_prob_estimates./(ones(no_class,1)*sum_prob_estimates);
        if store_flag == 1
            store_prob(data_flag,3,store_prob_estimates,runs,i);
        end        
        [tmp,pred_label] = max(store_prob_estimates);
        CVerror(i) = size(find(pred_label-exp_testlabel'),2);
        CVerror(i) = (CVerror(i)/no_test_data)*100;
    end
    err(1,runs)=mean(CVerror);
end
system('del model_cls*.mat');
fname=sprintf('tmp_error_data%d_duan_store.mat',data_flag);
save(fname,'err');
mean(err)
toc
