function [err1] = ova_rfe_svm_main(data,myindex,labels,class_id,cvfold,no_runs,data_flag)
%% Description of file %%
%% This file takes following inputs and outputs error vector. The elements of error vector
%% corresponds to error obtained for different feature subsets. The Inputs are
%% data: sample by feature matrix
%% myindex: indices of pre-partitioned data.
%% labels: labels of each sample
%% class_id: a vector containing all classes
%% cvfold: no of folds of CVFOLd experiment
%% no_runs: No of multiple runs. For each run different partition of data will be used
%% data_flag: if you have multiple data files, you can give flag to automatically indicates data file. helpful for storing outputs of program

%% for different datasets, program expects separate directory and hence calling function to change to that particular directory
%% Each data-dependent directory supposed to contain a directory named "selected_feats"

%% Other essential variables explained
%% File No_Feats_Selected_%d.txt contains size of different feature subsets

codedir = sprintf('Class_Wise_Feature_Selection'); %Give whole path of this directory like 'D:/User/Codes/Class_Wise_Feature_Selection'
chng_directory(data_flag);
cd selected_feats;

fname = sprintf('No_Feats_Selected_%d.txt',data_flag);
No_Feats_Selected = load(fname);
err1 = zeros(size(No_Feats_Selected,1),2);

cd(eval('codedir'));
for i = 1:size(No_Feats_Selected,1)
    [err] = ova_rfe_svm(data,myindex,labels,class_id,cvfold,no_runs,data_flag,No_Feats_Selected(i),codedir);
    err1(i,:)=[No_Feats_Selected(i),err];
end

chng_directory(data_flag);
cd selected_feats;
fname = sprintf('Feats_vs_err%d.txt',data_flag);
dlmwrite(fname,err1,'delimiter','\t');
cd(eval('codedir'));
