function [tmp_dec_vals] = duan_intermediate(tlabels,tdata,cvfold)


%take trng data and corresponding labels
no_trdata=size(tdata,1);
%generate cvfold cv
[index]=generate_strat_kfold(tlabels,cvfold);

%using cv get dec_vals for all training data
%dec_vals : no_trngdata*1 matrix
tmp_dec_vals=zeros(1,no_trdata);
for i=1:cvfold
    tmp_trindex=find(index~=i);
    tmp_tstindex=find(index==i);
    tmp_trndata=tdata(tmp_trindex,:);
    tmp_trnlabel=tlabels(tmp_trindex,:);

    tmp_tstdata=tdata(tmp_tstindex,:);
    tmp_tstlabel=tlabels(tmp_tstindex,:);
    
    cd D:\Ashish\project_ntu\SVMtoolbox\libsvm-mat-2.82-2\libsvm-mat-2.82-2;
    model=svmtrain(tmp_trnlabel,tmp_trndata,'-c 0.1 -t 0');
    [predicted_label, accuracy, dec_values] = svmpredict(tmp_tstlabel,tmp_tstdata,model);
    tmp_dec_vals(tmp_tstindex)=model.Label(1)*dec_values';
end

