function [err] = ova_rfe_svm_isotonic(data,myindex,labels,class_id,cvfold,no_runs,data_flag,No_Feats_Selected,codedir)

%performs ova svm using selected features by ova rfe procedure. Features
%obtained by ova rfe are used w/o any unification ova svm
%was performed for final classification.

%Decision: probability decision values can be considered for final
%decision
%Probability Method: Isotonic
%Author: Ashish Anand

data=[data,labels'];
[no_rows,no_cols] = size(data) %no_rows = no_samples and no_cols = no_genes+1

no_class = size(class_id,2);
err = zeros(1,no_runs);
DS_flag = 0;
store_flag = 1;
chng_directory(data_flag);
cd selected_feats;
for i=1:no_class
    fname=sprintf('feats%d_class%d.txt',No_Feats_Selected,i);
    load(fname);
end
cd(eval('codedir'));

total_count = 0;
rand('state',0);
tic
for runs = 1:no_runs
    runs
    CVerror = zeros(cvfold,1);
    for i=1:cvfold
        i
        total_count = total_count+1;
        testindex = find(myindex(runs,:)==i);
        no_test_data=size(testindex,2);
        trainindex = find(myindex(runs,:)~=i);
        
        if DS_flag == 1
            store_accuracy = zeros(no_class,1);
        end
        store_prob_estimates=zeros(no_class,no_test_data);
        for j=1:no_class
            traindata = data(trainindex,:);
            exp_trainlabel = traindata(:,no_cols);
            testdata = data(testindex,:);
            exp_testlabel = testdata(:,no_cols);
            
            neg_index = find(exp_trainlabel ~= class_id(j));
            pos_index = find(exp_trainlabel == class_id(j));
            traindata(neg_index,no_cols) = -1;
            traindata(pos_index,no_cols) = 1;
            trainlabel = traindata(:,no_cols);
            traindata = traindata(:,1:no_cols-1);
                
            neg_index = find(exp_testlabel ~= class_id(j));
            pos_index = find(exp_testlabel == class_id(j));
            testdata(neg_index,no_cols) = -1;
            testdata(pos_index,no_cols) = 1;
            testlabel = testdata(:,no_cols);
            testdata = testdata(:,1:no_cols-1);
            
            fname=sprintf('feats%d_class%d',No_Feats_Selected,j);
            x=eval(fname);
            [selectindex] = x(:,total_count)';
                                
            newtraindata = traindata(:,selectindex);
            testdata = testdata(:,selectindex);
            
            %SVM model training
            model = svmtrain(trainlabel,newtraindata,'-c 1.0 -t 0');
            [predicted_label, accuracy, dec_values] = svmpredict(testlabel,testdata,model);
            if DS_flag == 1
                store_accuracy(j) = accuracy(1)/100;
            end

            %isotonic regression on training data to estimate prob
            [tmp_dec_vals,ghat] = isotonic_regn(newtraindata,trainlabel,3);
                        
            dec_values = model.Label(1)*(dec_values);

            %map dec_values into [0,1]
            tmp_a = max(abs(dec_values));
            dec_values = (dec_values+tmp_a)/(2*tmp_a);
                        
            %find interval where dec_values falls into tmp_dec_vals
            for k=1:no_test_data
                k;             
                xlow = max(find((tmp_dec_vals-dec_values(k)<=0)));
                if size(xlow,2)==0
                    store_prob_estimates(j,k)=ghat(1);
                    continue;
                end
                xup = min(find((tmp_dec_vals-dec_values(k)>0)));
                if size(xup,2)==0
                    store_prob_estimates(j,k)=ghat(size(newtraindata,1));
                    continue;
                end
                %Linear interpolation
                store_prob_estimates(j,k) = ghat(xlow) + (ghat(xup) - ghat(xlow))/(tmp_dec_vals(xup)-tmp_dec_vals(xlow)) * (dec_values(k) - tmp_dec_vals(xlow));
            end                        
        end
        %Normalize isotonic probability
        sum_prob_estimates = sum(store_prob_estimates);
        store_prob_estimates = store_prob_estimates./(ones(no_class,1)*sum_prob_estimates);        
        if store_flag == 1
            store_prob(data_flag,2,store_prob_estimates,runs,i);
        end
        
        if DS_flag ~= 1
            [tmp,pred_label] = max(store_prob_estimates);
        end
        CVerror(i) = size(find(pred_label-exp_testlabel'),2);
        CVerror(i) = (CVerror(i)/no_test_data)*100;
    end
    err(1,runs)=mean(CVerror);
end

fname=sprintf('tmp_error_data%d_isotonic_store.mat',data_flag);

save(fname,'err');
mean(err)
toc
