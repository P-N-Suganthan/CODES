function [wt_values] = duan_softmax(tmp_dec_values,exp_trainlabel)

[no_cls,no_trn_data] = size(tmp_dec_values);
% wt_values = ones(no_cls,2);
for i=1:no_cls
    wt_values(i,:)=[0.01,0.01];
end
prob_estimates = cal_prob(wt_values,tmp_dec_values);

tmp_C = 1.0;
[wt_values] = fwt_values(wt_values,tmp_dec_values,prob_estimates,exp_trainlabel,tmp_C);


function [prob_estimates] = cal_prob(wt_values,tmp_dec_values)
[no_cls,no_trn_data] = size(tmp_dec_values);
prob_estimates = zeros(no_cls,no_trn_data);
for i=1:no_cls
    prob_estimates(i,:) = exp(wt_values(i,2)*tmp_dec_values(i,:)+wt_values(i,1));
end
sum_prob_estimates = sum(prob_estimates);
prob_estimates = prob_estimates./(ones(no_cls,1)*sum_prob_estimates);

