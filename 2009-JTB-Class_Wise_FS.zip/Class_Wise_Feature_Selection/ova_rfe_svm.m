function [err] = ova_rfe_svm(data,myindex,labels,class_id,cvfold,no_runs,data_flag,No_Feats_Selected,codedir)

%performs ova svm using selected features by ova rfe procedure. Features
%obtained by ova rfe are used w/o any unification ova svm
%was performed for final classification.

%Decision: max or probability decision values can be considered for final
%decision
%Probability Method: Platt
%Author: Ashish Anand

data=[data,labels'];
[no_rows,no_cols] = size(data) %no_rows = no_samples and no_cols = no_genes+1

no_class = size(class_id,2);
err = zeros(1,no_runs);
store_flag = 0;
prob_flag = 1;

chng_directory(data_flag);
cd selected_feats;
for i=1:no_class
    fname=sprintf('feats%d_class%d.txt',No_Feats_Selected,i);
    load(fname);
end
cd(eval('codedir'));
total_count = 0;

tic
for runs = 1:no_runs
    runs
    CVerror = zeros(cvfold,1);
    for i=1:cvfold
        i
        total_count = total_count+1;
        testindex = find(myindex(runs,:)==i);
        no_test_data=size(testindex,2);
        trainindex = find(myindex(runs,:)~=i);
        
        if prob_flag == 1
            store_prob_estimates=zeros(no_class,no_test_data);
        else
            store_dec_values=zeros(no_class,no_test_data);
        end
                
        for j=1:no_class
            traindata = data(trainindex,:);
            exp_trainlabel = traindata(:,no_cols);
            testdata = data(testindex,:);
            exp_testlabel = testdata(:,no_cols);
            
            neg_index = find(exp_trainlabel ~= class_id(j));
            pos_index = find(exp_trainlabel == class_id(j));
            traindata(neg_index,no_cols) = -1;
            traindata(pos_index,no_cols) = 1;
            trainlabel = traindata(:,no_cols);
            traindata = traindata(:,1:no_cols-1);
                
            neg_index = find(exp_testlabel ~= class_id(j));
            pos_index = find(exp_testlabel == class_id(j));
            testdata(neg_index,no_cols) = -1;
            testdata(pos_index,no_cols) = 1;
            testlabel = testdata(:,no_cols);
            testdata = testdata(:,1:no_cols-1);
            
            fname=sprintf('feats%d_class%d',No_Feats_Selected,j);
            x=eval(fname);
            [selectindex] = x(total_count,:); %Features are stored in file row-wise
                                
            newtraindata = traindata(:,selectindex);
            testdata = testdata(:,selectindex);
            
            %SVM framework for classification
            if prob_flag == 1              
                model = svmtrain(trainlabel,newtraindata,'-c 0.1 -t 0 -b 1');
                index_pos = find(model.Label==1);
                [predicted_label, accuracy, prob_estimates] = svmpredict(testlabel,testdata, model, '-b 1');
                store_prob_estimates(j,:)= prob_estimates(:,index_pos)';
            else
                model = svmtrain(trainlabel,newtraindata,'-c 0.1 -t 0 -b 1');
                [predicted_label, accuracy, dec_values] = svmpredict(testlabel,testdata,model);
                store_dec_values(j,:)= model.Label(1)*dec_values';
            end        
        end % End of class loop

        %Normalize Platt probability
        if prob_flag == 1
            sum_prob_estimates = sum(store_prob_estimates);
            store_prob_estimates = store_prob_estimates./(ones(no_class,1)*sum_prob_estimates);
           
            [tmp,pred_label] = max(store_prob_estimates);
        else
            [tmp,pred_label] = max(store_dec_values);
        end
        CVerror(i) = size(find(pred_label-exp_testlabel'),2);
        CVerror(i) = (CVerror(i)/no_test_data)*100;
        CVerror(i)
    end % End of cvfold interation
    err(1,runs) = mean(CVerror);
end %End of runs interation

chng_directory(data_flag);
cd selected_feats;
fname=sprintf('tmp_error_data%d_feat%d.mat',data_flag,No_Feats_Selected);
save(fname,'err');
mean(err)
mean_acc=100-mean(err)
toc

