%%% This file is defining all the variables and loading all dataset dependent information %%%
%%%
%%% cvfold: Number of folds to estimate error.
%%%
%%% no_runs: Number of times you want to repeat cross-validation experiment. For each run program is expecting to have different partition of data.
%%%
%%% No_Feats_Selected: This variable is starting from all features, this many number of features will be selected. My program is storing intermediate
%%%                    feature subsets also. Each step of SVM-RFE removes 1% of features.
%%%
%%% data_flag: indicator for different datasets

%%% myindex: This variable stores different partition of samples for different runs. So if you want to run 10 independent runs of CVFOLD experiment, you
%%%          have to partition 10 times your data into CVFOLD. myindex should be no_runs Times no_samples matrix with ij entry indicates the fold number of
%%%          jth sample in ith run.

%%% Then it calls either of the three program to do following things

%%% ova_rfe: class-wise feature selection. stores all selected feature subsets in a file. File names are automatically prefixed with data_flag

%%% ova_rfe_svm: For a fixed feature subset, this perform multi-class classification using selected class-wise features 

%%% ova_rfe_svm_main: similar as ova_rfe_svm but the main difference is it calls ova_rfe_svm for all subsets of selected features

nntwarn off;
cvfold = 4;
no_runs = 100;
No_Feats_Selected=10;
data_flag=4; %GCM=1,11_tumors=2
codedir = sprintf('Class_Wise_Feature_Selection');
%data and corresponding classes
switch(data_flag)
    case 1 
        class_id=(1:14); %all classes
        load D:\Ashish\project_ntu\data\dataset\gcm_all_data.mat; %data
        labels=load('D:\Ashish\project_ntu\data\dataset\gcm_all_label.txt'); %labels
        myindex = load('D:\Ashish\project_ntu\data\dataset\gcm_all_resampling.txt'); %myindex
    case 2 %variables are same as defined in the case 1
	class_id=(1:11); 
        data=load('D:\Ashish\project_ntu\data\dataset\cancer11_data.txt');
        labels=load('D:\Ashish\project_ntu\data\dataset\cancer11_label.txt');
        myindex = load('D:\Ashish\project_ntu\data\dataset\cancer11_resampling.txt');
end

ova_rfe(data,myindex,labels,class_id,cvfold,no_runs,data_flag,No_Feats_Selected,codedir);
% [err] = ova_rfe_svm(data,myindex,labels,class_id,cvfold,no_runs,data_flag,No_Feats_Selected,codedir);
%[err1] = ova_rfe_svm_main(data,myindex,labels,class_id,cvfold,no_runs,data_flag,codedir);
%[err] = ova_rfe_svm_isotonic(data,myindex,labels,class_id,cvfold,no_runs,data_flag,No_Feats_Selected,codedir);
