The main instructions to use programs.

1. main.m file defines all data-dependent variable and call different functions to perform different tasks. All variables and functions are described in the
main.m file itself.

2. Store libsvm in the same directory or add path to where it is stored.

3. chnge_directory() is function which just changes the directory depending on the "data_flag" variable. For each data-dependent directory, create a directory called "selected_feats". In this sub-directory, all selected feature subsets are stored. 

USER will have to change this file and replace directory name according to his/her data. AND he/she must create a directory called "selected_feats" in the
data-dapendent directory.


4. first uncomment ova_rfe in main.m for performing class-wise feature selection and storing them.

5. then comment it and uncomment ova_rfe_svm or ova_rfe_svm_main depending on whether you want to calculate classification-error-rate for all feature subsets
or for a fixed feature subset.


variables are described here also.

>> cvfold: Number of folds to estimate error.

>> no_runs: Number of times you want to repeat cross-validation experiment. For each run program is expecting to have different partition of data.

>> No_Feats_Selected: This variable is starting from all features, this many number of features will be selected. My program is storing intermediate
                    feature subsets also. Each step of SVM-RFE removes 1% of features.

>> data_flag: indicator for different datasets

>> myindex: This variable stores different partition of samples for different runs. So if you want to run 10 independent runs of CVFOLD experiment, you
          have to partition 10 times your data into CVFOLD. myindex should be no_runs Times no_samples matrix with ij entry indicates the fold number of
          jth sample in ith run. For each fold "i", all samples with entry "i" in myindex matrix (for a particular run) will be taken as test sample and
	  rest will be taken as training sample. User only have to supply the myindex file (as given in example below) and program will automatically select 	       training and test samples.

>> Example of myindex file [2 rows of myindex file corresponding to MLL data]
  2  4  3  4  4  1  3  4  2  2  4  1  4  2  1  3  3  1  2  2  1  3  1  3  1  2  1  4  4  1  4  3  1  4  1  2  4  2  3  2  3  3  3  2  3  4  2  1  3  2  3  4  2  1  4  1  4  3  2  2  4  1  3  1  1  1  3  4  2  3  4  2
  2  3  4  1  1  1  1  3  1  4  4  2  2  2  3  1  4  4  3  2  3  3  2  4  3  4  4  2  1  3  4  2  2  4  2  1  4  3  1  2  1  3  3  1  1  2  3  2  1  2  3  4  4  1  3  2  3  4  3  1  3  2  1  4  4  1  4  2  4  1  3  2
	
>> codedir: USER must change this variable in "main.m" to indicate the directory where all .m files(e.g. ova_rfe.m, main.m etc) are stored.
	Give whole path of this directory like 'D:/User/Codes/Class_Wise_Feature_Selection'.


Then call either one of the three functions from "main.m" to do following things

ova_rfe: class-wise feature selection. stores all selected feature subsets in a file. File names are automatically prefixed with data_flag

ova_rfe_svm: For a fixed feature subset, this perform multi-class classification using selected class-wise features. It implements platt probability method.

ova_rfe_svm_isotonic: it implements isotonic regression method.

ova_rfe_svm_duan: it implements duan probabilistic method.

ova_rfe_svm_main: similar as ova_rfe_svm but the main difference is it calls ova_rfe_svm for all subsets of selected features


