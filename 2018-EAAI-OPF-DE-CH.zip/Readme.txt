MATLAB code for case studies of following paper is shared.
Three different methods SPDE, SFDE and ECHTDE are applied.
You need MATPOWER to run the program. All the best.
The author can be contacted at parthapr001@e.ntu.edu.sg

"Optimal power flow solutions using differential evolution algorithm integrated with effective 
constraint handling techniques." Engineering Applications of Artificial Intelligence 68 (2018): 81-100.