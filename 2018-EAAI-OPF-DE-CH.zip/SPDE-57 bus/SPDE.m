 % The Ensemble of SF and SP constraint handling methods
global  nfeval %VD PGS emission ploss qloss Lind_worst VI fuelcost fuelvlvcost
format long e;
tic
D = 33;
NP = 30;

Xmin = [30 40 30 100 30 100 0.95*ones(1,7) 0 0 0 0.9*ones(1,17)];
Xmax = [100 140 100 550 100 410 1.1*ones(1,7) 20 20 20 1.1*ones(1,17)];

%Max_FES = 5000; 
Max_Gen = 1400; maxrun = 30; gn = 4; % gn is the no. of constraints
feval = []; contvar = zeros(maxrun,D);
pop1 = zeros(2*NP,D); val1 = zeros(); g1 = zeros(NP,gn);
%pop2 = zeros(3*NP,D); val2 = zeros(); g2 = zeros(NP,gn);
Re = zeros(maxrun,3); W = zeros(Max_Gen,3); Splitfitness = zeros(Max_Gen,4);

Func = @pflow;

 for runs=1:maxrun 
 
   fprintf('Run %d',runs);
   nfeval=0;
   
 k = 1;%for k=1:2
    
   pop=repmat(Xmin,NP,1)+repmat((Xmax-Xmin),NP,1).*rand(NP,D);
   val = zeros(NP,1); g = zeros(NP,gn); %PPB
   for i=1:NP
      [val(i,1),g(i,:)] = Func(pop(i,:));
   end
   
   nfeval=nfeval+NP;
   
   eval(['pop' num2str(k) '=pop;']);
   eval(['val' num2str(k) '=val;']);
   eval(['g' num2str(k) '=g;']);
  
 %end 
 
 cons_max = [];
 rot=(0:1:NP-1); 

for gen=1:Max_Gen

  %for k=1:2
    pop=eval(['pop' num2str(k)]);
    val=eval(['val' num2str(k)]);
    g=eval(['g' num2str(k)]);
    
    FM_mui = rand(NP,D) < 0.9; 
    FM_mpo = FM_mui < 0.5;   
    ind=randperm(2);
    FVr_a1 = randperm(NP); 
    rt=rem(rot+ind(1),NP);
    FVr_a2 = FVr_a1(rt+1);
    rt=rem(rot+ind(2),NP);
    FVr_a3 = FVr_a2(rt+1);                
   
    newpop(1:NP,:)=pop(FVr_a1,:)+ 0.7*(pop(FVr_a2,:)-pop(FVr_a3,:));
    
    newpop = boundConstraint(newpop,pop,Xmax,Xmin);
    
    newpop = pop.*FM_mpo + newpop.*FM_mui;   
    newval = zeros(NP,1); newg = zeros(NP,gn); %PPB            
    for i=1:NP
      [newval(i,1),newg(i,:)] = Func(newpop(i,:));
    end             
    nfeval=nfeval+NP;
        
    eval(['newpop' num2str(k) '=newpop;']);
    eval(['newval' num2str(k) '=newval;']);
    eval(['newg' num2str(k) '=newg;']);
  %end
 
    %A1 = vertcat(pop1,newpop1);%,newpop2);
    %A2 = vertcat(pop2,newpop2,newpop1);
    A2 = vertcat(pop1,newpop1);
    %B1 = vertcat(val1,newval1);%,newval2);
    %B2 = vertcat(val2,newval2,newval1);
    B2 = vertcat(val1,newval1);
    %G1 = vertcat(g1,newg1);%,newg2);
    %G2 = vertcat(g2,newg2,newg1);
    G2 = vertcat(g1,newg1);

    %Self-Adaptive Penalty
    cons2=(G2>0).*G2; 
    cons_max=max([cons_max;cons2],[],1);
    nzindex2=find(cons_max~=0);
    
    if isempty(nzindex2)
        tcons2=zeros(size(A2,1),1);
    else

        tcons2=sum(cons2(:,nzindex2)./repmat(cons_max(:,nzindex2),size(A2,1),1),2)./sum(1./cons_max(:,nzindex2));
    end 
        f2=SaPenalty(B2,tcons2,A2);
    
    index2 = find(f2((NP+1):2*NP) <= f2(1:NP));
    pop1(index2,:) = A2(NP+index2,:);
    val1(index2,:) = B2(NP+index2,:);
    g1(index2,:) = G2(NP+index2,:); 
 
    %totalpop=[pop1;pop2];
    totalpop = pop1;
    %totalval=[val1;val2];
    totalval = val1;
    %totalg=[g1;g2];
    totalg = g1;
     
    cons5=(totalg>0).*totalg; 
    cons_max=max([cons_max;cons5],[],1);
    nzindex5=find(cons_max~=0);
    
    if isempty(nzindex5)
        %tcons5=zeros(2*NP,1);
        tcons5=zeros(NP,1);
    else
        %tcons5=sum(cons5(:,nzindex5)./repmat(cons_max(:,nzindex5),2*NP,1),2)./sum(1./cons_max(:,nzindex5));
        tcons5=sum(cons5(:,nzindex5)./repmat(cons_max(:,nzindex5),NP,1),2)./sum(1./cons_max(:,nzindex5));
    end 
                
  feasindex=find(tcons5==0);
  if isempty(feasindex)
    [gbesttcons,ibest]=min(tcons5);
    gbestval=totalval(ibest);
    gbest = totalpop(ibest,:);
    %W(gen,1)=gbestval; % for convergence plot
  else
    [gbestval,ibest]=min(totalval(feasindex));
    gbesttcons=tcons5(feasindex(ibest));
    gbest = totalpop(feasindex(ibest),:);
    %W(gen,1)=gbestval; % for convergence plot
  end
  
  if(gen == 1)
      thegbestval = gbestval;
      thegbesttcons = gbesttcons;
      thegbest = gbest;
  elseif((gbesttcons < thegbesttcons) || (gbesttcons==0 && thegbesttcons ==0 && gbestval < thegbestval))
      thegbestval = gbestval;
      thegbesttcons = gbesttcons;
      thegbest = gbest;
  end

    W(gen,1)=thegbestval;
    W(gen,2)=thegbesttcons;
    W(gen,3)=nfeval;
%     Func(gbest); %only for multi-objectives
%     Splitfitness(gen,1) = nfeval; %only for multi-objectives
%     Splitfitness(gen,2) = thegbestval; %only for multi-objectives
%     Splitfitness(gen,3) = fuelcost; %only for multi-objectives
%     Splitfitness(gen,4) = Lind_worst; %only for multi-objectives
%     
    
 if(isempty(feval) && thegbesttcons == 0)
        feval = nfeval;
 end
%  thegbestval
%  fuelcost
%  Lind_worst
 end

dlmwrite(strcat('W_',char(num2str(runs)),'.txt'),W,'precision','%0.4f','newline','pc');
Re(runs,1) = thegbestval;
Re(runs,2) = thegbesttcons;
Re(runs,3) = feval;

contvar(runs,:) = thegbest;
 end

dlmwrite('Result.txt',Re,'precision','%0.4f','newline','pc');
eval('save contvar');
toc

% % Print results
% [~,IND] = min(Re(:,1));
% disp('Control Variables');
% fprintf('\t %0.4f',contvar(IND,:));
% Func(contvar(IND,:));
% fprintf('\n Swing generator power %0.5f MW',PGS);
% fprintf('\n Cumulative voltage drop %0.5f p.u.',VD);
% fprintf('\n Emission %0.5f ton/h',emission);
% fprintf('\n Real power loss %0.4f MW',ploss);
% fprintf('\n Reative power loss %0.4f MVAr',qloss);
% fprintf('\n L-index %0.5f',Lind_worst);
% fprintf('\n Fuelcost %0.4f',fuelcost);
% fprintf('\n Fuelvlvcost %0.4f \n',fuelvlvcost);
% disp('Load bus voltage');
% fprintf('\t %0.5f',VI);