%function [f1,error] = pflow(x)

global VD PGS ploss Lind_worst VI fuelcost 
x = contvar;
% x = ...
%     [0 0.742 2.34 0.77 394.9 85.7 17.6 33.8 32.4 0.41 190.8 273.6 19.5 7.34 28.6 11.1 4.29 32.95 31.3 19.5 190.5 48.9 36.8 56.4 146.1 144.5 0 347.3 ...
%     344.9 3.7 2.9 2.83 20.5 18.23 0.24 423.53 0.39 4.1 497 2.1 0.3 0.53 0.37 227.3 37.8 0.62 7.26 34.5 13.86 35.64 29.2 1.41 0 ...
%     1.038 1.059 1.05 1.042 1.052 1.046 1.044 1.046 1.045 1.055 1.08 1.09 1.048 1.04 1.05 1.053 1.0515 1.04133 1.044 1.0498 1.063 1.0487 1.0489 	...
%     1.0487 1.0609 1.0615 1.057 1.0625 1.0734 1.086 1.061 1.0545 1.0583 1.0496 1.0471 1.0615 1.07 1.06 1.05 1.074 1.056 1.059 1.065 1.059 1.062 1.052 1.044 ...
%     1.041 1.033 1.037 1.042 1.03 1.051 1.057 24 14.5 18.7 22.3 14.1 24.6 13.5 12.6 7.94 4 7.93 13 7.89 6.64 ...
%     0.989 0.996 0.985 0.979 0.984 0.998 1.03 0.966 0.972];


Qbus = [5 34 37 44 45 46 48 74 79 82 83 105 107 110];
Tbranch = [8 32 36 51 93 95 102 107 127];

data = loadcase(case118);
data.gen(1:29,2) = x(1:29);
data.gen(31:54,2) = x(30:53);
data.gen(1:54,6) = x(54:107);
data.bus(Qbus,6) = x(108:121);
data.branch(Tbranch,9) = x(122:130);

mpopt = mpoption('pf.enforce_q_lims',0,'verbose',0,'out.all',1);
result = runpf(data,mpopt);

rpowgen = [x(1:29),result.gen(30,2),x(30:53)];
%rpowgen = [x(1:29),663.66,x(30:53)];
costcoeff = data.gencost(:,5:7);

fuelcost = sum(costcoeff(:,3)+costcoeff(:,2).*rpowgen'+costcoeff(:,1).*(rpowgen.^2)'); % be careful of sequence of coefficients in 'case' file

%Constraint finding 
Vmax = data.bus(:,12);
Vmin = data.bus(:,13);
genbus = data.gen(:,1);
pqbus = data.bus(:,1);
pqbus(genbus) = [];

Qmax = data.gen(:,4)/data.baseMVA;
Qmin = data.gen(:,5)/data.baseMVA;
QG = result.gen(:,3)/data.baseMVA;

PGSmax = data.gen(30,9);
PGSmin = data.gen(30,10);
PGS = result.gen(30,2);
PGSerr = (PGS<PGSmin)*(abs(PGSmin-PGS)/(PGSmax-PGSmin))+(PGS>PGSmax)*(abs(PGSmax-PGS)/(PGSmax-PGSmin));

blimit = data.branch(:,6);
Slimit = sqrt(result.branch(:,14).^2+result.branch(:,15).^2);
Serr = sum((Slimit>blimit).*abs(blimit-Slimit))/data.baseMVA;

% TO find the error in Qg of gen buses- inequality constraint
Qerr = sum((QG<Qmin).*(abs(Qmin-QG)./(Qmax-Qmin))+(QG>Qmax).*(abs(Qmax-QG)./(Qmax-Qmin)));
% TO find the error in V of load buses-inequality constraint
VI = result.bus(:,8);  %V of load buses-inequality constraint
VI_complx = VI.*(cosd(result.bus(:,9))+1i*sind(result.bus(:,9)));
vpvbus = VI_complx;
vpqbus = VI_complx;
vpvbus(pqbus) = [];
vpqbus(genbus) = [];
VI(genbus)=[];
Vmax(genbus)=[];
Vmin(genbus)=[];
VIerr = sum((VI<Vmin).*(abs(Vmin-VI)./(Vmax-Vmin))+(VI>Vmax).*(abs(Vmax-VI)./(Vmax-Vmin)));
VD = sum(abs(VI-1));

% BUS ADMITTANCE MATRICES
[Ybus,~,~] = makeYbus(data);
Ybuspq = Ybus;
Ybuspq(genbus,:) = [];
Ybuspvg = Ybuspq;
Ybuspq(:,genbus) = [];
Ybuspvg(:,pqbus) = [];
Fmat = -Ybuspq\Ybuspvg;

Lind = abs(1-(1./vpqbus).*(Fmat*vpvbus));
Lind_worst = max(Lind);

%OBJECTIVE FUNCTIONS

ploss = sum(result.branch(:,14)+result.branch(:,16));
error = [Qerr,VIerr,Serr,PGSerr];
f1 = fuelcost;
result = [x';f1;ploss;VD;PGS];

