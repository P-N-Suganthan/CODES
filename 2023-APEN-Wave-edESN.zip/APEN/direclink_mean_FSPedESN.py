#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 16 16:56:41 2022

@author: hello
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 15 16:14:59 2022

@author: hello
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Mar 14 11:00:16 2022

@author: ruobi
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Mar 13 12:21:36 2022

@author: hello
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar  7 15:57:30 2022

@author: hello
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Jul 14 13:17:07 2021

@author: ruobi
"""

import numpy as np
import numpy.matlib as npm
import scipy as sc
import random
import sys
from scipy.fft import fft, fftfreq
import pywt
from sklearn.linear_model import Ridge
'''
This is an example of the application of ESN wavelet forecasting 

Reference paper:
Echo state network based ensemble approach for wind power forecasting

----
'''
from itertools import product
import matplotlib.pyplot as plt
import ForecastLib
from sklearn import preprocessing
import numpy as np
import random
import pandas as pd
# from DeepESN 
from DeepESN2 import DeepESN
from utils import MSE, config_MG, load_MG, select_indexes
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
def compute_error(actuals,predictions,history=None):
    actuals=actuals.ravel()
    predictions=predictions.ravel()
    
    metric=ForecastLib.TsMetric()
    error={}
    error['RMSE']=metric.RMSE(actuals, predictions)
    # error['MAPE']=metric.MAPE(actuals,predictions)
    error['MAE']=metric.MAE(actuals,predictions)
    if history is not None:
        history=history.ravel()
        error['MASE']=metric.MASE(actuals,predictions,history)
        
    
    return error
def get_data(name):
    #file_name = 'C:\\Users\\lenovo\\Desktop\\FuzzyTimeSeries\\pyFTS-master\\pyFTS\\'+name+'.csv'
    file_name = name+'.csv'
    #D:\Multivarate paper program\monthly_data
    dat = pd.read_csv(file_name)
    dat = dat.fillna(method='ffill')
    return dat,dat.columns
class Struct(object): pass

# sistemare indici per IP in config_pianomidi, mettere da un'altra parte
# sistema selezione indici con transiente messi all'interno della rete

def config_load(rohs,lis,iss,IP_indexes):

    configs = Struct()
    
    configs.rhos = rohs # set spectral radius 0.9 for all recurrent layers
    configs.lis = lis # set li 1.0 for all recurrent layers
    configs.iss = iss # set insput scale 0.1 for all recurrent layers
    
    configs.IPconf = Struct()
    configs.IPconf.DeepIP = 0 # activate pre-train
    configs.IPconf.threshold = 0.001 # threshold for gradient descent in pre-train algorithm
    configs.IPconf.eta = 10**-3 # learning rate for IP rule
    configs.IPconf.mu = 0 # mean of target gaussian function
    configs.IPconf.sigma = 0.1 # std of target gaussian function
    configs.IPconf.Nepochs = 20 # maximum number of epochs
    configs.IPconf.indexes = IP_indexes # perform the pre-train on these indexes

#    configs.IPconf.Nepochs=10
    configs.reservoirConf = Struct()
    configs.reservoirConf.connectivity = 1 # connectivity of recurrent matrix
    
    configs.readout = Struct()
    configs.readout.trainMethod = 'Normal' # train with singular value decomposition (more accurate)
    # configs.readout.regularizations = 10.0**np.array(range(-16,-1,1))
    
    return configs 
def feature_importance(x,y,method='DT'):
    x=x.T
    y=y.T
    # scaler=preprocessing.MinMaxScaler()
    # x=scaler.fit_transform(x)
    if method=='DT':
        model=DecisionTreeRegressor(criterion='mse')
        model.fit(x,y)
        importance=model.feature_importances_
    elif method=='LR':
        model=LinearRegression()
        # print('fs',x.shape,y.shape)
        model.fit(x,y.ravel())
        importance=abs(model.coef_)
    return importance
def feature_ranking(score):
    """
    Rank features in descending order according to reliefF score, the higher the reliefF score, the more important the
    feature is
    """
    idx = np.argsort(score, 0)
    return idx[::-1]
def dESN_predict(hyper,data,train_idx,test_idx,layer,s,last_states=None):
    #idxs:list(train_idx) 
#    Nrs,Nls,regs,transients,spectral_radiuss,leaky_rates,input_scale
    np.random.seed(s+layer)
    Nu=data.inputs[0].shape[0]
#    print(hyper)
#    hyper=[hyper_]
#    if layer>1:
    Nr = hyper[0][0] # number of recurrent units
#    else:
#        Nr=hyper[0]
    Nl = layer # number of recurrent layers
    transient = hyper[0][2]
    
    reg=[]
    rohs=[]
    lis=[]
    iss=[]
    ratios=[]
    for h in hyper:
        reg.append( h[1])
        rohs.append(h[3])
        lis.append(h[4])
        iss.append(h[5])
        ratios.append(h[6])
    # configs=config_load(rohs,lis,iss,train_idx)
    # input_size=data.inputs[0].shape[1]
#    print(Nr,Nl)
    # deepESN = DeepESN(Nu, Nr, Nl, configs)
    inputs=data.inputs[0]
    train_targets = select_indexes(data.targets, train_idx, transient)
    # test_states = select_indexes(states, test_idx)
    if last_states is None:
        # print(Nl)
        
        for i in range(Nl):
            h=hyper[i]
            reg=[h[1]]
            rohs=[h[3]]
            lis=[h[4]]
            iss=[h[5]]
            ratio=h[6]
            configs=config_load(rohs,lis,iss,train_idx)
            if i==0:
                ESN = DeepESN(Nu, Nr, 1, configs)
            else:
                ESN=DeepESN(Nu,Nr,1,configs)
            states=ESN.computeGlobalState(inputs, initialStates=None)
            # print(states.shape,data.inputs[0].shape)
            states=np.concatenate((data.inputs[0],states),axis=0)
            train_states = select_indexes([states], train_idx, transient)
            train_targets = select_indexes(data.targets, train_idx, transient)
            test_states = select_indexes([states], test_idx)
            # print(train_states[0].shape,train_targets[0].shape)
            if ratio>0:
                importance=feature_importance(train_states[0], train_targets[0],method='LR')
                idx=feature_ranking(importance)[:-ratio]#[:int(ratio*states.shape[0])]      
                states=states[idx,:]
            inputs=states
            Nu=states.shape[0]
            
    else:
        h=hyper[-1]
        reg=[h[1]]
        rohs=[h[3]]
        lis=[h[4]]
        iss=[h[5]]
        ratio=h[6]
        configs=config_load(rohs,lis,iss,train_idx)
        # print('last',Nl)
        Nu=last_states[0].shape[0]
      
        ESN=DeepESN(Nu,Nr,1,configs)
        states=ESN.computeGlobalState(last_states[0], initialStates=None)
        # print(states.shape,data.inputs[0].shape)
        states=np.concatenate((data.inputs[0],states),axis=0)
        train_states = select_indexes([states], train_idx, transient)
        train_targets = select_indexes(data.targets, train_idx, transient)
        test_states = select_indexes([states], test_idx)
        # print(train_states[0].shape,train_targets[0].shape)
        if ratio>0:
            importance=feature_importance(train_states[0], train_targets[0],method='LR')
            idx=feature_ranking(importance)[:-ratio]#[:int(ratio*states.shape[0])]      
            states=states[idx,:]
            
    train_states = select_indexes([states], train_idx, transient)
    train_targets = select_indexes(data.targets, train_idx, transient)
    test_states = select_indexes([states], test_idx)      
    ESN.trainReadout(train_states, train_targets, reg[-1])
    test_outputs_norm = ESN.computeOutput(test_states).T
    # print(test_outputs_norm.shape)
    return test_outputs_norm,[states]
def layer_cross_validation(hypers,data,raw_data,train_idx,val_idx,layer,
                           scaler=None,tscaler=None,s=0,last_states=None,best_hypers=None):
    cvloss=[]
    np.random.seed(s)
    states=[]
#    last_states=None
    for hyper in hypers:
        #hyper,data,train_idx,test_idx,layer,s,last_states=None
        if layer>1:
#            print('a',layer,best_hypers)
            hyper_=best_hypers.copy()#
            hyper_.append(hyper)
#            print('aa',hyper_,best_hypers)
        else:
#            print(layer,best_hypers)
            hyper_=[hyper]
        test_outputs_norm,_=dESN_predict(hyper_,data,train_idx,val_idx,layer,
                                         s,last_states=last_states)
        test_outputs_norm=(test_outputs_norm+1)/2
        test_outputs=tscaler.inverse_transform(test_outputs_norm)
        actuals=raw_data[-len(val_idx):,0]
        # print(actuals.shape,test_outputs.shape)
        test_err=compute_error(actuals,test_outputs,None)
        cvloss.append(test_err['RMSE'])
        states.append(_)
#    print(len(hypers))
    best_hyper=hypers[cvloss.index(min(cvloss))]
    best_state=states[cvloss.index(min(cvloss))]
    return best_hyper,best_state
def cross_validation(hypers,data,raw_data,train_idx,val_idx,Nl,regs,input_scale,scaler=None,tscaler=None,s=0):
    best_hypers=[]
    np.random.seed(s)
    layer_s=None
    # Nrs=[2**i for i in np.arange(3,8)]
    # regs=[1e-9,1e-11,1e-13]
    # transients=[12,24]#[48,96]
    # spectral_radiuss=[np.random.uniform(0.9,0.999)]#[0.94]#[0.9,0.94]
    # leaky_rates=[1.0]#,.8,.7]
    # input_scale=[0.1,0.01,0.001]
    # ratios=[1,2,3]#[1,2,4]
    # deepESN_hypers=list(product(Nrs,regs,transients,
                                            # spectral_radiuss,leaky_rates,input_scale,ratios))
    for i in range(Nl):
        # print('cross validation for layer', i+1)
#        print(i,layer_s)
        layer=i+1
        print('cv layer',layer,'hyper numbers', len(hypers))
        layer_h,layer_s=layer_cross_validation(hypers,data,raw_data,train_idx,val_idx,layer,
                           scaler=scaler,tscaler=tscaler,s=s,last_states=layer_s,best_hypers=best_hypers.copy())
        transients=[layer_h[2]]
        Nrs=[layer_h[0]]
#        input_scale=[layer_h[-1]]
        spectral_radiuss=[np.random.uniform(0.9,0.999)]#[layer_h[3]]
        leaky_rates=[1.0]
#        print(transients,layer_h)
        if layer==1:
            hypers=list(product(Nrs,regs,transients,
                                            spectral_radiuss,leaky_rates,input_scale,ratios))        
        best_hypers.append(layer_h)
    return best_hypers
def wavelet_transform(x, J):
    N = len(x)
    C = np.zeros(shape=(J + 1, N))
    # W: wavelet coefficients
    W = np.zeros(shape=(J + 1, N))
    C[0, :] = x.copy()
    for j in range(1, J + 1):
        for k in range(1, N):
            C[j, k] = 1 / 2 * (C[j - 1, k] + C[j - 1, k - np.power(2, j - 1)])
            W[j, k] = C[j - 1][k] - C[j, k]

    W[0, :] = C[J, :]
    return W[:, :]
def ts_DWT(s, level):
    """
    :return: list [An, Dn, Dn-1, …, D2, D1]
    """
    wavelet, mode='db7','symmetric'
    coeffs = pywt.wavedec(s, wavelet, mode = mode, level=level)
    subseries = []
    for i in range(len(coeffs)):
        coeffs_i = [np.zeros_like(i) for i in coeffs]
        coeffs_i[i] = coeffs[i]
        s_i =  pywt.waverec(coeffs_i, wavelet, mode='symmetric')
        subseries.append(s_i)
    return subseries
def edESN_predict(hyper,data,train_idx,test_idx,s,global_reg,ms,metric):
    #idxs:list(train_idx) 
#    Nrs,Nls,regs,transients,spectral_radiuss,leaky_rates,input_scale
    np.random.seed(s)
    Nu=data.inputs[0].shape[0]
    Nr = hyper[0][0] # number of recurrent units
    transient = hyper[0][2]
    Nl = len(hyper) # number of recurrent layers
    
    inputs=data.inputs[0]
    outputs=np.zeros((len(test_idx),Nl+1))
    trainpres=np.zeros((len(train_idx)-transient,Nl+1))
    globaltrstates=[]
    globaltestates=[]
    for i in range(Nl):
        h=hyper[i]
        reg=[h[1]]
        rohs=[h[3]]
        lis=[h[4]]
        iss=[h[5]]
        ratio=h[6]
        configs=config_load(rohs,lis,iss,train_idx)
        # ratio=ratios[i]
        if i==0:
            ESN = DeepESN(Nu, Nr, 1, configs)
        else:
            ESN=DeepESN(Nu,Nr,1,configs)
        states=ESN.computeGlobalState(inputs, initialStates=None)
        # print(states.shape,data.inputs[0].shape)
        states=np.concatenate((data.inputs[0],states),axis=0)
        train_states = select_indexes([states], train_idx, transient)
        train_targets = select_indexes(data.targets, train_idx, transient)
        test_states = select_indexes([states], test_idx)
        # print(train_states[0].shape,train_targets[0].shape)
        if ratio>0:
            importance=feature_importance(train_states[0], train_targets[0],method='LR')
            idx=feature_ranking(importance)[:-ratio]#[:int(ratio*states.shape[0])]      
            states=states[idx,:]
        
        inputs=states
        Nu=states.shape[0]
    # print(transient,data.inputs[0].shape,states[0].shape,states[0][0,:2],states[0][0,-2:])              
        train_states = select_indexes([states], train_idx, transient)
        train_targets = select_indexes(data.targets, train_idx, transient)
        test_states = select_indexes([states], test_idx)
        globaltrstates.append(train_states[0])
        globaltestates.append(test_states[0])
    # for i in range(Nl):              
        ESN.trainReadout(train_states, train_targets, reg[0])
        test_outputs_norm = ESN.computeOutput(test_states).T
        train_outputs_norm = ESN.computeOutput(train_states).T
        outputs[:,i:i+1]=test_outputs_norm
        trainpres[:,i:i+1]=train_outputs_norm
    globaltrstates=np.concatenate(globaltrstates,axis=0)
    globaltestates=np.concatenate(globaltestates,axis=0)
    global_reg=Ridge(alpha=global_reg)
    # print(globaltrstates.shape,train_targets[0].shape)
    global_reg.fit(globaltrstates.T,train_targets[0].T)
    
    outputs[:,-1:]=global_reg.predict(globaltestates.T)
    trainpres[:,-1:]=global_reg.predict(globaltrstates.T)
    test_targets = select_indexes(data.targets, test_idx)
    dyn_p=[]
    # print(trainpres.shape,train_targets[0].shape)
    _error=abs(trainpres[-ms:,:]-train_targets[0][0,-ms])
    # print(_error.shape)
    _error=np.mean(_error,axis=0)
    if metric=='InvS':
    # w = np.exp(-_error) / np.sum(np.exp(-_error))
        w=np.power(_error,-2) / np.sum(np.power(_error,-2))
    elif metric=='Inv':
        
        w=np.power(_error,-1) / np.sum(np.power(_error,-1))
    elif metric=='Softmax':
        w=np.exp(-_error) / np.sum(np.exp(-_error))
    w=w/np.sum(w)
    dyn_p.append(w.dot(outputs[:1].T))
    for i in range(len(test_idx)-1):
        # print(w)
        # print(outputs.shape)
        # print(test_targets[0].shape,len(test_idx))
        _error=abs(outputs[i:i+1,:]-test_targets[0][0,i])
        if metric=='InvS':
        # w = np.exp(-_error) / np.sum(np.exp(-_error))
            w=np.power(_error,-2) / np.sum(np.power(_error,-2))
        elif metric=='Inv':
            
            w=np.power(_error,-1) / np.sum(np.power(_error,-1))
        elif metric=='Softmax':
            w=np.exp(-_error) / np.sum(np.exp(-_error))
        w=w/np.sum(w)
        dyn_p.append(w.dot(outputs[i+1:i+2,:].T))
#    test_outputs=scaler.inverse_transform(test_outputs_norm)
#    actuals=data_[-len(test_idx):]
#    test_err=compute_error(actuals,test_outputs,None)
    return np.mean(outputs,axis=1).reshape(-1,1),outputs
def ed_cross_validation(hypers,data,raw_data,train_idx,val_idx,Nl,scaler=None,tscaler=None,s=0):
    if len(hypers)!=Nl:
        print('Error')
        return None
    cvloss=[]
    for i in range(1,Nl):
        edhyper=hypers[:i+1]
        test_outputs_norm,_=edESN_predict(edhyper,data,train_idx,val_idx,s)
        test_outputs_norm=(test_outputs_norm+1)/2
        test_outputs=tscaler.inverse_transform(test_outputs_norm)
        actuals=raw_data[-len(val_idx):,0]
        test_err=compute_error(actuals,test_outputs,None)
        cvloss.append(test_err['RMSE'])
        print(i,test_err['RMSE'])
#    print(cvloss,cvloss.index(min(cvloss)))
    return hypers[:cvloss.index(min(cvloss))+2]
def edESNmain(deepESN_hypers,data,data_,train_idx,val_idx,test_idx,s,Nls,regs,
              input_scale,scaler,tscaler,test_l,val_l,train_l):
    starttime=datetime.datetime.now()
    best_hypers=cross_validation(deepESN_hypers[:],data,data_[:-len(test_idx)],
                                                  train_idx,val_idx,Nls[0],regs,
                                                  input_scale,scaler=scaler,
                                                  tscaler=tscaler,s=s)
    endtime=datetime.datetime.now()
    # print('optimization time',(endtime-starttime).seconds)
    # ed_best_hypers=ed_cross_validation(best_hypers,data,data_[:-test_l],
    #                     train_idx,val_idx,Nls[0],scaler=scaler,tscaler=tscaler,s=s)
    # print(ed_best_hypers)
    ed_best_hypers=best_hypers
    raw_data=data_[:-len(test_idx)]
    val_errs=[]
    mine=np.inf
    counter=0
    for global_reg in regs:
        for ms in [1]:
            for metric in ['Inv','InvS','Softmax'][:1]:
                val_outputs_norm_mea,_=edESN_predict(ed_best_hypers,data,train_idx,val_idx,s,
                                                     global_reg,ms,metric)
                val_outputs_norm_mea=(val_outputs_norm_mea+1)/2
                val_outputs_ea=tscaler.inverse_transform(val_outputs_norm_mea)
                actuals=raw_data[-len(val_idx):,0]
                # print(actuals.shape,test_outputs.shape)
                # print(actuals.shape,val_outputs_ea.shape)
                val_err=compute_error(actuals,val_outputs_ea,None)['RMSE']
                
                # val_errs.append(val_err)
                if mine < val_err or counter==0:
                    best_g_reg=global_reg
                    best_ms=ms
                    best_metric=metric
                    mine=val_err
                    counter=1
#    print('Test',ed_best_hypers)
    train_idx=range(train_l+val_l-step)
    scaler.fit(data_[:-test_l])
    tscaler.fit(data_[:-test_l,-1:])
    norm_data=2*np.transpose(scaler.transform(data_))-1
    data.inputs=[norm_data[:,:-step]]
    data.targets=[norm_data[-1:,step:]]
    test_outputs_norm_mea,all_p_norm=edESN_predict(ed_best_hypers,data,train_idx,test_idx,s,best_g_reg,best_ms,best_metric)
    test_outputs_norm_mea=(test_outputs_norm_mea+1)/2
    testtime=datetime.datetime.now()
    # print('test time',(testtime-endtime).seconds)
    test_outputs_ea=tscaler.inverse_transform(test_outputs_norm_mea)
    outputs=np.zeros((all_p_norm.shape))
    for i in range(all_p_norm.shape[1]):
        outputs[:,i:i+1]=tscaler.inverse_transform(all_p_norm[:,i:i+1])
    return val_outputs_ea,test_outputs_ea,outputs
def scale_cv(valp,actual):
    #k dif
    #k same
    e=[]
#    print(valp.shape)
    scale=int(valp.shape[1]/2)
    difp=valp[:,:scale]
    samep=valp[:,scale:]
    for i in range(scale):
        
        current_pre=np.concatenate([difp[:,i:i+1],samep[:,:i+1]],axis=1)
        p=np.sum(current_pre,axis=1)
#        print(current_pre.shape,p.shape,actual.shape)
        err=compute_error(p,actual)
#        print(err['RMSE'])
        e.append(err['RMSE'])
        
    return int(e.index(min(e)))

def dynamic_weight_calculation(window_difference, cand_pool, weighting_pool, metric, weighting_method, discount_factor):
        #window_difference is inpool_forecast x evaluation_window
        assert metric in ['MSE', 'MAE']
        if metric is 'MSE':
            try:
                _,tau = window_difference.shape
                discount = np.power(discount_factor, np.arange(1,tau+1))
                discounted_window_difference = np.multiply(window_difference, discount)
                column_error = np.mean(np.power(discounted_window_difference,2), axis=1)
            except:
                column_error = np.power(window_difference,2)
        if metric is 'MAE':
            try:
                _,tau = window_difference.shape
                discount = np.power(discount_factor, np.arange(1,tau+1))
                discounted_window_difference = np.multiply(window_difference, discount)
                column_error = np.mean(discounted_window_difference, axis=1)
            except:
                column_error = window_difference

        column_error = np.array([1e-5 if i<1e-12 else i for i in column_error])


        assert weighting_method in ['Softmax', 'Inverted', 'SquaredInverted']
        if weighting_method is 'Softmax':
            if np.sum(np.exp(-column_error)) <1e-10:
                column_error = column_error/np.min(column_error)
            column_weight_all = np.exp(-column_error) / np.sum(np.exp(-column_error))

        if weighting_method is 'Inverted':
            column_weight_all = np.power(column_error,-1) / np.sum(np.power(np.abs(column_error),-1))

        if weighting_method is 'SquaredInverted':

            column_weight_all = np.power(column_error,-2) / np.sum(np.power(column_error,-2))

        column_weight_all = np.nan_to_num(column_weight_all)
        idx = np.argpartition(column_weight_all, -weighting_pool)[-weighting_pool:]
        column_weight = np.array([column_weight_all[i] if i in idx else 0 for i in range(cand_pool)])
        column_weight = column_weight / np.sum(column_weight)

        assert np.linalg.norm(np.sum(column_weight) - 1.0) < 1e-3
        return column_weight           
                
                
if __name__ == "__main__":
    for step in [1,2,4]:
        for seeds in [1,2,3,4,5][::-1]:
            import warnings
            warnings.filterwarnings('ignore')
            import datetime
            Nrs=[2**i for i in range(3,9)]#np.arange(50,300,50)
            Nls=[5]#np.arange(2,12,4)
            regs=[1e-9,1e-11,1e-13]
            transients=[12,24]#[48,96]
            spectral_radiuss=[np.random.uniform(0.9,0.999)]#[0.94]#[0.9,0.94]
            leaky_rates=[1.0]#,.8,.7]
            input_scale=[0.1,0.01,0.001]
            ratios=[1,2,3]#[1,2,4]
            deepESN_hypers=list(product(Nrs,regs,transients,
                                                    spectral_radiuss,leaky_rates,input_scale,ratios))
            
            print('ewedesn deep',len(deepESN_hypers))
            for year in ['2019','2018','2017']:
                for station in ['46085h','46077h']:#['46083h','46080h','46076h','46001h']:
                    print(year+station)
                    features=[ 'WDIR', 'WSPD', 'GST','APD','WVHT']
                    data=pd.read_csv('Ocean energy/'+station+year+'.txt',delim_whitespace=True)
                    data=data[features]
                    # data.fillna(method='ffill')
                    var_name=data.columns
                    data=data.where(data!='99.0',np.nan)
                    data=data.where(data!='99.00',np.nan)
                    data=data.fillna(method='ffill')
                    while data.isnull().values.any():
                        data=data.fillna(method='ffill')
                    print(data.isnull().values.any())
                    # data[data['WVHT']=='99.00']=np.median(data['WVHT'].values[1:].astype(np.float))
                    # data[data['DPD']=='99.00']=np.median(data['DPD'].values[1:].astype(np.float))
                    # data[data['GST']=='99.00']=np.median(data['GST'].values[1:].astype(np.float))
                    # print(data.values[:])
                    data_=data['WVHT'].values[1:].astype(np.float).reshape(-1,1)
                    ml_data=pd.DataFrame(data[features].values[1:,:].astype(np.float),columns=features)
                    
                    ml_data['WVHT']=data_
                    scaler=preprocessing.MinMaxScaler()    
                    tscaler=   preprocessing.MinMaxScaler()           
                    val_l,test_l=int(0.2*data_.shape[0]),int(0.2*data_.shape[0])
                    train_l=data_.shape[0]-val_l-test_l
                    #cross validation 
                    scale_errs=[]  
                    test_pres=[]
                    for s in np.arange(seeds-1,seeds):
                        test_scale_pres=[]
                        np.random.seed(s)
        #                 level=4
        #                 sub_series = wavelet_transform(data_[:,-1].ravel(), level)  
        #                 same_series=sub_series[1:,:]
        #                 dif_series_=[]
        #                 for i in range(1,level+1):
        #                     dif_series_.append(wavelet_transform(data_.ravel(), i)[:1,:])
        #                 dif_series=np.concatenate(dif_series_,axis=0)
        # #                print(dif_series.shape,same_series.shape)
        #                 sub_pres=[]
        #                 total_series=np.concatenate([dif_series,same_series],axis=0)
                        starttime=datetime.datetime.now()
                        # print(total_series.shape)
                        # for k in range(total_series.shape[0]):
                            # print('Total', total_series.shape[0],'scales, cross validation for scale', k)
                        subs=ml_data.values#total_series[k].reshape(-1,1)
                        
                        data=Struct()
                        scaler.fit(subs[:-test_l-val_l,:])
                        # tscaler.fit(subs[:-test_l-val_l,-1:])
                        tscaler.fit(subs[:-test_l-val_l,-1:])
                        norm_data=2*np.transpose(scaler.transform(subs))-1
        #                        print(subs.shape,k)
                        data.inputs=[norm_data[:,:-step]]
                        data.targets=[norm_data[-1:,step:]]
                        train_idx=range(train_l-step)
                        val_idx=range(train_l-step,train_l+val_l-step)
                        test_idx=range(train_l+val_l-step,data_.shape[0]-step)
        #                        best_hyper,_=cross_validation(deepESN_hypers[:],data,data_[:-test_l],train_idx,val_idx,scaler=scaler,s=s)
                        val_scalepre,test_pre,all_testps=edESNmain(deepESN_hypers,data,subs,
                                                             train_idx,val_idx,test_idx,
                                                             s,Nls,regs,
                                                             input_scale,scaler,tscaler,test_l,val_l,train_l)
        #                    print(val_scalepre.shape)
                        # sub_pres.append(val_scalepre)
                        # test_scale_pres.append(test_scalepre)
                        endtime=datetime.datetime.now()
                        # print('cross validation time',(endtime-starttime).seconds)
                        # val_scalepres=np.concatenate(sub_pres,axis=1)
                        # best_scale=scale_cv(val_scalepres,data_[-test_l-val_l:-test_l])
                        # testp=np.concatenate(test_scale_pres,axis=1)
        #                print(testp.shape)
                        # difp=testp[:,:level]
                        # samep=testp[:,level:]
                       
        #                for i in range(level):
                        # current_pre=np.concatenate([difp[:,best_scale:best_scale+1],samep[:,:best_scale+1]],axis=1)
                        # test_pre=np.sum(current_pre,axis=1)
                        # print(best_scale+1)#,np.concatenate(test_scale_pres,axis=1)[:,:best_scale].shape)
        #                test_pre=np.sum(np.concatenate(test_scale_pres,axis=1)[:,:best_scale],axis=1)
                        actuals=data_[-test_l:]
        #                    history=data_[:-test_l]
                        # plt.figure()
                        # plt.plot(actuals,label='raw')
                        # plt.plot(test_pre,label='pre')
                        # plt.legend()
                        # plt.show()
                        test_err=compute_error(actuals,test_pre,None)
                        # scale_errs.append(test_err['RMSE'])
                        test_pres.append(test_pre.reshape(-1,1))
                    
                        print(year+station,test_err,seeds)
        #                print(best_hyper)
                    test_p=np.concatenate(test_pres,axis=1)
                    df=pd.DataFrame(test_p)
                    df.to_csv('Ocean energy/Results_sr_tanh/direclink_mean_FSPedESN'+str(Nls[0])+station+year+'step'+str(step)+'seed'+str(seeds)+'.csv')
                    # print(test_p.shape)