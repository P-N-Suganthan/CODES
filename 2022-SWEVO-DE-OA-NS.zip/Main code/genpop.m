function [pop,nghbr_idx] = genpop(dim,niche_size)
%dim = 10; Xmin = -100; Xmax = 100;
if dim == 5
   Q = 15;
elseif dim == 10
   Q = 25;
elseif dim == 15
   Q = 40;
elseif dim == 20
   Q = 50;
end
J = 2;
N = (Q^J - 1)/(Q-1);
Xmax = 100; Xmin = -100;

pop_init = oa_permut(Q,N,J);
pop_init(:,(dim+1):N) = [];

pop = pop_init.*((Xmax-Xmin)/(max(max(pop_init))-min(min(pop_init))))+Xmin;

leng = Q^J;
distanceMatrix = zeros(leng, leng);
nghbr_idx = zeros(leng,niche_size);

% Find neighboring indices

for i = 1:leng
    for j = i+1:leng
        A = pop(i,:); B = pop(j,:);
        distanceMatrix(i,j) = norm(A-B);
        distanceMatrix(j,i)=distanceMatrix(i,j);
    end
    [~,sindex] = sort(distanceMatrix(i,:));
    nghbr_idx(i,:) = sindex(1:niche_size);
end