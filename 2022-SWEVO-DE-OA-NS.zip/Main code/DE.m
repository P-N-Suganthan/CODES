function ui=DE(pop,bm,st,F,CR,n,NP)
jj = 1;
r1=round(rand*NP); r2=round(rand*NP); r3=round(rand*NP);%r4=round(rand*NP);r5=round(rand*NP);
while (r1==jj || r1==0),r1=ceil(rand*NP);end
while (r2==jj || r2==r1 || r2==0),r2=ceil(rand*NP);end
while (r3==jj || r3==r1 || r3==r2 || r3==0),r3=ceil(rand*NP);end
%while (r4==jj || r4==r1 || r4==r2 || r4==r3 || r4==0),r4=ceil(rand*NP);end
%while (r5==jj || r5==r1 || r5==r2 || r5==r3 || r5==r4 || r5==0),r5=ceil(rand*NP); end
pm1=pop(r1,1:n);
pm2=pop(r2,1:n);
pm3=pop(r3,1:n);
%pm4=pop(r4,1:n);
%pm5=pop(r5,1:n);
popold = pop(jj,:);

mui = rand(1,n) < CR;          % all random numbers < CR are 1, 0 otherwise
if mui==zeros(1,n),nn=randperm(n);mui(nn(1))=1;end
mpo = mui < 0.5;                % inverse mask to mui

if (st == 1)                % DE/rand/1   6
    ui = pm3 + F*(pm1 - pm2);       % differential variation
    ui = popold.*mpo + ui.*mui;     % crossover
% elseif (st == 4)                  % DE/rand/2           10
%     ui = pm5 + F*(pm1 - pm2 + pm3 - pm4);  % differential variation
%     ui = popold.*mpo + ui.*mui;            % crossover
% elseif (st == 5)                  % DE/current-to-best/1    8
%     ui = popold + F*(bm-popold) + F*(pm1 - pm2);        
%     ui = popold.*mpo + ui.*mui;     % crossover
% elseif (st == 6)                  % DE/current-to-best -ve/1    8
%     ui = popold - F*(bm-popold) - F*(pm1 - pm2);        
%     ui = popold.*mpo + ui.*mui;     % crossover
elseif (st == 2)                  % DE/best/1    8
    ui = bm + F*(pm1 - pm2);        
    ui = popold.*mpo + ui.*mui;     % crossover
elseif (st == 3)                   % DE/current-to-best/1    8
    ui = popold + F*(bm-popold) + F*(pm1 - pm2);        
    ui = popold.*mpo + ui.*mui;     % crossover
end

ui=(ui<-100).*(-100)+(ui>=-100).*ui;
ui=(ui>100).*100+(ui<=100).*ui;