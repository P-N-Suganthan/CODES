function [cr,sf] = gencrsf(mu_cr,mu_sf,pop_size)
%% for generating crossover rate
cr = normrnd(mu_cr, 0.1);
term_pos = mu_cr == -1;
cr(term_pos) = 0;
cr = min(cr, 1);
cr = max(cr, 0);
      
%% for generating scaling factor
sf = mu_sf + 0.1 * tan(pi * (rand(pop_size, 1) - 0.5));
pos = find(sf <= 0);

while ~ isempty(pos)
   sf(pos) = mu_sf(pos) + 0.1 * tan(pi * (rand(length(pos), 1) - 0.5));
   pos = find(sf <= 0);
end
      
sf = min(sf, 1);