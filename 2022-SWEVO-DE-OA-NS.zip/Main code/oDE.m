function [pop,fitness,pop_near_idx,archive_f,archive_Cr,hist_pos,bestold, bestx, current_eval, res_det] =...
        oDE(pop,fitness,pop_near_idx,archive_f,archive_Cr,hist_pos,bestold, bestx, memory_size,....
        xmin, xmax, current_eval, nich_size, res_det, Printing,I_fno)   
    
    %% state
    fhd = @cec20_func;
    [pop_size, problem_size] = size(pop);
    mem_rand_index1 = ceil(memory_size * rand(pop_size, 1));
    mu_sf1 = archive_f(mem_rand_index1)';
    mu_cr1 = archive_Cr(mem_rand_index1)';
    
%     %% for generating crossover rate and scale factor
    [cr1,sf1] = gencrsf(mu_cr1,mu_sf1,pop_size);

    children_fitness = zeros(pop_size,1);
    for jj = 1:pop_size
        pop_nghbr = pop(pop_near_idx(jj,:),:);
        fitness_nghbr = [pop_near_idx(jj,:)',fitness(pop_near_idx(jj,:),:)];
        [~,best_mem_idx] = sort(fitness_nghbr(:,2));
        nn = floor(rand*min(nich_size,0.01*pop_size))+1;
        bestmem = pop(fitness_nghbr(best_mem_idx(nn),1),:); % best member
        X1 = DE(pop_nghbr,bestmem,3,sf1(jj),cr1(jj),problem_size,nich_size);
%     %%Evaluate new member
        children_fitness(jj,:) = feval(fhd,X1',I_fno);
        current_eval = current_eval+1;
       if children_fitness(jj,:) < fitness(jj,:)
           pop(jj,:) = X1;
           fitness(jj,:) = children_fitness(jj,:);
       if fitness(jj,:)<= bestold; bestold = fitness(jj,:); bestx = pop(jj,:); end
       end
    end
        %%% I == 1: the parent is better; I == 2: the offspring is better
        dif = abs(fitness - children_fitness);
        I = (fitness > children_fitness);
        goodCR = cr1(I == 1);  
        goodF = sf1(I == 1);
        dif_val = dif(I == 1);
        num_success_params = numel(goodCR);

        if num_success_params > 0 
        sum_dif = sum(dif_val);
        dif_val = dif_val / sum_dif;
      	% for updating the memory of scaling factor 
        archive_f(hist_pos) = (dif_val' * (goodF .^ 2)) / (dif_val' * goodF);

        % for updating the memory of crossover rate
        if max(goodCR) == 0 || archive_Cr(hist_pos)  == -1
        archive_Cr(hist_pos)  = -1;
        else
        archive_Cr(hist_pos) = (dif_val' * (goodCR .^ 2)) / (dif_val' * goodCR);
        end

        hist_pos = hist_pos + 1;
        if hist_pos > memory_size;  hist_pos = 1; end
        end
        
%% check to print
if Printing==1
    res_det= [res_det repmat(bestold,1,pop_size)];
end

end  
 