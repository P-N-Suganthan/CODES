function [Par] = Introd_Par(I_fno)

%% loading

Par.n_opr = 4;  %% number of operators 
Par.n     = 10; %% number of decision vriables


if Par.n == 5
    Par.Max_FES = 50000;
elseif Par.n == 10
    Par.Max_FES = 1000000;
elseif Par.n == 15
    Par.Max_FES = 3000000;
else
    Par.Max_FES = 10000000;
end
opt= [100, 1100,700,1900,1700,1600,2100,2200,2400,2500];      %% define the optimal solution as shown in the TR
Par.xmin= -100*ones(1,Par.n);
Par.xmax= 100*ones(1,Par.n);

Par.f_optimal  = opt(I_fno);
Par.PopSize    = 6*Par.n.^2; 
Par.MinPopSize = 4;
%% printing the detailed results- this will increase the computational time
Par.Printing = 1; %% 1 to print; 0 otherwise
%% Niche Calculation....
Par.nich_size = 10;
[pop_fix,pop_near_idx_fix] = genpop(Par.n,Par.nich_size); % orthogonal array based initialization
Par.pop_fix = pop_fix;
Par.pop_near_idx_fix = pop_near_idx_fix;
Par.Max_FES1 = 0.2*Par.Max_FES;
end