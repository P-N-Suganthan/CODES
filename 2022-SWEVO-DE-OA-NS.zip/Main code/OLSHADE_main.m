function [outcome,com_time,SR,avgFE,res_det,bestx] = OLSHADE_main(run,I_fno)
tic;
Par  = Introd_Par(I_fno);
iter = 0;             %% current generation

%% =================== Define a random seed ===============================
%%-----Becase we ran experiments in parallel, we used "*run" to differentiate
%%-----among runs which started at the same time
RandStream.setGlobalStream (RandStream('mt19937ar','seed',rand*run));
%% Orthogonal Learning
pop = Par.pop_fix; pop_near_idx = Par.pop_near_idx_fix; 
pop_size = size(pop,1);
current_eval = 0; 
fitness = cec20_func(pop',I_fno)';
%% ====================== store the best ==================
[bestold, bes_l] = min(fitness);     bestx = pop(bes_l,:);
res_det = repmat(bestold,1,pop_size); %% used to record the convergence
%% ==================== to adapt CR and F =================================
hist_pos    = 1;
memory_size = 20*Par.n;
archive_f   = ones(1,memory_size).*0.2;
archive_Cr  = ones(1,memory_size).*0.2;
stop_con    = 0;
while stop_con == 0
    [pop,fitness,pop_near_idx,archive_f,archive_Cr,hist_pos,bestold, bestx, current_eval,res_det] =...
        oDE(pop,fitness,pop_near_idx,archive_f,archive_Cr,hist_pos,bestold, bestx, memory_size...
        , Par.xmin, Par.xmax, current_eval, Par.nich_size,res_det,Par.Printing,I_fno);
    if current_eval > Par.Max_FES1
        stop_con = 1;
    end
end

[fitness,idx] = sort(fitness);
pop = pop(idx, :);
%% define variable         
PS1 = Par.PopSize;          
%% LSHADE_MODE
EA = pop(1:PS1,:);    EA_obj = fitness(1:PS1);   
%% ===== prob. of each DE operator
probDE1 = 1./Par.n_opr .* ones(1,Par.n_opr);
%% ===================== archive data ====================================
arch_rate   = 2.6;
archive.NP  = arch_rate * PS1; % the maximum size of the archive
archive.pop = zeros(0, Par.n); % the solutions stored in te archive
archive.funvalues = zeros(0, 1); % the function value of the archived solutions
%% ==================== to adapt CR and F =================================
hist_pos=1;
memory_size=20*Par.n;
archive_f= ones(1,memory_size).*0.2;
archive_Cr= ones(1,memory_size).*0.2;
%%
stop_con = 0; avgFE = Par.Max_FES; InitPop = PS1; thrshold = 1e-08;
indx = 0; 
%% main loop
while stop_con == 0
    iter  = iter+1;
    %% ======================Applying LSHADE_MODE ============================
            %% =============================== Linear Reduction of PS1 ===================================================
            UpdPopSize = round((((Par.MinPopSize - InitPop) / Par.Max_FES) * (current_eval)) + InitPop);
            if PS1 > UpdPopSize
                reduction_ind_num = PS1 - UpdPopSize;
                if PS1 - reduction_ind_num <  Par.MinPopSize
                    reduction_ind_num = PS1 - Par.MinPopSize;
                end
                %% remove the worst ind.
                for r = 1 : reduction_ind_num
                    vv=PS1;
                    EA(vv,:)=[];
                    EA_obj(vv)=[];
                    PS1 = PS1 - 1;
                end
                archive.NP = round(arch_rate * PS1);
                if size(archive.pop, 1) > archive.NP
                    rndpos = randperm(size(archive.pop, 1));
                    rndpos = rndpos(1 : archive.NP);
                    archive.pop = archive.pop(rndpos, :);
                end
            end
%             [EA, EA_obj,probDE1,bestold,bestx,archive,hist_pos,memory_size, archive_f,archive_Cr,current_eval,res_det] = ...
%                 LSHADE_MODE( EA,EA_obj,probDE1,bestold,bestx,archive,hist_pos,memory_size, archive_f,archive_Cr,....
%                 Par.xmin, Par.xmax,  Par.n,  PS1,  current_eval, I_fno,res_det,Par.Printing);
            [EA, EA_obj,probDE1,bestold,bestx,archive,hist_pos,memory_size, archive_f,archive_Cr,current_eval,res_det] = ...
                LSHADE_MODE_greedy( EA,EA_obj,probDE1,bestold,bestx,archive,hist_pos,memory_size, archive_f,archive_Cr,....
                Par.xmin, Par.xmax,  Par.n,  PS1,  current_eval, I_fno,res_det,Par.Printing,Par.Max_FES);
    %% ====================== stopping criterion check ====================
    if (current_eval>=Par.Max_FES-4*UpdPopSize)
        stop_con=1;
        avgFE=current_eval;
    end
    if ( (abs (Par.f_optimal - bestold)<= thrshold))
        stop_con=1;
        bestold=Par.f_optimal;
        avgFE=current_eval;
    end
    
    %% =============================== Print ==============================
    %          fprintf('current_eval\t %d fitness\t %d \n', current_eval, abs(Par.f_optimal-bestold));
    if stop_con
        com_time= toc;%cputime-start_time;
        fprintf('run\t %d, fitness\t %d, avg.FFE\t %d\t %d\n', run, abs(Par.f_optimal-bestold),avgFE,indx(1));
        outcome= abs(Par.f_optimal-bestold);
        if (min (bestx))< -100 || (max(bestx))>100 %% make sure  that the best solution is feasible
            fprintf('in problem: %d, there is  a violation',I_fno);
        end
        SR= (outcome==0);
    end
end
end
