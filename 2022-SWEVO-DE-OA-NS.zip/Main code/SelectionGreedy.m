function I = SelectionGreedy(x,ui,fitx,fitx_new)
N = size(x,1);
n = max(ceil(N*0.1),1);
if rand < 1
I1 = false(N,1);
for i = 1:N
%     temp_dist = pdist2(ui(i,:),x);
%     [~,ind] = sort(temp_dist);
    ind = randperm(N,n);
    neigh = fitx(ind(1:n));
    imp   = sum(neigh > fitx_new(i))/n;
    if imp > 0.25
        I1(i) = true;
    end
end
else
    I1 = true(N,1);
end
I2 = (fitx_new < fitx);
I = I1 & I2;
end