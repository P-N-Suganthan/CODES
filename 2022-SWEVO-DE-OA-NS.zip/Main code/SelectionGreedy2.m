function I = SelectionGreedy2(x,ui,fitx,fitx_new)
N = size(x,1);
n = max(ceil(N*0.15),1);
fit = [fitx;fitx_new];
if rand < 1
I1 = false(N,1);
for i = 1:N
    ind = randperm(2*N,n);
    neigh = fit(ind(1:n));
    imp   = sum(neigh > fitx_new(i))/n;
    if imp > 0.25
        I1(i) = true;
    end
end
else
    I1 = true(N,1);
end
I2 = (fitx_new < fitx);
I = I1 & I2;
end