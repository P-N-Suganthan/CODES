
function [f,X,g] = DE_new(GEN,NP,L,H,Run_No,func_num,D,ConvDisp)

% *************************** %
% ** ALGORITHM�S VARIABLES ** %
% *************************** %
X = zeros(D,1); % trial vector
Pop = zeros(D,NP); % population
Fit = zeros(1,NP); % fitness of the population
iBest = 1; % index of the best solution
r = zeros(3,1); % randomly selected indices
% *********************** %
% ** CREATE POPULATION ** %
% *********************** %
% initialize random number generator
rand('state',sum(100*clock));
for j = 1:NP % initialize each individual
    Pop(:,j) = L + (H-L)*rand(D,1); % within b.constraints
    Fit(1,j)= benchmark_func(Pop(:,j)',func_num);
end
[mn iBest]=min(Fit);
[mx iWorst]=max(Fit);
% ****************** %
% ** OPTIMIZATION ** %
% ****************** %
fall=[];
theoritical=0;



format long
CCC=0;

%CR=0.05; % WITH F1,F2,F3 ONLY
stgCount=zeros(1,NP);
CRNewFlags=zeros(1,NP);
CRRatio=zeros(1,11);
Cr_Values=[];;
for g = 1:GEN % for each generation



    for j = 1:NP % for each individual
                
         
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%5   CR USING MAXIMUM RATIO RULE WITH ALL PROBLEMS EXCEPT
        %%%%%%%F1,F2, F3 CR IS SET 0.05
        
        
        if(func_num==1||func_num==2||func_num==3)
            A=[0.05];
            CR = 0.05;
            
        elseif (CRNewFlags(j)==0 && (g)<=((1/10)*GEN))
            
            if((g)<=(1/60)*GEN)
                A=[0.05 0.1];
                
            elseif((g)<=((1/40)*GEN) && (g)>((1/60)*GEN))
                
                A=[0.05 0.1 0.2 0.3];
                
            elseif((g)<=((1/30)*GEN) && (g)>((1/40)*GEN))
                A=[0.05 0.1 0.2 0.3 0.4 0.5];
                
            elseif((g)<=((1/24)*GEN) && (g)>((1/30)*GEN))
                
                A=[0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.7];
                
            elseif((g)<=((1/20)*GEN) && (g)>((1/24)*GEN))
                A=[0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9];
            elseif((g)<=((1/10)*GEN) && (g)>((1/20)*GEN))
                A=[0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 0.95];
            end
            
            paraIndex= floor (rand(1,1)*length(A))+1;
            CR=A(paraIndex);
            
        elseif(CRNewFlags(j)==0 && (g)>((1/10)*GEN))
            stgCount(j)=stgCount(j)+1;
            
            if stgCount(j)==(20+1)
                stgCount(j)=0;
                A=[0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 0.95];
                paraIndex= floor (rand(1,1)*length(A))+1;
                CR=A(paraIndex);
                
            end
        else
            Ali_cr_new=A(find(CRRatio==max(CRRatio)));
            CR=Ali_cr_new(1);
            % CR=CRs(j);
        end
        
        

        CRs(j)=CR;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                f=Fit;

                [srt in]=sort(f,'ascend');
                AA=[in(1) in(2) in(3)  in(4) in(5)   ];
                BB=[  in(46) in(47) in(48) in(49) in(50) ];
                CC=[in(6) in(7) in(8) in(9) in(10) in(11) in(12) in(13) in(14) in(15) in(16) in(17) in(18) in(19) in(20) in(21) in(22) in(23) in(24) in(25) in(26) in(27) in(28) in(29) in(30) in(31) in(32) in(33) in(34) in(35) in(36) in(37) in(38) in(39) in(40) in(41) in(42) in(43) in(44) in(45)];
        if rand()<=(0.5)
            % choose three random individuals from population,
            % mutually different and different from j

                paraIndex=floor (rand(1,1)*length(AA))+1;
                paraIndex1=floor (rand(1,1)*length(BB))+1;
                paraIndex2=floor (rand(1,1)*length(CC))+1;
                r(1) = AA(paraIndex);
                r(2) = BB(paraIndex1);
                r(3) = CC(paraIndex2);
                F=rand;
                FF=rand;
                Rnd = floor(rand()*D) + 1;
                for i = 1:D
                    if ( rand()<CR ) || ( Rnd==i )
                          X(i)=Pop(i,r(3))+F*(Pop(i,r(1))-(Pop(i,r(3))))+FF*((Pop(i,r(3)))-(Pop(i,r(2))));
                    else
                        X(i) = Pop(i,j);
                    end
                end
        else
            r(1) = floor(rand()* NP) + 1;
            while r(1)==j
                r(1) = floor(rand()* NP) + 1;
            end
            r(2) = floor(rand()* NP) + 1;
            while (r(2)==r(1))||(r(2)==j)
                r(2) = floor(rand()* NP) + 1;
            end
            r(3) = floor(rand()* NP) + 1;
            while (r(3)==r(2))||(r(3)==r(1))||(r(3)==j)
                r(3) = floor(rand()* NP) + 1;
            end
            
            if rand<=0.5
                F=rand;
            else
                F=-1*rand;
            end
            Rnd = floor(rand()*D) + 1;
            for i = 1:D
                if ( rand()<CR ) || ( Rnd==i )
                    X(i) = Pop(i,r(3)) + F * (Pop(i,r(1)) - Pop(i,r(2)));

                else
                    X(i) = Pop(i,j);
                end
            end

        end



        % end%end of All cases
        % verify boundary constraints
        % verify boundary constraints
        for i = 1:D
            if (X(i)<L)||(X(i)>H)
                X(i) = L + (H-L)*rand();
            end
        end
        % select the best individual
        % between trial and current ones
        % calculate fitness of trial individual

        %f= benchmark_func(X',functname);
        f= benchmark_func(X',func_num);
       
        % if trial is better or equal than current
        if f <= Fit(j)
            
             CRRatio(find(A==CRs(j)))=CRRatio(find(A==CRs(j)))+1-(min(f,Fit(j))/max(f,Fit(j)));
           
            Pop(:,j) = X; % replace current by trial
            Fit(j) = f ;
            % if trial is better than the best
            if f <= Fit(iBest)
                iBest = j ; % update the best�s index
            end
            CRNewFlags(j)=1;
        else
            CRNewFlags(j)=0;

        end;%end of else Fit---

    end
    
    Cr_Values=[Cr_Values;CRs'];

%     [mx iWorst]=max(Fit);
%     f = Fit(iBest);
%     % fprintf('%e\n',Fit(iBest));
%     fprintf('g:%e\t:FitiBest%e\tCR:%e\n',g,Fit(iBest),CR);

    
        CCC=CCC+1;
    if(CCC==500)
        CCC=0;
        fprintf('g:%e\t:FitiBest%e\n',g,Fit(iBest));
    end
    
    
    fall=[fall,f];


end
%fprintf('CR:%e\n',CR);
% if ConvDisp
%
%      figure
%     plot(NP*(1:length(fall)),log10(fall-theoritical));
%
% end


if (ConvDisp)
    dim1=NP*(1:length(fall));
    dim2=log10(fall-theoritical);
    file_name=sprintf('Figures\\Figure_Problem#%s_Run#%s',int2str(func_num),int2str(Run_No));
    save(file_name,'dim1','dim2');
end



% ************* %
% ** RESULTS ** %
% ************* %
f = Fit(iBest);
X = Pop(:,iBest);
