function_number = 30;
count = 1;
while count <= function_number
    
    file_name = sprintf('shift_data_%s',int2str(count));
    fileall_name = sprintf('%s.txt',file_name);
    data = [];
    data = importdata(fileall_name);
    [row(1,count), col(1,count)] = size(data);
%     zeros_elements = zeros(row, col);
%     save_path = sprintf('C:\\Users\\PC\\Desktop\\�½��ļ���\\%s', fileall_name);
%     save sprintf('H:\\MZQ\\�����ļ�\\comparision\\Fifteen algorithms\\Test-Algorithm\\EO\\EO_comparison\\input_data\\%s', fileall_name)  -ascii  zeros_elements
%    save 'C:\Users\PC\Desktop\�½��ļ���\shift_data_30.txt' -ascii zeros_elements 
%     fid=fopen(save_path,'wt');
%     fprintf(fid,'%8.6f\t',zeros_elements);
%     fclose(fid);
    count = count + 1;
%     break;
end