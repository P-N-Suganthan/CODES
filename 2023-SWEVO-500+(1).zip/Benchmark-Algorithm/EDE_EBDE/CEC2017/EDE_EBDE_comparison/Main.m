% clc;
% clear all;

% function Main(L_Rate,EDE_best_rate,memory_size)
clc;
clear all;
L_Rate =  0.7763;
EDE_best_rate =  0.1264;
memory_size = 6;
format long;
format compact;
% L_Rate= 0.80;

Alg_Name='EB_EBDE';

SPACMA_Cluster = parcluster('local');
SPACMA_Cluster.NumWorkers = 5;  % define how many processors to use

Run_No=1;           %%% independent runing times
fhd=@cec17_func;    %%% call for CEC2017 benchmark suite

% problem_size = 30;    %% problem dimension 
    
% max_nfes = 10000 * problem_size;
rand('seed', sum(100 * clock));
val_2_reach = 10^(-8);
max_region = 100.0;
min_region = -100.0;
% lu = [min_region * ones(1, problem_size); max_region * ones(1, problem_size)];

num_problems = 30; 
Final_results = zeros(6,5);    %% to save the final results ����ķֱ���min(outcome),max(outcome),median(outcome), mean(outcome),std(outcome)
Outcomes = zeros(6, Run_No);

base_folder = 'C:\Users\84133mma\OneDrive - Erasmus University Rotterdam\Desktop\Fifteen algorithms\Benchmark-Algorithm\EDE_EBDE\CEC2017\EDE_EBDE_comparison';


 for problem_size = [10, 30, 50]

%     fprintf('Running %s algorithm on D= %d\n',Alg_Name, problem_size)
max_nfes = 10000 * problem_size;
lu = [min_region * ones(1, problem_size); max_region * ones(1, problem_size)];
iteration_result = [];
Final_results =[];
Outcomes = []; 

    for func_num = 1 : num_problems
        func = func_num;
        optimum = func * 100.0;
%         fprintf('\n-------------------------------------------------------\n')
%         fprintf('Function = %d, Dimension size = %d\n', func, problem_size)
        dimYfunvals=[];
        buffer = [];
        
        for run_id = 1 : Run_No

            %%  parameter settings for L-SHADE
%             EDE_best_rate = 0.10;      %%% this parameter can tuning in irace [0.1,0.5]
%             memory_size = 5;           %%% This parameter can tuning [4,6]
            pop_size = 18 * problem_size;
            max_pop_size = pop_size;
            min_pop_size = 4.0;

            memory_sf = 0.5 .* ones(memory_size, 1);
            memory_cr = 0.5 .* ones(memory_size, 1);
            memory_pos = 1;
            
            run_funcvals = [];
            
            %% Initialize the main population
            popold = repmat(lu(1, :), pop_size, 1) + rand(pop_size, problem_size) .* (repmat(lu(2, :) - lu(1, :), pop_size, 1));
            pop = popold; % the old population becomes the current population
            
            fitness = feval(fhd,pop',func);
            fitness = fitness';
            
            nfes = pop_size;
            bsf_fit_var = min(fitness);
            run_funcvals = [run_funcvals;bsf_fit_var];
            
            %%  parameter settings for Hybridization
            First_calss_percentage=0.5;
            
            memory_1st_class_percentage = First_calss_percentage.* ones(memory_size, 1); % Class#1 probability for Hybridization
            
            Hybridization_flag=1; % Indicator flag if we need to Activate Hybridization

            %% main loop
            iter = 0;
            while nfes < max_nfes

                pop = popold; % the old population becomes the current population
                [temp_fit, sorted_index] = sort(fitness, 'ascend');

                mem_rand_index = ceil(memory_size * rand(pop_size, 1));
                mu_sf = memory_sf(mem_rand_index);
                mu_cr = memory_cr(mem_rand_index);
                mem_rand_ratio = rand(pop_size, 1);
                
                %% for generating Hybridization Class probability
                Class_Select_Index=(memory_1st_class_percentage(mem_rand_index)>=mem_rand_ratio);
                if(Hybridization_flag==0)
                    Class_Select_Index=or(Class_Select_Index,~Class_Select_Index);%All will be in class#1
                end

                %% for generating crossover rate
                cr = normrnd(mu_cr, 0.1);
                term_pos = find(mu_cr == -1);
                cr(term_pos) = 0;
                cr = min(cr, 1);
                cr = max(cr, 0);
                
                %% for generating scaling factor
                sf = mu_sf + 0.1 * tan(pi * (rand(pop_size, 1) - 0.5));
                pos = find(sf <= 0);
                
                while ~ isempty(pos)
                    sf(pos) = mu_sf(pos) + 0.1 * tan(pi * (rand(length(pos), 1) - 0.5));
                    pos = find(sf <= 0);
                end
                
                sf = min(sf, 1);
                
                % Here we select top EDE_best_rate% (10%) to be inculded in EDE 
                EDEpNP = max(round(EDE_best_rate * pop_size), 2); %% choose at least two best solutions
                EDErandindex = ceil(rand(1, pop_size) .* EDEpNP); %% select from [1, 2, 3, ..., pNP]
                EDErandindex = max(1, EDErandindex); %% to avoid the problem that rand = 0 and thus ceil(rand) = 0
                EDEpestind=sorted_index(EDErandindex);


                R = Gen_R(pop_size,2);
                R(:,1)=[];
                R=[R EDEpestind];
                fr=fitness(R);
                [~,I] = sort(fr,2);
                R_S=[];
                for i=1:pop_size
                    R_S(i,:)=R(i,I(i,:));
                end
                rb=R_S(:,1);
                rm=R_S(:,2);
                rw=R_S(:,3);
                
                R2 = Gen_R(pop_size,3);
                R2(:,1)=[];
                fr=fitness(R2);
                [~,I] = sort(fr,2);
                R_S=[];
                for i=1:pop_size
                    R_S(i,:)=R2(i,I(i,:));
                end
                rb2=R_S(:,1);
                rm2=R_S(:,2);
                rw2=R_S(:,3);
                
%                 vi = pop + sf(:, ones(1, problem_size)) .* (pop(rb, :) - pop + pop(rm, :) - pop(rw, :));
                
                vi=[];
                if(sum(Class_Select_Index)~=0)
                    vi(Class_Select_Index,:) = pop(Class_Select_Index,:) + sf(Class_Select_Index, ones(1, problem_size)) .* (pop(rb2(Class_Select_Index), :) - pop(Class_Select_Index,:) + pop(rm2(Class_Select_Index), :) - pop(rw2(Class_Select_Index), :));
                end
                
                if(sum(~Class_Select_Index)~=0)
                    Sel=~Class_Select_Index;
                    vi(Sel,:) = pop(Sel,:) + sf(Sel, ones(1, problem_size)) .* (pop(rb(Sel), :) - pop(Sel,:) + pop(rm(Sel), :) - pop(rw(Sel), :));
                end
                                
                vi = boundConstraint(vi, pop, lu);
                
                mask = rand(pop_size, problem_size) > cr(:, ones(1, problem_size)); % mask is used to indicate which elements of ui comes from the parent
                rows = (1 : pop_size)'; cols = floor(rand(pop_size, 1) * problem_size)+1; % choose one position where the element of ui doesn't come from the parent
                jrand = sub2ind([pop_size problem_size], rows, cols); mask(jrand) = false;
                ui = vi; ui(mask) = pop(mask);
                
                children_fitness = feval(fhd, ui', func);
                children_fitness = children_fitness';
                
                for i = 1 : pop_size
                    nfes = nfes + 1;
                    if children_fitness(i) < bsf_fit_var
                        bsf_fit_var = children_fitness(i);
                    end
                    if nfes > max_nfes; break; end
                end
                
                dif = abs(fitness - children_fitness);
                
                %% I == 1: the parent is better; I == 2: the offspring is better
                Child_is_better_index = (fitness > children_fitness);
                goodCR = cr(Child_is_better_index == 1);
                goodF = sf(Child_is_better_index == 1);
                dif_val = dif(Child_is_better_index == 1);
                dif_val_Class_1 = dif(and(Child_is_better_index,Class_Select_Index) == 1);
                dif_val_Class_2 = dif(and(Child_is_better_index,~Class_Select_Index) == 1);

                [fitness, Child_is_better_index] = min([fitness, children_fitness], [], 2);
                
                popold = pop;
                popold(Child_is_better_index == 2, :) = ui(Child_is_better_index == 2, :);
                
                num_success_params = numel(goodCR);
                
                if num_success_params > 0
                    sum_dif = sum(dif_val);
                    dif_val = dif_val / sum_dif;
                    
                    %% for updating the memory of scaling factor
                    memory_sf(memory_pos) = (dif_val' * (goodF .^ 2)) / (dif_val' * goodF);
                    
                    %% for updating the memory of crossover rate
                    if max(goodCR) == 0 || memory_cr(memory_pos)  == -1
                        memory_cr(memory_pos)  = -1;
                    else
                        memory_cr(memory_pos) = (dif_val' * (goodCR .^ 2)) / (dif_val' * goodCR);
                    end
                    
                    if (Hybridization_flag==1)% if the Hybridization is activated
                        memory_1st_class_percentage(memory_pos) = memory_1st_class_percentage(memory_pos)*L_Rate+ (1-L_Rate)*(sum(dif_val_Class_1) / (sum(dif_val_Class_1) + sum(dif_val_Class_2)));
                        memory_1st_class_percentage(memory_pos)=min(memory_1st_class_percentage(memory_pos),0.8);
                        memory_1st_class_percentage(memory_pos)=max(memory_1st_class_percentage(memory_pos),0.2);
                    end

                    memory_pos = memory_pos + 1;
                    if memory_pos > memory_size;  memory_pos = 1; end
                end
                
                %% for resizing the population size
                plan_pop_size = round((((min_pop_size - max_pop_size) / max_nfes) * nfes) + max_pop_size);
                
                if pop_size > plan_pop_size
                    reduction_ind_num = pop_size - plan_pop_size;
                    if pop_size - reduction_ind_num <  min_pop_size; reduction_ind_num = pop_size - min_pop_size;end
                    
                    pop_size = pop_size - reduction_ind_num;
                    for r = 1 : reduction_ind_num
                        [valBest, indBest] = sort(fitness, 'ascend');
                        worst_ind = indBest(end);
                        popold(worst_ind,:) = [];
                        pop(worst_ind,:) = [];
                        fitness(worst_ind,:) = [];
                        Child_is_better_index(worst_ind,:) = [];
                    end
                    
                    
                end
                 iter =  iter + 1;
                run_funcvals = [run_funcvals;bsf_fit_var];
                %%%% �����������
                Convergence_curve(iter) = run_funcvals(end);
            end
            run_funcvals = abs(run_funcvals - optimum);
            
            funcval_out(run_id) = run_funcvals(end);
            
%             fprintf('%d th run, best-so-far error value = %1.8e\n', run_id , funcval_out(run_id))
            
            run_funcvals=run_funcvals';
         
            buffer(run_id)= min(run_funcvals);
        end %% end 1 run
    iteration_result(func_num, :) = Convergence_curve;
    outcome = buffer;
    Final_results(func_num, : ) = [min(outcome),max(outcome),median(outcome), mean(outcome),std(outcome)];
    Outcomes(func_num, : ) = outcome;
    func_num
    end
    
folder_name = [num2str(problem_size) 'D_Convergence_curve.txt'];
address = [base_folder '\' folder_name];
save(address,'iteration_result', '-ascii'); 

 end
    
%     save 'H:\MZQ\�����ļ�\comparision\Fifteen algorithms\Benchmark-Algorithm\EDE_EBDE\CEC2017\EDE_EBDE_comparison\30D_shiOutcome_TenTimes.txt' -ascii  Outcomes
%     save 'H:\MZQ\�����ļ�\comparision\Fifteen algorithms\Benchmark-Algorithm\EDE_EBDE\CEC2017\EDE_EBDE_comparison\30D_shiFinal_result.txt' -ascii  Final_results

    
%    Best = best'; 
%   save 'C:\Users\admin\Desktop\comparision\Fifteen algorithms\Benchmark-Algorithm\EDE_EBDE\CEC2017\CEC2017_tuning\parameters_test\auto_Result.txt' -ascii Best  
%   fid=fopen('Result.txt','wt');
%   fprintf(fid,'%g\n',best);
%   fclose(fid);   
%         fprintf('min_funvals:\t%e\n',min(funcval_out));
%         fprintf('median_funvals:\t%e\n',median(funcval_out));
%         fprintf('mean_funvals:\t%e\n',mean(funcval_out));
%         fprintf('max_funvals:\t%e\n',max(funcval_out));
%         fprintf('std_funvals:\t%e\n',std(funcval_out));
%         
%         median_figure=find(funcval_out== median(funcval_out));
%         dimYfunvals=dimYfunvals(median_figure(1),:);
%         dimX=1:length(dimYfunvals);
%         file_name=sprintf('Figures\\%s_CEC2017_Problem#%s_problem_size#%s',Alg_Name,int2str(func),int2str(problem_size));
%         save(file_name,'dimX','dimYfunvals');
%         
%         file_name=sprintf('Results\\%s_CEC2017_Problem#%s_problem_size#%s',Alg_Name,int2str(func),int2str(problem_size));
%         save(file_name,'funcval_out');
        
%     end %% end 1 function run
    




