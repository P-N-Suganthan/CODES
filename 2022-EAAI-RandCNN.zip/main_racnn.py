from __future__ import print_function
import random
import numpy as np
from pathlib import Path
from models.racnn import RACNN, train, evaluate
from utils import read_dataset, get_cv_splits, transfer_labels, RawDataset, spatial_encoder
from torch.optim.lr_scheduler import ReduceLROnPlateau
from torch.utils.data import DataLoader
import torch.optim as optim
import torch
import os, errno
import time

data_path = '../DEAP'

# Fixed Hyperparameters
nhid = 32
opt = 'Adam'
lr = 1e-3
clip = -1.
batch_size = 100
epochs = 150
cuda = True
gpu_id = 0
n_folds = 10
seed = 2345

random.seed(seed)
np.random.seed(seed)
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)
# torch.set_deterministic(True)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False

print('Loading data...')
for s in range(29, 33):
    fname = '{:s}/s{:02d}.dat'.format(data_path, s)
    X, Y = read_dataset(fname, s)
    X = spatial_encoder(X)


    indices = get_cv_splits(X, Y, n_folds, stratified=True, seed=seed)
    prob = ['valance', 'arousal']

    for p in range(2):
        Y_prob = Y[:, p]
        Y_prob, nums_class = transfer_labels(Y_prob)
        # Y_prob = to_categorical(Y_prob, nums_class)

        X = torch.Tensor(X)
        Y_prob = torch.Tensor(Y_prob)

        for fold in range(n_folds):
            train_x = X[indices[2*fold], :, :]
            train_y = Y_prob[indices[2*fold]]
            test_x = X[indices[2*fold + 1], :, :]
            test_y = Y_prob[indices[2*fold + 1]]
            train_set = RawDataset(train_x, train_y)
            test_set = RawDataset(test_x, test_y)

            # Initialize results file
            r_fname_out = Path('Experiments/Results/Result_RACNN_Sub' + str(s) + '_' + prob[p] + str(fold) + '.csv')
            m_fname_out = Path('Experiments/Models/Model_RACNN_Sub' + str(s) + '_' + prob[p] + str(fold) + '.pt')

            j = 1
            while r_fname_out.is_file():
                r_fname_out = Path('Experiments/Results/Result_RACNN_Sub' + str(s) + '_'  + prob[p] + str(fold) + '_' + str(j) + '.csv')
                m_fname_out = Path('Experiments/Models/Model_RACNN_Sub' + str(s) + '_' + prob[p] + str(fold) + '_' + str(j) + '.pt')
                j += 1

            try:
                os.makedirs('Experiments/Results')
            except OSError as e:
                if e.errno != errno.EEXIST:
                    raise

            try:
                os.makedirs('Experiments/Models')
            except OSError as e:
                if e.errno != errno.EEXIST:
                    raise

            with open(str(r_fname_out), 'a') as f:
                print('Epoch,Train_Loss,Train_Acc,Epoch Time,Test_Loss,Test_Acc', file=f)

            classes = train_set.Y.unique()
            nb_classes = len(train_set.Y.unique())  # Number of Classes
            class_dist = torch.zeros((nb_classes,), dtype=torch.int)

            for i in range(nb_classes):
                class_dist[i] = sum(test_set.Y == classes[i])

            in_ch = train_set.X.shape[1]
            in_len = train_set.X.shape[2]
            out_ch = nb_classes

            model = RACNN(h=9, w=9, n_class=out_ch).float()

            if cuda:
                model.cuda(gpu_id)
                train_set.cuda(gpu_id)
                test_set.cuda(gpu_id)

            train_loader = DataLoader(train_set, batch_size=batch_size, shuffle=True)
            test_loader = DataLoader(test_set, batch_size=batch_size)

            optimizer = getattr(optim, opt)(model.parameters(), lr=lr)
            scheduler = ReduceLROnPlateau(optimizer, factor=0.5, patience=50, min_lr=1e-4)

            torch.save(model.state_dict(), m_fname_out)
            best_loss = 1e10
            best_epoch = 0
            train_time = 0

            for ep in range(1, epochs + 1):
                epoch_start_time = time.time()
                train(model, train_loader, clip, optimizer, scheduler)
                epoch_end_time = time.time()
                epoch_time = epoch_end_time - epoch_start_time
                train_time += epoch_time

                train_acc, train_loss, _ = evaluate(model, train_loader)

                print('Train Epoch: {:2d}\tLearning rate: {:.5f}\tLoss: {:.6f}\tAcc: {:.3f}%\tTime: {:.3f}'.
                      format(ep, optimizer.param_groups[0]['lr'], train_loss, train_acc * 100, epoch_time))

                with open(r_fname_out, 'a') as f:
                    print('{:d},{:.3f},{:.5f},{:.3f},'.format(ep, train_loss, train_acc, epoch_time), end='', file=f)

                test_acc, test_loss, _ = evaluate(model, test_loader)

                print('Test set: Acc: {:.3f}%\n'.format(test_acc * 100))

                with open(r_fname_out, 'a') as f:
                    print('{:.3f},{:.5f},'.format(test_loss, test_acc), end='\n', file=f)

                if train_loss < best_loss:
                    torch.save(model.state_dict(), m_fname_out)
                    best_epoch = ep
                    best_loss = train_loss

            model.load_state_dict(torch.load(m_fname_out))
            if cuda:
                model.to(gpu_id)
            train_acc, train_loss, train_perf = evaluate(model, train_loader)

            print('\nBest Epoch: {:2d}\tLoss: {:.6f}\tTrain Acc: {:.3f}%\tTrain Time: {:3f}'
                  .format(best_epoch, train_loss, train_acc * 100, train_time))

            test_start_time = time.time()
            test_acc, test_loss, test_perf = evaluate(model, test_loader)
            test_end_time = time.time()
            test_time = test_end_time - test_start_time

            print('Test Acc: {:.3f}%\tTest Time: {:3f}\n'.format(test_acc * 100, test_time))

            fpath = Path('Experiments/Results/Results_RACNN.csv')

            if not fpath.is_file():
                with open(fpath, 'w') as f:
                    print('Subject,Type,Fold,Train Acc,Train F-Score,Train AUC,Train Keppa,Test Acc,Test F-Score,'
                          'Test AUC,Test Keppa,nhid,opt,lr,clip,batch_size,epochs,Train Time,Test Time'
                          , file=f)

            with open(fpath, 'a') as f:
                print('{:d},{:s},{:d},{:.3f},{:.3f},{:.3f},{:.3f},{:.3f},{:.3f},{:.3f},{:.3f},{:d},{:s},{:.5f},{:.2f},'
                      '{:d},{:d},{:.3f},{:.3f}'
                      .format(s, prob[p], fold, train_acc, train_perf['f score'], train_perf['auc'],
                              train_perf['keppa'], test_acc, test_perf['f score'], test_perf['auc'],
                              test_perf['keppa'], nhid, opt, lr, clip, batch_size, epochs,
                              train_time, test_time), file=f)
