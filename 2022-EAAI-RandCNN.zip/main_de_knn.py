from __future__ import print_function
import random
import numpy as np
from pathlib import Path
from models.DE_PSD import DE_PSD
from sklearn import neighbors
from utils import read_dataset, get_cv_splits
import torch
import os, errno
import time
import pandas as pd


data_path = '../DEAP'

# Fixed Hyperparameters
stft_para = {
    'stftn': 128,
    'fStart': [4,7,12,30],
    'fEnd': [8, 13, 32,51],
    'window': 1,
    'fs': 128
}

nhid = 100
opt = 'Adam'
lr = 1e-3
clip = -1.
batch_size = 100
epochs = 150
cuda = False
gpu_id = 0
n_folds = 10
seed = 2345

random.seed(seed)
np.random.seed(seed)
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)
# torch.set_deterministic(True)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False

print('Loading data...')
for s in range(1, 33):
    fname = '{:s}/s{:02d}.dat'.format(data_path, s)
    X, Y = read_dataset(fname, s)

    X_new = []
    for i in range(X.shape[0]):
        _, X_newT = DE_PSD(X[i], stft_para)
        X_new += [X_newT.reshape(-1)]

    X_new = np.array(X_new)

    indices = get_cv_splits(X, Y, n_folds, stratified=True, seed=seed)
    prob = ['valance', 'arousal']

    for p in range(2):
        Y_prob = Y[:, p]

        for fold in range(n_folds):
            train_x = X_new[indices[2*fold], :]
            train_y = Y_prob[indices[2*fold]]
            test_x = X_new[indices[2*fold + 1], :]
            test_y = Y_prob[indices[2*fold + 1]]

            try:
                os.makedirs('Experiments/Results')
            except OSError as e:
                if e.errno != errno.EEXIST:
                    raise

            clf = neighbors.KNeighborsClassifier(5)
            start_time = time.time()
            clf.fit(train_x, train_y)
            end_time = time.time()
            train_time = end_time - start_time

            train_y1 = clf.predict(train_x)
            train_acc = sum(train_y1 == train_y)/len(train_y)

            print('Train Acc: {:.3f}%\tTrain Time: {:.3f}'
                  .format(train_acc * 100, train_time))

            start_time = time.time()
            test_y1 = clf.predict(test_x)
            end_time = time.time()
            test_time = end_time - start_time
            test_acc = sum(test_y1 == test_y) / len(test_y)

            print('Test Acc: {:.3f}%\tTest Time:{:.3f}\n'.format(test_acc * 100, test_time))

            fpath = Path('Experiments/Results/Results_DE_KNN.csv')

            if not fpath.is_file():
                with open(fpath, 'w') as f:
                    print('Subject,Type,Fold,Train Acc,Test Acc,Train Time,Test Time'
                          , file=f)

            with open(fpath, 'a') as f:
                print('{:d},{:s},{:d},{:.3f},{:.3f},{:.3f},{:.3f}'
                      .format(s, prob[p], fold, train_acc, test_acc, train_time, test_time), file=f)

acc=pd.read_csv('Experiments/Results/Results_DE_KNN.csv')
a1=acc[acc['Type']=='valance']['Test Acc'].mean()
a2=acc[acc['Type']=='arousal']['Test Acc'].mean()
print(a1,a2)