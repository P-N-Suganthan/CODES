import numpy as np
import torch
from time import time
import torch.nn as nn
from torch.nn import Conv1d, ReLU, Flatten


class RandConv(nn.Module):
    def __init__(self, num_channels, num_kernels, kernel_size=4):
        super(RandConv, self).__init__()
        self.conv = Conv1d(num_channels, num_kernels, kernel_size)
        self.relu = ReLU(inplace=True)
        self.flat = Flatten()

    def forward(self, X):
        c1 = self.conv(X)
        c1 = self.relu(c1)
        features = self.flat(c1)
        
        return features
    

class Softmax(object):
    def __init__(self, Lambda=0.1):
        self.weights = []
        self.Lambda = Lambda
        
    def train(self, inputs, labels, weights=None):
        if weights is None:
            weights = 1

        else:
            if len(weights.shape) == 1:
                weights = weights.reshape(-1, 1)

        target = weights*labels
        if inputs.shape[1] < inputs.shape[0]:
            self.weights = np.linalg.pinv(inputs.T.dot(inputs) + self.Lambda *
                                          np.eye(inputs.shape[1])).dot(inputs.T).dot(target)

        else:
            self.weights = inputs.T.dot(np.linalg.pinv(inputs.dot(inputs.T) + self.Lambda *
                                                       np.eye(inputs.shape[0]))).dot(target)

    def predict(self, inputs):
        scores = inputs.dot(self.weights)
        scores = scores - scores.max(axis=1, keepdims=True)
        e_scores = np.exp(scores)
        probs = e_scores/e_scores.sum(axis=1, keepdims=True)
        return probs
    
        
class CNNLayer(object):
    def __init__(self, nK=10, Lambda=0.1, kernel_size=4,cuda=True, gpu_id=0):
        self.nK = nK
        self.Lambda = Lambda
        self.conv = None
        self.fea_mean = None
        self.fea_std = None
        self.softmax = Softmax(Lambda=self.Lambda)
        self.cuda = cuda
        self.gpu_id = gpu_id
        self.kernel_size = kernel_size

    def train(self, x, y, weights=None):
        start_time = time()

        n_in = x.shape[2]
        x_mean = np.expand_dims(x.mean(1), 1)
        x_std = np.expand_dims(x.std(1), 1)
        x_std = np.maximum(x_std, 1e-9)
        x = np.divide(x - x_mean, x_std)
        X = torch.from_numpy(x).permute(0, 2, 1)
        self.conv = RandConv(n_in, self.nK, int(self.kernel_size)).double()
        if self.cuda:
            X = X.cuda(self.gpu_id)
            self.conv = self.conv.cuda(self.gpu_id)

        featuresT = self.conv(X)
        features = featuresT.cpu().detach().numpy()

        self.fea_mean = features.mean(axis=0)
        self.fea_std = features.std(axis=0)
        self.fea_std = np.maximum(self.fea_std, 0.00001)
        features = np.divide(features - self.fea_mean, self.fea_std)
        features = np.concatenate((features, np.ones((features.shape[0], 1))), axis=1)
        self.softmax.train(inputs=features, labels=y, weights=weights)

        end_time = time()
        train_time = end_time - start_time
        out = self.softmax.predict(features)

        return x, features, out, train_time

    def predict(self, x):
        start_time = time()

        x_mean = np.expand_dims(x.mean(1), 1)
        x_std = np.expand_dims(x.std(1), 1)
        x_std = np.maximum(x_std, 1e-9)
        x = np.divide(x - x_mean, x_std)
        X = torch.from_numpy(x).permute(0, 2, 1)
        if self.cuda:
            X = X.cuda(self.gpu_id)
            self.conv = self.conv.cuda(self.gpu_id)

        featuresT = self.conv(X)
        features = featuresT.cpu().detach().numpy()

        features = np.divide(features - self.fea_mean, self.fea_std)
        features = np.concatenate((features, np.ones((features.shape[0], 1))), axis=1)
        out = self.softmax.predict(features)

        end_time = time()
        test_time = end_time - start_time

        return x, features, out, test_time
