import torch
import torch.nn as nn
import numpy as np
from sklearn.metrics import roc_auc_score


class TemporalFeatureExtractor(nn.Module):
    def __init__(self, nhid=32):
        super(TemporalFeatureExtractor, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv3d(1, nhid, kernel_size=(1, 1, 5), stride=(1, 1, 2), padding=(0, 0, 2), padding_mode='zeros'),
            nn.BatchNorm3d(nhid),
            nn.ReLU(inplace=True),
            nn.Conv3d(nhid, nhid, kernel_size=(1, 1, 3), stride=(1, 1, 2), padding=(0, 0, 1), padding_mode='zeros'),
            nn.BatchNorm3d(nhid),
            nn.ReLU(inplace=True),
            nn.Conv3d(nhid, nhid, kernel_size=(1, 1, 3), stride=(1, 1, 2), padding=(0, 0, 1), padding_mode='zeros'),
            nn.BatchNorm3d(nhid),
            nn.ReLU(inplace=True),
            nn.Conv3d(nhid, nhid, kernel_size=(1, 1, 16), stride=(1, 1, 2)),
            nn.BatchNorm3d(nhid),
            nn.ReLU(inplace=True)
        )

    def forward(self, input):
        out = self.conv(input)
        return out.flatten(3)


class RegionalFeatureExtractor(nn.Module):
    def __init__(self, in_ch=32, nhid=32):
        super(RegionalFeatureExtractor, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_ch, nhid, kernel_size=(3, 3), stride=(1, 1), padding='same', padding_mode='zeros'),
            nn.BatchNorm2d(nhid),
            nn.ReLU(inplace=True),
            nn.Conv2d(nhid, nhid, kernel_size=(3, 3), stride=(1, 1), padding='same', padding_mode='zeros'),
            nn.BatchNorm2d(nhid),
            nn.ReLU(inplace=True)
        )

    def forward(self, input):
        out = self.conv(input)
        return out


class AsymmetricFeatureExtractor(nn.Module):
    def __init__(self, in_ch=32, nhid=64):
        super(AsymmetricFeatureExtractor, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_ch, nhid, kernel_size=(1, 1), stride=(1, 1), padding='same', padding_mode='zeros'),
            nn.BatchNorm2d(nhid),
            nn.ReLU(inplace=True),
        )

    def forward(self, input):
        width = input.shape[2]
        new_width = int(width/2)
        left = input[:, :, :new_width]
        input = torch.flip(input, dims=(2,))
        right = input[:, :, :new_width]
        input = left - right
        out = self.conv(input)
        return out


class Classifier(nn.Module):
    def __init__(self, in_ch, n_class=2, nhid=20, dropout=0.3):
        super(Classifier, self).__init__()
        self.fc = nn.Sequential(
            nn.Linear(in_ch, nhid),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(nhid, n_class),
            nn.Softmax(dim=1)
        )

    def forward(self, input):
        out = self.fc(input)
        return out


class RACNN(nn.Module):
    def __init__(self, h, w, n_class=2):
        super(RACNN, self).__init__()
        self.TemporalFeatureExtractor = TemporalFeatureExtractor(nhid=32)
        self.RegionalFeatureExtractor = RegionalFeatureExtractor(in_ch=32, nhid=32)
        self.AsymmetricFeatureExtractor = AsymmetricFeatureExtractor(in_ch=32, nhid=64)
        in_features = 32 * h * w + 64 * h * int(w / 2)
        self.Classifier = Classifier(in_features, n_class=n_class, nhid=20, dropout=0.3)

    def forward(self, x):
        TemporalFeatures = self.TemporalFeatureExtractor(x)
        RegionalFeatures = self.RegionalFeatureExtractor(TemporalFeatures).flatten(1)
        AsymmetricFeatures = self.AsymmetricFeatureExtractor(TemporalFeatures).flatten(1)
        TotalFeatures = torch.cat((RegionalFeatures, AsymmetricFeatures), dim=1)
        out = self.Classifier(TotalFeatures)

        return out


def train(model, train_loader, clip, optimizer, scheduler):
    model.train()
    total_loss = 0
    criterion = torch.nn.CrossEntropyLoss()

    for i, (x, y) in enumerate(train_loader):
        optimizer.zero_grad()
        output = model(x.contiguous())
        loss = criterion(output, y.long())

        loss.backward()

        if clip > 0:
            torch.nn.utils.clip_grad_norm_(model.parameters(), clip)

        optimizer.step()
        total_loss += loss.item()

    cur_loss = total_loss / len(train_loader.dataset)
    scheduler.step(cur_loss)


def evaluate(model, data_loader):
    model.eval()
    criterion = torch.nn.CrossEntropyLoss(reduction='sum')
    total_loss = 0
    Y = []
    Y1 = []

    with torch.no_grad():
        for i, (x, y) in enumerate(data_loader):
            output = model(x.contiguous())
            total_loss += criterion(output, y.long())
            _, pred = torch.max(output.data, 1)

            Y += [y]
            Y1 += [pred]

        Y = torch.concat(Y, dim=0)
        Y1 = torch.concat(Y1, dim=0)

        tp = sum(torch.bitwise_and(Y1 == 1, Y == 1)).cpu().item()
        fp = sum(torch.bitwise_and(Y1 == 1, Y == 0)).cpu().item()
        tn = sum(torch.bitwise_and(Y1 == 0, Y == 0)).cpu().item()
        fn = sum(torch.bitwise_and(Y1 == 0, Y == 1)).cpu().item()

        acc = (tp + tn) / (tp + fp + tn + fn)
        f_score = tp / (tp + 0.5 * (fp + fn))
        py = ((fp + tp) / (tn + tp + fp + fn)) * ((fn + tp) / (tn + tp + fp + fn))
        pn = ((fn + tn) / (tn + tp + fp + fn)) * ((fp + tn) / (tn + tp + fp + fn))
        pe = py + pn
        keppa = (acc - pe) / (1 - pe)
        auc = roc_auc_score(Y.cpu(), Y1.cpu())
        c_matrix = np.array([[tp, fn], [fp, tn]])

        perf = {
            'acc': acc,
            'f score': f_score,
            'auc': auc,
            'keppa': keppa,
            'confusion matrix': c_matrix
        }

        total = len(data_loader.dataset)
        curr_loss = total_loss / total

    return acc, curr_loss, perf


if __name__ == '__main__':
    net = RACNN(h=9, w=9, n_class=2)
    data = torch.randn((100, 1, 9, 9, 128))
    out = net(data)
    print(out)
