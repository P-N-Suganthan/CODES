import torch
import torch.nn as nn
import numpy as np
from sklearn.metrics import roc_auc_score


class TDCNN(nn.Module):
    def __init__(self, in_ch, in_len, n_kernels=32, nhid=20, n_class=2, dropout=0.3):
        super(TDCNN, self).__init__()
        fea_len = int(n_kernels * in_ch/8 * in_len/8)
        self.CNN = nn.Sequential(
            nn.Conv2d(1, n_kernels, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), padding_mode='zeros'),
            nn.BatchNorm2d(n_kernels),
            nn.ReLU(inplace=True),
            nn.MaxPool2d((2, 2)),
            nn.Conv2d(n_kernels, n_kernels, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), padding_mode='zeros'),
            nn.BatchNorm2d(n_kernels),
            nn.ReLU(inplace=True),
            nn.MaxPool2d((2, 2)),
            nn.Conv2d(n_kernels, n_kernels, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), padding_mode='zeros'),
            nn.BatchNorm2d(n_kernels),
            nn.ReLU(inplace=True),
            nn.MaxPool2d((2, 2)),
            nn.Flatten(),
            nn.Linear(fea_len, nhid),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(nhid, n_class),
            nn.Softmax(dim=1)
        )

    def forward(self, x):
        out = self.CNN(x.unsqueeze(1))

        return out


def train(model, train_loader, clip, optimizer, scheduler):
    model.train()
    total_loss = 0
    criterion = torch.nn.CrossEntropyLoss()

    for i, (x, y) in enumerate(train_loader):
        optimizer.zero_grad()
        output = model(x.contiguous())
        loss = criterion(output, y.long())

        loss.backward()

        if clip > 0:
            torch.nn.utils.clip_grad_norm_(model.parameters(), clip)

        optimizer.step()
        total_loss += loss.item()

    cur_loss = total_loss / len(train_loader.dataset)
    scheduler.step(cur_loss)


def evaluate(model, data_loader):
    model.eval()
    criterion = torch.nn.CrossEntropyLoss(reduction='sum')
    total_loss = 0
    Y = []
    Y1 = []

    with torch.no_grad():
        for i, (x, y) in enumerate(data_loader):
            output = model(x.contiguous())
            total_loss += criterion(output, y.long())
            _, pred = torch.max(output.data, 1)

            Y += [y]
            Y1 += [pred]

        Y = torch.concat(Y, dim=0)
        Y1 = torch.concat(Y1, dim=0)

        tp = sum(torch.bitwise_and(Y1 == 1, Y == 1)).cpu().item()
        fp = sum(torch.bitwise_and(Y1 == 1, Y == 0)).cpu().item()
        tn = sum(torch.bitwise_and(Y1 == 0, Y == 0)).cpu().item()
        fn = sum(torch.bitwise_and(Y1 == 0, Y == 1)).cpu().item()

        acc = (tp + tn) / (tp + fp + tn + fn)
        f_score = tp / (tp + 0.5 * (fp + fn))
        py = ((fp + tp) / (tn + tp + fp + fn)) * ((fn + tp) / (tn + tp + fp + fn))
        pn = ((fn + tn) / (tn + tp + fp + fn)) * ((fp + tn) / (tn + tp + fp + fn))
        pe = py + pn
        keppa = (acc - pe) / (1 - pe)
        auc = roc_auc_score(Y.cpu(), Y1.cpu())
        c_matrix = np.array([[tp, fn], [fp, tn]])

        perf = {
            'acc': acc,
            'f score': f_score,
            'auc': auc,
            'keppa': keppa,
            'confusion matrix': c_matrix
        }

        total = len(data_loader.dataset)
        curr_loss = total_loss / total

    return acc, curr_loss, perf


if __name__ == '__main__':
    net = TDCNN(h=9, w=9, n_class=2)
    data = torch.randn((100, 1, 9, 9, 128))
    out = net(data)
    print(out)
