import pickle
import numpy as np
from bohb import BOHB
from models.Rand_Conv import CNNLayer
from functools import partial
from utils import get_cv_splits, confidence_loss, create_val_set
from time import time
from pickle import dump
from sklearn.metrics import roc_auc_score


class CNNModel(object):
    def __init__(self, nL=10, nK=10, kernel_size=4, Lambda=0, kFold=4, cuda=True, gpu_id=0, rng=None):
        self.nL = nL
        self.nK = nK
        self.kernel_size = kernel_size
        self.Lambda = Lambda
        self.rng = rng

        self.kFold = kFold
        self.cuda = cuda
        self.gpu_id = gpu_id

        self.layers = []
        self.losses = []

    def train_eval(self, train_x, train_y, test_x, test_y, search_space):
        train_acc, train_pref, train_time, val_loss, val_time = self.train(train_x, train_y, search_space)
        test_acc, test_pref, test_time = self.eval(test_x, test_y, cuda=self.cuda, gpu_id=self.gpu_id)

        return train_acc, train_pref, test_acc, test_pref, train_time, test_time, val_loss, val_time

    def train(self, train_x, train_y, search_space):
        # Initialization
        train_outs = np.zeros((train_y.shape + (self.nL,)), dtype=float)
        train_losses = np.Inf * np.ones((train_y.shape[0], self.nL), dtype=float)
        train_time = 0

        # RNG Initialization (if not present)
        if self.rng is None:
            self.rng = np.random.RandomState(1882517)

        weights = np.ones((train_y.shape[0],), dtype=float)

        # Get validation splits
        indices = get_cv_splits(train_x, train_y, self.kFold, self.rng.randint(99999))

        val_time = 0
        val_loss = 0.
        # Hyperparameter tuning
        if search_space is not None:
            start_time = time()
            val_loss = self.tune(train_x, train_y, weights, indices, search_space)
            end_time = time()
            val_time = end_time - start_time

        for layer in range(0, self.nL):
            # Builds layer
            print('create feature maps of %2d-th layer on train set (val_loss = %.4f)' % (layer + 1, val_loss))
            model_layer_temp = CNNLayer(nK=self.nK, Lambda=self.Lambda, cuda=self.cuda, gpu_id=self.gpu_id)
            train_x, _, train_output, train_timeT = model_layer_temp.train(train_x, train_y, weights=weights)
            self.layers.append(model_layer_temp)

            # Stores and calculate losses and times
            train_outs[:, :, layer] = train_output
            train_losses[:, layer] = confidence_loss(train_y, train_output)
            train_time += train_timeT

        train_out = train_outs.mean(axis=2)
        # train_out = voting(train_out)

        train_pred = np.argmax(train_out, axis=1)
        train_act = np.argmax(train_y, axis=1)

        tp = sum(np.bitwise_and(train_pred == 1,train_act == 1))
        fp = sum(np.bitwise_and(train_pred == 1,train_act == 0))
        tn = sum(np.bitwise_and(train_pred == 0,train_act == 0))
        fn = sum(np.bitwise_and(train_pred == 0,train_act == 1))
        train_acc = (tp + tn) / (tp + fp + tn + fn)
        f_score = tp / (tp + 0.5 * (fp + fn))
        py = ((fp + tp) / (tn + tp + fp + fn)) * ((fn + tp) / (tn + tp + fp + fn))
        pn = ((fn + tn) / (tn + tp + fp + fn)) * ((fp + tn) / (tn + tp + fp + fn))
        pe = py + pn
        keppa = (train_acc - pe) / (1 - pe)
        auc = roc_auc_score(train_act, train_pred)
        c_matrix = np.array([[tp, fn], [fp, tn]])

        train_perf = {
            'acc': train_acc,
            'f score': f_score,
            'auc': auc,
            'keppa': keppa,
            'confusion matrix': c_matrix
        }

        # train_acc = sum(train_pred == train_act) / len(train_act)

        self.losses = train_losses

        return train_acc, train_perf, train_time, val_loss, val_time

    def eval(self, test_x, test_y, cuda=True, gpu_id=0):
        # Initialization
        test_outs = np.zeros((test_y.shape + (len(self.layers),)), dtype=float)
        test_time = 0

        for layer in range(len(self.layers)):
            # Predicts and generate features on test sample (Test)
            print('create feature maps of %2d-th layer on test set' % (layer + 1))

            model_layer_temp = self.layers[layer]
            model_layer_temp.cuda = cuda
            model_layer_temp.gpu_id = gpu_id
            test_x, _, test_output, test_timeT = self.layers[layer].predict(test_x)

            # Stores and calculate losses and times
            test_outs[:, :, layer] = test_output
            test_time += test_timeT

        test_out = test_outs.mean(axis=2)
        # test_out = voting(test_out)

        test_pred = np.argmax(test_out, axis=1)
        test_act = np.argmax(test_y, axis=1)

        tp = sum(np.bitwise_and(test_pred == 1, test_act == 1))
        fp = sum(np.bitwise_and(test_pred == 1, test_act == 0))
        tn = sum(np.bitwise_and(test_pred == 0, test_act == 0))
        fn = sum(np.bitwise_and(test_pred == 0, test_act == 1))
        test_acc = (tp + tn) / (tp + fp + tn + fn)
        f_score = tp / (tp + 0.5 * (fp + fn))
        py = ((fp + tp) / (tn + tp + fp + fn)) * ((fn + tp) / (tn + tp + fp + fn))
        pn = ((fn + tn) / (tn + tp + fp + fn)) * ((fp + tn) / (tn + tp + fp + fn))
        pe = py + pn
        keppa = (test_acc - pe) / (1 - pe)
        auc = roc_auc_score(test_act, test_pred)
        c_matrix = np.array([[tp, fn], [fp, tn]])

        test_perf = {
            'acc': test_acc,
            'f score': f_score,
            'auc': auc,
            'keppa': keppa,
            'confusion matrix': c_matrix
        }

        # test_acc = sum(test_pred == test_act) / len(test_act)

        return test_acc, test_perf, test_time

    def tune(self, trainX, trainY, weights, indices, search_space):
        edEMN_evaluate = partial(self.evaluate_edEMN, x=trainX, y=trainY, weights=weights, indices=indices,
                                 cuda=self.cuda, gpu_id=self.gpu_id)
        opt = BOHB(search_space, edEMN_evaluate, min_budget=50, max_budget=150)
        results = opt.optimize()

        # Get best hyperparameters
        best_configs = results.best["hyperparameter"].to_dict()
        self.kernel_size = best_configs["kernel_size"]
        self.nK = int(results.best["budget"])
        self.Lambda = best_configs["lambda"]
        val_loss = results.best["loss"]

        return val_loss

    def save(self, fname):
        with open(fname, 'wb') as f:
            dump(self, file=f, protocol=pickle.HIGHEST_PROTOCOL)

    def evaluate_edEMN(self, params, budget, x, y, indices, weights=None, cuda=True, gpu_id=0):
        kernel_size = params['kernel_size']
        nK = int(budget)
        Lambda = params["lambda"]

        val_loss = 0
        start_time = time()
        train_x, train_y, train_weights, test_x, test_y, test_weights = create_val_set(x, y, weights, indices)
        for k in range(len(train_x)):

            model_layer_temp = CNNLayer(nK=nK, Lambda=Lambda, cuda=cuda, kernel_size=kernel_size, gpu_id=gpu_id)
            model_layer_temp.train(train_x[k], train_y[k], weights=train_weights[k])
            _, _, test_output, _ = model_layer_temp.predict(test_x[k])

            loss = confidence_loss(test_y[k], test_output)
            val_loss += loss.mean()

        end_time = time()
        val_time = end_time - start_time
        val_loss = val_loss/(len(indices)/2)

        print('nK = {:d}, Kernel Size = {:d}, lambda = {:.4e}, loss = {:.4f}, Time = {:.2f}'
              .format(nK, kernel_size, Lambda, val_loss, val_time))

        return val_loss
