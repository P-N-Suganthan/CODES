from __future__ import print_function
import random
import numpy as np
from pathlib import Path
from models.rand_CNN_BOHB import CNNModel
from bohb import configspace as cs
from utils import read_dataset, get_cv_splits, transfer_labels, to_categorical
import os, errno
import torch

data_path = '../DEAP'

# Model Hyperparameters
nL = 10                                                                 # Number of layers (1 = Shallow, >1 = Deep Ensemble Version)
                                                                        # Number of Kernels = 50 or 150
KS_space = cs.IntegerUniformHyperparameter('kernel_size', 2, 17)        # Kernel Size
Lb_space = cs.UniformHyperparameter('lambda', 0, 2.**9)                 # Regularization parameter lambda

# Experment Parameters
cuda = True         # Use GPU
gpu_id = 0          # Which GPU (default 0)
n_folds = 10        # Number of experiment folds
seed = 2345         # Seed (for consistency)

search_space = cs.ConfigurationSpace([KS_space, Lb_space], seed=seed)

random.seed(seed)
np.random.seed(seed)
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False
print('Loading data...')

# Experiment
for s in range(1, 33):
    # Collect data
    fname = '{:s}/s{:02d}.dat'.format(data_path, s)
    X, Y = read_dataset(fname, s)
    X = np.transpose(X, (0, 2, 1))
    indices = get_cv_splits(X, Y, n_folds, stratified=False, seed=seed)
    prob = ['valance', 'arousal']

    # Experiment for each problem
    for p in range(2):
        Y_prob = Y[:, p]
        Y_prob, nums_class = transfer_labels(Y_prob)
        Y_prob = to_categorical(Y_prob, nums_class)

        # Experiment Folds
        for fold in range(n_folds):
            train_x = X[indices[2 * fold], :, :]
            train_y = Y_prob[indices[2 * fold], :]
            test_x = X[indices[2 * fold + 1], :, :]
            test_y = Y_prob[indices[2 * fold + 1], :]

            model = CNNModel(nL=nL, cuda=cuda, gpu_id=gpu_id)
            train_acc, train_pref, test_acc, test_pref, train_time, test_time, val_loss, val_time \
                = model.train_eval(train_x, train_y, test_x, test_y, search_space)

            model_layer = model.layers

            print('Subject:', s)
            print('Problem:', prob[p])
            print('nL:', nL)
            print('Kernels:', model.nK)
            print('Kernel Size:', model.kernel_size)
            print('Lambda: ', model.Lambda)
            print('accuracy:', test_acc)
            print('train time',train_time)

            fpath = Path('Experiments/Results/Results_BOHB_CNN_' + str(s) + 'nL' + str(nL) + '.csv')

            if not fpath.is_file():
                try:
                    os.makedirs('Experiments/Results')
                except OSError as e:
                    if e.errno != errno.EEXIST:
                        raise

                with open(fpath, 'w') as f:
                    print('Subject,Type,Fold,Train Acc,Train F-Score,Train AUC,Train Keppa,Test Acc,Test F-Score,Test AUC,Test Keppa,nL,nK,Kernel Size,Lambda,Train Time,Test Time', file=f)

            with open(fpath, 'a') as f:
                print('{:d},{:s},{:d},{:.3f},{:.3f},{:.3f},{:.3f},{:.3f},{:.3f},{:.3f},{:.3f},{:d},{:d},{:d},{:f},'
                      '{:.3f},{:.3f}'
                      .format(s, prob[p], fold, train_acc, train_pref['f score'], train_pref['auc'],
                              train_pref['keppa'], test_acc, test_pref['f score'], test_pref['auc'],
                              test_pref['keppa'], nL, model.nK, model.kernel_size, model.Lambda,
                              train_time, test_time), file=f)

            try:
                os.makedirs('Experiments/Models')
            except OSError as e:
                if e.errno != errno.EEXIST:
                    raise

            mpath = Path('Experiments/Models/BOHB_Model_Sub_grid_CNN1d' + str(s) + 'nL' + str(nL) + '_' + prob[p] + str(fold) +
                         '.pkl')
            model.save(mpath)
