from sklearn.model_selection import StratifiedKFold, KFold, StratifiedShuffleSplit, ShuffleSplit
import numpy as np
from pickle import load
from torch.utils.data import Dataset
from torch.autograd import Variable


def read_dataset(fname, subject=1, length=1, sample_rate=128, baseline=3):
    g2t = [0, 1, 3, 2, 5, 4, 7, 6, 9, 8, 11, 10, 15, 12, 13, 14, 31, 30, 28, 29, 26, 27, 24, 25, 21, 22, 19, 20, 17, 16,
           18, 23]

    with open(fname, 'rb') as f:
        dataset = load(f, encoding='latin1')
        if subject > 22:
            x = dataset['data'][:, g2t, :]
        else:
            x = dataset['data'][:, :32, :]

        # x = dataset['data'][:, :32, :]
        y = dataset['labels']

    # Baseline pretrial signals
    baseline_x = x[:, :, :baseline*sample_rate]
    baseline_x = baseline_x.reshape((x.shape[0], x.shape[1], -1, length*sample_rate))
    baseline_x_mean = baseline_x.mean(axis=2)

    x = x[:, :, baseline*sample_rate:]
    y = y[:, :2]
    y = (y > 5).astype(int)

    n_sample = x.shape[0]
    n_ch = x.shape[1]
    full_length = x.shape[2]

    n_sample_new = int(n_sample*full_length/(length*sample_rate))
    baseline_x_mean = np.tile(baseline_x_mean, (1, 1, int(full_length / (length * sample_rate))))
    x = x - baseline_x_mean
    x = x.transpose((1, 0, 2)).reshape((n_ch, n_sample_new, length*sample_rate)).transpose(1, 0, 2)

    # z-normalize across time series
    x_mean = x.mean()
    x_std = x.std()
    x = (x - x_mean)/x_std

    y = np.tile(y, (1, int(full_length/(length*sample_rate)))).reshape(n_sample_new, -1)

    return x, y


def spatial_encoder(x):
    # Places x to grid
    """
        0   1   2   3   4   5   6   7   8           0   1   2   3   4   5   6   7   8
    0   -   -   -   0   -   29  -   -   -       0   -   -   -   Fp1 -   Fp2 -   -   -
    1   -   -   -   1   -   28  -   -   -       1   -   -   -   AF3 -   AF4 -   -   -
    2   2   -   3   -   30  -   26  -   27      2   F7  -   F3  -   Fz  -   F4  -   F8
    3   -   5   -   4   -   25  -   24  -       3   -   FC5 -   FC1 -   FC2 -   FC6 -
    4   6   -   7   -   31  -   22  -   23      4   T7  -   C3  -   Cz  -   C4  -   T8
    5   -   9   -   8   -   21  -   20  -       5   -   CP5 -   CP1 -   CP2 -   CP6 -
    6   10  -   11  -   12  -   18  -   19      6   P7  -   P3  -   Pz  -   P4  -   P8
    7   -   -   -   13  -   17  -   -   -       7   -   -   -   PO3 -   PO4 -   -   -
    8   -   -   -   14  15  16  -   -   -       8   -   -   -   O1  Oz  O2  -   -   -
    """
    x_grid = np.zeros((x.shape[0], 1, 9, 9, x.shape[-1]), dtype=float)
    x_grid[:, 0, 0, 3, :] = x[:, 0, :]
    x_grid[:, 0, 1, 3, :] = x[:, 1, :]
    x_grid[:, 0, 2, 0, :] = x[:, 2, :]
    x_grid[:, 0, 2, 2, :] = x[:, 3, :]
    x_grid[:, 0, 3, 3, :] = x[:, 4, :]
    x_grid[:, 0, 3, 1, :] = x[:, 5, :]
    x_grid[:, 0, 4, 0, :] = x[:, 6, :]
    x_grid[:, 0, 4, 2, :] = x[:, 7, :]
    x_grid[:, 0, 5, 3, :] = x[:, 8, :]
    x_grid[:, 0, 5, 1, :] = x[:, 9, :]
    x_grid[:, 0, 6, 0, :] = x[:, 10, :]
    x_grid[:, 0, 6, 2, :] = x[:, 11, :]
    x_grid[:, 0, 6, 4, :] = x[:, 12, :]
    x_grid[:, 0, 7, 3, :] = x[:, 13, :]
    x_grid[:, 0, 8, 3, :] = x[:, 14, :]
    x_grid[:, 0, 8, 4, :] = x[:, 15, :]
    x_grid[:, 0, 8, 5, :] = x[:, 16, :]
    x_grid[:, 0, 7, 5, :] = x[:, 17, :]
    x_grid[:, 0, 6, 6, :] = x[:, 18, :]
    x_grid[:, 0, 6, 8, :] = x[:, 19, :]
    x_grid[:, 0, 5, 7, :] = x[:, 20, :]
    x_grid[:, 0, 5, 5, :] = x[:, 21, :]
    x_grid[:, 0, 4, 6, :] = x[:, 22, :]
    x_grid[:, 0, 4, 8, :] = x[:, 23, :]
    x_grid[:, 0, 3, 7, :] = x[:, 24, :]
    x_grid[:, 0, 3, 5, :] = x[:, 25, :]
    x_grid[:, 0, 2, 6, :] = x[:, 26, :]
    x_grid[:, 0, 2, 8, :] = x[:, 27, :]
    x_grid[:, 0, 1, 5, :] = x[:, 28, :]
    x_grid[:, 0, 0, 5, :] = x[:, 29, :]
    x_grid[:, 0, 2, 4, :] = x[:, 30, :]
    x_grid[:, 0, 4, 4, :] = x[:, 31, :]

    return x_grid


def create_val_set(x, y, weights, indices):
    train_x = []
    train_y = []
    train_weights = []
    test_x = []
    test_y = []
    test_weights = []

    for k in range(int(len(indices)/2)):
        train_x.append(x[indices[2*k], :])
        train_y.append(y[indices[2*k], :])
        train_weights.append(weights[indices[2*k]])
        test_x.append(x[indices[2*k+1], :])
        test_y.append(y[indices[2*k+1], :])
        test_weights.append(weights[indices[2*k+1]])

    return train_x, train_y, train_weights, test_x, test_y, test_weights


def get_cv_splits(X, Y, nFolds, stratified=True, seed=None):
    if seed is None:
        seed = np.random.randint(999999)

    if stratified:
        skf = StratifiedKFold(nFolds, shuffle=True, random_state=seed)

        tune_indices = []
        for train_idx, test_idx in skf.split(X, Y.argmax(axis=1)):
            tune_indices += [train_idx]
            tune_indices += [test_idx]

    else:
        kf = KFold(nFolds, shuffle=True, random_state=seed)

        tune_indices = []
        for train_idx, test_idx in kf.split(X):
            tune_indices += [train_idx]
            tune_indices += [test_idx]

    return tune_indices


def get_cv_splits_trials(X, Y, nFolds, stratified=True, seed=None):
    if seed is None:
        seed = np.random.randint(999999)

    X_t = [X[60 * i][np.newaxis, :, :] for i in range(40)]
    X_T = np.concatenate(X_t, axis=0)
    Y_t = [Y[60 * i][np.newaxis, :] for i in range(40)]
    Y_T = np.concatenate(Y_t, axis=0)

    if stratified:
        skf = StratifiedKFold(nFolds, shuffle=True, random_state=seed)

        tune_indices = []
        for train_idx, test_idx in skf.split(X_T, Y_T.argmax(axis=1)):
            train_idxT = [np.arange(start=i * 60, stop=(i + 1) * 60) for i in train_idx]
            train_idxT = np.concatenate(train_idxT)

            test_idxT = [np.arange(start=i * 60, stop=(i + 1) * 60) for i in test_idx]
            test_idxT = np.concatenate(test_idxT)

            tune_indices += [train_idxT]
            tune_indices += [test_idxT]

    else:
        kf = KFold(nFolds, shuffle=True, random_state=seed)

        tune_indices = []
        for train_idx, test_idx in kf.split(X_T):
            train_idxT = [np.arange(start=i * 60, stop=(i + 1) * 60) for i in train_idx]
            train_idxT = np.concatenate(train_idxT)

            test_idxT = [np.arange(start=i * 60, stop=(i + 1) * 60) for i in test_idx]
            test_idxT = np.concatenate(test_idxT)

            tune_indices += [train_idxT]
            tune_indices += [test_idxT]

    return tune_indices


def get_splits(X, Y, nFolds, train_size, stratified=True, seed=None):
    Y = Y.argmax(axis=1)

    if seed is None:
        seed = np.random.randint(999999)

    if stratified:
        _classes = np.unique(Y)

        for i in range(len(_classes)):
            count = np.sum(Y==_classes[i])

            if count < 2:
                stratified = False
                break

    if stratified:
        skf = StratifiedShuffleSplit(nFolds, train_size=train_size, test_size=1-train_size, random_state=seed)

        tune_indices = []
        for train_idx, test_idx in skf.split(X, Y):
            tune_indices += [train_idx]
            tune_indices += [test_idx]

    else:
        kf = ShuffleSplit(nFolds, train_size=train_size, test_size=1-train_size, random_state=seed)

        tune_indices = []
        for train_idx, test_idx in kf.split(X):
            tune_indices += [train_idx]
            tune_indices += [test_idx]

    return tune_indices


def cross_entropy_loss(y, y_hat):
    return np.diagonal(-y.dot(np.log(y_hat).transpose()))


def confidence_loss(y, y_hat):
    corr = y == 1
    y_hat_corr = y_hat[corr]
    y_hat_incorr = y_hat[np.bitwise_not(corr)].reshape(y_hat.shape[0], y_hat.shape[1] - 1)
    y_hat_incorr_max = y_hat_incorr.max(axis=1)
    diff = y_hat_corr - y_hat_incorr_max

    return 1 - diff


def euclidean_distance(x1, x2, batch_size=100):
    distances = []

    if len(x1.shape) == 2:
        x1 = x1[:, :, np.newaxis]

    if len(x2.shape) == 2:
        x2 = x2[:, :, np.newaxis]

    distances2 = []
    for i in range(int(np.ceil(x2.shape[0] / batch_size))):
        x2t = x2[batch_size * i:batch_size * (i + 1), :, :]

        distances1 = []
        for j in range(x1.shape[0]):
            x1t = np.tile(x1[j, :, 0].reshape(1, -1), (x2t.shape[0], 1))
            distance = x1t - x2t[:, :, 0]
            distances1 += [np.diagonal(distance.dot(distance.transpose()))[np.newaxis, :]]

        distances2 += [np.concatenate(distances1, axis=0)]

    return np.concatenate(distances2, axis=1)


def voting(prob, weights=None):
    votes = np.zeros(prob.shape[:2], dtype=float)
    if weights is None:
        weights = np.ones((prob.shape[0], prob.shape[2]), dtype=float)

    for i in range(prob.shape[0]):
        for k in range(prob.shape[2]):
            j = np.argmax(prob[i, :, k])
            votes[i, j] += weights[i, k]

    return votes


def transfer_labels(labels):
    indexes = np.unique(labels)
    num_classes = indexes.shape[0]
    num_samples = np.shape(labels)[0]
    for i in range(num_samples):
        new_label = np.argwhere(indexes == labels[i])[0][0]
        labels[i] = new_label
    return labels, num_classes


def to_categorical(y, num_classes=None, dtype='float32'):
    """Converts a class vector (integers) to binary class matrix.

    E.g. for use with categorical_crossentropy.

    Arguments:
        y: class vector to be converted into a matrix
            (integers from 0 to num_classes).
        num_classes: total number of classes. If `None`, this would be inferred
          as the (largest number in `y`) + 1.
        dtype: The data type expected by the input. Default: `'float32'`.

    Returns:
        A binary matrix representation of the input. The classes axis is placed
        last.

    Example:

    >>> a = tf.keras.utils.to_categorical([0, 1, 2, 3], num_classes=4)
    >>> a = tf.constant(a, shape=[4, 4])
    >>> print(a)
    tf.Tensor(
      [[1. 0. 0. 0.]
       [0. 1. 0. 0.]
       [0. 0. 1. 0.]
       [0. 0. 0. 1.]], shape=(4, 4), dtype=float32)

    >>> b = tf.constant([.9, .04, .03, .03,
    ...                  .3, .45, .15, .13,
    ...                  .04, .01, .94, .05,
    ...                  .12, .21, .5, .17],
    ...                 shape=[4, 4])
    >>> loss = tf.keras.backend.categorical_crossentropy(a, b)
    >>> print(np.around(loss, 5))
    [0.10536 0.82807 0.1011  1.77196]

    >>> loss = tf.keras.backend.categorical_crossentropy(a, a)
    >>> print(np.around(loss, 5))
    [0. 0. 0. 0.]

    Raises:
        Value Error: If input contains string value

    """
    y = np.array(y, dtype='int')
    input_shape = y.shape
    if input_shape and input_shape[-1] == 1 and len(input_shape) > 1:
        input_shape = tuple(input_shape[:-1])
    y = y.ravel()
    if not num_classes:
        num_classes = np.max(y) + 1
    n = y.shape[0]
    categorical = np.zeros((n, num_classes), dtype=dtype)
    categorical[np.arange(n), y] = 1
    output_shape = input_shape + (num_classes,)
    categorical = np.reshape(categorical, output_shape)
    return categorical


class RawDataset(Dataset):
    def __init__(self, input, labels):
        super(RawDataset, self).__init__()
        self.X = input
        self.Y = labels

    def __getitem__(self, index):
        data = Variable(self.X[index])
        label = Variable(self.Y[index])
        return data, label

    def __len__(self):
        return len(self.X)

    def cuda(self, gpu_id):
        self.X = self.X.cuda(gpu_id)
        self.Y = self.Y.cuda(gpu_id)