function logngumbelplot()
global mcarlo SHP HP1 nbins

% Solar parameter
mu = 5.0; sigma = 0.6;
Psr = 45; % [MW] Equivalent rated power output of the PV generator
Gstd = 1000; %[W/m2] Solar irradiation in the standard enviroment
Rc = 120; % [W/m2] A certain irradiation

% Small hydro parameter
p = 1000;       % water density
ntot = 0.85;    % combined turbine, generator and coupler efficiency
% ng = 0.95;      % generator efficiency
% nm = 0.98;      % coupler efficency
h = 25;         % head of water above ref level
lambda = 15; % Gumbel PDF parameter
sig = 1.2;     % Gumbel PDF parameter
Phr = 5; % hydro rated power
                                       
P_unit = 9.81*p*ntot*h; % Power for unit flow rate

nbins = 30; % No. of bins for histogram
mcarlo = 8000; % No. of Montecalro scenarios

G1 = lognrnd(mu,sigma,mcarlo,1);
Q1 = evrnd(lambda,sig,mcarlo,1);

% lognormal plots activate if you need to plot
%{
figure(5)
histfit(G1,nbins,'lognormal')
xlabel('Solar irradiance (W/m^2) for the site')
ylabel('Frequency')
legend('Solar irradiance')
%}

% Gumbel plots activate if you need to plot
%{
figure(6)
histfit(Q1,nbins,'ev')
xlabel('River flow rate (m^3/s) for the site')
ylabel('Frequency')
legend('River flow rate')
%}

% Power calculation 
G1und = G1(G1<=Rc);
G1over = G1(G1>Rc);
P1und = Psr*(G1und.^2/(Gstd*Rc));
P1over_site = Psr*(G1over./Gstd); % power at site
P1over = min(repmat(Psr,size(G1over,1),1),Psr*(G1over./Gstd)); %% power from unit
SP2_site = vertcat(P1und,P1over_site);
SP2 = vertcat(P1und,P1over); % Solar power
HP1_site = (Q1.*P_unit)/10^6;
HP1 = min(repmat(Phr,size(Q1,1),1),(Q1.*P_unit)/10^6); % Hydro power
SHP = SP2+HP1;

% plots of solar PV power, activate if you need to plot
%{
figure(7)
subplot(2,1,1)
[num1,xout1] = hist(SP2_site,nbins);
bar(xout1,num1/sum(num1));
xlabel('Available solar power (MW) for the site')
ylabel('Relative frequency')
subplot(2,1,2)
[num1,xout1] = hist(SP2,nbins);
bar(xout1,num1/sum(num1));
xlabel('Available solar power (MW) from the solar PV unit')
ylabel('Relative frequency')
%}
% plots of small hydro power, activate if you need to plot
%{
figure(8)
subplot(2,1,1)
[num2,xout2] = hist(HP1_site,nbins);
bar(xout2,num2/sum(num2));
xlabel('Available hydro power (MW) for the site')
ylabel('Relative frequency')
subplot(2,1,2)
[num2,xout2] = hist(HP1,nbins);
bar(xout2,num2/sum(num2));
xlabel('Available hydro power (MW) from the small-hydro unit')
ylabel('Relative frequency')
%}

% plots of total power, activate if you need to plot
%{
figure(9)
[num3,xout3] = hist(SHP,nbins);
bar(xout3,num3/sum(num3));
xlabel('Available real power (MW) from combined solar PV & small hydro')
ylabel('Relative frequency')
%}

% Contribution from small-hydro
% Hyd_pow = xout3-xout1;
