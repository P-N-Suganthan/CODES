function f = initialize_variables(N, M, V, min_range, max_range, ncon)
%N = 100; %V = 11; M = 2; ncon = 4;
%% function f = initialize_variables(N, M, V, min_tange, max_range) 
% This function initializes the chromosomes. Each chromosome has the
% following at this stage
%       * set of decision variables
%       * objective function values
% 
% where,
% N - Population size
% M - Number of objective functions
% V - Number of decision variables
% min_range - A vector of decimal values which indicate the minimum value
% for each decision variable.
% max_range - Vector of maximum possible values for decision variables.
% Xmin = [20 0 10 0 0 0.95 0.95 0.95 0.95 0.95 0.95];
% Xmax = [80 75 35 50 60 1.1 1.1 1.1 1.1 1.1 1.1];
% range= vertcat(Xmin,Xmax)';
% min_range=range(:,1)';
% max_range=range(:,2)';

min = min_range;
max = max_range;

% K is the total number of array elements. For ease of computation decision
% variables and objective functions are concatenated to form a single
% array. For crossover and mutation only the decision variables are used
% while for selection, only the objective variable are utilized.

K = V+M+3;
f = zeros(N,K+ncon);
%% Initialize each chromosome
% For each chromosome perform the following (N is the population size)
for i = 1 : N
    % Initialize the decision variables based on the minimum and maximum
    % possible values. V is the number of decision variable. A random
    % number is picked between the minimum and maximum possible values for
    % the each decision variable.
    for j = 1 : V
        f(i,j) = min(j) + (max(j) - min(j))*rand(1);
    end
    % For ease of computation and handling data the chromosome also has the
    % vlaue of the objective function concatenated at the end. The elements
    % V + 1 to K has the objective function valued. 
    % The function evaluate_objective takes one chromosome at a time,
    % infact only the decision variables are passed to the function along
    % with information about the number of objective functions which are
    % processed and returns the value for the objective functions. These
    % values are now stored at the end of the chromosome itself.
    f(i,V+1:K+ncon) = evaluate_objective(f(i,:), M, V);
end
% cons = ff(:,(K+1):(K+ncon));
% cons_max = max(cons);
% cons_norm = bsxfun(@rdivide,cons,cons_max);
% cons_norm(~isfinite(cons_norm)) = 0;
% tot_cons = sum(cons_norm,2);
% f = ff(:,(V+1):K,tot_cons);
