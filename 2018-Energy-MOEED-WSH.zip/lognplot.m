function lognplot()
global mcarlo SP1 nbins
mu = 5.2; sigma = 0.6;
Psr = 50; % [MW] Equivalent rated power output of the PV generator
Gstd = 1000; %[W/m2] Solar irradiation in the standard enviroment
Rc = 120; % [W/m2] A certain irradiation
nbins = 30; % No. of bins for histogram
mcarlo = 8000; % No. of Montecalro scenarios

G1 = lognrnd(mu,sigma,mcarlo,1);

% lognormal plots activate if you need to plot
%{
figure(2)
histfit(G1,nbins,'lognormal')
xlabel('Solar irradiance (W/m^2) for the site')
ylabel('Frequency')
legend('Solar irradiance')
%}

% Power calculation
G1und = G1(G1<=Rc);
G1over = G1(G1>Rc);
P1und = Psr*(G1und.^2/(Gstd*Rc));
P1over_site = Psr*(G1over./Gstd); % avaialable at site
P1over = min(repmat(Psr,size(G1over,1),1),Psr*(G1over./Gstd)); % available from the unit
SP1_site = vertcat(P1und,P1over_site);
SP1 = vertcat(P1und,P1over);

% plots of power activate if you need to plot
%{
figure(3)
[num,xout] = hist(SP1_site,nbins);
bar(xout,num/sum(num));
xlabel('Available solar power (MW) for the site')
ylabel('Relative frequency')

figure(4)
[num,xout] = hist(SP1,nbins);
bar(xout,num/sum(num));
xlabel('Available real power (MW) from the solar PV')
ylabel('Relative frequency')
%}
