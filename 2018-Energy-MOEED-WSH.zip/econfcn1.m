function [z1,z2,error] = econfcn1(x)

global fn_eval VD PGS emission ploss VI scale shape fuelvlvcost Qgen mcarlo SP1 SHP HP1 wgencost sgencost shgencost nbins cumcost;
fn_eval=fn_eval+1;% Function count

% weibullplot(); % for plotting Weibull PDF
% lognplot(); % for plotting lognormal PDF
% logngumbelplot(); % for plotting lognormal];
% x = [47.086,61.893,35,49.863,44.981,0.95416,1.1,1.0354,1.0913,1.0514,1.08];
%x = [62.84 50 24.64 40 40 1.0591 1.05273 1.03364 1.0355 1.071 1.08075];
%scale = 9; % Enter shape parameters for Weibull dist
%shape = 2; % Enter shape parameters for Weibull dist
NT = 25; % No. of turbines in the windfarm
Vin = 3; Vout = 25; Vr = 16; Pr = 3; % Cut-in, cut-out, rated speed and rated power of turbine

% Emission : Of thermal generating unit
% bus_no. alpha beta gama omega miu d e Pmin POZL1 POZH1 POZL2 POZH2
 thgendata = [
 	1	0.04091 -0.05554 0.06490 0.000200 6.667 18 0.037 50 0 0 0 0;
 	2	0.02543 -0.06047 0.05638 0.000500 3.333 16 0.038 20 30 40 55 65;
 	8	0.05326 -0.03550 0.03380 0.002000 2.000 12 0.045 10 0 0 0 0];

% Check for gen at bus 2 for POZ
if x(1)>thgendata(2,10) && x(1)<thgendata(2,11)
temp = round((x(1)-thgendata(2,10))/(thgendata(2,11)-thgendata(2,10)));
x(1) = thgendata(2,10);
if temp == 1
    x(1) = thgendata(2,11);
end
end

if x(1)>thgendata(2,12) && x(1)<thgendata(2,13)
temp = round((x(1)-thgendata(2,12))/(thgendata(2,13)-thgendata(2,12)));
x(1) = thgendata(2,12);
if temp == 1
    x(1) = thgendata(2,13);
end
end

data = loadcase(case30);
data.gen(2:6,2) = x(1:5);
data.gen(1:6,6) = x(6:11);
mpopt = mpoption('pf.enforce_q_lims',0,'verbose',0,'out.all',0);
result = runpf(data,mpopt);

thpowgen = [result.gen(1,2),x(1),x(3)];
%thpowgen = [94.7753,x(1),x(3)];
thgencoeff = vertcat(data.gencost(1:2,5:7),data.gencost(4,5:7));

thgencost = sum(thgencoeff(:,1)+thgencoeff(:,2).*thpowgen'+thgencoeff(:,3).*(thpowgen.^2)'); % thermal generator cost

%Find wind generator related parameters
%windgen parameter sl no. bus costcoeff
wgenpar = [1   5   1.70];
Crwj = 3; Cpwj = 1.4; % wind power penalty and reserve cost coefficients
schwpow = x(2);

%stochastic wind power cost
%meanwpow = [26;30]; wp = 35;
Prw0 = 1-exp(-(Vin/scale)^shape)+exp(-(Vout/scale)^shape);
Prwwr = exp(-(Vr/scale)^shape)-exp(-(Vout/scale)^shape);

    Prww1 = (shape*(Vr-Vin))/((scale^shape)*(NT*Pr));
    Prww = @(wp)((schwpow-wp)*Prww1*((Vin + (wp/(NT*Pr))*(Vr-Vin))^(shape-1))*(exp(-((Vin + (wp/(NT*Pr))*(Vr-Vin))/scale)^shape)));
    wovest2 = integral(Prww,0,schwpow,'ArrayValued',true);
    wovest = schwpow*Prw0*Crwj+Crwj*wovest2;

    Prww = @(wp)((wp-schwpow)*Prww1*((Vin + (wp/(NT*Pr))*(Vr-Vin))^(shape-1))*(exp(-((Vin + (wp/(NT*Pr))*(Vr-Vin))/scale)^shape)));
    wundest2 = integral(Prww,schwpow,NT*Pr,'ArrayValued',true);
    wundest = (NT*Pr-schwpow)*Prwwr*Cpwj+Cpwj*wundest2;
    
wgencost = wgenpar(3)*schwpow + wovest + wundest; % wind generator cost

%solargen parameter sl no. bus costcoeff
sgenpar = [1   11  1.60];
Crsj = 3; % Reserve cost for solar power overestimation ($/MW)
Cpsj = 1.4; % Penalty cost for solar power underestimation ($/MW)
schspow = x(4); % solar generator schedule power

% Segregate over and underestimated power on the power histogram

[histy1,histx1] = hist(SP1,nbins);

Lowind1 = histx1<schspow;
Highind1 = histx1>schspow;
allP1und = schspow-histx1(histx1<schspow);
allP1over = histx1(histx1>schspow)-schspow;
ProbP1und = histy1(Lowind1)./mcarlo;
ProbP1over = histy1(Highind1)./mcarlo;

% Finding under and over estimation cost
C1und = sum(Crsj*(ProbP1und.*allP1und));
C1over = sum(Cpsj*(ProbP1over.*allP1over));
sovundcost = [C1und,C1over];

sgencost = sgenpar(3)*schspow+sum(sovundcost); % solar generator cost

%solar+hydro gen parameter sl no. bus costcoeff
hydpar = [1   13  1.50];
schshpow = x(5); % solar+hydro generator schedule power

% Segregate over and underestimated power on the power histogram

[histy2,histx2] = hist(SHP,nbins);

Lowind2 = histx2<schshpow;
Highind2 = histx2>schshpow;
allP2und = schshpow-histx2(histx2<schshpow);
allP2over = histx2(histx2>schshpow)-schshpow;
ProbP2und = histy2(Lowind2)./mcarlo;
ProbP2over = histy2(Highind2)./mcarlo;

% Finding under and over estimation cost
C2und = sum(Crsj*(ProbP2und.*allP2und));
C2over = sum(Cpsj*(ProbP2over.*allP2over));
shovundcost = [C2und,C2over];

% Finding closest value of schshpow
[~,idx] = min(abs(SHP-schshpow));
hydpow = HP1(idx);
shgencost = hydpar(3)*hydpow+sgenpar(3)*(schshpow-hydpow)+sum(shovundcost); % solar+hydro generator cost

%Constraint finding 
Vmax = data.bus(:,12);
Vmin = data.bus(:,13);
genbus = data.gen(:,1);

Qmax = data.gen(:,4)/data.baseMVA;
Qmin = data.gen(:,5)/data.baseMVA;
Qgen = result.gen(:,3);
QG = result.gen(:,3)/data.baseMVA;

PGSmax = data.gen(1,9);
PGSmin = data.gen(1,10);
PGS = result.gen(1,2);
PGSerr = (PGS<PGSmin)*(abs(PGSmin-PGS)/(PGSmax-PGSmin))+(PGS>PGSmax)*(abs(PGSmax-PGS)/(PGSmax-PGSmin));

blimit = data.branch(:,6);
Slimit = sqrt(result.branch(:,14).^2+result.branch(:,15).^2);
Serr = sum((Slimit>blimit).*abs(blimit-Slimit))/data.baseMVA;

% TO find the error in Qg of gen buses- inequality constraint
Qerr = sum((QG<Qmin).*(abs(Qmin-QG)./(Qmax-Qmin))+(QG>Qmax).*(abs(Qmax-QG)./(Qmax-Qmin)));
% TO find the error in V of load buses-inequality constraint
VI = result.bus(:,8);  %V of load buses-inequality constraint
VI(genbus)=[];
Vmax(genbus)=[];
Vmin(genbus)=[];
VIerr = sum((VI<Vmin).*(abs(Vmin-VI)./(Vmax-Vmin))+(VI>Vmax).*(abs(Vmax-VI)./(Vmax-Vmin)));
VD = sum(abs(VI-1));

% VALVE EFFECT
valveff = sum(abs(thgendata(:,7).*sin(thgendata(:,8).*(thgendata(:,9)-thpowgen')))); % if all have valve effects

% OBJECTIVE FUNCTIONS
emission = sum(thgendata(:,2)+thgendata(:,3).*thpowgen'/100+thgendata(:,4).*(thpowgen.^2/100^2)'...
     +thgendata(:,5).*exp(thgendata(:,6).*thpowgen'/100));

ploss = sum(result.branch(:,14)+result.branch(:,16));

fuelvlvcost = thgencost+valveff;
cumcost = fuelvlvcost+wgencost+sgencost+shgencost;
error = [Qerr,VIerr,Serr,PGSerr];

%penalty = sum(error);

z1 = cumcost; %+50*penalty;
z2 = emission; %+2*penalty;


