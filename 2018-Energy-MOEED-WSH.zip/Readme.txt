MATLAB Code: "Multiobjective economic-environmental power dispatch with stochastic wind-solar-small hydro
power." Energy 150(2018):1039-1057.

You need MATPOWER to run the program.
Code of SMODE-SF algorithm is shared.
The author can be contacted at parthapr001@e.ntu.edu.sg