function xf= rank_sort(x,dim,n_obj,NP,~,Max_Gen)
%Max_Gen=200;

xx=x;
fmax = zeros(); fmin = zeros(); f = zeros(size(x,1),n_obj);
for i=1:n_obj
    fmax(i)=max(x(:,dim+i));
    fmin(i)=min(x(:,dim+i));
    f(:,i)=(x(:,dim+i)-fmin(i))/(fmax(i)-fmin(i));    
end

rank2=sum(f,2);
xx(:,dim+n_obj+1)=rank2;
x=xx; 

tim=0.8;
saver=[];

for i=1:n_obj

     [mini(i),~]=min(x(:,dim+i));
     [~,bbb]=sort(x(:,dim+i));
     maxi(i)=max(x(:,dim+i));
    
     n_grid(i)=(maxi(i)-mini(i))/Max_Gen;
     for j=1:Max_Gen*tim
         a=find((xx(:,dim+i)>(j-1)*n_grid(i)+mini(i)) & (xx(:,dim+i)<=j*n_grid(i)+mini(i)));
         if (isempty(a))==0

                 [~,c]=min(xx(a,dim+n_obj+1));
                 saver=[saver,a(c)];

         else
             continue;
         end
         
     end

       saver=[saver,bbb(1:10)'];
end  
 saver1=unique(saver);

 if length(saver1)>NP
     
    yy=x(saver1,:);
    index1=randperm(length(saver1));
    xf=yy(index1,:);

 else    
    xx(saver1,dim+n_obj+1)=0;
    [~,index_of_fronts] = sort(xx(:,n_obj + dim + 1));
    index_of_fronts=index_of_fronts(1:NP);
    xf = xx(index_of_fronts,:);
 end















