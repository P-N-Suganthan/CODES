%function mode(runs)
weibullplot(); % for plotting Weibull PDF
lognplot(); % for plotting lognormal PDF
logngumbelplot(); % for plotting lognormal and gumbel PDF

%pop=150;
NP=200;
no_gen=200;
F=0.5;
CR=0.9;
st=2;
frep=[];
store_chromosome=[];
rtemp=[];
global xl xu SHP HP1 VD PGS emission ploss VI fuelvlvcost Qgen wgencost sgencost shgencost cumcost 
 
Xmin = [20 0 10 0 0 0.95 0.95 0.95 0.95 0.95 0.95];
Xmax = [80 75 35 50 max(SHP) 1.1 1.1 1.1 1.1 1.1 1.1];
range= vertcat(Xmin,Xmax)';

M=2; % number of objectives
V=size(range,1); % dimension of the problem
ncon = 4; % number of constraints
min_range=range(:,1)';
max_range=range(:,2)';
xl=min_range;
xu=max_range;
    %% Initialize the population
    % Population is initialized with random values which are within the
    % specified range. Each chromosome consists of the decision variables. Also
    % the value of the objective functions, rank and crowding distance
    % information is also added to the chromosome vector but only the elements
    % of the vector which has the decision variables are operated upon to
    % perform the genetic operations like corssover and mutation.
 for run = 1:21
 fprintf('\n Run:%d',run);   
    child = zeros(NP,V+M+4);
    rep = initialize_variables(NP, M, V, min_range, max_range, ncon);
    
    %PPB: constraint normalization
    cons = rep(:,(V+M+4):(V+M+3+ncon));
    cons_max = max(cons);
    cons_den = 1./cons_max;
    cons_den(~isfinite(cons_den)) = 0;
    cons_norm = bsxfun(@rdivide,cons,cons_max);
    cons_norm(~isfinite(cons_norm)) = 0;
    tot_cons = sum(cons_norm,2)./sum(cons_den);
    tot_cons(~isfinite(tot_cons)) = 0;
    rep = [rep(:,1:(V+M+3)),tot_cons];
    %PPB
    
    parent = rep;
 for i = 1 : no_gen
        for j=1:NP
   
        [rep_size,~]=size(rep);
        h=ceil(rand*rep_size);
        bm=rep(h,1:V);
        popold=parent(j,1:V);
        newpop=parent(:,1:V);
        parent1=newpop;
        
        child(j,1:V)=DE(j,popold,parent1,bm,st,F,CR,V,size(parent1,1));      
        child(j,V+1:V+M+ncon+3) = evaluate_objective(child(j,:),M,V);              
         
        end  
    
    %PPB: constraint normalization
    cons1 = child(:,(V+M+4):(V+M+3+ncon));
    cons_max1 = max(cons1);
    cons_den1 = 1./cons_max1;
    cons_den1(~isfinite(cons_den1)) = 0;
    cons_norm1 = bsxfun(@rdivide,cons1,cons_max1);
    cons_norm1(~isfinite(cons_norm1)) = 0;
    tot_cons1 = sum(cons_norm1,2)./sum(cons_den1);
    tot_cons1(~isfinite(tot_cons1)) = 0;
    child = [child(:,1:(V+M+3)),tot_cons1];
    %PPB
    
    rep=[parent;child];

[~, size_c]=size(rep);
fea=find(rep(:,size_c)<=0);
rtemp=[rtemp;i*NP length(fea)];

if length(fea)<NP
    [~,c]=sort(rep(:,size_c));
    rep=rep(c(1:NP),:);
else
    rep=rep(fea,:);  
    %rep=rank_sort(rep,V,M,NP,i,no_gen);
    rep=rank_sort_new(rep,V,M,NP,i,no_gen);
end

parent=rep;
      
if i>no_gen-3
   
  frep=[rep;frep];
  %PPB
  frep_temp = frep(:,1:V);
  [frep1,frep_r,frep_c] = unique(frep_temp,'rows');
  frep = frep(frep_r,:);
  size(frep);
  %PPB

end
    
end
rep11 = rep; %% PPB
rep=non_domination_sort_mod_2(frep,V,M);
rep12 = rep; %% PPB
    if size(rep,1)>NP,

         rep=crowding_distance(rep,V,M,NP);

    end
   
  hydpower = zeros(NP,1);
% round off rating for generator with POZ
  for ii = 1:NP
      if rep(ii,1)>30 && rep(ii,1)<40
        temp = round((rep(ii,1)-30)/(40-30));
        rep(ii,1) = 30;
        if temp == 1
        rep(ii,1) = 40;
        end
     end

      if rep(ii,1)>55 && rep(ii,1)<65
        temp = round((rep(ii,1)-55)/(65-55));
        rep(ii,1) = 55;
        if temp == 1
        rep(ii,1) = 65;
        end
      end
      %contribution from hydro power
      [~,idx] = min(abs(SHP-rep(ii,5)));
      hydpower(ii,:) = HP1(idx);
  end
  
  dlmwrite(strcat('result',char(num2str(run)),'.txt'),rep,'newline','pc');
  dlmwrite(strcat('hydpower',char(num2str(run)),'.txt'),hydpower,'newline','pc');
  dlmwrite('feasible.txt',rtemp,'newline','pc');
  parameter = rep(:,1:V);
  eval(['save parameter_' num2str(run) ' parameter']);
    
  % Best compromise solution
  objpareto = rep(:,V+1:V+M);
  objpareto = flip(sortrows(objpareto,1));
  eval(['save paretofront_' num2str(run) ' objpareto']);
  [no_par,no_pf] = size(objpareto);
  miu_pf = zeros(no_par,no_pf);
  for jj = 1:no_pf
    max_pareto = max(objpareto(:,jj));
    min_pareto = min(objpareto(:,jj));
    miu_pf(:,jj) = (repmat(max_pareto,no_par,1)-objpareto(:,jj))./(max_pareto-min_pareto);
  end
  miu_sum = sum(miu_pf,2);
  miu_wt = miu_sum./sum(miu_sum);
  [miu_max,ind] = max(miu_wt);
  comp_obj(run,1:(no_pf+1+no_pf)) = [objpareto(ind,:),miu_max,min(objpareto)];
  
 end
 dlmwrite(strcat('summary.txt'),comp_obj,'newline','pc');     