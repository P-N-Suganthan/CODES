function weibullplot()
global scale shape nbins
scale = 9; % Enter shape parameters of 2 windfarms for Weibull dist
shape = 2; % Enter shape parameters of 2 windfarms for Weibull dist
nbins = 30; % No. of bins for histogram

W1 = wblrnd(scale(1),shape(1),8000,1);
figure(1)
histfit(W1,nbins,'weibull')
xlabel('Wind speed (m/s) for wind generator at bus 5')
ylabel('Frequency')
legend ('Wind distribution')