t0=clock;
% tic
for i=1:10
    
    mode(i)
end
% toc
t=etime(clock,t0);
dlmwrite('time.txt',t,'newline','pc');