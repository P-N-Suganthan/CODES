from model_for_test import *
from sklearn.linear_model import LinearRegression
import xgboost as xgb
from sklearn.svm import SVR

class MLForecaster(object):
    def __init__(self, Xtrain, ytrain, Xval, yval, Xtest, ytest):
        self.Xtrain = Xtrain
        self.ytrain = ytrain
        self.Xvalid = Xval
        self.yvalid = yval
        self.Xtest = Xtest
        self.ytest = ytest

    def LR_predict(self):
        LR_model = LinearRegression().fit(np.vstack((self.Xtrain, self.Xvalid)),
                                          np.concatenate((self.ytrain, self.yvalid))
                                          )
        LR_hat = LR_model.predict(self.Xtest)
        return LR_hat

    '''=======================================SVR=============================================='''
    def SVR_predict(self, tuning=False, specified=False, HP_SVR=[]):
        D_out = self.ytrain.shape[1]
        hat_ls = []
        for horizon in range(D_out):
            kernel_list = ['rbf']
            C_list = [1, 10, 100, 1000, 10000]  # loss的惩罚
            Gamma_list = [1e-5, 1e-4, 1e-3, 1e-2, 1e-1]
            HParams = list(itertools.product(kernel_list, C_list, Gamma_list))
            best_vloss = 1e6
            best_HP = HParams[0]
            for HP in HParams:
                model_SVR = SVR(kernel=HP[0], C=HP[1], gamma=HP[2])
                model_SVR.fit(self.Xtrain, self.ytrain[:,horizon])
                y_hat = model_SVR.predict(self.Xvalid)
                vloss = np.linalg.norm(y_hat - self.yvalid[:,horizon], 1) / len(y_hat)
                if vloss < best_vloss:
                    best_vloss = vloss
                    best_HP = HP
            best_model = SVR(kernel=best_HP[0], C=best_HP[1], gamma=best_HP[2])
            best_model.fit(np.vstack((self.Xtrain, self.Xvalid)),
                           np.concatenate((self.ytrain[:,horizon], self.yvalid[:,horizon])))
            SVR_hat = best_model.predict(self.Xtest)
            hat_ls.append(np.expand_dims(SVR_hat,-1))
        return np.concatenate(hat_ls,axis=1)

    def XGB_predict(self, specified=False, HP_XGB=[]):
        params = {
            'n_estimators': 500,
            'booster': 'gbtree',
            'objective': 'reg:squarederror',
            'eval_metric': 'mae',
            'gamma': 0.1,
            'max_depth': 7,
            'reg_lambda': 0.1,
            'reg_alpha': 0.1,
            'subsample': 1,
            'colsample_bytree': 1,
            'min_child_weight': 4,
            'verbosity': 0,
            'eta': 0.1,
            'random_state': 1000
        }
        D_out = self.ytrain.shape[1]
        xgb_hat = []
        for horizon in range(D_out):
            dtrain_temp = xgb.DMatrix(self.Xtrain, self.ytrain[:,horizon])
            dvalid_temp = xgb.DMatrix(self.Xvalid, self.yvalid[:,horizon])
            watchlist = [(dtrain_temp, 'train'), (dvalid_temp, 'valid')]
            num_rounds = 1000
            XGB_model = xgb.train(params, dtrain_temp, num_rounds, evals=watchlist,
                                  verbose_eval=False, early_stopping_rounds=50)
            XGB_hat_horizon = XGB_model.predict(xgb.DMatrix(self.Xtest))
            xgb_hat.append(np.expand_dims(XGB_hat_horizon,-1))
        return np.concatenate(xgb_hat,axis=1)

class NNForecaster(object):
    def __init__(self, Xtrain, ytrain, Xvalid, yvalid, Xtest, ytest, adj=None, SNXtrain=None, SNXval=None, SNXtest=None):
        USE_CUDA = torch.cuda.is_available()
        self.device = torch.device("cuda" if USE_CUDA else "cpu")
        self.Xtrain = torch.tensor(Xtrain, dtype=torch.float32).to(self.device)
        self.ytrain = torch.tensor(ytrain, dtype=torch.float32).to(self.device)
        self.Xvalid = torch.tensor(Xvalid, dtype=torch.float32).to(self.device)
        self.yvalid = torch.tensor(yvalid, dtype=torch.float32).to(self.device)
        self.Xtest = torch.tensor(Xtest, dtype=torch.float32).to(self.device)
        self.ytest = torch.tensor(ytest, dtype=torch.float32).to(self.device)

        self.adj_vec = adj
        self.NXtrain = SNXtrain
        self.NXval = SNXval
        self.NXtest = SNXtest

    def MLP_predict(self, tuning=False, specified=False, HP_MLP=[]):
        D_in = self.Xtrain.shape[1]
        D_out = self.ytrain.shape[1]
        if specified is True:
            H, activation, lr = HP_MLP
        else:
            if tuning is False:
                H = round(D_in * 1.2)
                lr = 1e-2
                activation = 3
            else:
                H, lr, activation = self.MLP_tuning()

        best_HP = {'hidden_1': H,
                   'activation': activation,
                   'learning_rate': lr,
                   }
        epoch = 500
        model = MLP(D_in, D_out, H, H, activation).to(self.device)
        loss_fn = nn.MSELoss()
        optimizer = torch.optim.Adam(model.parameters(), lr=lr)
        for i in range(epoch):
            y_pred = model(torch.cat((self.Xtrain, self.Xvalid), 0)
                           )
            loss = loss_fn(torch.squeeze(y_pred), torch.cat((self.ytrain, self.yvalid), 0))
            # if i % 100 == 0:
            #     print(loss.item())
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()  # one-step
            # loss.backward()
            # optimizer.step()
            # optimizer.zero_grad()
        Test_y = model(self.Xtest).detach().cpu().numpy()
        return Test_y, best_HP

    def MLP_tuning(self):
        D_in = self.Xtrain.shape[1]
        D_out = self.ytrain.shape[1]
        temp = [0.8 * D_in, 0.9 * D_in, 1.0 * D_in, 1.1 * D_in, 1.2 * D_in]
        H = [2, 4, 8, 16, 32, 64, 128]
        lr = [1e-3, 1e-2, 1e-1]
        activation = [1, 2, 3]
        HParams = list(itertools.product(H, lr, activation))
        best_vloss = 1e8
        best_HP = HParams[0]
        activation = 3
        epoch = 500
        for HP in HParams:
            model_i = MLP(D_in, D_out, HP[0], HP[0], HP[2]).to(self.device)
            loss_fn = nn.MSELoss()
            optimizer = torch.optim.Adam(model_i.parameters(), lr=HP[1])
            for i in range(epoch):
                y_pred = model_i(self.Xtrain)
                loss = loss_fn(y_pred, self.ytrain)
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()  # one-step

            yvalid_hat = model_i(self.Xvalid).detach()
            vloss = loss_fn(yvalid_hat, self.yvalid)
            if vloss < best_vloss:
                print('H=%d, activation=%d, lr=%f' % (HP[0], HP[2], HP[1]), ',Loss=', vloss.item())
                best_vloss = vloss
                best_HP = HP
        return best_HP

    def LSTM_predict(self, tuning=False, specified=False, HP_LSTM=[]):
        if specified is True:
            num_layer, hidden_num, lr = HP_LSTM
        else:
            if tuning is False:
                num_layer = 2
                hidden_num = 16
                lr = 1e-2
            else:
                num_layer, hidden_num, lr = self.lstm_tuning()

        best_HP = {'num_layer': num_layer,
                   'hidden_num': hidden_num,
                   'learning_rate': lr,
                   }

        LSTMX_trv = torch.unsqueeze(torch.cat((self.Xtrain, self.Xvalid), 0), -1)
        LSTMy_trv = torch.cat((self.ytrain, self.yvalid), 0)
        LSTMX_test = torch.unsqueeze(self.Xtest, -1)
        input_size = 1 #self.Xtrain.shape[1]
        horizon = self.ytrain.shape[1]
        lstm_model = LSTM(num_layer, hidden_num, input_size, horizon).to(self.device)
        epoch = 200
        lr = lr
        loss_fn = nn.MSELoss()
        optimizer = torch.optim.Adam(lstm_model.parameters(), lr=lr)
        for i in range(epoch):
            y_pred = lstm_model(LSTMX_trv)
            loss = loss_fn(y_pred, LSTMy_trv)
            # if i % 50 == 0:
            #     print(loss.item())
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()  # one-step
        Test_y = lstm_model(LSTMX_test).cpu().detach().numpy()
        return Test_y, best_HP

    def LSTM_tuning(self):
        num_layer = 1, 2, 3, 4
        hidden_num = [8, 16, 32, 64]
        lr = 1e-3, 1e-2, 1e-1

        HParams = list(itertools.product(num_layer, hidden_num, lr))
        best_vloss = 1e8
        best_HP = HParams[0]
        Xtrain = torch.unsqueeze(self.Xtrain, -1)
        ytrain = self.ytrain
        Xvalid = torch.unsqueeze(self.Xvalid, -1)
        yvalid = self.yvalid
        input_size = 1 #self.Xtrain.shape[1]
        horizon = self.ytrain.shape[1]
        for HP in HParams:
            model_i = LSTM(num_layers=HP[0], hidden_size=HP[1], input_size=1, horizon=horizon).to(self.device)
            loss_fn = nn.MSELoss()
            optimizer = torch.optim.Adam(model_i.parameters(), lr=HP[2])
            for i in range(200):
                y_pred = model_i(Xtrain)
                loss = loss_fn(y_pred, ytrain)
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()  # one-step

            yvalid_hat = model_i(Xvalid).detach()
            vloss = loss_fn(yvalid_hat, yvalid)
            if vloss < best_vloss:
                print('num_layer=%d, num_hidden=%d, lr=%f' % (HP[0], HP[1], HP[2]), ',Loss=', vloss.item())
                best_vloss = vloss
                best_HP = HP
        return best_HP

    def TCN_predict(self, tuning=False, specified=False, HP_TCN=[]):
        L,D_in = self.Xtrain.shape[1],1
        D_out = self.ytrain.shape[1]
        if specified is True:
            C, filter, lr = HP_TCN
        else:
            if tuning is False:
                C = 32
                filter = 6
                lr = 0.01
            else:
                C, filter, lr = self.TCN_tuning()

        best_HP = {'channels': C,
                   'filter size': filter,
                   'learning_rate': lr,
                   }

        TCNX_trv = torch.unsqueeze(torch.cat((self.Xtrain, self.Xvalid), 0), 1)
        TCNy_trv = torch.cat((self.ytrain, self.yvalid))
        TCNX_test = torch.unsqueeze(self.Xtest, 1)
        model = TemporalConvNet(L,D_in, D_out, [C, C, C], kernel_size=filter).to(self.device)
        epoch = 200
        loss_fn = nn.MSELoss()
        optimizer = torch.optim.Adam(model.parameters(), lr=lr)
        for i in range(epoch):
            y_pred = model(TCNX_trv)
            loss = loss_fn(y_pred, TCNy_trv)
            # if i % 100 == 0:
            #     print(loss.item())
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()  # one-step

        Test_y = model(TCNX_test).detach().cpu().numpy()
        return Test_y, best_HP

    def TCN_tuning(self):
        L = self.Xtrain.shape[1]
        C = [8, 16, 32, 64, 128]
        filter = [2, 4, 6]
        lr = [0.1, 0.05, 0.01]
        HParams = list(itertools.product(C, filter, lr))
        best_vloss = 1e8
        best_HP = HParams[0]
        Xtrain = torch.unsqueeze(self.Xtrain, 1)
        ytrain = self.ytrain
        Xvalid = torch.unsqueeze(self.Xvalid, 1)
        yvalid = self.yvalid
        epoch = 200
        for HP in HParams:
            model_i = TemporalConvNet(L, 1, [HP[0], HP[0], HP[0]], kernel_size=HP[1]).to(self.device)
            loss_fn = nn.MSELoss()
            optimizer = torch.optim.Adam(model_i.parameters(), lr=HP[2])
            for i in range(epoch):
                y_pred = model_i(Xtrain)
                loss = loss_fn(torch.squeeze(y_pred), ytrain)
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()  # one-step

            yvalid_hat = model_i(Xvalid).detach()
            vloss = loss_fn(torch.squeeze(yvalid_hat), yvalid)
            if vloss < best_vloss:
                print('channel=%d, kernel=%d, lr=%f' % (HP[0], HP[1], HP[2]), ',Loss=', vloss.item())
                best_vloss = vloss
                best_HP = HP
        return best_HP

    def DeepAR_predict(self,tuning=False, specified=False, HP_DeepAR=[]):
        if DeepAR is True:
            num_layer, hidden, lr = HP_DeepAR
        else:
            if tuning is False:
                num_layer = 2
                hidden = 64
                lr = 1e-3
            else:
                num_layer,hidden ,lr = self.DeepAR_tuning()

        best_HP = { 'num of layers': num_layer,
                    'Hidden neurons':hidden,
                    'learning rate': lr
        }

        DeepARX_trv = torch.unsqueeze(torch.cat((self.Xtrain, self.Xvalid), 0), -1)
        DeepARy_trv = torch.cat((self.ytrain, self.yvalid),0)
        DeepARX_test = torch.unsqueeze(self.Xtest, -1)
        D_in, D_out = 1, self.ytrain.shape[1]

        model = DeepAR(D_in=D_in,D_out=D_out,num_layers=num_layer,hidden_size=hidden).to(self.device)
        optimizer = torch.optim.Adam(model.parameters(), lr=lr)
        # training
        for epoch in range(200):
            ypred, mu, sigma = model(DeepARX_trv)
            # ypred_rho = ypred
            # e = ypred_rho - yf
            # loss = torch.max(rho * e, (rho - 1) * e).mean()
            ## gaussian loss
            loss = gaussian_likelihood_loss(DeepARy_trv, mu, sigma)
            # if epoch % 50 is 0:
            #     print(loss)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        yhat, mu, sig = model(DeepARX_test)
        Test_y = yhat.cpu().detach().numpy()
        return Test_y,best_HP,(mu,sig)

    def DeepAR_tuning(self):
        num_layer = [1, 2, 3, 4]
        hidden_num = [8, 16, 32, 64]
        lr = [1e-3, 1e-2, 1e-1]

        HParams = list(itertools.product(num_layer, hidden_num, lr))
        best_vloss = 1e8
        best_HP = HParams[0]

        Xtrain_dpAR = torch.unsqueeze(self.Xtrain, 2)
        ytrain_dpAR = torch.unsqueeze(self.ytrain, 1)
        Xvalid_dpAR = torch.unsqueeze(self.Xvalid, 2)
        yvalid_dpAR = self.yvalid

        loss_fn = nn.MSELoss()
        # training
        for HP in HParams:
            model_i = DeepAR(num_layers=HP[0],hidden_size=HP[1]).to(self.device)
            optimizer = torch.optim.Adam(model_i.parameters(), lr=HP[2])
            for i in range(200):
                y_pred,mu,sigma = model_i(Xtrain_dpAR)
                loss = gaussian_likelihood_loss(ytrain_dpAR, mu, sigma)
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()  # one-step

            yvalid_hat,_,_ = model_i(Xvalid_dpAR)
            vloss = loss_fn(torch.squeeze(yvalid_hat), yvalid_dpAR)
            if vloss < best_vloss:
                print('num_layer=%d, num_hidden=%d, lr=%f' % (HP[0], HP[1], HP[2]), ',Loss=', vloss.item())
                best_vloss = vloss
                best_HP = HP
        return best_HP

class RANForecaster(object):
    def __init__(self, Xtrain, ytrain, Xvalid, yvalid, Xtest, ytest, adj_vec=None, SNXtrain=None, SNXval=None, SNXtest=None):
        self.Xtrain = torch.tensor(Xtrain, dtype=torch.float32)
        self.ytrain = torch.tensor(ytrain, dtype=torch.float32)
        self.Xvalid = torch.tensor(Xvalid, dtype=torch.float32)
        self.yvalid = torch.tensor(yvalid, dtype=torch.float32)
        self.Xtest = torch.tensor(Xtest, dtype=torch.float32)
        self.ytest = torch.tensor(ytest, dtype=torch.float32)
        self.adj_vec = adj_vec
        self.NXtrain = SNXtrain
        self.NXval = SNXval
        self.NXtest = SNXtest

    def RVFL_predict(self):
        D_in = self.Xtrain.shape[1]
        model = RVFL(D_in=D_in, H=D_in)
        model.train(torch.cat((self.Xtrain, self.Xvalid), dim=0), torch.cat((self.ytrain, self.yvalid), dim=0))
        ytest_rvfl = model.predict(self.Xtest)
        return ytest_rvfl

    def EdRVFL_predict(self, num_layer=3, ensemble='mean'):
        D_in = self.Xtrain.shape[1]
        model = EdRVFL(D_in=D_in, H=D_in, num_layer=num_layer)
        model.feed_data(self.Xtrain, self.ytrain, self.Xvalid, self.yvalid)
        model.pruning()
        model.train()
        ytest_ls = model.predict(self.Xtest)
        ytest_Edrvfl = torch.stack(ytest_ls, dim=0)
        if ensemble =='mean':
            ytest_Edrvfl_ensemble = torch.mean(ytest_Edrvfl, dim=0)
        else:
            ytest_Edrvfl_ensemble = torch.median(ytest_Edrvfl,dim=0)
        return ytest_Edrvfl_ensemble

    def GRVFL_predict(self):
        D_in = self.Xtrain.shape[1]
        model = GRVFL(D_in=D_in, H=D_in, adj_vec=self.adj_vec, weight_min=-1, weight_max=1, bias_range=(0, 1),
                      activation='Sigmoid', reg=1)
        model.train(torch.cat((self.Xtrain, self.Xvalid), dim=0), torch.cat((self.ytrain, self.yvalid), dim=0),
                    NXtrain=torch.cat((self.NXtrain, self.NXval), dim=1))
        ytest_GRVFL = model.predict(self.Xtest, self.NXtest)
        return ytest_GRVFL

    def GEdRVFL_predict(self,num_layer=3, final_feat=10, group_size=5,
                        feature_selection='Embedded', activation='Sigmoid',ensemble='mean'):
        D_in = self.Xtrain.shape[1]
        model = GEdRVFL(D_in=D_in, H=D_in, num_layer=num_layer, adj_vec=self.adj_vec, weight_min=-1, weight_max=1, bias_range=(0, 1),
                        activation=activation, reg=1, feature_selection=feature_selection)
        model.feed_data(self.Xtrain, self.ytrain, self.NXtrain, self.Xvalid, self.yvalid, self.NXval)
        model.pruning(final_feat=final_feat, group_size=group_size)
        model.train()
        ytest_GEdRVFL = model.predict(self.Xtest, self.NXtest)
        ytest_GEdRVFL = torch.stack(ytest_GEdRVFL, dim=0)
        if ensemble == 'mean':
            ytest_GEdRVFL_ensemble = torch.mean(ytest_GEdRVFL, dim=0)
        else:
            ytest_GEdRVFL_ensemble = torch.median(ytest_GEdRVFL, dim=0)
        return ytest_GEdRVFL_ensemble


if __name__ == '__main__':
    Xtrain = np.load('..\\0.1-PEMS-BAY\\train.npz')['x']
    Ytrain = np.load('..\\0.1-PEMS-BAY\\train.npz')['y']

    Xval = np.load('..\\0.1-PEMS-BAY\\val.npz')['x']
    Yval = np.load('..\\0.1-PEMS-BAY\\val.npz')['y']

    Xtest = np.load('..\\0.1-PEMS-BAY\\test.npz')['x']
    Ytest = np.load('..\\0.1-PEMS-BAY\\test.npz')['y']

    sensor_ids, sensor_id_to_ind, adj_mx = load_pickle('..\\0.1-PEMS-BAY\\adj_mat_bay.pkl')
    # load GNN data
    GW_LA_hat = torch.load('GW_prediction\\bay_yhat_1038.pth').cpu().numpy()
    GW_LA_true = torch.load('GW_prediction\\bay_ytest_1038.pth').cpu().numpy()
    GW_0_0 = GW_LA_true[:,0,0]

    DCRNN_LA_hat = np.transpose(np.load('DCRNN_prediction\\bay_predictions.npz')['prediction'][:, :1038, :], (1, 2, 0))
    DCRNN_LA_true = np.transpose(np.load('DCRNN_prediction\\bay_predictions.npz')['truth'][:, :1038, :], (1, 2, 0))
    DCRNN_0_0 = DCRNN_LA_true[:,0,0]

    DCRNN_LA_hat2 = np.transpose(np.load('DCRNN_prediction\\dcrnn_predictions_pytorch.npz')['prediction'][:, -743:-62, :], (1, 2, 0))
    DCRNN_LA_true2 = np.transpose(np.load('DCRNN_prediction\\dcrnn_predictions_pytorch.npz')['truth'][:, -743:-62, :], (1, 2, 0))

    # G =  torch.load('GW_prediction\\la_ytest_681.pth').cpu().numpy()
    # A = np.load('DCRNN_prediction\\la_predictions.npz')['truth'] #A.shape = [out_dim, length_test, node_num)
    # B = np.load('DCRNN_prediction\\dcrnn_predictions_pytorch.npz')['truth']
    # i = np.random.randint(1,207)
    # plt.figure()
    # plt.plot(DCRNN_LA_true[:,i,0],'r-', label='true_our')
    # plt.plot(DCRNN_LA_hat[:,i,0],'r--', label='pre_our')
    # plt.plot(DCRNN_LA_hat2[:,i,0],'b--', label='pre_author')
    # plt.plot(DCRNN_LA_true2[:,i,0],'b-', label='true_author')
    # plt.legend()



    #RVFL,MLP
    RVFL_mase = []
    EdRVFL_mase = [] #mean
    GRVFL_mase = []
    GEdRVFL_emb_mase = []
    stEdRVFL_emb_mase = []

    NXtrain = torch.tensor(Xtrain[..., 0]).permute(2,0,1).float()
    NXval = torch.tensor(Xval[..., 0]).permute(2,0,1).float()
    NXtest = torch.tensor(Xtest[..., 0]).permute(2,0,1).float()

    scaler = StandardScaler(mean=NXtrain.mean(), std=NXtrain[..., 0].std())
    SNXtrain = scaler.transform(NXtrain)
    SNXval = scaler.transform(NXval)
    SNXtest = scaler.transform(NXtest)

    loss_func = torch.nn.L1Loss()
    horizon = 12
    start_time = time.time()

    for node_i in range(300,325):  #325
        print('node_i:%d, running time:%.3f seconds'%(node_i, time.time()-start_time))
        min_x = np.min(Xtrain)
        max_x = np.max(Xtrain)
        X_train = (Xtrain[:, :, node_i, 0] - min_x)/(max_x-min_x)
        y_train = (Ytrain[:, :horizon, node_i, 0] - min_x)/(max_x-min_x)
        X_val = (Xval[:, :, node_i, 0] - min_x)/(max_x-min_x)
        y_val = (Yval[:, :horizon, node_i, 0] - min_x)/(max_x-min_x)
        X_test = (Xtest[:, :, node_i, 0] - min_x)/(max_x-min_x)
        y_test = (Ytest[:, :horizon, node_i, 0] - min_x)/(max_x-min_x)
        history = np.concatenate((y_train, y_val), axis=0)[:,0]

        MASE_ls = []
        MAE_ls = []
        RMSE_ls = []

        MLF = MLForecaster(X_train, y_train, X_val, y_val, X_test, y_test)
        #ml
        naive_hat = np.concatenate([X_test[:,-1:]]*horizon, axis=1)
        LR_hat = MLF.LR_predict()
        XGB_hat = MLF.XGB_predict()
        SVR_hat = MLF.SVR_predict()
        #dnn
        NNF = NNForecaster(X_train, y_train, X_val, y_val, X_test, y_test)
        MLP_hat,_ = NNF.MLP_predict()
        LSTM_hat,_ = NNF.LSTM_predict()
        DeepAR_hat,_,_ = NNF.DeepAR_predict()
        TCN_hat,_ = NNF.TCN_predict()
        #gnn
        DCRNN_hat = (DCRNN_LA_hat[:,node_i,:]- min_x)/(max_x-min_x)
        GW_hat = (GW_LA_hat[:, node_i, :]- min_x)/(max_x-min_x)

        #rvfl
        RF = RANForecaster(X_train, y_train, X_val, y_val, X_test, y_test, adj_mx[node_i,:],SNXtrain,SNXval,SNXtest)
        rvfl_hat = np.array(RF.RVFL_predict())
        EdRVFL_hat = np.array(RF.EdRVFL_predict(num_layer=3, ensemble='mean'))
        GRVFL_hat = np.array(RF.GRVFL_predict())
        GEdRVFL_hat = np.array(RF.GEdRVFL_predict())




        print('node_i:%d, running time:%.3f seconds' % (node_i, time.time() - start_time))

        np.savez_compressed("..\\results_bay\\node_%s.npz"%(str(node_i)),
                            test = y_test, naive = naive_hat,LR=LR_hat, SVR=SVR_hat,
                            XGB = XGB_hat, MLP = MLP_hat, LSTM=LSTM_hat, DeepAR=DeepAR_hat,
                            TCN=TCN_hat, DCRNN=DCRNN_hat, GW = GW_hat,
                            RVFL=rvfl_hat, EdRVFL=EdRVFL_hat,GRVFL=GRVFL_hat, GEdRVFL=GEdRVFL_hat
                            )
        a = np.load("..\\results_bay\\node_0.npz")
        for i in a.files:
            print(TsMetric.MASE(a[i][:,0], a['test'][:,0], history))

        #RVFL

