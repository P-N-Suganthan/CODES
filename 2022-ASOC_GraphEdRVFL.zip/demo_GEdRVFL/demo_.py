from Utils import *

class RVFL():
    def __init__(self, D_in, H, weight_min=-1,weight_max=1, bias_range=(0,1),
                 activation='Sigmoid',reg=1):
        self.D_in = D_in
        self.H = H
        self.reg = reg
        self.activation = activation
        self.weight = weight_min + (weight_max-weight_min)*torch.rand(D_in, H)
        self.bias = bias_range[0] + (bias_range[1] - bias_range[0]) * torch.rand(1, H)

    def train(self, Xtrain, ytrain):
        self.Xtrain = Xtrain
        if len(ytrain.shape)==1:
            self.ytrain = torch.unsqueeze(ytrain,1)
        else:
            self.ytrain = ytrain

        self.embedding = self._activation(torch.mm(self.Xtrain, self.weight) \
                         + torch.mm(torch.ones([self.Xtrain.shape[0], 1]),self.bias))
        self.embedding = torch.cat((self.embedding, self.Xtrain), dim=1)
        self.beta = Ridge(self.embedding,self.ytrain,self.reg)

    def predict(self, Xtest):
        test_embedding = self._activation(torch.mm(Xtest, self.weight) + \
                         torch.mm(torch.ones([Xtest.shape[0], 1]),self.bias))
        test_embedding = torch.cat((test_embedding, Xtest),dim=1)
        ytest_hat = torch.mm(test_embedding,self.beta)
        return ytest_hat

    def _activation(self,x):
        assert torch.is_tensor(x)
        activation = self.activation.lower()
        assert activation in ['sigmoid','relu','tanh']
        return eval('torch.%s'%(activation))(x)

class GRVFL():
    def __init__(self, D_in, H, adj_vec, weight_min=-1,weight_max=1, bias_range=(0,1),
                 activation='Sigmoid',reg=1):
        self.D_in = D_in
        self.H = H
        self.a = torch.unsqueeze(torch.tensor(adj_vec),dim=0)
        self.reg = reg
        self.activation = activation
        self.weight = weight_min + (weight_max-weight_min)*torch.rand(D_in, H)
        self.bias = bias_range[0] + (bias_range[1] - bias_range[0]) * torch.rand(1, H)

    def train(self, Xtrain, ytrain, NXtrain):
        self.Xtrain = Xtrain
        if len(ytrain.shape) == 1:
            self.ytrain = torch.unsqueeze(ytrain, 1)
        else:
            self.ytrain = ytrain

        N,B,P = NXtrain.shape
        X = torch.reshape(NXtrain,(N,B*P))
        aX = torch.reshape(torch.squeeze(torch.mm(self.a,X)),(B,P))
        aXW = self._activation(torch.mm(aX, self.weight)+ torch.mm(torch.ones([B, 1]),self.bias))
        embedding = torch.cat((aXW, self.Xtrain), dim=1)
        self.beta = Ridge(embedding,self.ytrain,self.reg)

    def predict(self, Xtest, NXtest):
        N,B,P = NXtest.shape
        NXtest = torch.reshape(NXtest,(N,B*P))
        aX = torch.reshape(torch.squeeze(torch.mm(self.a, NXtest)), (B, P))
        aXW = self._activation(torch.mm(aX, self.weight) + torch.mm(torch.ones([B, 1]), self.bias))
        test_embedding = torch.cat((aXW, Xtest),dim=1)
        ytest_hat = torch.mm(test_embedding,self.beta)
        return ytest_hat

    def _activation(self,x):
        assert torch.is_tensor(x)
        activation = self.activation.lower()
        assert activation in ['sigmoid','relu','tanh']
        return eval('torch.%s'%(activation))(x)

class EdRVFL():
    def __init__(self,D_in, H, num_layer,weight_min=-1,weight_max=1, bias_range=(0,1),
                 activation='Sigmoid',reg=1, feature_selection=None):
        self.D_in = D_in
        self.H = H
        self.reg = reg
        self.activation = activation
        self.num_layer = num_layer  # 定义类的本身属性
        for i in range(self.num_layer):
            if i == 0:
                self.__setattr__('weight_%d'%(i),weight_min + (weight_max - weight_min) * torch.rand(D_in, H))
            else:
                self.__setattr__('weight_%d' % (i), weight_min + (weight_max - weight_min) * torch.rand(H, H))
            self.__setattr__('bias_%d'%(i),bias_range[0] + (bias_range[1] - bias_range[0]) * torch.rand(1, H))
        print('Total layers: %d'%(self.num_layer))
        self.feature_selection =  feature_selection

    def feed_data(self,Xtrain, ytrain, Xval=None, yval=None):
        self.Xtrain = Xtrain
        self.ytrain = torch.unsqueeze(ytrain, -1) if len(ytrain.shape) == 1 else ytrain
        if Xval == None:
            self.Xtrval = self.Xtrain
            self.ytrval = self.ytrain
        else:
            self.Xval = Xval
            self.yval = torch.unsqueeze(yval, -1) if len(yval.shape) == 1 else yval
            self.Xtrval = torch.cat((self.Xtrain, self.Xval), dim=0)
            self.ytrval = torch.cat((self.ytrain, self.yval), dim=0)

        embeddings = []
        embedding_prev = self.Xtrval
        for i in range(self.num_layer):
            weight_i = self.__getattribute__('weight_%d'%(i))
            bias_i = self.__getattribute__('bias_%d'%(i))
            embedding_i = self._activation(torch.mm(embedding_prev, weight_i) \
                             + torch.mm(torch.ones([self.Xtrval.shape[0], 1]),bias_i))
            embeddings.append(embedding_i)
            embedding_prev = embedding_i
        self.trvalembeddings = embeddings

    def train(self):
        betas = []
        for j in range(self.num_layer):
            pruned_embed = torch.mm(self.trvalembeddings[j], self.prunings[j])
            H_j = torch.cat((self.Xtrval, pruned_embed), dim=1)
            beta_j = Ridge(H_j, self.ytrval, self.reg)
            betas.append(beta_j)
        self.betas = betas

    def pruning(self,final_feat=None,group_size=None):
        self.prunings = [torch.eye(self.H) for i in range(self.num_layer)]
        Htrval = self.trvalembeddings[0]

        if self.feature_selection == None:
            pass

        elif self.feature_selection == 'Pearson':

            for i in range(self.num_layer):
                self.prunings[i] = feature_pccs(Htrval, self.ytrval,
                                                final_feat=final_feat).float()
                if i < (self.num_layer-1):
                    Htrval = self.trvalembeddings[i+1]
                    Htrval = torch.mm(Htrval,self.prunings[i])


        elif self.feature_selection == 'Variance':
            for i in range(self.num_layer):
                self.prunings[i] = feature_variance(Htrval,final_feat=final_feat).float()
                if i < (self.num_layer-1):
                    Htrval = self.trvalembeddings[i+1]
                    Htrval = torch.mm(Htrval,self.prunings[i])

        elif self.feature_selection == 'Embedded':
            for i in range(self.num_layer):
                self.prunings[i] = feature_embed(Htrval,self.ytrval,final_feat=final_feat).float()
                if i < (self.num_layer-1):
                    Htrval = self.trvalembeddings[i+1]
                    Htrval = torch.mm(Htrval,self.prunings[i])

        elif self.feature_selection == 'Wrapper':
            for i in range(self.num_layer):
                self.prunings[i] = feature_wrapper(
                    self.Xtrain, self.ytrain, Htrval[:self.Xtrain.shape[0],:],
                    self.Xval, self.yval, Htrval[self.Xtrain.shape[0]:,:],
                    group_size=group_size,final_feat=final_feat).float()
                if i < (self.num_layer-1):
                    Htrval = self.trvalembeddings[i+1]
                    Htrval = torch.mm(Htrval,self.prunings[i])

        print('pruning finished using %s'%(self.feature_selection))

    def predict(self,Xtest):
        embedding_prev = Xtest
        ytests = []
        for i in range(self.num_layer):
            weight_i = self.__getattribute__('weight_%d'%(i))
            bias_i = self.__getattribute__('bias_%d'%(i))
            embedding_i = self._activation(torch.mm(embedding_prev, weight_i) \
                             + torch.mm(torch.ones([Xtest.shape[0], 1]),bias_i))
            H_i = torch.cat((Xtest, embedding_i ), dim=1)
            pruned_embedding_i = torch.mm(embedding_i, self.prunings[i])

            ytest_i = torch.mm(H_i, self.betas[i])

            ytests.append(ytest_i)
            embedding_prev = pruned_embedding_i

        return ytests

    def _activation(self,x):
        assert torch.is_tensor(x)
        activation = self.activation.lower()
        assert activation in ['sigmoid','relu','tanh']
        return eval('torch.%s'%(activation))(x)

class GEdRVFL():
    def __init__(self, D_in, H,num_layer, adj_vec, weight_min=-1,weight_max=1, bias_range=(0,1),
                 activation='Sigmoid',reg=1, feature_selection=None):
        self.D_in = D_in
        self.H = H
        self.num_layer = num_layer
        self.a = torch.unsqueeze(torch.tensor(adj_vec),dim=0)
        self.reg = reg
        self.activation = activation
        for i in range(self.num_layer):
            if i == 0:
                self.__setattr__('weight_%d'%(i),weight_min + (weight_max - weight_min) * torch.rand(D_in, H))
            else:
                self.__setattr__('weight_%d' % (i), weight_min + (weight_max - weight_min) * torch.rand(H, H))
            self.__setattr__('bias_%d'%(i),bias_range[0] + (bias_range[1] - bias_range[0]) * torch.rand(1, H))
        print('Total layers: %d'%(self.num_layer))
        self.feature_selection =  feature_selection

    def feed_data(self,Xtrain, ytrain,  NXtrain, Xval=None, yval=None, NXval=None):
        self.Xtrain = Xtrain
        self.ytrain = torch.unsqueeze(ytrain, -1) if len(ytrain.shape) == 1 else ytrain
        if Xval == None:
            self.Xtrval = self.Xtrain
            self.ytrval = self.ytrain
            self.NXtrval = NXtrain
        else:
            self.Xval = Xval
            self.yval = torch.unsqueeze(yval, -1) if len(yval.shape) == 1 else yval
            self.Xtrval = torch.cat((self.Xtrain, self.Xval), dim=0)
            self.ytrval = torch.cat((self.ytrain, self.yval), dim=0)
            self.NXtrval = torch.cat((NXtrain,NXval),dim=1)
        N,B,P = self.NXtrval.shape
        embeddings = []
        for i in range(self.num_layer):
            weight_i = self.__getattribute__('weight_%d' % (i))
            bias_i = self.__getattribute__('bias_%d' % (i))
            if i == 0:
                NX = torch.reshape(self.NXtrval, (N, B * P))
                aX = torch.reshape(torch.squeeze(torch.mm(self.a, NX)), (B, P))
                aXW = self._activation(torch.mm(aX, weight_i) + torch.mm(torch.ones([B, 1]), bias_i))
                H = aXW
            else:
                H = self._activation(torch.mm(H_prev, weight_i) + torch.mm(torch.ones([B, 1]), bias_i))
            embeddings.append(H)
            H_prev = H
        self.trvalembeddings = embeddings

    def train(self):
        betas = []
        for j in range(self.num_layer):
            pruned_embed = torch.mm(self.trvalembeddings[j], self.prunings[j])
            H_j = torch.cat((self.Xtrval, pruned_embed), dim=1)
            beta_j = Ridge(H_j, self.ytrval, self.reg)
            betas.append(beta_j)
        self.betas = betas

    def pruning(self, final_feat=None, group_size=None):
        self.prunings = [torch.eye(self.H) for i in range(self.num_layer)]
        Htrval = self.trvalembeddings[0]

        if self.feature_selection == None:
            pass

        elif self.feature_selection == 'Pearson':

            for i in range(self.num_layer):
                self.prunings[i] = feature_pccs(Htrval, self.ytrval,
                                                final_feat=final_feat).float()
                if i < (self.num_layer-1):
                    Htrval = self.trvalembeddings[i+1]
                    Htrval = torch.mm(Htrval,self.prunings[i])


        elif self.feature_selection == 'Variance':
            for i in range(self.num_layer):
                self.prunings[i] = feature_variance(Htrval,final_feat=final_feat).float()
                if i < (self.num_layer-1):
                    Htrval = self.trvalembeddings[i+1]
                    Htrval = torch.mm(Htrval,self.prunings[i])

        elif self.feature_selection == 'Embedded':
            for i in range(self.num_layer):
                self.prunings[i] = feature_embed(Htrval,self.ytrval,final_feat=final_feat).float()
                if i < (self.num_layer-1):
                    Htrval = self.trvalembeddings[i+1]
                    Htrval = torch.mm(Htrval,self.prunings[i])

        elif self.feature_selection == 'Wrapper':
            for i in range(self.num_layer):
                self.prunings[i] = feature_wrapper(
                    self.Xtrain, self.ytrain, Htrval[:self.Xtrain.shape[0],:],
                    self.Xval, self.yval, Htrval[self.Xtrain.shape[0]:,:],
                    group_size=group_size,final_feat=final_feat).float()
                if i < (self.num_layer-1):
                    Htrval = self.trvalembeddings[i+1]
                    Htrval = torch.mm(Htrval,self.prunings[i])

        print('pruning finished using %s'%(self.feature_selection))

    def predict(self, Xtest, NXtest):
        N, B, P = NXtest.shape
        NXtest = torch.reshape(NXtest, (N, B * P))
        ytests = []
        for i in range(self.num_layer):
            weight_i = self.__getattribute__('weight_%d' % (i))
            bias_i = self.__getattribute__('bias_%d' % (i))
            if i==0:
                NX= torch.reshape(NXtest, (N, B * P))
                aX = torch.reshape(torch.squeeze(torch.mm(self.a, NX)), (B, P))
                aXW = self._activation(torch.mm(aX, weight_i) +
                                       torch.mm(torch.ones([B, 1]), bias_i))
                H = aXW
            else:
                H = self._activation(torch.mm(H_prev, weight_i) + torch.mm(torch.ones([B, 1]), bias_i))
            pruned_embedding_i = torch.mm(H, self.prunings[i])
            HX = torch.cat((Xtest, pruned_embedding_i), dim=1)
            ytest_i = torch.mm(HX, self.betas[i])
            ytests.append(ytest_i)
            H_prev = H

        return ytests

    def _activation(self,x):
        assert torch.is_tensor(x)
        activation = self.activation.lower()
        assert activation in ['sigmoid','relu','tanh']
        return eval('torch.%s'%(activation))(x)

class RANForecaster(object):
    def __init__(self, Xtrain, ytrain, Xvalid, yvalid, Xtest, ytest, adj_vec=None, SNXtrain=None, SNXval=None, SNXtest=None):
        self.Xtrain = torch.tensor(Xtrain, dtype=torch.float32)
        self.ytrain = torch.tensor(ytrain, dtype=torch.float32)
        self.Xvalid = torch.tensor(Xvalid, dtype=torch.float32)
        self.yvalid = torch.tensor(yvalid, dtype=torch.float32)
        self.Xtest = torch.tensor(Xtest, dtype=torch.float32)
        self.ytest = torch.tensor(ytest, dtype=torch.float32)
        self.adj_vec = adj_vec
        self.NXtrain = SNXtrain
        self.NXval = SNXval
        self.NXtest = SNXtest

    def RVFL_predict(self):
        D_in = self.Xtrain.shape[1]
        model = RVFL(D_in=D_in, H=D_in)
        model.train(torch.cat((self.Xtrain, self.Xvalid), dim=0), torch.cat((self.ytrain, self.yvalid), dim=0))
        ytest_rvfl = model.predict(self.Xtest)
        return ytest_rvfl

    def EdRVFL_predict(self, num_layer=3, ensemble='mean'):
        D_in = self.Xtrain.shape[1]
        model = EdRVFL(D_in=D_in, H=D_in, num_layer=num_layer)
        model.feed_data(self.Xtrain, self.ytrain, self.Xvalid, self.yvalid)
        model.pruning()
        model.train()
        ytest_ls = model.predict(self.Xtest)
        ytest_Edrvfl = torch.stack(ytest_ls, dim=0)
        if ensemble =='mean':
            ytest_Edrvfl_ensemble = torch.mean(ytest_Edrvfl, dim=0)
        else:
            ytest_Edrvfl_ensemble = torch.median(ytest_Edrvfl,dim=0)
        return ytest_Edrvfl_ensemble

    def GRVFL_predict(self):
        D_in = self.Xtrain.shape[1]
        model = GRVFL(D_in=D_in, H=D_in, adj_vec=self.adj_vec, weight_min=-1, weight_max=1, bias_range=(0, 1),
                      activation='Sigmoid', reg=1)
        model.train(torch.cat((self.Xtrain, self.Xvalid), dim=0), torch.cat((self.ytrain, self.yvalid), dim=0),
                    NXtrain=torch.cat((self.NXtrain, self.NXval), dim=1))
        ytest_GRVFL = model.predict(self.Xtest, self.NXtest)
        return ytest_GRVFL

    def GEdRVFL_predict(self,num_layer=3, final_feat=10, group_size=5,
                        feature_selection='Embedded', activation='Sigmoid',ensemble='mean'):
        D_in = self.Xtrain.shape[1]
        model = GEdRVFL(D_in=D_in, H=D_in, num_layer=num_layer, adj_vec=self.adj_vec, weight_min=-1, weight_max=1, bias_range=(0, 1),
                        activation=activation, reg=1, feature_selection=feature_selection)
        model.feed_data(self.Xtrain, self.ytrain, self.NXtrain, self.Xvalid, self.yvalid, self.NXval)
        model.pruning(final_feat=final_feat, group_size=group_size)
        model.train()
        ytest_GEdRVFL = model.predict(self.Xtest, self.NXtest)
        ytest_GEdRVFL = torch.stack(ytest_GEdRVFL, dim=0)
        if ensemble == 'mean':
            ytest_GEdRVFL_ensemble = torch.mean(ytest_GEdRVFL, dim=0)
        else:
            ytest_GEdRVFL_ensemble = torch.median(ytest_GEdRVFL, dim=0)
        return ytest_GEdRVFL_ensemble



if __name__ == '__main__':
    Xtrain = np.load('0.1-METR-LA\\train.npz')['x']
    Ytrain = np.load('0.1-METR-LA\\train.npz')['y']

    Xval = np.load('0.1-METR-LA\\val.npz')['x']
    Yval = np.load('0.1-METR-LA\\val.npz')['y']

    Xtest = np.load('0.1-METR-LA\\test.npz')['x']
    Ytest = np.load('0.1-METR-LA\\test.npz')['y']

    GW_LA_hat = torch.load('GW_prediction\\la_yhat_681.pth').cpu().numpy()
    GW_LA_true = torch.load('GW_prediction\\la_ytest_681.pth').cpu().numpy()

    DCRNN_LA_hat = np.transpose(np.load('DCRNN_prediction\\dcrnn_predictions_pytorch.npz')['prediction'][:, -743:-62, :], (1, 2, 0))
    DCRNN_LA_true = np.transpose(np.load('DCRNN_prediction\\dcrnn_predictions_pytorch.npz')['truth'][:, -743:-62, :], (1, 2, 0))

    sensor_ids, sensor_id_to_ind, adj_mx = load_pickle('0.1-METR-LA\\adj_mat_la.pkl')
    # load GNN data

    NXtrain = torch.tensor(Xtrain[..., 0]).permute(2, 0, 1).float()
    NXval = torch.tensor(Xval[..., 0]).permute(2, 0, 1).float()
    NXtest = torch.tensor(Xtest[..., 0]).permute(2, 0, 1).float()

    scaler = StandardScaler(mean=NXtrain.mean(), std=NXtrain[..., 0].std())
    SNXtrain = scaler.transform(NXtrain)
    SNXval = scaler.transform(NXval)
    SNXtest = scaler.transform(NXtest)

    loss_func = torch.nn.L1Loss()
    horizon = 12
    start_time = time.time()

    for node_i in range(100,102):  # 207):
        print('node_i:%d, running time:%.3f seconds' % (node_i, time.time() - start_time))
        min_x = np.min(Xtrain)
        max_x = np.max(Xtrain)
        X_train = (Xtrain[:, :, node_i, 0] - min_x) / (max_x - min_x)
        y_train = (Ytrain[:, :horizon, node_i, 0] - min_x) / (max_x - min_x)
        X_val = (Xval[:, :, node_i, 0] - min_x) / (max_x - min_x)
        y_val = (Yval[:, :horizon, node_i, 0] - min_x) / (max_x - min_x)
        X_test = (Xtest[:, :, node_i, 0] - min_x) / (max_x - min_x)
        y_test = (Ytest[:, :horizon, node_i, 0] - min_x) / (max_x - min_x)
        history = np.concatenate((y_train, y_val), axis=0)[:, 0]

        # gnn
        DCRNN_hat = (DCRNN_LA_hat[:, node_i, :] - min_x) / (max_x - min_x)
        GW_hat = (GW_LA_hat[:, node_i, :] - min_x) / (max_x - min_x)

        # rvfl
        RF = RANForecaster(X_train, y_train, X_val, y_val, X_test, y_test, adj_mx[node_i, :], SNXtrain, SNXval, SNXtest)
        rvfl_hat = np.array(RF.RVFL_predict())
        EdRVFL_hat = np.array(RF.EdRVFL_predict(num_layer=3, ensemble='mean'))
        GRVFL_hat = np.array(RF.GRVFL_predict())
        GEdRVFL_hat = np.array(RF.GEdRVFL_predict())

        #1-step forecast visualization
        plt.figure()
        plt.plot(y_test[:,0],'k',label='Actual')
        plt.plot(DCRNN_hat[:,0],'r',label='DCRNN')
        plt.plot(GW_hat[:,0],'r:',label='Graph WaveNet')
        plt.plot(GEdRVFL_hat[:,0],'b',label='GEdRvfl')
        plt.legend()
        plt.show()
