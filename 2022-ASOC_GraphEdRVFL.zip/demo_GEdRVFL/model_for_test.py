import torch
import numpy as np
import pandas as pd
import torch.nn as nn
import torch.nn.functional as F
import itertools
from ForecastUtils import TsMetric
from Utils import *

class MLP(nn.Module):
    def __init__(self, D_in, D_out, H1, H2, activation=3):  # framework definition
        super(MLP, self).__init__()
        self.linear1 = torch.nn.Linear(D_in, H1, bias=True)
        self.linear2 = torch.nn.Linear(H1, H2, bias=True)
        self.linear3 = torch.nn.Linear(H2, D_out, bias=True)
        self.activation = activation

    def forward(self, x):  # forward computing

        if self.activation == 1:
            y_pred = self.linear3(F.relu(self.linear2(F.relu(self.linear1(x)))))
        elif self.activation == 2:
            y_pred = self.linear3(torch.tanh(self.linear2(torch.tanh(self.linear1(x)))))
        else:
            y_pred = self.linear3(torch.sigmoid(self.linear2(torch.sigmoid(self.linear1(x)))))
        return y_pred

class LSTM(nn.Module):
    def __init__(self, num_layers, hidden_size,input_size, horizon):  # framework definition
        super(LSTM, self).__init__()
        self.rnn = nn.LSTM(input_size=input_size, hidden_size=hidden_size, num_layers=num_layers, batch_first=True)
        self.linear = nn.Linear(hidden_size, horizon)

    def forward(self, x):
        Hidden, _ = self.rnn(x)
        last_hidden = Hidden[:, -1, :]
        y_out = self.linear(last_hidden)
        return y_out

class DeepAR(nn.Module):

    def __init__(self,D_in, D_out, hidden_size, num_layers, likelihood="g"):
        super(DeepAR, self).__init__()

        # network
        # self.input_embed = nn.Linear(1, embedding_size)
        self.encoder = nn.LSTM(D_in, hidden_size, num_layers, bias=True, batch_first=True)
        if likelihood == "g":
            self.likelihood_layer = Gaussian(hidden_size, D_out)
        elif likelihood == "nb":
            self.likelihood_layer = NegativeBinomial(hidden_size, D_out)
        self.likelihood = likelihood

    def forward(self, X):
        _, (h, c) = self.encoder(X)  # X:batch_size, look_back order, 1
        hs = h[-1, :, :]  # h:num_Layer,batch,hidden_size
        hs = F.relu(hs)
        mu, sigma = self.likelihood_layer(hs)
        if self.likelihood == "g":
            yhat = gaussian_sample(mu, sigma)
        elif self.likelihood == "nb":
            alpha_t = sigma
            mu_t = mu
            yhat = negative_binomial_sample(mu_t, alpha_t)
        return yhat, mu, sigma
    # if without true value, use prediction

class TemporalConvNet(nn.Module):
    def __init__(self, L, num_inputs,num_outputs, num_channels, kernel_size=2,
                 dropout=0.2):  # num_input 是输入的channel数 也就是变量的维度  ； num_channels 是output的channel数，filter的数量 ；而序列的长度输入和输出是一样的
        super(TemporalConvNet, self).__init__()
        layers = []
        num_levels = len(num_channels)
        for i in range(num_levels):
            dilation_size = 2 ** i
            in_channels = num_inputs if i == 0 else num_channels[i - 1]
            out_channels = num_channels[i]
            layers += [TemporalBlock(in_channels, out_channels, kernel_size, stride=1, dilation=dilation_size,
                                     padding=(kernel_size - 1) * dilation_size, dropout=dropout)]

        self.network = nn.Sequential(*layers)
        self.dense = nn.Flatten()
        self.reg = nn.Linear(num_channels[-1] * L, num_outputs)

    def forward(self, x):
        tcn_out = self.network(x)
        dense_out = self.dense(tcn_out)
        tcn_predict = self.reg(dense_out)
        return tcn_predict

class RVFL():
    def __init__(self, D_in, H, weight_min=-1,weight_max=1, bias_range=(0,1),
                 activation='Sigmoid',reg=1):
        self.D_in = D_in
        self.H = H
        self.reg = reg
        self.activation = activation
        self.weight = weight_min + (weight_max-weight_min)*torch.rand(D_in, H)
        self.bias = bias_range[0] + (bias_range[1] - bias_range[0]) * torch.rand(1, H)

    def train(self, Xtrain, ytrain):
        self.Xtrain = Xtrain
        if len(ytrain.shape)==1:
            self.ytrain = torch.unsqueeze(ytrain,1)
        else:
            self.ytrain = ytrain

        self.embedding = self._activation(torch.mm(self.Xtrain, self.weight) \
                         + torch.mm(torch.ones([self.Xtrain.shape[0], 1]),self.bias))
        self.embedding = torch.cat((self.embedding, self.Xtrain), dim=1)
        self.beta = Ridge(self.embedding,self.ytrain,self.reg)

    def predict(self, Xtest):
        test_embedding = self._activation(torch.mm(Xtest, self.weight) + \
                         torch.mm(torch.ones([Xtest.shape[0], 1]),self.bias))
        test_embedding = torch.cat((test_embedding, Xtest),dim=1)
        ytest_hat = torch.mm(test_embedding,self.beta)
        return ytest_hat

    def _activation(self,x):
        assert torch.is_tensor(x)
        activation = self.activation.lower()
        assert activation in ['sigmoid','relu','tanh']
        return eval('torch.%s'%(activation))(x)

class GRVFL():
    def __init__(self, D_in, H, adj_vec, weight_min=-1,weight_max=1, bias_range=(0,1),
                 activation='Sigmoid',reg=1):
        self.D_in = D_in
        self.H = H
        self.a = torch.unsqueeze(torch.tensor(adj_vec),dim=0)
        self.reg = reg
        self.activation = activation
        self.weight = weight_min + (weight_max-weight_min)*torch.rand(D_in, H)
        self.bias = bias_range[0] + (bias_range[1] - bias_range[0]) * torch.rand(1, H)

    def train(self, Xtrain, ytrain, NXtrain):
        self.Xtrain = Xtrain
        if len(ytrain.shape) == 1:
            self.ytrain = torch.unsqueeze(ytrain, 1)
        else:
            self.ytrain = ytrain

        N,B,P = NXtrain.shape
        X = torch.reshape(NXtrain,(N,B*P))
        aX = torch.reshape(torch.squeeze(torch.mm(self.a,X)),(B,P))
        aXW = self._activation(torch.mm(aX, self.weight)+ torch.mm(torch.ones([B, 1]),self.bias))
        embedding = torch.cat((aXW, self.Xtrain), dim=1)
        self.beta = Ridge(embedding,self.ytrain,self.reg)

    def predict(self, Xtest, NXtest):
        N,B,P = NXtest.shape
        NXtest = torch.reshape(NXtest,(N,B*P))
        aX = torch.reshape(torch.squeeze(torch.mm(self.a, NXtest)), (B, P))
        aXW = self._activation(torch.mm(aX, self.weight) + torch.mm(torch.ones([B, 1]), self.bias))
        test_embedding = torch.cat((aXW, Xtest),dim=1)
        ytest_hat = torch.mm(test_embedding,self.beta)
        return ytest_hat

    def _activation(self,x):
        assert torch.is_tensor(x)
        activation = self.activation.lower()
        assert activation in ['sigmoid','relu','tanh']
        return eval('torch.%s'%(activation))(x)

class EdRVFL():
    def __init__(self,D_in, H, num_layer,weight_min=-1,weight_max=1, bias_range=(0,1),
                 activation='Sigmoid',reg=1, feature_selection=None):
        self.D_in = D_in
        self.H = H
        self.reg = reg
        self.activation = activation
        self.num_layer = num_layer  # 定义类的本身属性
        for i in range(self.num_layer):
            if i == 0:
                self.__setattr__('weight_%d'%(i),weight_min + (weight_max - weight_min) * torch.rand(D_in, H))
            else:
                self.__setattr__('weight_%d' % (i), weight_min + (weight_max - weight_min) * torch.rand(H, H))
            self.__setattr__('bias_%d'%(i),bias_range[0] + (bias_range[1] - bias_range[0]) * torch.rand(1, H))
        print('Total layers: %d'%(self.num_layer))
        self.feature_selection =  feature_selection

    def feed_data(self,Xtrain, ytrain, Xval=None, yval=None):
        self.Xtrain = Xtrain
        self.ytrain = torch.unsqueeze(ytrain, -1) if len(ytrain.shape) == 1 else ytrain
        if Xval == None:
            self.Xtrval = self.Xtrain
            self.ytrval = self.ytrain
        else:
            self.Xval = Xval
            self.yval = torch.unsqueeze(yval, -1) if len(yval.shape) == 1 else yval
            self.Xtrval = torch.cat((self.Xtrain, self.Xval), dim=0)
            self.ytrval = torch.cat((self.ytrain, self.yval), dim=0)

        embeddings = []
        embedding_prev = self.Xtrval
        for i in range(self.num_layer):
            weight_i = self.__getattribute__('weight_%d'%(i))
            bias_i = self.__getattribute__('bias_%d'%(i))
            embedding_i = self._activation(torch.mm(embedding_prev, weight_i) \
                             + torch.mm(torch.ones([self.Xtrval.shape[0], 1]),bias_i))
            embeddings.append(embedding_i)
            embedding_prev = embedding_i
        self.trvalembeddings = embeddings

    def train(self):
        betas = []
        for j in range(self.num_layer):
            pruned_embed = torch.mm(self.trvalembeddings[j], self.prunings[j])
            H_j = torch.cat((self.Xtrval, pruned_embed), dim=1)
            beta_j = Ridge(H_j, self.ytrval, self.reg)
            betas.append(beta_j)
        self.betas = betas

    def pruning(self,final_feat=None,group_size=None):
        self.prunings = [torch.eye(self.H) for i in range(self.num_layer)]
        Htrval = self.trvalembeddings[0]

        if self.feature_selection == None:
            pass

        elif self.feature_selection == 'Pearson':

            for i in range(self.num_layer):
                self.prunings[i] = feature_pccs(Htrval, self.ytrval,
                                                final_feat=final_feat).float()
                if i < (self.num_layer-1):
                    Htrval = self.trvalembeddings[i+1]
                    Htrval = torch.mm(Htrval,self.prunings[i])


        elif self.feature_selection == 'Variance':
            for i in range(self.num_layer):
                self.prunings[i] = feature_variance(Htrval,final_feat=final_feat).float()
                if i < (self.num_layer-1):
                    Htrval = self.trvalembeddings[i+1]
                    Htrval = torch.mm(Htrval,self.prunings[i])

        elif self.feature_selection == 'Embedded':
            for i in range(self.num_layer):
                self.prunings[i] = feature_embed(Htrval,self.ytrval,final_feat=final_feat).float()
                if i < (self.num_layer-1):
                    Htrval = self.trvalembeddings[i+1]
                    Htrval = torch.mm(Htrval,self.prunings[i])

        elif self.feature_selection == 'Wrapper':
            for i in range(self.num_layer):
                self.prunings[i] = feature_wrapper(
                    self.Xtrain, self.ytrain, Htrval[:self.Xtrain.shape[0],:],
                    self.Xval, self.yval, Htrval[self.Xtrain.shape[0]:,:],
                    group_size=group_size,final_feat=final_feat).float()
                if i < (self.num_layer-1):
                    Htrval = self.trvalembeddings[i+1]
                    Htrval = torch.mm(Htrval,self.prunings[i])

        print('pruning finished using %s'%(self.feature_selection))

    def predict(self,Xtest):
        embedding_prev = Xtest
        ytests = []
        for i in range(self.num_layer):
            weight_i = self.__getattribute__('weight_%d'%(i))
            bias_i = self.__getattribute__('bias_%d'%(i))
            embedding_i = self._activation(torch.mm(embedding_prev, weight_i) \
                             + torch.mm(torch.ones([Xtest.shape[0], 1]),bias_i))
            H_i = torch.cat((Xtest, embedding_i ), dim=1)
            pruned_embedding_i = torch.mm(embedding_i, self.prunings[i])

            ytest_i = torch.mm(H_i, self.betas[i])

            ytests.append(ytest_i)
            embedding_prev = pruned_embedding_i

        return ytests

    def _activation(self,x):
        assert torch.is_tensor(x)
        activation = self.activation.lower()
        assert activation in ['sigmoid','relu','tanh']
        return eval('torch.%s'%(activation))(x)

class GEdRVFL():
    def __init__(self, D_in, H,num_layer, adj_vec, weight_min=-1,weight_max=1, bias_range=(0,1),
                 activation='Sigmoid',reg=1, feature_selection=None):
        self.D_in = D_in
        self.H = H
        self.num_layer = num_layer
        self.a = torch.unsqueeze(torch.tensor(adj_vec),dim=0)
        self.reg = reg
        self.activation = activation
        for i in range(self.num_layer):
            if i == 0:
                self.__setattr__('weight_%d'%(i),weight_min + (weight_max - weight_min) * torch.rand(D_in, H))
            else:
                self.__setattr__('weight_%d' % (i), weight_min + (weight_max - weight_min) * torch.rand(H, H))
            self.__setattr__('bias_%d'%(i),bias_range[0] + (bias_range[1] - bias_range[0]) * torch.rand(1, H))
        print('Total layers: %d'%(self.num_layer))
        self.feature_selection =  feature_selection

    def feed_data(self,Xtrain, ytrain,  NXtrain, Xval=None, yval=None, NXval=None):
        self.Xtrain = Xtrain
        self.ytrain = torch.unsqueeze(ytrain, -1) if len(ytrain.shape) == 1 else ytrain
        if Xval == None:
            self.Xtrval = self.Xtrain
            self.ytrval = self.ytrain
            self.NXtrval = NXtrain
        else:
            self.Xval = Xval
            self.yval = torch.unsqueeze(yval, -1) if len(yval.shape) == 1 else yval
            self.Xtrval = torch.cat((self.Xtrain, self.Xval), dim=0)
            self.ytrval = torch.cat((self.ytrain, self.yval), dim=0)
            self.NXtrval = torch.cat((NXtrain,NXval),dim=1)
        N,B,P = self.NXtrval.shape
        embeddings = []
        for i in range(self.num_layer):
            weight_i = self.__getattribute__('weight_%d' % (i))
            bias_i = self.__getattribute__('bias_%d' % (i))
            if i == 0:
                NX = torch.reshape(self.NXtrval, (N, B * P))
                aX = torch.reshape(torch.squeeze(torch.mm(self.a, NX)), (B, P))
                aXW = self._activation(torch.mm(aX, weight_i) + torch.mm(torch.ones([B, 1]), bias_i))
                H = aXW
            else:
                H = self._activation(torch.mm(H_prev, weight_i) + torch.mm(torch.ones([B, 1]), bias_i))
            embeddings.append(H)
            H_prev = H
        self.trvalembeddings = embeddings

    def train(self):
        betas = []
        for j in range(self.num_layer):
            pruned_embed = torch.mm(self.trvalembeddings[j], self.prunings[j])
            H_j = torch.cat((self.Xtrval, pruned_embed), dim=1)
            beta_j = Ridge(H_j, self.ytrval, self.reg)
            betas.append(beta_j)
        self.betas = betas

    def pruning(self, final_feat=None, group_size=None):
        self.prunings = [torch.eye(self.H) for i in range(self.num_layer)]
        Htrval = self.trvalembeddings[0]

        if self.feature_selection == None:
            pass

        elif self.feature_selection == 'Pearson':

            for i in range(self.num_layer):
                self.prunings[i] = feature_pccs(Htrval, self.ytrval,
                                                final_feat=final_feat).float()
                if i < (self.num_layer-1):
                    Htrval = self.trvalembeddings[i+1]
                    Htrval = torch.mm(Htrval,self.prunings[i])


        elif self.feature_selection == 'Variance':
            for i in range(self.num_layer):
                self.prunings[i] = feature_variance(Htrval,final_feat=final_feat).float()
                if i < (self.num_layer-1):
                    Htrval = self.trvalembeddings[i+1]
                    Htrval = torch.mm(Htrval,self.prunings[i])

        elif self.feature_selection == 'Embedded':
            for i in range(self.num_layer):
                self.prunings[i] = feature_embed(Htrval,self.ytrval,final_feat=final_feat).float()
                if i < (self.num_layer-1):
                    Htrval = self.trvalembeddings[i+1]
                    Htrval = torch.mm(Htrval,self.prunings[i])

        elif self.feature_selection == 'Wrapper':
            for i in range(self.num_layer):
                self.prunings[i] = feature_wrapper(
                    self.Xtrain, self.ytrain, Htrval[:self.Xtrain.shape[0],:],
                    self.Xval, self.yval, Htrval[self.Xtrain.shape[0]:,:],
                    group_size=group_size,final_feat=final_feat).float()
                if i < (self.num_layer-1):
                    Htrval = self.trvalembeddings[i+1]
                    Htrval = torch.mm(Htrval,self.prunings[i])

        print('pruning finished using %s'%(self.feature_selection))

    def predict(self, Xtest, NXtest):
        N, B, P = NXtest.shape
        NXtest = torch.reshape(NXtest, (N, B * P))
        ytests = []
        for i in range(self.num_layer):
            weight_i = self.__getattribute__('weight_%d' % (i))
            bias_i = self.__getattribute__('bias_%d' % (i))
            if i==0:
                NX= torch.reshape(NXtest, (N, B * P))
                aX = torch.reshape(torch.squeeze(torch.mm(self.a, NX)), (B, P))
                aXW = self._activation(torch.mm(aX, weight_i) +
                                       torch.mm(torch.ones([B, 1]), bias_i))
                H = aXW
            else:
                H = self._activation(torch.mm(H_prev, weight_i) + torch.mm(torch.ones([B, 1]), bias_i))
            pruned_embedding_i = torch.mm(H, self.prunings[i])
            HX = torch.cat((Xtest, pruned_embedding_i), dim=1)
            ytest_i = torch.mm(HX, self.betas[i])
            ytests.append(ytest_i)
            H_prev = H

        return ytests

    def _activation(self,x):
        assert torch.is_tensor(x)
        activation = self.activation.lower()
        assert activation in ['sigmoid','relu','tanh']
        return eval('torch.%s'%(activation))(x)


# baseline： Naive, 24H_MA, MLP,LSTM,TCN,DeepAR     DCRNN,Graph WaveNet, RVFL, GRVFL   EdRVFL, GEdRVFL,GEdRVFL+FS+BAO


