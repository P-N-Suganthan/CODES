import pickle
import torch
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from scipy.stats import pearsonr
from sklearn.ensemble import RandomForestRegressor
import torch.nn as nn
from torch.nn.utils import weight_norm
import matplotlib.pyplot as plt
import time

def Ridge(h,y,reg=1):
    assert h.shape[0] == y.shape[0]
    assert len(h.shape) == 2 and len(y.shape) == 2
    if h.shape[0] > h.shape[1]:
        beta = torch.pinverse((reg * torch.eye(h.shape[1]) + torch.mm(h.t(), h))).mm(h.t()).mm(y)
    else:
        beta = h.t().mm(torch.pinverse(reg * torch.eye(h.shape[0]) + torch.mm(h, h.t()))).mm(y)
    return beta

def load_pickle(pickle_file):
    try:
        with open(pickle_file, 'rb') as f:
            pickle_data = pickle.load(f)
    except UnicodeDecodeError as e:
        with open(pickle_file, 'rb') as f:
            pickle_data = pickle.load(f, encoding='latin1')
    except Exception as e:
        print('Unable to load data ', pickle_file, ':', e)
        raise
    return pickle_data

def add_spatio(X,a,NX):
    N,B,P = NX.shape
    assert X.shape[0]==B and X.shape[1]==P and a.shape[0]==1 and a.shape[1]==N
    NX = torch.reshape(NX, (N, B * P))
    aX = torch.reshape(torch.squeeze(torch.mm(a, NX)), (B, P))
    return torch.cat((X, aX),dim=-1)

def feature_pccs(X,y,final_feat=10): #X,y should be tensor
    B,P = X.shape
    assert y.shape[0] == B
    y = torch.squeeze(y)
    pccs = []
    for i in range(P):
        x = X[:,i]
        pccs.append(abs(np.corrcoef(x, y)[0,1]))
    rank = np.array(pccs).argsort()[0:final_feat]
    select_vec = torch.tensor([1 if i in rank else 0 for i in range(P)])
    pruning_mx = torch.diag(select_vec)
    return pruning_mx

def feature_variance(X,final_feat=10):
    B,P = X.shape
    vars = []
    for i in range(P):
        x = X[:,i]
        vars.append(torch.var(x))
    rank = np.array(vars).argsort()[0:final_feat]
    select_vec = torch.tensor([1 if i in rank else 0 for i in range(P)])
    pruning_mx = torch.diag(select_vec)
    return pruning_mx

def feature_embed(X,y,final_feat=10):
    B,P = X.shape
    assert X.shape[0] == y.shape[0]
    regressor = RandomForestRegressor(n_estimators=200, random_state=0)
    regressor.fit(X, torch.squeeze(y))
    importances = np.array(list(regressor.feature_importances_))#每个节点的对应feature划分引起的带权不纯度下降值就是该节点对于其feature importance 的贡献。
    rank_embed = importances.argsort()[::-1][0:final_feat] #rank的输出就是最后的选择结果
    select_vec = torch.tensor([1 if i in rank_embed else 0 for i in range(P)])
    pruning_mx = torch.diag(select_vec)
    return pruning_mx

def feature_wrapper(Xtrain,ytrain,Htrain, Xval,yval,Hval,group_size, final_feat, run_times=50):
    B, P = Htrain.shape
    num_group = int(P/group_size)
    num_SLgroup = int(final_feat/group_size)
    group_idx = np.array([i for i in range(num_group)]*group_size)
    group_ = np.arange(num_group)
    feat_MSE= np.zeros(P)
    feat_counts = np.zeros(P)
    for i in range(run_times):
        np.random.shuffle(group_idx) #打乱对所有feat的分组
        np.random.shuffle(group_)  #打乱对组的选取
        selected_groups = group_[:num_SLgroup]
        feat_select = [idx for idx,i in enumerate(group_idx) if i in selected_groups]
        feat_counts += np.array([1 if i in feat_select else 0 for i in range(P)])

        Htrain_select = Htrain[:,feat_select]
        XHtrain = torch.cat((Xtrain,Htrain_select),dim=-1)
        weight = Ridge(XHtrain,ytrain)

        Hval_select = Hval[:,feat_select]
        XHval = torch.cat((Xval,Hval_select),dim=-1)
        yhat = torch.mm(XHval,weight)
        MSELOSS = torch.nn.functional.mse_loss(yhat,yval)
        feat_MSE += np.array([MSELOSS if i in feat_select else 0 for i in range(P)])

    feat_normMSE = feat_MSE/(feat_counts+0.001)
    #根据feat_norm来选择
    rank_wrapper = feat_normMSE.argsort()[0:final_feat] #rank的输出就是最后的选择结果
    select_vec = torch.tensor([1 if i in rank_wrapper else 0 for i in range(P)])
    pruning_mx = torch.diag(select_vec)
    return pruning_mx

class StandardScaler():
    """
    Standard the input
    """

    def __init__(self, mean, std):
        self.mean = mean
        self.std = std

    def transform(self, data):
        return (data - self.mean) / self.std

    def inverse_transform(self, data):
        return (data * self.std) + self.mean


















