function [c,ceq] = mycon(x,func,Xmin,Xmax,ratio)

% x=((x<=Xmax).*(x>=Xmin)).*x+(x<Xmin).*(2*Xmin-x)+(x>Xmax).*(-x+2*Xmax);
x=((x<=Xmax).*(x>=Xmin)).*x+(x<Xmin).*(Xmin+mod(Xmin-x,Xmax-Xmin))+(x>Xmax).*(Xmax-mod(x-Xmax,Xmax-Xmin));

gn=[9,2,0,6,2,2,8,2,4,6,0,1,0,0,0,38,0,13,5,6,1,1,2,2];
gn=gn(func);
hn=[0,0,1,0,3,0,0,0,0,0,1,0,3,3,2,0,4,0,0,14,5,19,4,0];
hn=hn(func);
% if sum((x<Xmin)+(x>Xmax))==0

    [f,c,ceq]=fcnsuite_func(x,func);
    
    % c=c+1e-20;
%     ceq=(abs(ceq)-1e-4);
    ceq=(abs(ceq)<=1e-4).*0+(ceq>1e-4).*(ceq-1e-4)+(ceq<-1e-4).*(ceq+1e-4);
%     c=[c;ceq];ceq=[];
%     c=100.*ratio'.*c;

    c=100.*ratio(1:gn)'.*c;     
    ceq=100.*ratio((gn+1):(gn+hn))'.*ceq;
    c=c+1e-10;
    ceq=ceq+1e-10;
% c=c+1e-4;
% ceq=ceq;
%     ceq=(ceq>0).*ceq;

    
%     c=sum((c>0).*c);
% sum((c>0).*c)
% else
%     f=1e+6.*(1+sum((x<Xmin).*(Xmin-x)+(x>Xmax).*(x-Xmax)));
%     c=f.*ones(gn,1);ceq=f.*ones(hn,1);
% end

%cec2006 bak
% ceq=(abs(ceq)-1e-4);
%     c=100.*ratio(1:gn)'.*c;     
%     ceq=100.*ratio((gn+1):(gn+hn))'.*ceq;
% c=c+1e-200;
% ceq=ceq+1e-200;
%     ceq=(ceq>0).*ceq;