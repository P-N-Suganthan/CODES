function [gbest,gbestval,fitcount,fit_cut,get_flag]= DMS_PSO_cons_subswarm_local6(fhd,err,Max_FES,group_num,Particle_Number,Dimension,Xmin,Xmax,VRmin,VRmax,varargin)
% global fitcount
rand('state',sum(100*clock));
group_ps=Particle_Number;
ps=group_num*group_ps;
D=Dimension;
cc=[1.49445 1.49445];   %acceleration constants
iwt=0.729;
% iwt=0.9-(1:me)*(0.7/me);
% iwt=0.9;
if length(VRmin)==1
    VRmin=repmat(VRmin,1,D);
    VRmax=repmat(VRmax,1,D);
end

VRmin=repmat(VRmin,ps,1);
VRmax=repmat(VRmax,ps,1);

if length(Xmin)==1
    Xmin=repmat(Xmin,1,D);
    Xmax=repmat(Xmax,1,D);
end
Xmin=repmat(Xmin,ps,1);
Xmax=repmat(Xmax,ps,1);

mv=0.5*(Xmax-Xmin);
Vmin=-mv;
Vmax=-Vmin;

pos=Xmin+(Xmax-Xmin).*rand(ps,D);

for i=1:ps;
e(i,:)=feval(fhd,pos(i,:),varargin{:});
end

fitcount=ps;
vel=Vmin+2.*Vmax.*rand(ps,D);%initialize the velocity of the particles
pbest=pos;
pbestval=e; %initialize the pbest and the pbest's fitness value
nn=length(e(1,:));
g_max=max(e(:,2:nn));
ratio=1./((g_max==0)+g_max);
ratio=ratio./sum(ratio);

c_infeas=e(:,2:nn)>0;
n_infeas=sum(c_infeas);
cons_imp=n_infeas/ps;
f_imp=1-mean(cons_imp);
        if sum(cons_imp)~=0
        cons_imp=mean(cons_imp).*cons_imp./sum(cons_imp);
        else
        cons_imp=zeros(1,nn-1);    
        end
p_imp=f_imp;
for i=1:(nn-1)
    p_imp=[p_imp,p_imp(i)+cons_imp(i)];
end
pos_rem=1:ps;
for i=1:group_num
    tmp=find(p_imp>=rand);f_num(i)=tmp(1);
    [tmp,tmpid]=sort(e(pos_rem,f_num(i)));
    group_id(i,:)=pos_rem(tmpid([1,length(pos_rem)-group_ps+2:length(pos_rem)]));
    pos_rem=pos_rem(tmpid(2:length(pos_rem)-group_ps+1));
    if pbestval(group_id(i,group_ps),f_num(i))==0
        f_num(i)=1;
    end
    pos_group(group_id(i,:))=i;
    gbestid=group_id(i,1);
    gbest(i,:)=pbest(gbestid,:);%initialize the gbest and the gbest's fitness value
    gbestval(i,:)=pbestval(gbestid,:);    
end
get_flag=0;
i=0;
best_pos=gbest(1,:);bestval=gbestval(1,:);
while fitcount<0.7.*Max_FES
%     iwt=0.9-0.5.*fitcount/0.7/Max_FES;iwt=0.729;
    i=i+1;
    for k=1:ps
    aa(k,:)=cc(1).*rand(1,D).*(pbest(k,:)-pos(k,:))+cc(2).*rand(1,D).*(gbest(pos_group(k),:)-pos(k,:));
    vel(k,:)=iwt.*vel(k,:)+aa(k,:); 
    vel(k,:)=(vel(k,:)>mv(k,:)).*mv(k,:)+(vel(k,:)<=mv(k,:)).*vel(k,:); 
    vel(k,:)=(vel(k,:)<(-mv(k,:))).*(-mv(k,:))+(vel(k,:)>=(-mv(k,:))).*vel(k,:);
    pos1(k,:)=pos(k,:)+vel(k,:); 
    keep_d=rand(1,D)<0.5;
    pos(k,:)=keep_d.*pbest(k,:)+(1-keep_d).*pos1(k,:); 
%     pos(k,:)=((pos(k,:)<=VRmax(1,:)).*(pos(k,:)>=VRmin(1,:))).*pos(k,:)+(pos(k,:)<VRmin(1,:)).*(2*VRmin(1,:)-pos(k,:))+(pos(k,:)>VRmax(1,:)).*(-pos(k,:)+2*VRmax(1,:));
    if (sum(pos(k,:)>VRmax(k,:))+sum(pos(k,:)<VRmin(k,:)))==0;
    e(k,:)=feval(fhd,pos(k,:),varargin{:});
    fitcount=fitcount+1;

%     tmp=((e(k,f_num(pos_group(k)))<=pbestval(k,f_num(pos_group(k))))&(e(k,1)<pbestval(k,1)));
    tmp=(e(k,f_num(pos_group(k)))<pbestval(k,f_num(pos_group(k))))...
        |((sum(ratio.*e(k,2:nn))<=sum(ratio.*pbestval(k,2:nn)))&(e(k,1)<pbestval(k,1)));
%         |(sum(ratio.*e(k,2:nn))<sum(ratio.*pbestval(k,2:nn)));
%     tmp=tmp|((e(k,1)<pbestval(k,1))&(sum(e(k,2:nn))==sum(pbestval(k,2:nn))));

%     tmp=((e(k,f_num(pos_group(k)))<pbestval(k,f_num(pos_group(k))))&(f_num(pos_group(k))~=1))...
%         |((sum(ratio.*e(k,2:nn))<=sum(ratio.*pbestval(k,2:nn)))&(e(k,1)<pbestval(k,1)))...
%         |((sum(ratio.*e(k,2:nn))<sum(ratio.*pbestval(k,2:nn)))&(f_num(pos_group(k))==1));
    
    pbest(k,:)=(1-tmp).*pbest(k,:)+tmp.*pos(k,:);
    pbestval(k,:)=(1-tmp).*pbestval(k,:)+tmp.*e(k,:);%update the pbest
    if ((pbestval(k,f_num(pos_group(k)))<gbestval(pos_group(k),f_num(pos_group(k)))))...%&(f_num(pos_group(k))~=1))...
        |((sum(pbestval(k,2:nn))<=sum(gbestval(pos_group(k),2:nn)))&(pbestval(k,1)<gbestval(pos_group(k),1)))...
%         |((sum(ratio.*pbestval(k,2:nn))<sum(ratio.*gbestval(pos_group(k),2:nn)))&(f_num(pos_group(k))==1))
%     if ((sum(pbestval(k,f_num(pos_group(k))))<=sum(gbestval(pos_group(k),f_num(pos_group(k)))))&(pbestval(k,1)<gbestval(pos_group(k),1)))
        gbest(pos_group(k),:)=pbest(k,:);
        gbestval(pos_group(k),:)=pbestval(k,:);
    end
    
    end
    
    end
    
    tmp=max(e(:,2:nn));
    g_max=(tmp<=g_max).*g_max+(tmp>g_max).*tmp;

    if mod(i,100)==0
        ratio=1./((g_max==0)+g_max);
        ratio=ratio./sum(ratio);
        
        group_id=[];gbest=[];gbestval=[];
        c_infeas=e(:,2:nn)>0;
        n_infeas=sum(c_infeas);
        cons_imp=n_infeas/ps;
        tmp=sum(sum(pbestval(:,2:nn),2)==0);tmp=tmp/ps;
        tmp=1-mean(cons_imp);
        f_imp=tmp;
        if sum(cons_imp)~=0
        cons_imp=(1-tmp).*cons_imp./sum(cons_imp);
        else
        cons_imp=zeros(1,nn-1);    
        end
        p_imp=f_imp;
        for k=1:(nn-1)
            p_imp=[p_imp,p_imp(k)+cons_imp(k)];
        end
        pos_rem=1:ps;
%         rc=randperm(ps);
        for k=1:group_num
            tmp=find(p_imp>rand);
            f_num(k)=tmp(1); %if rand<0.5,f_num(k)=1;end

            [tmp,tmpid]=sort(e(pos_rem,f_num(k)));
            group_id(k,:)=pos_rem(tmpid([1,length(pos_rem)-group_ps+2:length(pos_rem)]));
            pos_rem=pos_rem(tmpid(2:length(pos_rem)-group_ps+1));
%             group_id(k,:)=rc((k*group_ps-group_ps+1):(k*group_ps));
            pos_group(group_id(k,:))=k;
            gbestid=group_id(k,1);
            gbest(k,:)=pbest(gbestid,:);%initialize the gbest and the gbest's fitness value
            gbestval(k,:)=pbestval(gbestid,:);    
        end
% pos((ps-group_ps+1):ps,:)=Xmin((ps-group_ps+1):ps,:)+(Xmax((ps-group_ps+1):ps,:)-Xmin((ps-group_ps+1):ps,:)).*rand(group_ps,D);
% vel((ps-group_ps+1):ps,:)=Vmin((ps-group_ps+1):ps,:)+2.*Vmax((ps-group_ps+1):ps,:).*rand(group_ps,D);
    end
    
 
    for k=1:group_num
        if (f_num~=1)&(sum(pbestval(group_id(k,:),f_num(k)))==0)
            tmp=find(p_imp>rand);
            f_num(k)=tmp(1); 
        end
     end


    if 0&mod(i,500)==0&fitcount>0.5*Max_FES

    i,
    if min(sum(pbestval(:,2:nn),2))==0
    f_tmp=find(sum(pbestval(:,2:nn),2)==0);
    [tmp,tmpid]=sort(pbestval(f_tmp));
    tmpid=f_tmp(tmpid(1));
    pbestval(tmpid,1),sum(ratio.*pbestval(tmpid,2:nn))
    x0=pbest(tmpid,:);

    
    else
    [tmp,tmpid]=sort(sum(pbestval(:,2:nn),2));
    tmpid=tmpid(1);
    x0=pbest(tmpid,:);
    pbestval(tmpid,1)
    end
% bestval
    [tmp,tmpid]=sort(pbestval(:,1));
    tmpid=tmpid(1);
    rc=tmpid;rrr=randperm(group_num);
    rc=randperm(ps);
    for k=1:5
        x0=pbest(rc(k),:);%save x0 x0;
%         x0=gbest(rrr(k),:);
        opts=optimset('largescale','off','display','off','MaxFunEvals',1000,'TolCon',1e-200);%,'TolX',1e-20,'TolFun',1e-4,'DiffMinChange',1e-20,'DiffMaxChange',1e-4
        [xx,fval,exitflag,output] = fmincon('myfun',x0,[],[],[],[],VRmin(1,:),VRmax(1,:),'mycon', opts,varargin{:},VRmin(1,:),VRmax(1,:),ratio);
        fitcount=fitcount+output.funcCount;
%         xx=((xx<=VRmax(1,:)).*(xx>=VRmin(1,:))).*xx+(xx<VRmin(1,:)).*(2*VRmin(1,:)-xx)+(xx>VRmax(1,:)).*(-xx+2*VRmax(1,:));
        xx=((xx<=VRmax(1,:)).*(xx>=VRmin(1,:))).*xx+(xx<VRmin(1,:)).*(VRmin(1,:)+mod(VRmin(1,:)-xx,VRmax(1,:)-VRmin(1,:)))+(xx>VRmax(1,:)).*(VRmax(1,:)-mod(xx-VRmax(1,:),VRmax(1,:)-VRmin(1,:)));
        fval=feval(fhd,xx,varargin{:})
        dis=sum((pbest-repmat(xx,ps,1)).^2,2);[tmp,tmpid]=sort(dis);rc(k)=tmpid(1);
        if ((fval(1)<pbestval(rc(k),1))&(sum(fval(2:nn)>0)==0))|(sum(ratio.*fval(2:nn))<sum(ratio.*pbestval(rc(k),2:nn)))
            pbest(rc(k),:)=xx;
            pbestval(rc(k),:)=fval;
            if ((sum(pbestval(rc(k),2:nn))==sum(gbestval(pos_group(rc(k)),2:nn)))&(pbestval(rc(k),1)<gbestval(pos_group(rc(k)),1)))...
                |(sum(ratio.*pbestval(rc(k),2:nn))<sum(ratio.*gbestval(pos_group(rc(k)),2:nn)));%...
            gbest(pos_group(rc(k)),:)=pbest(rc(k),:);
            gbestval(pos_group(rc(k)),:)=pbestval(rc(k),:);
            end
        end
    end
%     max(max(pos)-min(pos)),sum(sum(pbestval(:,2:nn),2)==0)

    end

if mod(i,200)==0
    i
%     gbest
    bestval,best_pos
end
if min(sum(pbestval(:,2:nn),2))==0
    f_tmp=find(sum(repmat(ratio,ps,1).*pbestval(:,2:nn),2)==0);
    [tmp,tmpid]=sort(pbestval(f_tmp));
    if (sum(ratio.*pbestval(f_tmp(tmpid(1)),2:nn),2)<=sum(ratio.*bestval(2:nn)))&(pbestval(f_tmp(tmpid(1)),1)<bestval(1))
        best_pos=pbest(f_tmp(tmpid(1)),:);
        bestval=pbestval(f_tmp(tmpid(1)),:);
%     else
%         pbest(f_tmp(tmpid(1)),:)=best_pos;
%         pbestval(f_tmp(tmpid(1)),:)=bestval;
    end
else
    [tmp,tmpid]=sort(sum(repmat(ratio,ps,1).*pbestval(:,2:nn),2));
    best_pos=pbest(tmpid(1),:);
    bestval=pbestval(tmpid(1),:);
    if sum(ratio.*pbestval(tmpid(1),2:nn),2)<=sum(ratio.*bestval(2:nn))
        best_pos=pbest(tmpid(1),:);
        bestval=pbestval(tmpid(1),:);
%    else
%         pbest(tmpid(1),:)=best_pos;
%         pbestval(tmpid(1),:)=bestval;    
    end
end

end
if min(sum(pbestval(:,2:nn),2))==0
    f_tmp=find(sum(repmat(ratio,ps,1).*pbestval(:,2:nn),2)==0);
    [tmp,tmpid]=sort(pbestval(f_tmp));
    gbest=pbest(f_tmp(tmpid(1)),:);
    gbestval=pbestval(f_tmp(tmpid(1)),:);
else
    [tmp,tmpid]=sort(sum(repmat(ratio,ps,1).*pbestval(:,2:nn),2));
    gbest=pbest(tmpid(1),:);
    gbestval=pbestval(tmpid(1),:);
end
% gbest=best_pos;gbestval=bestval;pbest(1,:)=best_pos;pbestval(1,:)=bestval;
while fitcount<=Max_FES
    
    i=i+1;
    for k=1:ps
    aa(k,:)=cc(1).*rand(1,D).*(pbest(k,:)-pos(k,:))+cc(2).*rand(1,D).*(gbest-pos(k,:));
    vel(k,:)=iwt.*vel(k,:)+aa(k,:); 
    vel(k,:)=(vel(k,:)>mv(k,:)).*mv(k,:)+(vel(k,:)<=mv(k,:)).*vel(k,:); 
    vel(k,:)=(vel(k,:)<(-mv(k,:))).*(-mv(k,:))+(vel(k,:)>=(-mv(k,:))).*vel(k,:);
    pos(k,:)=pos(k,:)+vel(k,:); 
%     if (sum(pos(k,:)>VRmax(k,:))+sum(pos(k,:)<VRmin(k,:)))==0;
    pos(k,:)=((pos(k,:)<=VRmax(1,:)).*(pos(k,:)>=VRmin(1,:))).*pos(k,:)+(pos(k,:)<VRmin(1,:)).*(2*VRmin(1,:)-pos(k,:))+(pos(k,:)>VRmax(1,:)).*(-pos(k,:)+2*VRmax(1,:));
    e(k,:)=feval(fhd,pos(k,:),varargin{:});
    fitcount=fitcount+1;
    tmp=(sum(pbestval(k,2:nn))==sum(e(k,2:nn))).*(e(k,1)<pbestval(k,1))|(sum(ratio.*e(k,2:nn))<sum(ratio.*pbestval(k,2:nn)));
    pbest(k,:)=(1-tmp).*pbest(k,:)+tmp.*pos(k,:);
    pbestval(k,:)=(1-tmp).*pbestval(k,:)+tmp.*e(k,:);%update the pbest
    if (sum(pbestval(k,2:nn))==sum(gbestval(2:nn))).*(pbestval(k,1)<gbestval(1))|(sum(ratio.*pbestval(k,2:nn))<sum(ratio.*gbestval(2:nn)))
    gbest=pbest(k,:);
    gbestval=pbestval(k,:);
    end
%     end
    
    end
    if 0&mod(i,500)==0
        i,fitcount
        opts=optimset('largescale','off','display','off','MaxFunEvals',5000,'TolCon',1e-200);%,'TolFun',1e-4,,'DiffMinChange',1e-20,'DiffMinChange',1e-10,'DiffMaxChange',1e-4
        [xx,fval,exitflag,output] = fmincon('myfun',gbest,[],[],[],[],VRmin(1,:),VRmax(1,:),'mycon', opts,varargin{:},VRmin(1,:),VRmax(1,:),ratio);
        fitcount=fitcount+output.funcCount;
%         xx=((xx<=VRmax(1,:)).*(xx>=VRmin(1,:))).*xx+(xx<VRmin(1,:)).*(2*VRmin(1,:)-xx)+(xx>VRmax(1,:)).*(-xx+2*VRmax(1,:));
        xx=((xx<=VRmax(1,:)).*(xx>=VRmin(1,:))).*xx+(xx<VRmin(1,:)).*(VRmin(1,:)+mod(VRmin(1,:)-xx,VRmax(1,:)-VRmin(1,:)))+(xx>VRmax(1,:)).*(VRmax(1,:)-mod(xx-VRmax(1,:),VRmax(1,:)-VRmin(1,:)));
        fval=feval(fhd,xx,varargin{:})
%         fitcount=fitcount+1;
        if ((fval(1)<gbestval(1))&(sum(fval(2:nn)>0)==0))...
                |(sum(ratio.*fval(2:nn))<sum(ratio.*gbestval(2:nn)))
            gbest=xx;
            gbestval=feval(fhd,xx,varargin{:});
        end
        gbestval(1),sum(gbestval(2:nn))
    end

end



%         opts=optimset('largescale','off','display','final','MaxFunEvals',10000,'TolCon',1e-20,'DiffMinChange',1e-20,'DiffMaxChange',1e-10);%,'TolFun',1e-4,,'DiffMinChange',1e-20
%         [xx,fval,exitflag,output] = fmincon('myfun',gbest,[],[],[],[],VRmin(1,:),VRmax(1,:),'mycon', opts,varargin{:},VRmin(1,:),VRmax(1,:),ratio);
%         fitcount=fitcount+output.funcCount;
%         xx=((xx<=VRmax(1,:)).*(xx>=VRmin(1,:))).*xx+(xx<VRmin(1,:)).*(2*VRmin(1,:)-xx)+(xx>VRmax(1,:)).*(-xx+2*VRmax(1,:));
%         fval=feval(fhd,xx,varargin{:})
%         if (fval(1)<gbest(1))&(sum(ratio.*fval(2:nn))==0)
%             gbest=xx;
%             gbestval=feval(fhd,xx,varargin{:});
%         end

        gbestval=gbestval(1);%fitcount
%     plot(pos(:,D-1),pos(:,D),'b*');
%     hold on
%     plot(gbest(:,D-1),gbest(:,D),'r*');   
%     hold off
%     axis([VRmin(1,D-1),VRmax(1,D-1),VRmin(1,D),VRmax(1,D)])
%     title(['PSO: ',num2str(i),' generations, Gbestval=',num2str(min(gbestval))]);  
%     drawnow




