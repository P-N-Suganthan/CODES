%cec2006_test
clear all
warning off
global initial_flag f_hist v_hist f_keep x_keep c_keep v_keep cc fit_cut get_flag feasible_flag fit_feasible count
%bounds:
Xmin1=[0 0 0 0 0 0 0 0 0 0 0 0 0];
Xmax1=[1 1 1 1 1 1 1 1 1 100 100 100 1];
Xmin2=zeros(1,20)+1e-100;
Xmax2=10.*ones(1,20);
Xmin3=zeros(1,10);
Xmax3=ones(1,10);
Xmin4=[78 33 27 27 27];
Xmax4=[102 45 45 45 45];
Xmin5=[0 0 -0.55 -0.55];
Xmax5=[1200 1200 0.55 0.55];
Xmin6=[13 0];
Xmax6=[100 100];
Xmin7=-10.*ones(1,10);
Xmax7=10.*ones(1,10);
Xmin8=[0 0];
Xmax8=[10 10];
Xmin9=-10.*ones(1,7);
Xmax9=10.*ones(1,7);
Xmin10=[100 1000 1000 10 10 10 10 10];
Xmax10=[10000 10000 10000 1000 1000 1000 1000 1000];
Xmin11=[-1 -1];
Xmax11=[1 1];
Xmin12=[0 0 0];
Xmax12=[10 10 10];
Xmin13=[-2.3 -2.3 -3.2 -3.2 -3.2];
Xmax13=[2.3 2.3 3.2 3.2 3.2];
Xmin14=zeros(1,10)+1e-100;
Xmax14=10.*ones(1,10);
Xmin15=[0 0 0];
Xmax15=[10 10 10];
Xmin16=[704.4148,68.6,0,193,25];
Xmax16=[906.3855,288.88,134.75,287.0966,84.1988];
Xmin17=[0 0 340 340 -1000 0];
Xmax17=[400 1000 420 420 1000 0.5236];
Xmin18=[-10 -10 -10 -10 -10 -10 -10 -10 0];
Xmax18=[10 10 10 10 10 10 10 10 20];
Xmin19=zeros(1,15);
Xmax19=10.*ones(1,15);
Xmin20=zeros(1,24);Xmin20(1)=1e-100;Xmin20(24)=1e-100;
Xmax20=10.*ones(1,24);
Xmin21=[0 0 0 100 6.3 5.9 4.5];
Xmax21=[1000 40 40 300 6.7 6.4 6.25];
Xmin22=[0 0 0 0 0 0 0 100 100 100.01 100 100 0 0 0 0.01 0.01 -4.7 -4.7 -4.7 -4.7 -4.7];
Xmax22=[20000 1e+6 1e+6 1e+6 4e+7 4e+7 4e+7 299.99 399.99 300 400 600 500 500 500 300 400 6.25 6.25 6.25 6.25 6.25];
Xmin23=[0 0 0 0 0 0 0 0 0.01];
Xmax23=[300 300 100 200 100 300 100 200 0.03];
Xmin24=[0 0];
Xmax24=[3 4];

Max_FES=500000;
Dimension=[13 20 10 5 4 2 10 2 7 8 2 3 5 10 3 5 6 9 15 24 7 22 9 2];
err=1e-4;

% best_known=[-15.00000 -0.803619 -1 -30665.538672 5126.498110 -6961.813800 24.306209 -0.095825 680.630057 7049.330700 0.75 -1 0.0539498 -47.764411 961.715172 -1.905155 8876.980680 -0.865735 32.655593 0.096737 193.778349 382.902205 -400.002500 -5.508013];
best_known=[-15.0000000000 -0.8036191042 -1.0005001000  -30665.5386717834  5126.4967140071  -6961.8138755802  24.3062090681  -0.0958250415  680.6300573745  7049.2480205286  0.7499000000  -1.0000000000  0.0539415140  -47.7648884595 961.7150222899  -1.9051552586  8853.5396748064  -0.8660254038 32.6555929502  0.2049794002  193.7245100700  236.4309755040  -400.0551000000  -5.5080132716 ];

runs=25;
for func_num=1:24
    D=Dimension(func_num);
    eval(['Xmin=Xmin' int2str(func_num) ';']);
    eval(['Xmax=Xmax' int2str(func_num) ';']);
for run=1:runs
        func_num,run
        initial_flag=0;f_hist=[];f_keep=[];v_hist=[];x_keep=[];c_keep=[];v_keep=[];cc=[];fit_cut=[]; get_flag=[];feasible_flag =[];fit_feasible=[];
        tic
        [gbest,gbestval,fitcount]= DMS_PSO_cons_subswarm_local6('fcn_func',err,Max_FES,10,3,D,Xmin,Xmax,Xmin,Xmax,func_num);
        gbestval=gbestval-best_known(func_num);
        t_res(func_num,run)=toc;
        eval(['gbest' int2str(func_num) '_res(run,:)=gbest;']);
        eval(['f_keep' int2str(func_num) '_res(run,:)=f_keep;']);
        eval(['v_keep' int2str(func_num) '_res(run,:)=v_keep;']);
        eval(['cc' int2str(func_num) '_res(run,:)=cc;']);
        gbestval_res(func_num,run)=gbestval;
        fitcount_res(func_num,run)=fitcount;
        fitcut_res(func_num,run)=fit_cut;
        get_flag_res(func_num,run)=get_flag;
        fitfeas_res(func_num,run)=fit_feasible;
        feas_flag_res(func_num,run)=feasible_flag;
        eval(['save result/f_hist' int2str(func_num) '_' int2str(run) ' f_hist']);
        eval(['save result/v_hist' int2str(func_num) '_' int2str(run) ' v_hist']);
        eval(['save result/x_keep' int2str(func_num) '_' int2str(run) ' x_keep']);
        eval(['save result/c_keep' int2str(func_num) '_' int2str(run) ' c_keep']);
        f_hist(length(f_hist))
               
        save result/cec2006_test_2_12
    end
    
end

