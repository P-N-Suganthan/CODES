function ff=fcn_func(x,func)
global initial_flag f_hist v_hist f_keep x_keep c_keep v_keep cc fit_cut get_flag feasible_flag fit_feasible count
persistent  fhd gn hn best_known keep_id bestval bestval_c best bestval_g bestval_h


if initial_flag==0
if func==1,fhd='g01';
elseif func==2,fhd='g02';
elseif func==3,fhd='g03'; 
elseif func==4,fhd='g04';
elseif func==5,fhd='g05';
elseif func==6,fhd='g06';
elseif func==7,fhd='g07';
elseif func==8,fhd='g08';
elseif func==9,fhd='g09';
elseif func==10,fhd='g10';
elseif func==11,fhd='g11';
elseif func==12,fhd='g12';
elseif func==13,fhd='g13';
elseif func==14,fhd='g14';
elseif func==15,fhd='g15';
elseif func==16,fhd='g16';
elseif func==17,fhd='g17';
elseif func==18,fhd='g18';
elseif func==19,fhd='g19';
elseif func==20,fhd='g20';
elseif func==21,fhd='g21';
elseif func==22,fhd='g22';
elseif func==23,fhd='g23';
elseif func==24,fhd='g24';
end
gn=[9,2,0,6,2,2,8,2,4,6,0,1,0,0,0,38,0,13,5,6,1,1,2,2];
gn=gn(func);
hn=[0,0,1,0,3,0,0,0,0,0,1,0,3,3,2,0,4,0,0,14,5,19,4,0];
hn=hn(func);
% best_known=[-15.00000 -0.803619 -1 -30665.538672 5126.498110 -6961.813800 24.306209 -0.095825 680.630057 7049.330700 0.75 -1 0.0539498 -47.764411 961.715172 -1.905155 8876.980680 -0.865735 32.655593 0.096737 193.778349 382.902205 -400.002500 -5.508013];
best_known=[-15.0000000000 -0.8036191042 -1.0005001000  -30665.5386717834  5126.4967140071  -6961.8138755802  24.3062090681  -0.0958250415  680.6300573745  7049.2480205286  0.7499000000  -1.0000000000  0.0539415140  -47.7648884595 961.7150222899  -1.9051552586  8853.5396748064  -0.8660254038 32.6555929502  0.2049794002  193.7245100700  236.4309755040  -400.0551000000  -5.5080132716 ];
best_known=best_known(func);
count=0;
keep_id=1;
bestval=1e+100;bestval_c=1e+100;best=x;
get_flag=0;
fit_cut=500000;
feasible_flag =0;
fit_feasible=500000;
initial_flag=1;
end

[ps,D]=size(x);
count=count+ps;
if ps~=1
    break;
end
delta=1e-4;


[f, g, h] = mlbsuite(x', gn, hn, fhd);
ff=[f;(g>0).*g;(abs(h)>delta).*(abs(h)-delta)]';
f=f-best_known;

c=(sum((g>0).*(g),1)+sum((abs(h)>delta).*(abs(h)-delta),1))/(gn+hn);%(sum((g>0).*(g.^2),1)+sum((abs(h)>delta).*((abs(h)-delta).^2),1));
cons=[(g>0).*g;(abs(h)>delta).*(abs(h)-delta)];

if ((bestval_c==c).*(f<bestval))|((bestval_c~=c).*(c<bestval_c))
    bestval=f;
    bestval_c=c;
    best=x;
    bestval_g=g;
    bestval_h=h;
end

if get_flag==0 & f<=1e-4 & (c==0)
    fit_cut=count;get_flag=1;
end

if feasible_flag==0 &  (c==0)
    fit_feasible=count;feasible_flag=1;
end 

if mod(count,500)==1
% if mod(count,100)==1
f_hist=[f_hist,bestval];%f];
v_hist=[v_hist,bestval_c];%(sum((g>0).*(g),1)+sum((abs(h)>delta).*(abs(h)-delta),1))/(gn+hn)];
end

sample=[5e+3,5e+4,5e+5,0];
% sample=[10,25,50,0];
if count==sample(keep_id)
%     count
    f_keep(1,keep_id)=bestval;%f;
    x_keep(keep_id,:)=best;%x;
    tmp=[1,0.01,0.0001];
    c_keep(keep_id,1)=sum(bestval_g>tmp(1),1)+sum(abs(bestval_h)>tmp(1),1);
    c_keep(keep_id,2)=sum(bestval_g>tmp(2),1)+sum(abs(bestval_h)>tmp(2),1);
    c_keep(keep_id,3)=sum(bestval_g>tmp(3),1)+sum(abs(bestval_h)>tmp(3),1);
    cc(1,keep_id)=sum(bestval_g>0,1)+sum(abs(bestval_h)>delta,1);
    v_keep(keep_id)=bestval_c;
    keep_id=keep_id+1;
end
% count,ff