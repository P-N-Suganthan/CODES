function f = myfun(x,func,Xmin,Xmax,ratio)
% opts=optimset('fmincon');
% opts.MaxFunEvals=100000;
% opts.TolCon=1E-4;
% opts.TolFun=1E-10;
%  [x,f,exitflag,output] = fmincon('myfun',gbest(1,:),[],[],[],[],VRmax(1,:),VRmax(1,:),'mycon', opts,varargin{:});
%  FcnCount = output.funcCount + FcnCount;
% x=((x<=Xmax).*(x>=Xmin)).*x+(x<Xmin).*(2*Xmin-x)+(x>Xmax).*(-x+2*Xmax);
% x

gn=[9,2,0,6,2,2,8,2,4,6,0,1,0,0,0,38,0,13,5,6,1,1,2,2];
gn=gn(func);
hn=[0,0,1,0,3,0,0,0,0,0,1,0,3,3,2,0,4,0,0,14,5,19,4,0];
hn=hn(func);

x=((x<=Xmax).*(x>=Xmin)).*x+(x<Xmin).*(Xmin+mod(Xmin-x,Xmax-Xmin))+(x>Xmax).*(Xmax-mod(x-Xmax,Xmax-Xmin));

% x
[f,c,ceq]=fcnsuite_func(x,func);
% f=fcn_func(x,func);
% f=f(1);

%     c=f(2:gn+1);ceq=f((gn+2):(gn+hn+1));
%     ceq=(abs(ceq)-1e-4).*(abs(ceq)>1e-4);%+1e-20;
%     c=(c>0).*c;
%     c=[c,ceq];
%     c=100.*ratio.*c;
%     f=f(1)+sum(abs(c));