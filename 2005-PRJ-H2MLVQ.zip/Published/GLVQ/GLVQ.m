% Generalizaed Learning Vector Quantization (GLVQ) algorithm

function [CR,Proto] = GLVQ(trainset,testset,Nodeperclass)

% % Nomalize the dataset along each dimension (option)
% [trainset,testset]=Normalization(trainset,testset);

Proto.trainset=trainset;
Proto.testset=testset;

% Initialization of the GLVQ Network

% Distance metric used, 2=>Euclidean
Proto.metric = 2;

% Dimensionality of data space
Proto.NoFeats=size(Proto.trainset,2)-1;

% The max class label in the GLVQ network; NOTE: All the class label must over 1
realclass=unique(Proto.trainset(:,Proto.NoFeats+1));
Proto.NoClasses=max(realclass); % "NoClasses" stands for the maximum class label value in the current label set "realclass"

% Initialize prototype vectors

% Method 1: random initialization around the mean of each class
Proto.w=[];
wclass=[];
for i=1:size(realclass,1)
    wclass=[wclass,realclass(i)*ones(1,Nodeperclass)];
    Proto.w = [Proto.w;0.1*rand(Nodeperclass,Proto.NoFeats) + ones(Nodeperclass,1)*mean(Proto.trainset(find(Proto.trainset(:,Proto.NoFeats+1)==realclass(i)),1:Proto.NoFeats))];
end
Proto.nodelabel=wclass;

% % Method 2: random initialization around the mean of whole dataset
%   Proto.w=0.1*rand(Nodeperclass*size(realclass,1),Proto.NoFeats)+ones(Nodeperclass*size(realclass,1),1)*mean(Proto.trainset(:,1:Proto.NoFeats));
%   wclass=[];
%   for i=1:size(realclass,1)
%       wclass=[wclass,realclass(i)*ones(1,Nodeperclass)];
%   end
%   Proto.nodelabel=wclass;


% % Method 3: random initialization in the data space
%   Proto.w=rand(Nodeperclass*size(realclass,1),Proto.NoFeats);
%   wclass=[];
%   for i=1:size(realclass,1)
%       wclass=[wclass,realclass(i)*ones(1,Nodeperclass)];
%   end
%   Proto.nodelabel=wclass;

% % Method 4: initialization by unsupervised NG or supervised NG algorithm
% ....


stopcriteria=0.0001;
Proto.previousw=Proto.w;

flag=1;
beta=1;    % Parameter in sigmoid function 1/(1+exp(-beta*u)) to control the change of the updating range near the border

for iter1=0:99
    if flag==1
        iter=0;
        trndata = Proto.trainset;	 % Copy dataset to working dataset, from which used samples are removed one by one
        rand('state',sum(100*clock));
        while ~isempty(trndata)
            beta=beta*1.00001;
            % 1: Select input sample
            index = ceil(size(trndata,1)*rand(1,1));  % Choose a training sample randomly from the training dataset
            CurVec = trndata(index,1:Proto.NoFeats);
            plabel=trndata(index,Proto.NoFeats+1);
            trndata(index,:) = [];                    % Remove the used samples
            iter=iter+1;
            t=iter+iter1*size(trainset,1);
            
            % 2:Update the nearest correct (corr) and wrong prototypes (wron) according to current input vector "CurVec"
            tempcor=[];
            tempwro=[];
            for i=1:size(Proto.w,1)			% find neighbours of the winning node s and update them
                if Proto.nodelabel(i)==plabel
                    tempcor=[tempcor,i];
                else
                    tempwro=[tempwro,i];
                end
            end
            if ~isempty(tempcor)
                d=[];
                for j=1:size(tempcor,2)
                    d(j) = sum(((CurVec-Proto.w(tempcor(j),:)).^2));
                end
                [corrminval,corr]=min(d);
            else
                error('no correct label prototype');
            end
            if ~isempty(tempwro)
                d=[];
                for j=1:size(tempwro,2)
                    d(j) = norm(CurVec-Proto.w(tempwro(j),:),Proto.metric)^2;
                end
                [wronminval,wron]=min(d);
            else
                error('no wrong label prototype');
            end
            uvalue=(corrminval-wronminval)/(corrminval+wronminval);
            if ((exp(-uvalue*beta))/((1+exp(-uvalue*beta))^2)) > eps 
                fvalue=(exp(-uvalue*beta))/((1+exp(-uvalue*beta))^2);
            else
                fvalue=0;
            end
            Proto.w(tempcor(corr),:) = Proto.w(tempcor(corr),:) + 0.05*fvalue*4*(wronminval/(corrminval+wronminval))*((CurVec-Proto.w(tempcor(corr),:)));	
            Proto.w(tempwro(wron),:) = Proto.w(tempwro(wron),:) - 0.05*fvalue*4*(corrminval/(corrminval+wronminval))*((CurVec-Proto.w(tempwro(wron),:)));	
              
%             if mod(t,100) == 0, 
%                 hold off 
%                 plot(Proto.trainset(find(Proto.trainset(:,Proto.NoFeats+1)==1),1),Proto.trainset(find(Proto.trainset(:,Proto.NoFeats+1)==1),2),'r.');
%                 hold on;
%                 plot(Proto.trainset(find(Proto.trainset(:,Proto.NoFeats+1)==2),1),Proto.trainset(find(Proto.trainset(:,Proto.NoFeats+1)==2),2),'g.');
%                 plot(Proto.trainset(find(Proto.trainset(:,Proto.NoFeats+1)==3),1),Proto.trainset(find(Proto.trainset(:,Proto.NoFeats+1)==3),2),'y.');
%                 plot(Proto.w(find(Proto.nodelabel==1),1),Proto.w(find(Proto.nodelabel==1),2),'bx');
%                 plot(Proto.w(find(Proto.nodelabel==2),1),Proto.w(find(Proto.nodelabel==2),2),'ko');
%                 plot(Proto.w(find(Proto.nodelabel==3),1),Proto.w(find(Proto.nodelabel==3),2),'go');                     
%                 drawnow
%             end         
        end
        
        crit=0;
        for i=1:size(Proto.w,1)
            crit=crit+norm(Proto.previousw(i,:)-Proto.w(i,:),Proto.metric);
        end
        crit=crit/size(Proto.w,1);
        if crit <= stopcriteria
            flag=0;
        else
            Proto.previousw=Proto.w;
        end
        
    end
end 

% hold off 
% plot(Proto.trainset(find(Proto.trainset(:,Proto.NoFeats+1)==1),1),Proto.trainset(find(Proto.trainset(:,Proto.NoFeats+1)==1),2),'r.');
% hold on;
% plot(Proto.trainset(find(Proto.trainset(:,Proto.NoFeats+1)==2),1),Proto.trainset(find(Proto.trainset(:,Proto.NoFeats+1)==2),2),'g.');
% plot(Proto.trainset(find(Proto.trainset(:,Proto.NoFeats+1)==3),1),Proto.trainset(find(Proto.trainset(:,Proto.NoFeats+1)==3),2),'y.');
% plot(Proto.w(find(Proto.nodelabel==1),1),Proto.w(find(Proto.nodelabel==1),2),'bx');
% plot(Proto.w(find(Proto.nodelabel==2),1),Proto.w(find(Proto.nodelabel==2),2),'ko');
% plot(Proto.w(find(Proto.nodelabel==3),1),Proto.w(find(Proto.nodelabel==3),2),'go');

[CR] = MajorVot(Proto.w,Proto.trainset,Proto.testset,Proto.nodelabel);