function [trainset,testset] = Normalization(trainset,testset)

% % Normalizing the data into [0,1]
% trainsize=size(trainset,1);
% Dataset=[trainset;testset];
% [row,column] = size(Dataset);
% NormData = [];
% for i = 1:column-1
%     minustemp = max(Dataset(:,i))-min(Dataset(:,i));
%     if (minustemp~=0) & (~(max(Dataset(:,i))==1 & min(Dataset(:,i))==0))
%         NormData = [NormData,(Dataset(:,i)-min(Dataset(:,i)))/minustemp];
%     else
%         NormData=[NormData,Dataset(:,i)];
%     end
% end
% Dataset=[NormData,Dataset(:,column)];
% trainset=Dataset(1:trainsize,:);
% Dataset(1:trainsize,:)=[];
% testset=Dataset;

% Normalizing data into [-1,1]
trainsize=size(trainset,1);
Dataset=[trainset;testset];
[row,column] = size(Dataset);
NormData = [];
for i = 1:column-1
    plustemp = (max(Dataset(:,i))+min(Dataset(:,i)))/2;
    minustemp = (max(Dataset(:,i))-min(Dataset(:,i)))/2;
    if (minustemp~=0) & (~(max(Dataset(:,i))==1 & min(Dataset(:,i))==-1))
        NormData = [NormData,(Dataset(:,i)-plustemp)/minustemp];
    else
        NormData=[NormData,Dataset(:,i)];
    end
end
Dataset=[NormData,Dataset(:,column)];
trainset=Dataset(1:trainsize,:);
Dataset(1:trainsize,:)=[];
testset=Dataset;