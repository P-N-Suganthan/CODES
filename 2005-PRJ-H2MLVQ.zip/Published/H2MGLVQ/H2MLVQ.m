% Harmonic to Mimimum Learning Vector Quantization (H2M-LVQ) algorithm

function [CR,Proto] = H2MLVQ(trainset,testset,Nodeperclass)

% % Nomalize the dataset along each dimension (option)
% [trainset,testset]=Normalization(trainset,testset);

Proto.trainset=trainset;
Proto.testset=testset;

% Initialization of the H2M-LVQ Network

% Distance metric used, 2=>Euclidean
  Proto.metric = 2;

% Dimensionality of data space
  Proto.NoFeats=size(Proto.trainset,2)-1;

% The max class label in the H2M-LVQ network; NOTE: All the class label must over 1
  realclass=unique(Proto.trainset(:,Proto.NoFeats+1));
  Proto.NoClasses=max(realclass); % "NoClasses" stands for the maximum class label value in the current label set "realclass"
  
% Initialize prototype vectors

% Method 1: random initialization around the mean of each class
  Proto.w=[];
  wclass=[];
  for i=1:size(realclass,1)
      wclass=[wclass,realclass(i)*ones(1,Nodeperclass)];
      Proto.w = [Proto.w;0.1*rand(Nodeperclass,Proto.NoFeats) + ones(Nodeperclass,1)*mean(Proto.trainset(find(Proto.trainset(:,Proto.NoFeats+1)==realclass(i)),1:Proto.NoFeats))];
  end
  Proto.nodelabel=wclass;

% % Method 2: random initialization around the mean of whole dataset
%   Proto.w=0.1*rand(Nodeperclass*size(realclass,1),Proto.NoFeats)+ones(Nodeperclass*size(realclass,1),1)*mean(Proto.trainset(:,1:Proto.NoFeats));
%   wclass=[];
%   for i=1:size(realclass,1)
%       wclass=[wclass,realclass(i)*ones(1,Nodeperclass)];
%   end
%   Proto.nodelabel=wclass;


% % Method 3: random initialization in the data space
%   Proto.w=rand(Nodeperclass*size(realclass,1),Proto.NoFeats);
%   wclass=[];
%   for i=1:size(realclass,1)
%       wclass=[wclass,realclass(i)*ones(1,Nodeperclass)];
%   end
%   Proto.nodelabel=wclass;

% % Method 4: initialization by unsupervised NG or supervised NG algorithm
% ....


stopcriteria=0.0001;
Proto.previousw=Proto.w;
flag=1;
beta=1;    % Parameter in sigmoid function 1/(1+exp(-beta*u)) to control the change of the updating range near the border
Max_iter=100;

rand('state',0);
for iter1=0:Max_iter-1
   if flag==1
     iter=0;
     softcoef=exp(-iter1/(0.5*Max_iter));
     ecorr=0.05;
     ewron=0.01*(0.05/0.01).^(iter1/(Max_iter-1));
     
     
     trndata = Proto.trainset;	 % Copy dataset to working dataset, from which used samples are removed one by one
     rand('state',sum(100*clock));
     while ~isempty(trndata)
         beta=beta*1.00001;
         % 1: Select input sample
	      index = ceil(size(trndata,1)*rand(1,1));  % Choose a training sample randomly from the training dataset
	      CurVec = trndata(index,1:Proto.NoFeats);
          plabel=trndata(index,Proto.NoFeats+1);
          trndata(index,:) = [];                    % Remove the used samples
          iter=iter+1;
          t=iter+iter1*size(trainset,1);         

            	% 2:Update the correct (corr) prototypes and the nearest wrong prototype (wron) according to one input vector "CurVec"
                tempcor=[];
                tempwro=[];
                for i=1:size(Proto.w,1)			% find neighbours of the winning node s and update them
                   if Proto.nodelabel(i)==plabel
                       tempcor=[tempcor,i];
                   else
                       tempwro=[tempwro,i];
                   end
                end
                
                if ~isempty(tempcor)
                   d=[];
                   for j=1:size(tempcor,2)
                       d(j) = sum(((CurVec-Proto.w(tempcor(j),:)).^2));
%                        d(j)=norm(CurVec-Proto.w(tempcor(j),:),2);
                   end
                   dcorr=d;
                else
                   error('no correct label prototype');
                end
                
                if ~isempty(tempwro)
                   d=[];
                   for j=1:size(tempwro,2)
                       d(j) = sum(((CurVec-Proto.w(tempwro(j),:)).^2));
%                        d(j)=norm(CurVec-Proto.w(tempwro(j),:),2);
                   end
                   dwron=d;
                else
                    error('no wrong label prototype');
                end
                 
                
                [dcorr_min,dcorr_minidx]=min(dcorr);
                [dwron_min,dwron_minidx]=min(dwron);
                temp=0;
                for i=1:size(dcorr,2)
                    if i~=dcorr_minidx
                        temp=temp+(dcorr_min/dcorr(i))^softcoef;
                    end
                end
                harmdist_cor=(size(dcorr,2)*dcorr_min)/(1+temp);
                
                temp=0;
                for i=1:size(dwron,2)
                    if i~=dwron_minidx
                        temp=temp+(dwron_min/dwron(i))^softcoef;
                    end
                end
                harmdist_wro=(size(dwron,2)*dwron_min)/(1+temp);

                uvalue=(harmdist_cor-harmdist_wro)/(harmdist_cor+harmdist_wro);
                if ((exp(-uvalue*beta))/((1+exp(-uvalue*beta))^2)) > eps 
                    fvalue=(exp(-uvalue*beta))/((1+exp(-uvalue*beta))^2);
                else
                    fvalue=0;
                end
                
                
                temp_cor=0;
                for j=1:size(dcorr,2)
                    if j~=dcorr_minidx
                        temp_cor=temp_cor+dcorr(j)^(-softcoef);
                    end
                end
                temp_wro=0;
                for j=1:size(dwron,2)
                    if j~=dwron_minidx
                       temp_wro=temp_wro+dwron(j)^(-softcoef);
                    end
                end
                
                
                for i=1:size(dcorr,2) 
                    if i==dcorr_minidx
                        aa(i)=size(dcorr,2)*((dcorr_min^(-1)+(dcorr_min^(softcoef-1))*temp_cor)^(-2))*(-1*dcorr_min^(-2)+(softcoef-1)*(dcorr_min^(softcoef-2))*temp_cor);
                    else
                        aa(i)=size(dcorr,2)*((dcorr_min^(-1)+(dcorr_min^(softcoef-1))*temp_cor)^(-2))*((dcorr_min^(softcoef-1))*(-softcoef)*(dcorr(i)^(-softcoef-1)));
                    end
                end

                for i=1:size(dwron,2)    
                    if i==dwron_minidx
                        bb(i)=size(dwron,2)*((dwron_min^(-1)+(dwron_min^(softcoef-1))*temp_wro)^(-2))*(-1*dwron_min^(-2)+(softcoef-1)*(dwron_min^(softcoef-2))*temp_wro);
                    else
                        bb(i)=size(dwron,2)*((dwron_min^(-1)+(dwron_min^(softcoef-1))*temp_wro)^(-2))*((dwron_min^(softcoef-1))*(-softcoef)*(dwron(i)^(-softcoef-1)));
                    end                
                end

                for i=1:size(dcorr,2) 
                    Proto.w(tempcor(i),:) = Proto.w(tempcor(i),:) - ecorr*fvalue*4*(harmdist_wro/(harmdist_cor+harmdist_wro))*aa(i)*(CurVec-Proto.w(tempcor(i),:));
                end
                for i=1:size(dwron,2)   
                    Proto.w(tempwro(i),:) = Proto.w(tempwro(i),:) + ewron*fvalue*4*(harmdist_cor/(harmdist_cor+harmdist_wro))*bb(i)*(CurVec-Proto.w(tempwro(i),:));
                end

%                  if mod(t,100) == 0, 
%                       hold off 
%                       plot(Proto.trainset(find(Proto.trainset(:,Proto.NoFeats+1)==1),1),Proto.trainset(find(Proto.trainset(:,Proto.NoFeats+1)==1),2),'r.');
%                       hold on;
%                       plot(Proto.trainset(find(Proto.trainset(:,Proto.NoFeats+1)==2),1),Proto.trainset(find(Proto.trainset(:,Proto.NoFeats+1)==2),2),'g.');
%                       plot(Proto.trainset(find(Proto.trainset(:,Proto.NoFeats+1)==3),1),Proto.trainset(find(Proto.trainset(:,Proto.NoFeats+1)==3),2),'y.');
%                       plot(Proto.w(find(Proto.nodelabel==1),1),Proto.w(find(Proto.nodelabel==1),2),'bx');
%                       plot(Proto.w(find(Proto.nodelabel==2),1),Proto.w(find(Proto.nodelabel==2),2),'ko');
%                       plot(Proto.w(find(Proto.nodelabel==3),1),Proto.w(find(Proto.nodelabel==3),2),'go');                     
%                       drawnow
%                  end         
      end

      crit=0;
      for i=1:size(Proto.w,1)
          crit=crit+norm(Proto.previousw(i,:)-Proto.w(i,:),Proto.metric);
      end
      crit=crit/size(Proto.w,1);
      if crit <= stopcriteria
          flag=0;
      else
          Proto.previousw=Proto.w;
      end
  end
 
end 
[CR] = MajorVot(Proto.w,Proto.trainset,Proto.testset,Proto.nodelabel);