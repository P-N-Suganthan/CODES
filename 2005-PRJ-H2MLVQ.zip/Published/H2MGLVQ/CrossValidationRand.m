% This function performs distribution balanced stratified n-fold Cross-Validation for Dataset A
function [classrate,standvar]=CrossValidationRand(A,n,numproper)

% Usage: [classrate,standvar]=CrossValidationRand(dataset,n,numproper)
%   dataset:    n*(d+1) with n data items of d-dim and classlabel in the last column
%   n:          n-fold crossvalidation
%   numproper:  pre-specified number of prototypes per class

[A]=Normalization(A,A);
NoClasses=max(unique(A(:,size(A,2))));

%perform n-fold cross-validation for a given dataset A after partitioning according to class label
reclassrate=[];
for i=1:NoClasses
    eval(['Partset' int2str(i) '=[];']);
    eval(['list' int2str(i) '=[];']);
end
for i=1:NoClasses
    temp=find(A(:,size(A,2))==i);
    if ~isempty(temp)
        for j=1:size(temp,1)
            eval(['Partset' int2str(i) '=[Partset' int2str(i) ';A(temp(j),:)];']);
        end
    end
end
temp=0;
for i=1:NoClasses
    if eval(['~isempty(Partset' int2str(i) ')'])
        temp=temp+1;
        eval(['a = Partset' int2str(i) ';']);
        [row,column]=size(a);
        for j=1:column
            eval(['list' int2str(temp) '(j)=min(a(:,j));']);
        end
        for j=2:row+1
            eval(['b=list' int2str(temp) '(j-1,1:column-1);']);
            d=[];
            for k=1:size(a,1)
                d=[d,norm(b-a(k,1:column-1),2)];
            end
            [minval,s]=min(d);
            eval(['list' int2str(temp) '=[list' int2str(temp) ';a(s,:)];']);
            a(s,:)=[];
        end
    end
end

for i=1:n
    eval(['T' int2str(i) '=[];']);
end
Listremain=[];
for i=1:temp
    eval(['b = list' int2str(i) '(2:size(list' int2str(i) ',1),:);']);
    if ~isempty(b)
        while size(b,1) >= n
            for j=1:n
                eval(['T' int2str(j) '=[T' int2str(j) ';b(1,:)];']);
                b(1,:)=[];
            end
        end
        Listremain=[Listremain;b];
        b=[];
    end
end

while ~isempty(Listremain)
    for i=1:n
        if ~isempty(Listremain)
            eval(['T' int2str(i) '=[T' int2str(i) ';Listremain(1,:)];']);
            Listremain(1,:)=[];
        end
    end
end

for i=1:n
    validset=[];
    trnset=[];
    eval(['validset=[validset;T' int2str(i) '];']);
    for j=1:n
        if j~=i
            eval(['trnset=[trnset;T' int2str(j) '];']);
        end
    end

% % Perform 5-fold cross-validation for a given dataset A, after partitioning according to class label
% reclassrate=[];
% 
% for i=1:NoClasses
%     eval(['Partset' int2str(i) '=[];']);
% end
% for i=1:NoClasses
%     temp=find(A(:,size(A,2))==i);
%     if ~isempty(temp)
%         for j=1:size(temp,1)
%             eval(['Partset' int2str(i) '=[Partset' int2str(i) ';A(temp(j),:)];']);
%         end
%     end
% end
% 
% for i=1:NoClasses
%     if eval(['~isempty(Partset' int2str(i) ')'])
%         eval(['a = Partset' int2str(i) ';']);
%         [m,k] = size(a);
%         J = randperm(m);
%         eval(['Partset' int2str(i) '=a(J,:);']);
%     end
% end
% 
% for i=1:n
%     validset=[];
%     trnset=[];
%     for j=1:NoClasses
%         if eval(['~isempty(Partset' int2str(j) ')'])
%             eval(['a = Partset' int2str(j) ';']);
%             [m,k] = size(a);
%             iter = floor(m/n);
%             OUT = ((i-1)*iter+1):i*iter;
%             validset=[validset;a(OUT,:)];
%             a(OUT,:)=[];
%             trnset=[trnset;a];
%         end
%     end
    
    [CR] = H2MLVQ(trnset,validset,numproper);
    reclassrate = [reclassrate,CR]   
end
classrate = mean(reclassrate);
standvar = std(reclassrate);