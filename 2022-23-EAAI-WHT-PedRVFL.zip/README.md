# EAAI-WVHT-PedRVFL-SOURCECODES

This repository contains the sources codes and results of the following paper

Significant wave height forecasting using hybrid ensemble deep randomized networks with neurons pruning

arima's forecasts are stored in csv file.

File calculating_error can be used to replicate the results directly.

For further details (such as optimized parameters, results, etc): https://github.com/Robinpredict/EAAI-WVHT-PedRVFL-SOURCECODES/tree/main