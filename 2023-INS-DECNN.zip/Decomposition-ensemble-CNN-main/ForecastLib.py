import numpy as np
# from vmdpy import VMD
import pywt
# from PyEMD import EMD
# import ewtpy

import matplotlib.pyplot as plt


class TsAnalyzer(object):
    def __init__(self):
        pass

    def ts_DWT(self,s, wavelet, mode, level):
        """
        :return: list [An, Dn, Dn-1, …, D2, D1]
        """
        coeffs = pywt.wavedec(s, wavelet, mode = mode, level=level)
        subseries = []
        for i in range(len(coeffs)):
            coeffs_i = [np.zeros_like(i) for i in coeffs]
            coeffs_i[i] = coeffs[i]
            s_i =  pywt.waverec(coeffs_i, wavelet, mode='symmetric')
            subseries.append(s_i)
        return subseries


    def ts_EMD(self,s, k=10):
        """
        :param args:
        :return: k*len nd-array
        """
        emd = EMD()
        IMFs = emd(s, max_imf=k)
        return IMFs

    def ts_EWT(self,s,k):
        """
        :param k: number of components
        :return: ewt--  len*k   nd array,mfb -filter bank, boundaries: frequency boundaries
        """
        ewt,  mfb ,boundaries = ewtpy.EWT1D(s, N = k)
        return ewt, mfb, boundaries

    def ts_VMD(self,x, display=0, alpha = 100,tau = 0.01,k = 3,DC = 0,init = 1, tol = 1e-5 ):
        """
        alpha = 2000       # moderate bandwidth constraint
        tau = 0.1           # noise-tolerance (no strict fidelity enforcement)
        K = 4              # 3 modes
        DC = 1             # no DC part imposed
        init = 1           # initialize omegas uniformly
        tol = 1e-7
        return: vmd_x   K*len   nd array
                vmd_spectrum
        """
        vmd_x, vmd_spectrum, centre_omega = VMD(x, alpha, tau, k, DC, init, tol)

        if display == 1:
            plt.figure()
            for i in range(1, 4):
                plt.subplot(3, 1, i)
                plt.plot(vmd_x[i - 1, :], c="b", linewidth=1)
                plt.title("Centre frequency is %.3f" % centre_omega[-1, i - 1])
            plt.suptitle("VMD of given series")
            plt.show()

        return vmd_x, vmd_spectrum, centre_omega

