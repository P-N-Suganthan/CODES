import scipy.io as sio
import numpy as np

from ForecastLib import TsAnalyzer


def load_drivedata(input_type, one_hot=False):
    filename = 'journaltaiwanbalanced.mat'
    tmp = sio.loadmat(filename)
    subIdx = np.array(tmp['subindex'])
    if input_type == 'raw':
        x_data = np.array(tmp['EEGsample'])
        label = np.array(tmp['substate'])
        label.astype(int)
        subIdx.astype(int)
        samplenum = label.shape[0]
        xdata = x_data
        if one_hot:
            ydata = np.zeros((samplenum, 2), dtype=np.longlong)
            for k in range(len(label)):
                if label[k] == 1:
                    ydata[k] = [0, 1]
                else:
                    ydata[k] = [1, 0]
        else:
            ydata = np.squeeze(label.astype(np.int64))
    return xdata, ydata, subIdx


if __name__ == '__main__':
    xdata, ydata, subIdx = load_drivedata('raw')
    decomposition = TsAnalyzer()
    data_decomposition = np.zeros((xdata.shape[0], xdata.shape[1], 6, xdata.shape[2]))
    for i in range(xdata.shape[0]):
        data = np.squeeze(xdata[i, :, :])
        for j in range(data.shape[0]):
            data_channel = data[j, :]
            data_channel_dec = np.array(decomposition.ts_DWT(data_channel, 'db3', 'symmetric', level=5))  # you can try different db wavelet, here we put db3 as an example
            data_decomposition[i, j, :, :] = data_channel_dec
            print('i, j {}, {}'.format(i, j))
    np.savez('drivedata_dwt_db3_6_decomposition', data_decomposition, ydata, subIdx)
    print(1)
