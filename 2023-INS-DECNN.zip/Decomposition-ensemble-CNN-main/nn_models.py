# -*- coding: utf-8 -*-
"""
Created on

@author:
"""
import torch
import torch.nn as nn
from torch.nn import functional as F

# from layers import GraphConvolution, graph_constructor


######## InterpretableCNN ###########
class InterpretableCNN(torch.nn.Module):

    """
    The codes implement the CNN model proposed in the paper "EEG-based Cross-Subject Driver Drowsiness Recognition
    with Interpretable CNN ".

    The network is designed to classify multi-channel EEG signals for the purposed of driver drowsiness recognition.

    Parameters:

    classes       : number of classes to classify, the default number is 2 corresponding to the 'alert' and 'drowsy' labels.
    sampleChannel : channel number of the input signals.
    sampleLength  : the length of the EEG signals. The default value is 384, which is 3s signal with sampling rate of 128Hz.
    N1            : number of nodes in the first pointwise layer.
    d             : number of kernels for each new signal in the second depthwise layer.
    kernelLength  : length of convolutional kernel in second depthwise layer.

    if you have any problems with the code, please contact Dr. Cui Jian at cuij0006@ntu.edu.sg
    """

    def __init__(self, classes=2, sampleChannel=30, sampleLength=384 ,N1=16, d=2, kernelLength=64):  # 30
        super(InterpretableCNN, self).__init__()
        self.pointwise = torch.nn.Conv2d(1, N1, (sampleChannel, 1))
        self.depthwise = torch.nn.Conv2d(N1, d*N1, (1, kernelLength), groups=N1)
        self.activ=torch.nn.ReLU()
        self.batchnorm = torch.nn.BatchNorm2d(d*N1, track_running_stats=True)
        self.GAP=torch.nn.AvgPool2d((1, sampleLength-kernelLength+1))
        self.fc = torch.nn.Linear(d*N1, classes)
        # self.softmax=torch.nn.LogSoftmax(dim=1)

    def forward(self, inputdata):
        # inputdata = inputdata.view(inputdata.size(0), 1, inputdata.size(1), inputdata.size(2))
        intermediate = self.pointwise(inputdata)
        self.spatial_feature = intermediate.detach()
        intermediate = self.depthwise(intermediate)
        intermediate = self.activ(intermediate)
        intermediate = self.batchnorm(intermediate)
        # self.temporal_feature = intermediate.detach()
        intermediate = self.GAP(intermediate)
        intermediate = intermediate.view(intermediate.size()[0], -1)
        self.feature = intermediate.detach()
        output = self.fc(intermediate)
        # output = self.softmax(intermediate)

        return output


class EIPCNN(nn.Module):
    def __init__(self, n_net=3):
        super(EIPCNN, self).__init__()
        self.n_net = n_net
        for i in range(n_net):
            self.__setattr__('net_%d' % i, InterpretableCNN())
            # self.__setattr__('weight_%d' % i, nn.parameter.Parameter(torch.randn(1)))

    def forward(self, input_set):
        intermediate = torch.zeros((len(input_set), input_set[0].size(0), 2))
        intermediate = intermediate.cuda()
        for i in range(self.n_net):
            net_i = self.__getattr__('net_%d' % i)
            intermediate[i, :, :] = net_i(input_set[i])
        output = torch.mean(intermediate, dim=0)
        # output = intermediate[]
        return output


######## EEGNet ###########
class SeparableConv2d(nn.Module):
    def __init__(self, c_in: int, c_out: int, kernel_size: tuple, padding: tuple = 0):
        super().__init__()
        self.c_in = c_in
        self.c_out = c_out
        self.kernel_size = kernel_size
        self.padding = padding
        self.depthwise_conv = nn.Conv2d(self.c_in, self.c_in, kernel_size=self.kernel_size,
                                        padding=self.padding, groups=self.c_in)
        self.conv2d_1x1 = nn.Conv2d(self.c_in, self.c_out, kernel_size=1)

    def forward(self, x: torch.Tensor):
        y = self.depthwise_conv(x)
        y = self.conv2d_1x1(y)
        return y


class SeparableConv1d(nn.Module):
    def __init__(self, c_in: int, c_out: int, kernel_size: tuple, padding: tuple = 0):
        super().__init__()
        self.c_in = c_in
        self.c_out = c_out
        self.kernel_size = kernel_size
        self.padding = padding
        self.depthwise_conv = nn.Conv1d(self.c_in, self.c_in, kernel_size=self.kernel_size,
                                        padding=self.padding, groups=self.c_in)
        self.conv1d_1x1 = nn.Conv1d(self.c_in, self.c_out, kernel_size=1)

    def forward(self, x: torch.Tensor):
        y = self.depthwise_conv(x)
        y = self.conv1d_1x1(y)
        return y


class EEGNet(nn.Module):
    def __init__(self, nb_classes: int = 2, Chans: int = 30, Samples: int = 384,
                 dropoutRate: float = 0.5, kernLength: int = 63,
                 F1:int = 8, D:int = 2):
        super().__init__()

        F2 = F1 * D

        # Make kernel size and odd number
        # try:
        #     assert kernLength % 2 != 0
        # except AssertionError:
        #     raise ValueError("ERROR: kernLength must be odd number")

        # In: (B, Chans, Samples, 1)
        # Out: (B, F1, Samples, 1)
        self.conv1 = nn.Conv2d(1, F1, (1, kernLength), padding=(0, kernLength//2))
        self.bn1 = nn.BatchNorm2d(F1, track_running_stats=False)   # (B, F1, Samples, 1)
        # In: (B, F1, Samples, 1)
        # Out: (B, F2, Samples - Chans + 1, 1)
        self.conv2 = nn.Conv2d(F1, F2, (Chans, 1), groups=F1)
        self.bn2 = nn.BatchNorm2d(F2, track_running_stats=False) # (B, F2, Samples - Chans + 1, 1)
        # In: (B, F2, Samples - Chans + 1, 1)
        # Out: (B, F2, (Samples - Chans + 1) / 4, 1)
        self.avg_pool = nn.AvgPool2d((1, 4))
        self.dropout = nn.Dropout(dropoutRate)

        # In: (B, F2, (Samples - Chans + 1) / 4, 1)
        # Out: (B, F2, (Samples - Chans + 1) / 4, 1)
        self.conv3 = SeparableConv2d(F2, F2, kernel_size=(1, 15), padding=(0, 7))
        self.bn3 = nn.BatchNorm2d(F2, track_running_stats=True)
        # In: (B, F2, (Samples - Chans + 1) / 4, 1)
        # Out: (B, F2, (Samples - Chans + 1) / 32, 1)
        self.avg_pool2 = nn.AvgPool2d((1, 8))
        # In: (B, F2 *  (Samples - Chans + 1) / 32)
        self.fc = nn.Linear(F2 * Samples // 32, nb_classes)

    def forward(self, x: torch.Tensor):
        # Block 1
        # x = x.view(x.size(0), 1, x.size(1), x.size(2))
        y1 = self.conv1(x)
        #print("conv1: ", y1.shape)
        y1 = self.bn1(y1)
        #print("bn1: ", y1.shape)
        y1 = self.conv2(y1)
        #print("conv2", y1.shape)
        y1 = F.relu(self.bn2(y1))
        #print("bn2", y1.shape)
        y1 = self.avg_pool(y1)
        #print("avg_pool", y1.shape)
        y1 = self.dropout(y1)
        #print("dropout", y1.shape)

        # Block 2
        y2 = self.conv3(y1)
        #print("conv3", y2.shape)
        y2 = F.relu(self.bn3(y2))
        #print("bn3", y2.shape)
        y2 = self.avg_pool2(y2)
        #print("avg_pool2", y2.shape)
        y2 = self.dropout(y2)
        #print("dropout", y2.shape)
        y2 = torch.flatten(y2, 1)
        self.feature = y2.detach()
        #print("flatten", y2.shape)
        y2 = self.fc(y2)
        #print("fc", y2.shape)

        return y2


