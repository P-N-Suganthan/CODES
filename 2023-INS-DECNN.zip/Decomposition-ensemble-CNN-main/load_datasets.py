import numpy as np

def load_drivedata(one_hot=False, decomposition_mode='dwt'):
    data_file = r'drivedata/drivedata_' + decomposition_mode + '_decomposition.npz'
    data = np.load(data_file)
    xdata = data['arr_0']
    label = data['arr_1']
    subIdx = data['arr_2']

    samplenum = label.shape[0]
    if one_hot:
        ydata = np.zeros((samplenum, 2), dtype=np.longlong)
        for k in range(len(label)):
            if label[k] == 1:
                ydata[k] = [0, 1]
            else:
                ydata[k] = [1, 0]
    else:
        ydata = np.squeeze(label.astype(np.int64))

    return xdata, ydata, subIdx