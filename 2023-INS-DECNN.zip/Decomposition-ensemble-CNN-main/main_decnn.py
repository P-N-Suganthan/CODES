import os
import numpy as np
from sklearn.metrics import accuracy_score, precision_recall_fscore_support

import torch
import torch.nn as nn
import torch.backends.cudnn as cudnn

from load_datasets import load_drivedata
from cnn_utils import train, validate, save_checkpoint
from nn_models import InterpretableCNN,EEGNet, EIPCNN


def main_work_cnn(model_name='ensemble', evaluate=False, sub=1, ensemble=False, element=0, decomposition_mode='dwt', n_net=10):
    # setting seed
    seed = 0
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.deterministic = True

    # creat model
    print("=> creating model '{}'".format('model_name'))

    dataset_sel = 'drivedata'
    mode = 'inter'

    lr = 1e-3
    epochs = 50
    batch_size = 50

    if model_name == 'InterpretableCNN':
        model = InterpretableCNN()
    elif model_name == 'EEGNet':
        model = EEGNet()
    elif model_name == 'ensemble':  # ensemble
        model = EIPCNN(n_net=n_net)
    else:
        raise Exception('model_name: {}'.format(model_name))

    print(model)

    num_params = 0
    for param in model.parameters():
        num_params += param.numel()
    print('Total number of parameters: %d' % num_params)

    #   Get cpu or gpu device for training
    torch.cuda.get_device_name(0)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("Using {} device".format(device))
    model = model.cuda(device)

    optimizer = torch.optim.Adam(model.parameters(), lr)

    # define loss function (criterion) and optimizer
    criterion = nn.CrossEntropyLoss().cuda(device)

    xdata, ydata, subIdx = load_drivedata(one_hot=False, decomposition_mode=decomposition_mode)

    #       form the training data
    trainindx=np.where(subIdx != sub)[0]
    xtrain=xdata[trainindx]
    if not ensemble:
        xtrain = xtrain[:, :, element, :]
    x_train = np.expand_dims(xtrain, axis=1)
    y_train = ydata[trainindx]

    #       form the testing data
    testindx = np.where(subIdx == sub)[0]
    xtest = xdata[testindx]
    if not ensemble:
        xtest = xtest[:, :, element, :]
    x_test = np.expand_dims(xtest, axis=1)
    y_test = ydata[testindx]

    dataset = torch.utils.data.TensorDataset(torch.from_numpy(x_train.astype(np.float32)),
                                             torch.from_numpy(y_train))
    train_loader = torch.utils.data.DataLoader(dataset, batch_size=batch_size, shuffle=True)

    dataset = torch.utils.data.TensorDataset(torch.from_numpy(x_test.astype(np.float32)), torch.from_numpy(y_test))
    test_loader = torch.utils.data.DataLoader(dataset, batch_size=x_test.shape[0], shuffle=False)

    start_epoch = 0
    best_acc1 = 0
    # if mode == 'inter':
    if not ensemble:
        save_cp_path = 'Checkpoint' + os.sep + dataset_sel + os.sep + model_name + os.sep + 'decompostition_' \
                       + str(element) + os.sep + decomposition_mode + os.sep + str(sub)
    else:
        save_cp_path = 'Checkpoint' + os.sep + dataset_sel + os.sep + model_name + os.sep + str(sub)

    if not os.path.exists(save_cp_path):
        os.makedirs(save_cp_path)

    train_hist = {}
    train_hist['loss'] = []
    train_hist['val_loss'] = []

    cudnn.benchmark = False

    if evaluate:
        accs = []
        # load from pre-trained, before DistributedDataParallel constructor
        pretrained = save_cp_path + os.sep + 'model_best.pth.tar'
        if pretrained:
            print('pretrained is True')
            if os.path.isfile(pretrained):
                print("=> loading checkpoint '{}'".format(pretrained))
                checkpoint = torch.load(pretrained, map_location="cpu")
                model.load_state_dict(checkpoint['state_dict'])
                print('loaded from epoch {}'.format(checkpoint['epoch']))
                print('train loss {}'.format(checkpoint['loss']))
                acc, _ = validate(test_loader, model, criterion, ensemble=ensemble)
                accs.append(acc.item())
            else:
                raise Exception('pretrained path error: {}'.format(pretrained))
        print('result: {}'.format(accs))
        return accs

    # for epoch in range(args.start_epoch, args.epochs):
    for epoch in range(start_epoch, epochs):

        train_hist, loss = train(train_loader, model, criterion, optimizer, epoch, ensemble=ensemble, train_hist=train_hist)

        # evaluate on validation set
        acc1, train_hist = validate(test_loader, model, criterion, ensemble=ensemble, train_hist=train_hist)

        # remember best acc@1 and save checkpoint
        is_best = acc1 > best_acc1
        best_acc1 = max(acc1, best_acc1)

        save_checkpoint({
            'epoch': epoch + 1,
            'arch': model_name,
            'state_dict': model.state_dict(),
            'best_acc1': best_acc1,
            'loss': loss,
            'optimizer': optimizer.state_dict(),
        }, is_best, save_cp_path, epoch, filename=save_cp_path + os.sep + 'checkpoint_{:04d}.pth.tar'.format(epoch), save_data=True
        )


def ensemble_learning(mode='inter', decomposition_mode=None):
    seed = 0
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.deterministic = True

    dataset_sel = 'drivedata'

    xdata, ydata, subIdx = load_drivedata(one_hot=False, decomposition_mode=decomposition_mode)

    aa = np.zeros((11, 1))
    prob_set = []
    y_test_set = []
    for sub in range(1, 12):
        # form the training data
        trainindx = np.where(subIdx != sub)[0]
        xtrain = xdata[trainindx]
        xtrain = np.expand_dims(xtrain, axis=1)
        y_train = ydata[trainindx]

        # form the testing data
        testindx = np.where(subIdx == sub)[0]
        xtest = xdata[testindx]
        xtest = np.expand_dims(xtest, axis=1)
        y_test = ydata[testindx]

        output_set = torch.zeros(size=[xdata.shape[2], xtest.shape[0], 2])
        for k in range(xdata.shape[2]):
            x_train = xtrain[:, :, :, k, :]

            x_test = xtest[:, :, :, k, :]

            x_train = torch.tensor(x_train, dtype=torch.float32)
            x_train = x_train.cuda()
            x_test = torch.tensor(x_test, dtype=torch.float32)
            x_test = x_test.cuda()

            # load cnns
            model = EEGNet()
            model = model.cuda()

            save_cp_path = 'Checkpoint' + os.sep + dataset_sel + os.sep + 'EEGNet' + os.sep + 'decompostition_' \
                           + str(k) + os.sep + decomposition_mode + os.sep + str(sub)

            # you can choose the desired epochs
            pretrained = save_cp_path + os.sep + 'model_best.pth.tar'
            # pretrained = save_cp_path + os.sep + 'checkpoint_{:04d}.pth.tar'.format(epoch_no)
            if pretrained:
                # print('pretrained is True')
                if os.path.isfile(pretrained):
                    # print("=> loading checkpoint '{}'".format(pretrained))
                    checkpoint = torch.load(pretrained, map_location="cpu")
                    model.load_state_dict(checkpoint['state_dict'])
                    # print('loaded from epoch {}'.format(checkpoint['epoch']))
                    # print('train loss {}'.format(checkpoint['loss']))
                    model.eval()
                    with torch.no_grad():
                        output = model(x_test)
                    probs = nn.functional.softmax(output, dim=1)
                    output_set[k, :, :] = probs.cpu()
                else:
                    raise Exception('There is no pretrained path {}'.format(pretrained))

        voting_output = torch.mean(output_set, dim=0)
        output_array = voting_output.detach().numpy()
        accu = accuracy_score(y_test, output_array.argmax(axis=-1))
        aa[sub-1] = accu

        prob_set = prob_set + output_array.argmax(axis=-1).tolist()
        y_test_set = y_test_set + y_test.tolist()

        print(accu)
    print(np.mean(aa))
    precise, recall, fscore, _ = precision_recall_fscore_support(y_test_set, prob_set)
    print('precise: {}, recall: {}, fscore: {}'.format(precise, recall, fscore))


if __name__ == '__main__':

############### DWT-based EEEGNet in E2 mode ############

    evaluate = False
    #

    for element in range(6):
        accss = []
        for sub in range(1, 12):
            accs = main_work_cnn(model_name='EEGNet',
                                 sub=sub,
                                 evaluate=evaluate,
                                 ensemble=False,
                                 element=element,
                                 decomposition_mode='dwt_db3_6',
                                 n_net=6)
            if evaluate:
                accss = accss + accs
                print(1)
        if evaluate:
            print(f'################# element {str(element)} ################')
            for i in range(11):
                print(accss[i])
            print(np.mean(accss))


############ Output Fusion Mode ########################
    ensemble_learning(decomposition_mode='dwt_db3_6')



