# Decomposition-ensemble-CNN
Decomposition-based ensemble CNN
by Ruilin Li, Ruobin Gao, P. N. Suganthan

A demo of the DWT-based ensemble EEGNet in E2 mode described in the paper "A decomposition-based hybrid ensemble CNN framework for driver fatigue recognition" (https://doi.org/10.1016/j.ins.2022.12.088). 

If you find the codes useful, please cite the paper:

Ruilin Li, Ruobin Gao, Ponnuthurai Nagaratnam Suganthan, A decomposition-based hybrid ensemble CNN framework for driver fatigue recognition, Information Sciences, Volume 624, 2023, Pages 833-848, https://doi.org/10.1016/j.ins.2022.12.088.

The implementation of the models in E1 mode will be uploaded later.
