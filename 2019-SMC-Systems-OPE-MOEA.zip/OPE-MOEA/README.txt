The algorithm OPE_MOEA can be run by putting in the folder Algorithms of PlatEMO.

The PlatEMO can be download in website:
https://github.com/BIMK/PlatEMO


The relevant work is as follows:
Huangke Chen, Guohua Wu, Witold Pedrycz, Ponnuthurai Nagaratnam Suganthan, Lining Xing, and Xiaomin Zhu. An Adaptive Resource Allocation Strategy for Objective Space Partition-Based Multiobjective Optimization, IEEE Transactions on Systems, Man, and Cybernetics: Systems, DOI: 10.1109/TSMC.2019.2898456