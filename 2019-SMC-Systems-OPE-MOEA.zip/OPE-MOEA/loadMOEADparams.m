function [params, obtainPop] = loadMOEADparams(Global)
    %LOADPARAMS Load the parameter settings for MOEA/D.
    
    % The struct of MOEA/D 
    params = struct('population',[], 'varDomain',[], 'popuSize',[], 'subProbWeight',[], 'neighborRelation',[], ...
         'maxNonDomiSoluNum',[], 'setGenerations',[], 'evaluationUpper',[], 'c3',[], 'Tm',[], 'CR',[], 'F',[]);
    
    
    %% Set population size, reference vector, maximal fitness evaluations
    popSize = Global.N;
    [tempWeight, ~] = UniformPoint(Global.N, Global.M);
    %tempWeight = Weight(Global.N, Global.M)';
    
    v  = squareform(pdist(tempWeight)); %�������     
    [~, neighborRelation]= sort(v); % ����֮��Ĺ�ϵ
    
    params.setGenerations = 50; % The interation number of a selected subarea 
    
    params.popuSize = popSize; % Population size
    params.subProbWeight = tempWeight; % weight
    params.neighborRelation = neighborRelation;
    params.evaluationUpper = Global.evaluation; 
    
    
    %% Initialize a population
    empty_subArea.PositionMatrix = [];
    empty_subArea.ObjectiveMatrix = [];
    empty_subArea.SubPop = [];
    %empty_subArea.VelocityMatrix = [];
    empty_subArea.SubAreaIndexArray = [];
    empty_subArea.Distance = [];
    population = repmat(empty_subArea, params.popuSize, 1);
    params.population = population;
    
    % Initialization of each subproblems in MOEA/D
    varDomain = zeros(2, Global.D);
    varDomain(1, :) = Global.lower;
    varDomain(2, :) = Global.upper;
    params.varDomain = varDomain; % Lower and upper boundary
    initFactor = 20;
    XRRmin = repmat(varDomain(1, :), ceil(popSize*initFactor), 1);            
    XRRmax = repmat(varDomain(2, :), ceil(popSize*initFactor), 1);           
    initPopulation = XRRmin + (XRRmax - XRRmin) .* rand(ceil(popSize*initFactor), Global.D); % Initialize a population
    
    obtainPop = INDIVIDUAL(initPopulation);
    initObjectiveMatrix = obtainPop.objs; % evaluate(mop, initPopulation);  % Obtain the objective vectors
    
    weightMatrixTONF = sqrt(sum(params.subProbWeight.^2, 2)); %�ӿռ�б�ʵĶ��η�ʽ
    params.weightMatrixTONF = weightMatrixTONF;
    
    if strcmp(class(Global.problem), 'ZDT4')
        idealPoint = min(initObjectiveMatrix(:, 2))*0.9;
        meanPoint = mean(initObjectiveMatrix(:, 2));
    end
    
    
    %% Assocaite each solution to a sub-space   
    for newSolutionIndex = 1: size(initObjectiveMatrix, 1) 
        
        objArray = initObjectiveMatrix(newSolutionIndex, :); % Objective vector
        
        if strcmp(class(Global.problem), 'ZDT4')
            objArray(2) = (objArray(2) - idealPoint)/(meanPoint - idealPoint);
        end
        
        angleArray = acos(1-pdist2(objArray, params.subProbWeight, 'cosine'));
        [~, subAreaIndex] = min(angleArray);
        
        params.population(subAreaIndex).PositionMatrix = [params.population(subAreaIndex).PositionMatrix
            initPopulation(newSolutionIndex, :)]; % 
        params.population(subAreaIndex).ObjectiveMatrix = [params.population(subAreaIndex).ObjectiveMatrix
            initObjectiveMatrix(newSolutionIndex, :)]; % 
        params.population(subAreaIndex).SubPop = [params.population(subAreaIndex).SubPop, obtainPop(newSolutionIndex)];
                        
    end
    
    
    %% Update each sub-space
    idealPoint = zeros(1, Global.M);
    idealPoint = idealPoint * -1;
    for subAreaIndex = 1: numel(params.population)
        subAreaObjMatrix = params.population(subAreaIndex).ObjectiveMatrix; % Objective vectors in a sub-space
        objNum = size(subAreaObjMatrix, 1); % Number of solutions
        
        weight = params.subProbWeight(subAreaIndex, :);
        
        if objNum == 1 
            %params.population(subAreaIndex).VelocityMatrix = zeros(1, Global.D);
            
            % Rewrite !!!!
%             params.population(subAreaIndex).Distance = sqrt(sum((subAreaObjMatrix(1, :)-idealPoint).^2)); %����������������㣨0��0���ľ���
            
            tempObjs = subAreaObjMatrix - repmat(idealPoint, objNum, 1);
            CosVectorOri = 1-pdist2(tempObjs, weight, 'cosine');
            SinVectorOri = sqrt(1 - CosVectorOri.^2);
            Fitness = sqrt(sum(tempObjs.^2, 2)).*CosVectorOri + sqrt(sum(tempObjs.^2, 2)).*SinVectorOri;
            params.population(subAreaIndex).Distance = min(Fitness);
            
        elseif objNum >= 2
            % Indentify dominated solutions
            dominatedTag = false(1, objNum);
            for objIndex = 1: objNum-1
                if dominatedTag(objIndex)
                    continue;
                end
                
                for compObjIndex = 2: objNum
                    % Obtain objective vector
                    firstObjArray = subAreaObjMatrix(objIndex, :);
                    secondObjArray = subAreaObjMatrix(compObjIndex, :);
                    
                    if all(firstObjArray >= secondObjArray) && any(firstObjArray > secondObjArray) 
                       dominatedTag(objIndex) = true;
                       break;
                    end
                    
                    if all(firstObjArray <= secondObjArray) && any(firstObjArray < secondObjArray) 
                        dominatedTag(compObjIndex) = true;
                    end  
                end  
            end
            % Remove dominated solutions
            dominatedIndexArray = find(dominatedTag == true);
            params.population(subAreaIndex).ObjectiveMatrix(dominatedIndexArray, :) = [];
            params.population(subAreaIndex).PositionMatrix(dominatedIndexArray, :) = [];
            
            tempSubPop = params.population(subAreaIndex).SubPop;
            params.population(subAreaIndex).SubPop = tempSubPop(~dominatedTag);
            
            
            nonDominatedNum = size(params.population(subAreaIndex).ObjectiveMatrix, 1);            
            if nonDominatedNum > params.maxNonDomiSoluNum % Number of non-dominated solutions is larger than
                
                % Rewrite !!!!
%                 distanceArray = sqrt(sum( power(params.population(subAreaIndex).ObjectiveMatrix, 2), 2));
                
                subAreaObjMatrix = params.population(subAreaIndex).ObjectiveMatrix;
                tempObjs = subAreaObjMatrix - repmat(idealPoint, nonDominatedNum, 1);
                CosVectorOri = 1-pdist2(tempObjs, weight, 'cosine');
                SinVectorOri = sqrt(1 - CosVectorOri.^2);
                distanceArray = sqrt(sum(tempObjs.^2, 2)).*CosVectorOri + sqrt(sum(tempObjs.^2, 2)).*SinVectorOri;
                
                [~, rank] = sort(distanceArray);    
                params.population(subAreaIndex).ObjectiveMatrix = params.population(subAreaIndex).ObjectiveMatrix(rank(1: params.maxNonDomiSoluNum), :);
                params.population(subAreaIndex).PositionMatrix = params.population(subAreaIndex).PositionMatrix(rank(1: params.maxNonDomiSoluNum), :);
                %params.population(subAreaIndex).Distance = sqrt(sum((subAreaObjMatrix(1, :)-idealPoint).^2));
                
                params.population(subAreaIndex).Distance = min(distanceArray);
            else
                %params.population(subAreaIndex).VelocityMatrix = zeros(nonDominatedNum, Global.D);
                
                % Rewrite !!!!
                %params.population(subAreaIndex).Distance = sqrt(sum((subAreaObjMatrix(1, :)-idealPoint).^2)); %����������������㣨0��0���ľ���
                
                subAreaObjMatrix = params.population(subAreaIndex).ObjectiveMatrix;
                tempObjs = subAreaObjMatrix - repmat(idealPoint, nonDominatedNum, 1);
                CosVectorOri = 1-pdist2(tempObjs, weight, 'cosine');
                SinVectorOri = sqrt(1 - CosVectorOri.^2);
                distanceArray = sqrt(sum(tempObjs.^2, 2)).*CosVectorOri + sqrt(sum(tempObjs.^2, 2)).*SinVectorOri;
                params.population(subAreaIndex).Distance = min(distanceArray);
                
            end   
        end
                
        
        solutionNum = size(params.population(subAreaIndex).PositionMatrix, 1);
        params.population(subAreaIndex).SubAreaIndexArray = ones(solutionNum, 1) * -1;
    end
    
    
    %% ���ö����������Ⱥ�Ĳ���c3
    M = ceil(params.popuSize - Global.D/10);
    c3 = Global.D/M*0.01;
    params.c3 = c3;    
    params.Tm = 30; % 30  %MOP2: 15;    
    params.F = 0.5;
    
    switch class(Global.problem) % mop.name          
        case {'MOEADM2M_F1', 'MOEADM2M_F3', 'MOEADM2M_F4', 'MOEADM2M_F5', 'MOEADM2M_F6', 'MOEADM2M_F7'}             
            params.CR = 1; 
            params.Tm = 30; % 30  %MOP2: 15;
        case {'MOEADM2M_F2'}             
            params.CR = 1; 
            params.Tm = 15; % 30  %MOP2: 15;
        case {'DTLZ1' }
            params.CR = 0.5;
            params.Tm = 30; % 30  %MOP2: 15;
        case {'DTLZ4'}
            params.CR = 0.5;  
            params.Tm = 20; % 30  %MOP2: 15;
        case {'DTLZ3'}
            params.CR = 0.1; % 0.5; 
            params.Tm = ceil(params.popuSize/2); % 30  %MOP2: 15;
        case { 'DTLZ2' } 
            params.CR = 0.5;  
            params.Tm = 30; % 30  %MOP2: 15;
        case {'ZDT1', 'ZDT2', 'ZDT3', 'ZDT4', 'ZDT6',  'MOEADDE_F1',  ...
                 'MOEADDE_F4',  'MOEADDE_F6', 'MOEADDE_F7', 'MOEADDE_F8' } 
            params.CR = 1.0;  
            params.Tm = 30; % 30  %MOP2: 15;
        case {'MOEADDE_F2', 'MOEADDE_F3' } 
            params.CR = 1.0;  
            params.Tm = 25; % 30  %MOP2: 15;            
        case {'MOEADDE_F5' } 
            params.CR = 1.0;  
            params.Tm = 15; % 30  %MOP2: 15;            
        case {'MOEADDE_F9' } 
            params.CR = 1.0;  
            params.Tm = 15; 
        case {'IMMOEA_F10' }
            params.CR = 0.5;
            params.Tm = 10;
        otherwise            
            params.CR = 0.5;  
            params.Tm = 30; % 30
    end
        
    switch class(Global.problem) % mop.name            
        case {'ZDT1', 'ZDT2', 'ZDT3', 'ZDT4', 'ZDT6', 'MOEADDE_F1'} 
            %params.Tm = 15; % 30  %MOP2: 15;
            params.maxNonDomiSoluNum = 5; %ÿ���������ڵ�����֧�������  ZDT1 ZDT2: 2
        case { 'MOEADDE_F5',  'MOEADDE_F6',  'MOEADDE_F7', 'MOEADDE_F8' } 
            params.maxNonDomiSoluNum = 2;           
        case { 'MOEADDE_F9'  } 
            params.maxNonDomiSoluNum = 3;        
        case {'DTLZ1'}
            params.maxNonDomiSoluNum = 2;
        case {'DTLZ2'}
            params.maxNonDomiSoluNum = 15;
        case {'DTLZ3'}
            params.maxNonDomiSoluNum = 2;
        case {'MOEADDE_F2', 'MOEADDE_F3' } 
            params.maxNonDomiSoluNum = 3;
        case {'IMMOEA_F10' }
            params.maxNonDomiSoluNum = 10;
        otherwise
             params.maxNonDomiSoluNum = 5;
    end
    
end

function val_w = Weight(popsize,objDim)
    if objDim==2
        start      = 1/(popsize*100000);
        val_w(1,:) = linspace(start,1-start,popsize);
        val_w(2,:) = ones(1,popsize)-val_w(1,:);
    elseif objDim==3
        val_w = lhsdesign(popsize, 3, 'criterion','maximin')';
    else
        [tempWeight, ~] = UniformPoint(popsize, objDim);
        val_w = tempWeight';
    end
end