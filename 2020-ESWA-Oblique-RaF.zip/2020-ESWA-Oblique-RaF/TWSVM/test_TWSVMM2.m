% function [Predict_Y2,acc] = test_TWSVMM2(FunPara,trainX,trainY,TestX,testY)
function [Predict_Y,acc] = test_TWSVMM2(kern,trainX,trainY,TestX,W,fun_handle)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Predict and output
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
w1=W(1:end-1,1);
b1=W(end,1);
w2=W(1:end-1,2);
b2=W(end,2);

kerfPara.type=kern.type;
kerfPara.pars=kern.mu;
if strcmp(fun_handle,'TWSVMM3')
    m=size(TestX,1);
    
    if strcmp(kerfPara.type,'lin')
        H=TestX;
        w11=sqrt(w1'*w1);
        w22=sqrt(w2'*w2);
        y1=H*w1+b1*ones(m,1);
        y2=H*w2+b2*ones(m,1);
    else
        % C=[DataTrain.A;DataTrain.B];
        C=trainX;
        X=trainX;
        H=kernelfun(TestX,kerfPara,C);
        w11=sqrt(w1'*kernelfun(X,kerfPara,C)*w1);
        w22=sqrt(w2'*kernelfun(X,kerfPara,C)*w2);
        y1=H*w1+b1*ones(m,1);
        y2=H*w2+b2*ones(m,1);
    end
    wp=sqrt(2+2*w1'*w2/(w11*w22));
    wm=sqrt(2-2*w1'*w2/(w11*w22));
    clear H; clear C;
    
    m1=y1/w11;
    m2=y2/w22;
    MP=(m1+m2)/wp;
    MN=(m1-m2)/wm;
    mind=min(abs(MP),abs(MN));
    maxd=max(abs(MP),abs(MN));
    Predict_Y = sign(abs(m2)-abs(m1));
    
    Predict_Y2 = Predict_Y;
    if ~strcmp(trainY,'skipp')
        lbls_uniq = unique(trainY);
        Predict_Y2(Predict_Y==1)=lbls_uniq(1);
        Predict_Y2(Predict_Y==-1)=lbls_uniq(2);
        
        %acc = sum(Predict_Y2==testY)/length(testY);
        testY=trainY;
        acc = sum(Predict_Y2==testY)/length(testY);
    else
        acc=0;
    end
end % Function End