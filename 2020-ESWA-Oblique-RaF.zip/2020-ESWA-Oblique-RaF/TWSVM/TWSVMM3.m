function [bestCutVar,b]= TWSVMM3(Data,Label,FunPara,minleaf,fun_handle)
% function Predict_Y = TWSVMM2(TestX,DataTrain,FunPara)
% function [Predict_Y2 acc] = TWSVMM3(FunPara,trainX,trainY,TestX,testY)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TWSVM: Twin Support Vector Machine
%
% Predict_Y = TWSVM(TestX,DataTrain,FunPara)
%
% Input:
%    TestX - Test Data matrix. Each row vector of fea is a data point.
%
%    DataTrain - Struct value in Matlab(Training data).
%                DataTrain.A: Positive input of Data matrix.
%                DataTrain.B: Negative input of Data matrix.
%
%    FunPara - Struct value in Matlab. The fields in options that can be set:
%              c1: [0,inf] Paramter to tune the weight.
%              c2: [0,inf] Paramter to tune the weight.
%              c3: [0,inf] Paramter to tune the weight.
%              c4: [0,inf] Paramter to tune the weight.
%              kerfPara:Kernel parameters. See kernelfun.m.
%
% Output:
%    Predict_Y - Predict value of the TestX.
%
% Examples:
%    DataTrain.A = rand(50,10);
%    DataTrain.B = rand(60,10);
%    TestX=rand(20,10);
%    FunPara.c1=0.1;
%    FunPara.c2=0.1;
%    FunPara.c3=0.1;
%    FunPara.c4=0.1;
%    FunPara.kerfPara.type = 'lin';
%    Predict_Y = TWSVM(TestX,DataTrain,FunPara);
%
% Reference:
%    Y.-H. Shao, C.-H. Chun, X.-B. Wang, N.-Y. Deng.Improvements on Twin
%    Support Vector Machines.IEEE Transactions on Neural Networks, 2011, 22
%    (6):962-968.
%
%    Version 1.0 --Apr/2013
%
%    Written by Yuan-Hai Shao (shaoyuanhai21@163.com)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initailization

unique_label=unique(Label);
flag_temp=1;
m=length(unique_label);
BAD_flag=0;
XX=unique(Label);
if length(XX)==1
   bestCutVar=-1;
   BAD_flag=1;
   W_new=zeros(size(Data,2)+1,1)';
end
if BAD_flag==0
if m>=3
    [group1,group2]=group([Label,Data]);
else
    group1=unique_label(1);
    group2=unique_label(2);
end

 m1=length(group1);
 m2=length(group2);
 index1=[];
 for i=1:m1
    index=find(Label==group1(i));
    index1=[index1;index];
 end
index2=[];
for i=1:m2
    index=find(Label==group2(i));
    index2=[index2;index];
end
if size(index1,2)~=1
    index1=index1';
end
if size(index2,2)~=1
    index2=index2';
end
Label_A=Label(index1);
Label_B=Label(index2);
Data_A=Data(index1,:);
Data_B=Data(index2,:);
DataTrain.A=Data_A;
DataTrain.B=Data_B;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Preprocessing the data
% lbls_uniq = unique(trainY);
% DataTrain.A = trainX(trainY==lbls_uniq(1),:);
% DataTrain.B = trainX(trainY==lbls_uniq(2),:);
%%%%%%%

%tic;
Xpos = DataTrain.A;
Xneg = DataTrain.B;
cpos = FunPara.C1;
cneg = FunPara.C1;
eps1 = FunPara.C3;
eps2 = FunPara.C3;
kerfPara.type = FunPara.type;
kerfPara.pars=FunPara.mu;
m1=size(Xpos,1);
m2=size(Xneg,1);
e1=-ones(m1,1);
e2=-ones(m2,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute Kernel
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if strcmp(kerfPara.type,'lin')
    H=[Xpos,-e1];
    G=[Xneg,-e2];
else
    X=[DataTrain.A;DataTrain.B];
    H=[kernelfun(Xpos,kerfPara,X),-e1];
    G=[kernelfun(Xneg,kerfPara,X),-e2];
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute (w1,b1) and (w2,b2)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%DTWSVM1
HH=H'*H;
HH = HH + eps1*eye(size(HH));%regularization
HHG = HH\G';
kerH1=G*HHG;
kerH1=(kerH1+kerH1')/2;
alpha=qpSOR(kerH1,0.5,cpos,0.05); %SOR
vpos=-HHG*alpha;

%%%%DTWSVM2
QQ=G'*G;
QQ=QQ + eps2*eye(size(QQ));%regularization
QQP=QQ\H';
kerH1=H*QQP;
kerH1=(kerH1+kerH1')/2;
gamma=qpSOR(kerH1,0.5,cneg,0.05);
vneg=QQP*gamma;
clear kerH1 H G HH HHG QQ QQP;

% w1=vpos(1:(length(vpos)-1));
% b1=vpos(length(vpos));
% w2=vneg(1:(length(vneg)-1));
% b2=vneg(length(vneg));
%%%
w1=vpos(1:length(vpos));
% b1=vpos(length(vpos));
w2=vneg(1:length(vneg));
% b2=vneg(length(vneg));
W=[w1 w2];
% [bestCutVar,W_new]=select_hyperplane(W,Data,Labels,minleaf,kern)
kern.type=FunPara.type;
kern.mu=FunPara.mu;
[bestCutVar,b]=select_hyperplane3_2(W,Data,Label,minleaf,kern,fun_handle);
%%%
%toc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Predict and output
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% m=size(TestX,1);
% if strcmp(kerfPara.type,'lin')
%     H=TestX;
%     w11=sqrt(w1'*w1);
%     w22=sqrt(w2'*w2);
%     y1=H*w1+b1*ones(m,1);
%     y2=H*w2+b2*ones(m,1);
% else
%     C=[DataTrain.A;DataTrain.B];
%     H=kernelfun(TestX,kerfPara,C);
%     w11=sqrt(w1'*kernelfun(X,kerfPara,C)*w1);
%     w22=sqrt(w2'*kernelfun(X,kerfPara,C)*w2);
%     y1=H*w1+b1*ones(m,1);
%     y2=H*w2+b2*ones(m,1);
% end
% wp=sqrt(2+2*w1'*w2/(w11*w22));
% wm=sqrt(2-2*w1'*w2/(w11*w22));
% clear H; clear C;
%
% m1=y1/w11;
% m2=y2/w22;
% MP=(m1+m2)/wp;
% MN=(m1-m2)/wm;
% mind=min(abs(MP),abs(MN));
% maxd=max(abs(MP),abs(MN));
% Predict_Y = sign(abs(m2)-abs(m1));
%
% Predict_Y2 = Predict_Y;
% Predict_Y2(Predict_Y==1)=lbls_uniq(1);
% Predict_Y2(Predict_Y==-1)=lbls_uniq(2);
% acc = sum(Predict_Y2==testY)/length(testY);
end