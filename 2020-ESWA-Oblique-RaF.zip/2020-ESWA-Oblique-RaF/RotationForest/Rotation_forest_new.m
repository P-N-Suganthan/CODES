function [Y_hat,Y,accuracy,model,Trainingtime,Testingtime]=Rotation_forest_new(FunPara,TrainX,TrainY,TestX,TestY,K,L,O,minleaf)
% O indictaes which decision tree to use in rotation forests.
% O=1 standrad                      'oblique'=1
% O=2 PSVM-Tikhonov regularization  'oblique'=3
% O=3 PSVM-axis parallel            'oblique'=4
% O=4 PSVM-subspace                 'onlique'=5
% L   ensemble size
% K   unmber of features in each subfeature space.
% Y_hat  the final prediction by the forest
% Y the vote for each tree
fun_handle='';

if (~exist('O','var'))
   O=1;
   fprintf('No information about which decision tree to be involved\n ');
   fprintf('default : standard axis-parallel decision tree\n');
end
[m,n]=size(TestX);
if K>n
    error 'the number of features in each subspace can not be larger than the dimension of the samples'
end

model=cell(L,1);
 %% number of ensemble individuals;
Y=zeros(m,L);
Index=1:length(TrainY);
Trainingtime=0;
Testingtime=0;

for i=1:L
    %%% obtain the new samples by rotation forest %%%
    tic
    if (mod(i,50) == 0) 
        fprintf([num2str(i),' decision tree generated in new Rotation Forest with: ']);
    end
    

    ratio=0.75;
   [R_new,R_coeff,trainRFnew,testXRFnew]=RotationFal(TrainX, TrainY, TestX, K, ratio);

   if O==1 
       if (mod(i,50) == 0) 
        fprintf('axis-parallel split\n ');
       end
       
       model{i} = Obliquecartree_train('',trainRFnew,TrainY,Index,'oblique',O,'minleaf',minleaf,'nvartosample',round(sqrt(size(trainRFnew,2))));
   end
   if O==3
       if (mod(i,50) == 0) 
       fprintf(' PSVM-Tikhonov regularization\n');
       end
        model{i} = Obliquecartree_train('',trainRFnew,TrainY,Index,'oblique',O,'minleaf',minleaf,'nvartosample',round(sqrt(size(trainRFnew,2))));
   end
   if O==4
       if (mod(i,50) == 0) 
       fprintf('PSVM-axis parallel regularization\n');
       end
       model{i} = Obliquecartree_train('',trainRFnew,TrainY,Index,'oblique',O,'minleaf',minleaf,'nvartosample',round(sqrt(size(trainRFnew,2))));
   end
   if O==5
       if (mod(i,50) == 0) 
       fprintf('PSVM-subspace regularization\n ');
       end
       model{i} = Obliquecartree_train('',trainRFnew,TrainY,Index,'oblique',O,'minleaf',minleaf,'nvartosample',round(sqrt(size(trainRFnew,2))));
   end
    if O==12 
       if (mod(i,10) == 0) 
        fprintf('optimized  PSVM-Tikhonov regularization\n ');
       end
       model{i} = Obliquecartree_train('',trainRFnew,TrainY,Index,'oblique',O,'minleaf',minleaf);
    end
     if O==13 
       if (mod(i,50) == 0) 
        fprintf('TwinSVM_ROF\n ');
       end
       fun_handle='TWSVMM3';
       model{i} = Obliquecartree_train(FunPara,trainRFnew,TrainY,Index,'oblique',O,'minleaf',minleaf,'nvartosample',round(sqrt(size(trainRFnew,2))));
       %model{i} = Obliquecartree_train(FunPara,trainRFnew,TrainY,Index,'oblique',O,'minleaf',minleaf);
    end
   
   Trainingtime_temp=toc; 
   Trainingtime=Trainingtime+Trainingtime_temp;
   tic
   tree_output = Obliquecartree_predict(fun_handle,FunPara,testXRFnew,model{i});
   Testingtime_temp=toc;
   Testingtime=Testingtime+Testingtime_temp;
   
   if size(tree_output,2)~=1
       tree_output=tree_output';
   end
Y(:,i)=tree_output;
end
 Y_hat=zeros(m,1);
 for i=1:m
     Y_temp=unique(Y(i,:));
     count=zeros(1,length(Y_temp));
     for j=1:length(Y_temp)
     count(j)= length(find(Y(i,:)==Y_temp(j)));
     end
     [max_value,max_index]=max(count);
     Y_hat(i)=Y_temp(max_index);
 end
 accuracy=length(find(Y_hat==TestY))/length(TestY);

