function new_data=normalize_data(data)
data1=data';
[nSam,~]=size(data1);
for i=1:nSam
    data1(i,:)=mapminmax(data1(i,:),0,1);
%     data1(i,:)=data1(i,:)+1;
%     data1(i,:)=data1(i,:)./2;
end
new_data=data1';

end