function [bestCutVar,W,best_impurity]=optimal_hyperplane(Labels, Data,iteration1,iteration2,minleaf)
% iteration1 : number of re-start
% iteration2 : number of random jump

very_small=0.00001;
[m,n]=size(Data);
[bestCutVar bestCutValue] =axis_parallel_cut(Labels,Data,minleaf);
if bestCutVar~=-1
[cut_value_temp,best_impurity]=gini_impurity(Labels,Data(:,bestCutVar),minleaf);
best_impurity
W=zeros(n+1,1);
W(bestCutVar)=1;
W(end)=bestCutValue;
impurity_loop=ones(1,iteration1);
alfa_loop=zeros(n+1,iteration1);
 for loop=1:iteration1
     if loop==1
      alfa_old=W;
     [alfa_loop(:,loop),impurity_loop(loop),success_flag]=perturb_alfa(alfa_old,Data,Labels,minleaf);
     
     else
      alfa_old=rand(n+1,1)-0.5;
     [alfa_loop(:,loop),impurity_loop(loop),success_flag]=perturb_alfa(alfa_old,Data,Labels,minleaf);
     end
     
     if success_flag==0
         iteration2=0;
         success_flag_random_jump=0;
         while(iteration2<=iteration2 && success_flag_random_jump==0)
             iteration2=iteration2+1;
             [alfa_new,gini_new,success_flag_random_jump]=perturb_R(alfa_loop(:,loop),Data,Labels,impurity_loop(loop),minleaf);
         end
         if success_flag_random_jump==1
             alfa_loop(:,loop)=alfa_new';
             impurity_loop(loop)=gini_new;
         end
     end
     
 end
[min_value,min_index]=min(impurity_loop);

W=alfa_loop(:,min_index)';
best_impurity=min_value;




















else
    best_impurity=1;
    W=rand(n+1,1);
end
end