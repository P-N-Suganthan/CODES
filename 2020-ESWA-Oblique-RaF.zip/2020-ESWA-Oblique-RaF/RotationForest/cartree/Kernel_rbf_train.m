function matrix=Kernel_rbf_train(train_data,sigma)
m=size(train_data,1);


matrix=zeros(m,m);

for i=1:m-1
    for j=i+1:m
       matrix(i,j)= exp(-1*(norm(train_data(i,:)-train_data(j,:))/(2*(sigma)^2)));
       matrix(j,i)=matrix(i,j);
       matrix(i,i)=1;
    end
end


 


