function matrix=Kernel_rbf_test(train_data,test_data,sigma)
m=size(train_data,1);
n=size(test_data,1);

matrix=zeros(m,n);

for i=1:n
    for j=1:m
       matrix(j,i)= exp(-1*(norm(train_data(j,:)-test_data(i,:))/(2*(sigma)^2)));
    end
end


 


