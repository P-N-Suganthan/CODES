function RETree = Obliquecartree_train(FunPara,Data1,Labels1,Index,varargin)

%RETree = cartree(Data,Labels,varargin)
%
%   Grows a CARTree using Data(samplesXfeatures)
%   and one of the following criteria which
%   can be set via the parameter 'method'
%
%       'g' : gini impurity index (classification)
%       'c' : information gain (classification, default)
%       'r' : squared error (regression)
%
%   Other parameters that can be set are:
%
%       minparent    : the minimum amount of samples in an impure node
%                      for it to be considered for splitting (default 2)
%
%       minleaf      : the minimum amount of samples in a leaf (default 1)
%
%       weights      : a vector of values which weigh the samples
%                      when considering a split (default [])
%
%       nvartosample : the number of (randomly selected) variables
%                      to consider at each node (default all)

myflag=0;
okargs =   {'minparent' 'minleaf' 'nvartosample' 'method' 'weights' 'oblique' };
defaults = {2 1 size(Data1,2) 'c' [] 1};
[eid,emsg,minparent,minleaf,m,method,W,o] = getargs(okargs,defaults,varargin{:});
Sigma=1;
Data=Data1(Index,:);
Labels=Labels1(Index);
N = numel(Labels);
OOBIdx=setdiff(1:N,Index);
L = 2*ceil(N/minleaf) - 1;
M = size(Data,2);
nodeDataIndx = cell(L,1);
nodeDataIndx{1} = 1 : N;
nodevar=cell(L,1);
nodep=cell(L,1);
nodeCutVar = zeros(L,1);
nodeCutValue = zeros(L,1);
nodeStructure=cell(L,1);
nodeflags = zeros(L+1,1);
nodeOOBIndx = cell(L,1);
nodeOOBIndx{1} = OOBIdx;
nodelabel = zeros(L,1);
childnode = zeros(L,1);

nodeflags(1) = 1;
kernel_flag=0;
if o==6
    % kernel_matrix=Kernel_rbf_train(Data,Sigma);
    kernel_flag=1;
end
if o==8
    kernel_matrix=Kernel_rbf_train(Data,Sigma);
    kernel_flag=2;
end

switch lower(method)
    case {'c','g'}
        [unique_labels,temp,Labels]= unique(Labels);
        max_label = numel(unique_labels);
    otherwise
        max_label= [];
end

current_node = 1;
tiny_val=1e-10;
while nodeflags(current_node) == 1;
    
    OOB_flag=0;
    free_node = find(nodeflags == 0,1);
    currentDataIndx = nodeDataIndx{current_node};
    currentOOBIndx = nodeOOBIndx{current_node};
    if isempty(currentOOBIndx)
        
        OOB_flag=1;
    end
    if  numel(unique(Labels(currentDataIndx)))==1
        switch lower(method)
            case {'c','g'}
                nodelabel(current_node) = unique_labels(Labels(currentDataIndx(1)));
            case 'r'
                nodelabel(current_node) = Labels(currentDataIndx(1));
        end
        nodeCutVar(current_node) = 0;
        nodeCutValue(current_node) = 0;
        nodevar{current_node}=0;
        nodep{current_node}=0;
    else
        if numel(currentDataIndx)>2*minparent
            
            node_var = randperm(M);
            node_var = node_var(1:m);
            
%             if numel(W)>0
%                 Wcd = W(currentDataIndx);
%             else
%                 Wcd = [];
%             end
            
            
            
            X=Data(currentDataIndx,node_var);
            
            XOOB=Data1(currentOOBIndx,node_var);
            switch o
                case 1
                    %             [bestCutVar bestCutValue] = ...
                    %                 best_cut_node(method,X,Labels(currentDataIndx),Wcd,minleaf,max_label);
                    [bestCutVar bestCutValue] =axis_parallel_cut(Labels(currentDataIndx),X,minleaf);
                    
                    if bestCutVar~=-1
                        b=zeros(m+1,1);
                        b(bestCutVar)=1;
                        b(end)=bestCutValue;
                    end
                case 2
                    
                    
                    Labels(currentDataIndx)
                    
                    if length(currentDataIndx)>m
                        [bestCutVar,b,best_impurity]=optimal_hyperplane(Labels(currentDataIndx),X,10,10,minleaf);
                    else
                        [bestCutVar bestCutValue] =axis_parallel_cut(Labels(currentDataIndx),X,minleaf);
                        
                        if bestCutVar~=-1
                            b=zeros(m+1,1);
                            b(bestCutVar)=1;
                            b(end)=bestCutValue;
                        end
                    end
                case 3
                    Delta=0.01;
                    [bestCutVar, b] =hyperplane_psvm(X,Labels(currentDataIndx),1,minleaf,Delta);
                    
                    
                case 4
                    
                    [bestCutVar, b] =hyperplane_psvm(X,Labels(currentDataIndx),2,minleaf);
                    
                    
                case 5
                    [ bestCutVar,b]=hyperplane_psvm_subspace(X,Labels(currentDataIndx),minleaf);
                    
                case 6
                    kernel_matrix=Kernel_rbf_train(X,Sigma);
                    [bestCutVar, b] =hyperplane_psvm_kernel(kernel_matrix,Labels(currentDataIndx),minleaf,1);
                    %
                case 7
                    if length (currentDataIndx)>=m
                        iqr_X=iqr(X);
                        median_X=median(X);
                        X1=X-repmat(median_X,length(currentDataIndx),1);
                        X1=X1./rempat(iqr_X,length(currentDataIndx),1);
                        [bestCutVar,b,gini]=cart_lc(Labels(currentDataIndx),X1,minleaf);
                        Structure_node=cell(1,2);
                        Structure_node{1}=median_X;
                        Structure_node{2}=iqr_X;
                    else
                        [bestCutVar bestCutValue] =axis_parallel_cut(Labels(currentDataIndx),X,minleaf);
                        
                        if bestCutVar~=-1
                            b=zeros(m+1,1);
                            b(bestCutVar)=1;
                            b(end)=bestCutValue;
                        end
                    end
                case 8
                    [bestCutVar, b] =hyperplane_psvm_kernel(kernel_matrix(currentDataIndx,currentDataIndx),Labels(currentDataIndx),minleaf,1);
                case 9
                    [bestCutVar,b,gini]=random_oblique(Labels(currentDataIndx),X,minleaf) ;
                case 10
                    [bestCutVar,b,gini]=random_axis_parallel(Labels(currentDataIndx),X,minleaf);
                case 11
                    [bestCutVar,b,gini]=extremely_random_oblique(Labels(currentDataIndx),X,minleaf) ;
                case 12
                    % same as case 3 but 'delta' optimized with OOB samples
                    if OOB_flag==0
                        [bestCutVar,delta,bestacc]=select_parameter(X,Labels(currentDataIndx),XOOB,Labels1(currentOOBIndx),minleaf);
                        if bestCutVar~=-1
                            %    [bestCutVar, b] =hyperplane_psvm(X,Labels(currentDataIndx),1,minleaf,0.01);
                            [bestCutVar, b] =hyperplane_psvm(X,Labels(currentDataIndx),1,minleaf,delta);
                        end
                    else
                        Delta=0.01;
                        [bestCutVar, b] =hyperplane_psvm(X,Labels(currentDataIndx),1,minleaf,Delta);
                    end
                    %%
                case 13
                    myflag=1;
                    fun_handle='TWSVMM3';
                    [bestCutVar,b]= TWSVMM3(X,Labels(currentDataIndx),FunPara,minleaf,fun_handle);
                    
                otherwise
                    % simulation annealing
                    
                    
                    
            end
            %                  X
            %                    b
            %                    kernel_matrix(currentDataIndx,:)
            %                  Labels(currentDataIndx)
            if bestCutVar~=-1
                
                %                 nodeCutVar(current_node) = node_var(bestCutVar);
                nodeCutVar(current_node) = bestCutVar;
                %                 nodeCutValue(current_node) = bestCutValue;
                nodevar{current_node}=node_var;
                nodep{current_node}=b;
                if myflag==1
                    w1=b(1:end-1,1);
                    b1=b(end,1);
                    w2=b(1:end-1,2);
                    b2=b(end,2);
                    W=[w1,w2;b1,b2];
                    C=X;
                    [Predict_Y,~] = test_TWSVMM2(FunPara,C,Labels(currentDataIndx),C,W,fun_handle);
                    nodeDataIndx{free_node} = currentDataIndx(Predict_Y==1);% Data Bisecting occurs here
                    nodeDataIndx{free_node+1} = currentDataIndx(Predict_Y==-1);
                    
                else
                    
                    if kernel_flag==0
                        D=X*b(1:end-1);
                    else if kernel_flag==1
                            D=kernel_matrix*b(1:end-1);
                        else
                            D=kernel_matrix(currentDataIndx,currentDataIndx)*b(1:end-1);
                        end
                    end
                    if o==7
                        D=X1*b(1:end-1);
                        nodeStructure{current_node}=Structure_node;
                    end
                    
                    nodeDataIndx{free_node} = currentDataIndx(D<=b(end));
                    nodeDataIndx{free_node+1} = currentDataIndx(D>b(end));
                    if OOB_flag==0
                        DOOB=XOOB*b(1:end-1);
                        nodeOOBIndx{free_node} = currentOOBIndx(DOOB<=b(end));
                        nodeOOBIndx{free_node+1} = currentOOBIndx(DOOB>b(end));
                    else
                        nodeOOBIndx{free_node} ='';
                        nodeOOBIndx{free_node+1} ='';
                    end
                end
                nodeflags(free_node:free_node + 1) = 1;
                childnode(current_node)=free_node;
            else
                switch lower(method)
                    case {'c' 'g'}
                        [~, leaf_label] = max(hist(Labels(currentDataIndx),1:max_label));
                        nodelabel(current_node)=unique_labels(leaf_label);
                    case 'r'
                        nodelabel(current_node)  = mean(Labels(currentDataIndx));
                end
                
            end
        else
            switch lower(method)
                case {'c' 'g'}
                    [~, leaf_label] = max(hist(Labels(currentDataIndx),1:max_label));
                    nodelabel(current_node)=unique_labels(leaf_label);
                case 'r'
                    nodelabel(current_node)  = mean(Labels(currentDataIndx));
            end
        end
    end
    current_node = current_node+1;
end
RETree.nodeStructure=nodeStructure(1:current_node-1);
RETree.kernel=kernel_flag;
RETree.nodeDataIndex=  nodeDataIndx(1:current_node-1);
RETree.p=nodep(1:current_node-1);
RETree.node_var=nodevar(1:current_node-1);
RETree.nodeCutVar = nodeCutVar(1:current_node-1);
% RETree.nodeCutValue =nodeCutValue(1:current_node-1);
RETree.childnode = childnode(1:current_node-1);
RETree.nodelabel = nodelabel(1:current_node-1);
RETree.dataindex=Index;
RETree.nodeOOBIndx=nodeOOBIndx(1:current_node-1);