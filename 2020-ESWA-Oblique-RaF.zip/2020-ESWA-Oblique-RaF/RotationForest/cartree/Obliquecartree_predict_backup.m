function tree_output = Obliquecartree_predict(Train_data,Data,RETree)
 
% Evaluates the tree output

        Sigma=1;
        
        kernel_flag=RETree.kernel;
        M=size(Data,1);
        Structure_node=RETree.nodeStructure;
        dataindex=RETree.dataindex;
        node_index=RETree.nodeDataIndex;
        child_node=RETree.childnode;
        Node_var=RETree.node_var;
        
        Pca=RETree.p;
%         Node_cutvalue=RETree.nodeCutValue;
        Node_label=RETree.nodelabel;
%         if kernel_flag==1
%            kernel_matrix=Kernel_rbf_test(Train_data,Data,Sigma); 
%         end
    for i=1:M
        
        current_node = 1;
        while (child_node(current_node)~=0)
            
            cvar = Node_var{current_node};
            cp=Pca{current_node};
            
            Structure_node_temp=Structure_node{current_node};
            median_temp=Structure_node_temp;
            if ~isempty(median_temp)
               data_temp=Data(i,cvar)- Structure_node_temp{1};
               data_temp= data_temp./Structure_node_temp{2};
               X=data_temp*cp(1:end-1);
            else   
            
%                 if kernel_flag==1
%                 index_temp=node_index{current_node};
%                 index_temp1=dataindex(index_temp);
%                 X1=Kernel_rbf_test(Train_data(index_temp1,cvar),Data(i,cvar),Sigma);
%                   X1=kernel_matrix(index_temp,i)';
%                
%                   X=X1*cp(1:end-1);
%                  else
% %             var=Node_cutvar(current_node);
%                 X=Data(i,cvar)*cp(1:end-1);
%                 end
                if kernel_flag==1
                 index_temp=node_index{current_node};
                 index_temp1=dataindex(index_temp);
                 X1=Kernel_rbf_test(Train_data(index_temp1,cvar),Data(i,cvar),Sigma)';
                  X=X1*cp(1:end-1);
                end
                if kernel_flag==2
                  index_temp=node_index{current_node};
                  index_temp1=dataindex(index_temp);
                  X1=Kernel_rbf_test(Train_data(index_temp1,:),Data(i,:),Sigma)';
                     X=X1*cp(1:end-1);
                end
                  
               if kernel_flag==0
%             var=Node_cutvar(current_node);
                X=Data(i,cvar)*cp(1:end-1);
                end
            end
%             if (X(:,var)< Node_cutvalue(current_node)) 
            if X<cp(end)
               current_node = child_node(current_node);
            else
                current_node = child_node(current_node)+1;
            end
        end
            tree_output(i) = Node_label(current_node); 
    end
      if (size(Data,1) == size(tree_output,1)) 
      tree_output = tree_output';
      end