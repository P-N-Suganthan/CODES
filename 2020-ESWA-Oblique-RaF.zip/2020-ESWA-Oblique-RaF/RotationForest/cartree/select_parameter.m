function [bestCutVar,delta,bestacc]=select_parameter(TrainX,TrainY,TestX,TestY,minleaf)
unique_label=unique(TrainY);
m=length(unique_label);
BAD_flag=0;
bestCutVar=1;
delta=0.01;
if m>=3
    [group1,group2]=group([TrainY,TrainX]);
    else
    group1=unique_label(1);
    group2=unique_label(2);
end

XX=intersect(group1,group2);

if ~isempty(XX)
    BAD_flag=1;
    delta=1;
    bestacc=-1;
    bestCutVar=-1;
end
if BAD_flag==0
TrainY1=zeros(length(TrainY),1);
TestY1=zeros(length(TestY),1);
for i=1:length(group1)
    
    index_temp1= TrainY==group1(i);
    TrainY1(index_temp1)=1;
    
    index_temp2= TestY==group1(i);
    TestY1(index_temp2)=1;
end

for i=1:length(group2)
    
    index_temp3= TrainY==group2(i);
    TrainY1(index_temp3)=-1;
    
    index_temp4= TestY==group2(i);
    TestY1(index_temp4)=-1;
end

  bestacc=0;
for i=-10:2:10
   
       
     
     [bestCutVar1,W_new]=hyperplane_psvm_kernel(TrainX,TrainY1,minleaf,2^(i));
     Y1=sign(TrainX*W_new(1:end-1)-W_new(end));
     acc1=length(find(Y1==TrainY1))/length(TrainY1);
     Y11=-1*Y1;
     acc2=length(find(Y11==TrainY1))/length(TrainY1);
     Y2=sign(TestX*W_new(1:end-1)-W_new(end));
     
        if acc1<acc2
            
        
            Y2=-1*Y2;
        end
        acc=length(find(Y2==TestY1))/length(TestY1);
        if acc>bestacc
            bestacc=acc;
            bestCutVar=1;
            delta=2^(i);
        end
    
end
end
end