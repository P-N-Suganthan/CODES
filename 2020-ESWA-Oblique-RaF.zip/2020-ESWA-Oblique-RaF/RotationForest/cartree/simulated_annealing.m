function [bestCutVar,W,best_impurity]=simulated_annealing(Labels, Data,iterations)
minleaf=1;
[~,n]=size(Data);
W=zeros(n+1,1);
best_impurity=exp(20);
bestCutVar=-1;

 T=exp(3);   
alfa=rand(n+1,1);
X=Data*alfa(1:n);
[cut_value, impurity]=gini_impurity(Labels, X,minleaf);
if impurity<best_impurity
    best_impurity=impurity;
    alfa(n+1)=cut_value;
end

gen=0;
while(gen<=iterations)
    T=0.9*T;
 index=randperm(n);
 index=index(1);
 alfa1=alfa;
 alfa1(index)=alfa1(index)+rand(1)-0.5;
    X=Data*alfa1(1:n);
    impurity_old=impurity;
    [cut_value, impurity]=gini_impurity(Labels, X,minleaf);
    if impurity<best_impurity
        best_impurity=impurity;
    else 
        gen=gen+1;
    end
    
    if impurity<impurity_old
        bestCutVar=1;
        alfa=alfa1;
        alfa(end)=cut_value;
    else
        delta=impurity-impurity_old;
        p=exp((-delta)/T);
        
        if p<rand(1)
            bestCutVar=1;
            alfa=alfa1;
            alfa(end)=cut_value;
        end
    end
    
end
W=alfa;
end