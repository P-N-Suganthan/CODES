function  [y,w]=pca_ica(x)
n=size(x,1);
[E,D]=eig(cov(x'));
V=E*D^(-0.5)*E'*x;
z=repmat(sqrt(sum(V.^2)),n,1).*V; 
index=find(isnan(z)==0);
z(index)=0;
index=find(isfinite(z)==0);
z(index)=0;
[EE,DD]=eig(cov(z'));
y=EE'*V;
w=EE'*E*D^(-0.5)*E';
end