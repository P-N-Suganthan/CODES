function [bestCutVar,W,gini]=cart_lc(Labels,Data,minleaf)
[bestCutVar, bestCutValue] =axis_parallel_cut(Labels,Data,minleaf);
[nSamp,nFea]=size(Data);
very_small=0.00001;

if bestCutVar~=-1
   w=zeros(nFea+1,1);
   w(bestCutVar)=1;
   w(end)=bestCutValue;
   flag=1;
   loop=0;
   
   data1=Data*w(1:end-1)-w(end);
   gini_uni=get_gini(data1,Labels);
while (flag==1 && loop<=20)
       loop=loop+1;
    for i=1:nFea 
        gini_best_gamma=ones(3,1);
        delta=zeros(3,1);
        flag_gamma=0;
        if loop==1
                gini_best=gini_uni; 
             else
                gini_best=impurity(loop-1);
             end
             gini_best_gamma=gini_best*gini_best_gamma;
         for gamma=-0.25:0.25:0.25
             flag_gamma=flag_gamma+1;
             
         V=Data*w(1:end-1);
         U=(V-w(end))./(Data(:,i)+gamma);
          index_U=find(Data(:,i)+gamma==0);
          U(index_U)=1000;
         [U_sort,sort_index]=sort(U,'ascend');
         Pinx=find(Data(:,i)+gamma>=0);
         Ninx=find(Data(:,i)+gamma<0);
         PU=U(Pinx);
         NU=U(Ninx);
         L_temp=length(U_sort);
             for loop_temp=1:L_temp-1
                deta_temp=U_sort(loop_temp);
                index1=find(PU<=deta_temp);
                index2=find(NU>deta_temp);
                index1=Pinx(index1);
                index2=Ninx(index2);
                 if size(index1,1)~=1
                     index1=index1';
                 end
                 if size(index2,1)~=1
                     index2=index2';
                 end
    
                 index_temp1=[index1,index2];
                 index_temp2=setdiff(1:nSamp,index_temp1);
                 length_temp=min([length(index_temp1),length(index_temp2)]);
                 if length_temp>=minleaf
                    unique_label1=unique(Labels(index_temp1));
                    unique_label2=unique(Labels(index_temp2));
                    L1=length(unique_label1);
                    diff_label1=zeros(1,L1);
                  for loop1=1:length(index_temp1)
                    label_temp=Labels(index_temp1(loop1));
                    idx=find(unique_label1==label_temp);
                    diff_label1(idx)=diff_label1(idx)+1;
                  end
                   g1=0;
                  for loop1=1:L1
                  g1=g1+diff_label1(loop1)*diff_label1(loop1);
                  end
                  L2=length(unique_label2);
                  diff_label2=zeros(1,L2);
                  for loop2=1:length(index_temp2)
                  label_temp=Labels(index_temp2(loop2));
                  idx=find(unique_label2==label_temp);
                  diff_label2(idx)=diff_label2(idx)+1;
                  end
                  g2=0;
                  for loop2=1:L2
                  g2=g2+diff_label2(loop2)*diff_label2(loop2);
                  end
                  g1=1-g1/(length(index_temp1)*length(index_temp1));
                  g2=1-g2/(length(index_temp2)*length(index_temp2));
                  gini_temp=length(index_temp1)*g1/nSamp+length(index_temp2)*g2/nSamp;
                 else
                  gini_temp=100;
                 end
                   
                  if gini_best_gamma(flag_gamma)-gini_temp>very_small
                   gini_best_gamma(flag_gamma)=gini_temp;
                   delta(flag_gamma)=(U_sort(loop_temp)+U_sort(loop_temp+1))/2;
                  end
                  
             end
         end
            [min_value,min_index]=min(gini_best_gamma);
            if loop>1
                if min_value<impurity(loop-1)
                switch min_index
                case 1
                    
                    w(i)=w(i)-delta(1);
                    w(end)=w(end)-delta(1)*0.25;
                case 2
                    
                    w(i)=w(i)-delta(2);
                    w(end)=w(end);
                case 3
                    
                   w(i)=w(i)-delta(3);
                   w(end)=w(end)+delta(3)*0.25;
                end
                end
            else if  min_value<gini_uni
                switch min_index
                case 1
                    
                    w(i)=w(i)-delta(1);
                    w(end)=w(end)-delta(1)*0.25;
                case 2
                   
                    w(i)=w(i)-delta(2);
                    w(end)=w(end);
                case 3
                    
                   w(i)=w(i)-delta(3);
                   w(end)=w(end)+delta(3)*0.25;
                end
                end
            end
    end
                
                gini_best1(loop)=min_value;
                
               
 Data_temp=Data*w(1:end-1);
 data=Data_temp-w(end);
 
 [cut_value, impurity(loop)]=gini_impurity(Labels, Data_temp,minleaf);
                
 w(end)=cut_value;

 if loop>1
  if abs(impurity(loop-1)-impurity(loop))<very_small
      flag=0;
  end
 end
end
gini=impurity(loop);
W=w;
else
    W=rand(nFea+1,1);
    gini=1;

end

end