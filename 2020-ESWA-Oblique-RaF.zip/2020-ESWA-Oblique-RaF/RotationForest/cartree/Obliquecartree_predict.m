function [tree_output,index] = Obliquecartree_predict(fun_handle,FunPara,Data,RETree)

% Evaluates the tree output
% tree_output = mx_eval_cartree(Data,RETree.nodeCutVar,RETree.nodeCutValue,RETree.childnode,RETree.nodelabel,RETree.p,RETree.node_var);


% #include <stdio.h>
% #include <mex.h>
% #include <math.h>
%
% void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {
%
%     double *Data,*tree_output,*cut_var,*cut_val,*nodechilds,*nodelabel;
%     int i,current_node,M,cvar;
%
%
%     Data= mxGetPr(prhs[0]);
%     cut_var = mxGetPr(prhs[1]);
%     cut_val = mxGetPr(prhs[2]);
%     nodechilds = mxGetPr(prhs[3]);
%     nodelabel = mxGetPr(prhs[4]);
%
%     M=mxGetM(prhs[0]);
%
%     plhs[0] = mxCreateDoubleMatrix(M, 1, mxREAL);
%     tree_output = mxGetPr(plhs[0]);
%
%     for(i = 0;i<M;i++){
%         current_node = 0;
%         while (nodechilds[current_node]!=0){
%             cvar = cut_var[current_node];
%             if (Data[i + (cvar-1)*M] < cut_val[current_node]) current_node = nodechilds[current_node]-1;
%             else current_node = nodechilds[current_node];
%                                             }
%         tree_output[i] = nodelabel[current_node];
%           }
% }
Sigma=1;

kernel_flag=RETree.kernel;
M=size(Data,1);
if nargout > 1
    index=zeros(M,1);
end
Structure_node=RETree.nodeStructure;
dataindex=RETree.dataindex;
node_index=RETree.nodeDataIndex;
child_node=RETree.childnode;
Node_var=RETree.node_var;

Pca=RETree.p;
%         Node_cutvalue=RETree.nodeCutValue;
Node_label=RETree.nodelabel;
%         if kernel_flag==1
%            kernel_matrix=Kernel_rbf_test(Train_data,Data,Sigma);
%         end
for i=1:M
    
    current_node = 1;
    while (child_node(current_node)~=0)
        
        cvar = Node_var{current_node};
        cp=Pca{current_node};
        if strcmp(fun_handle,'TWSVMM3')
            w1=cp(1:end-1,1);
            b1=cp(end,1);
            w2=cp(1:end-1,2);
            b2=cp(end,2);
            W=[w1,w2;b1,b2];
            % kern=struct('C1',2^-8,'C3',2^-6,'type','lin','mu',0);
            [Predict_Y,~] = test_TWSVMM2(FunPara,Data(i,cvar),'skipp',Data(i,cvar),W,fun_handle);
            
            if Predict_Y==1
                current_node = child_node(current_node);
            else
                current_node = child_node(current_node)+1;
            end
        else
            index_temp=dataindex(node_index{current_node});
            Structure_node_temp=Structure_node{current_node};
            median_temp=Structure_node_temp;
            if ~isempty(median_temp)
                data_temp=Data(i,cvar)- Structure_node_temp(1);
                data_temp= data_temp./Structure_node_temp(2);
                X=data_temp*cp(1:end-1);
            else
                
                
                
                if kernel_flag==0
                    %             var=Node_cutvar(current_node);
                    X=Data(i,cvar)*cp(1:end-1);
                end
            end
            %             if (X(:,var)< Node_cutvalue(current_node))
            if X<cp(end)
                current_node = child_node(current_node);
            else
                current_node = child_node(current_node)+1;
            end
        end
    end
    tree_output(i) = Node_label(current_node);
    
    if nargout > 1
        index(i)=current_node;
    end
end
if (size(Data,1) == size(tree_output,1))
    tree_output = tree_output';
end