function [tree_output,index] = Obliquecartree_predict(FunPara,fun_handle,Data,RETree)
M=size(Data,1);
if nargout > 1
    index=zeros(M,1);
end

tree_output=zeros(M,1);
child_node=RETree.childnode;
Node_var=RETree.node_var;

Pca=RETree.p;

Node_label=RETree.nodelabel;

for i=1:M
    
    current_node = 1;
    while (child_node(current_node)~=0)
        
        cvar = Node_var{current_node};
        cp=Pca{current_node};
        if strcmp(fun_handle,'TWSVMM3')
            w1=cp(1:end-1,1);
            b1=cp(end,1);
            w2=cp(1:end-1,2);
            b2=cp(end,2);
            W=[w1,w2;b1,b2];
           % kern=struct('C1',2^-8,'C3',2^-6,'type','lin','mu',0);
            [Predict_Y,~] = test_TWSVMM2(FunPara,Data(i,cvar),'skipp',Data(i,cvar),W,fun_handle);
            
            if Predict_Y==1
                current_node = child_node(current_node);
            else
                current_node = child_node(current_node)+1;
            end
        else
            X=Data(i,cvar)*cp(1:end-1);
            if X<cp(end)
                current_node = child_node(current_node);
            else
                current_node = child_node(current_node)+1;
            end
        end
    end
    tree_output(i) = Node_label(current_node);
    
    if nargout > 1
        index(i)=current_node;
    end
end
if (size(Data,1) == size(tree_output,1))
    tree_output = tree_output';
end