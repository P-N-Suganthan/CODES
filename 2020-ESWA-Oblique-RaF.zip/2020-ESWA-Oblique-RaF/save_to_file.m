function [zz]=save_to_file(file_handle,Dataset_name,max_acc1)
%             fprintf(file2,'%20s %15.6g %15.6g  %15.6g %15.6g \n',Dataset_name,cell2mat(q),cell2mat(r),cell2mat(mm),max_acc1);
file2=fopen(file_handle,'a+');
[row,col]=size(max_acc1);
for i=1:row
    fprintf(file2,'%20s',Dataset_name);
    for j=1:col-1
        fprintf(file2,'%15.6g',max_acc1(i,j));
    end
    fprintf(file2,'%15.6g\n',max_acc1(i,col));
end
zz=0;
fclose(file2);
end