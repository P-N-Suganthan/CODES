clear all;
clc;
data_path='E:\Datasets\data\'; %put slash at last
addpath('./Optimal_Parameters')
addpath(genpath('./RF_oblique'))
addpath(genpath('./TWSVM'))
zz_temp=importdata('Datasets_Used.txt');
rng('default');
for ii=1:length(zz_temp)
    Dataset_name=char(zz_temp(ii))
    read_path=strcat(data_path,Dataset_name,'\');
    
    Dataset_path=strcat(read_path,Dataset_name,'_R.dat');
    if ~exist(Dataset_path)
        continue;
    end
    Data_struct=importdata(Dataset_path);
    Data=Data_struct.data;  %Data Matrix with first column as in index and final as the class label
    %% Separate Labels and Data
    dataX=Data(:,2:end-1);
    dataY=Data(:,end);
    dataX=full(dataX);
    [m,n]=size(dataX);
    %% Decide The Cross Validation
    M=5; v=4;     step=floor(m/v);
    %% Model: TBRaF
    TBRaF=readtable('optimal_TBRaF.txt');
    [val_indx,~]=find(strcmp(Dataset_name,TBRaF.Var1));
    optimal_temp=TBRaF(ii-1,:);
    temp_c1=optimal_temp.Var2;
    temp_c3=optimal_temp.Var3;
    
    FunPara=struct('C1',temp_c1,'C3',temp_c3,'type','lin','mu',0,'myflag',1);
    flag=0;
    TWSVMM2_ob=[]; T7=[];Ts7=0;
    %%
    for i=1:M
        index=randperm(m);
        for j =1:v
            if j~= v
                flag=flag+1
                startpoint=(j-1)*step+1;
                endpoint=(j)*step;
            else
                startpoint=(j-1)*step+1;
                endpoint=m;
            end
            cv_p=startpoint:endpoint; %%%% test set position
            %%%%%%%%%%%%%% test set
            testX=dataX(index(cv_p),:);
            testY= dataY(index(cv_p),:);  %%%%label
            %%%%%%%%%%%%%% training data
            trainX=dataX;
            trainX(index(cv_p),:)='';
            trainY=dataY;
            trainY(index(cv_p),:)='';
            mtry=round(sqrt(size(trainX,2)));
            
            [model7,T72]=ObliqueRF_train(FunPara,trainX,trainY,'ntrees',50,'nvartosample',mtry,'oblique',7);
            [Y7,fv,Ts72,~]=ObliqueRF_predict(FunPara,'TWSVMM3',testX,model7);
            acc8=length(find(Y7==testY))/length(cv_p);
            TWSVMM2_ob=[TWSVMM2_ob,acc8];
            T7=[T7,T72];
            Ts7=[Ts7,Ts72];
        end
    end
    all_acc=mean(TWSVMM2_ob);    all_train_time=mean(T7);
    [zz]=save_to_file('Result_Accuracy.txt',Dataset_name,all_acc);
    [zz]=save_to_file('Training_Time.txt',Dataset_name,all_train_time);
end %For each Dataset
rmpath(genpath('./RF_oblique'))