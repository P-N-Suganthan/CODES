clear all;
clc;
data_path='E:\Datasets\data\'; %put slash at last
addpath('./Optimal_Parameters')
addpath(genpath('./RotationForest'));
addpath(genpath('./TWSVM'))
zz_temp=importdata('Datasets_Used.txt');
rng('default');
for ii=1:length(zz_temp)
    Dataset_name=char(zz_temp(ii))
    read_path=strcat(data_path,Dataset_name,'\');
    
    Dataset_path=strcat(read_path,Dataset_name,'_R.dat');
    if ~exist(Dataset_path)
        continue;
    end
    Data_struct=importdata(Dataset_path);
    Data=Data_struct.data;  %Data Matrix with first column as in index and final as the class label
    %% Separate Labels and Data
    dataX=Data(:,2:end-1);
    dataY=Data(:,end);
    %% Normalize the Data
    %     dataX=normalize(dataX);
    
    dataX=full(dataX);
    [m,n]=size(dataX);
    
    %% Decide the ensemble size of the trees ntry and the mtry for each tree mtry
    ntree=50;
    L=ntree;
    K=3;
    minleaf=1;
    %% Decide The Cross Validation
    M=5; v=4;
    step=floor(m/v);    
    %% Model: TBRaF
    TBRRoF=readtable('optimal_TBRRoF.txt');
    [val_indx,~]=find(strcmp(Dataset_name,TBRRoF.Var1));
    optimal_temp=TBRRoF(ii-1,:);
    temp_c1=optimal_temp.Var2;
    temp_c3=optimal_temp.Var3;
    
    FunPara=struct('C1',temp_c1,'C3',temp_c3,'type','lin','mu',0,'myflag',1);
    flag=0;  
    TWSVMM2_ob=[];
    T7=[]; Ts7=0;
    %% Insert Below This
    for i=1:M
        index=randperm(m);
        for j =1:v
            if j~= v
                flag=flag+1
                startpoint=(j-1)*step+1;
                endpoint=(j)*step;
            else
                startpoint=(j-1)*step+1;
                endpoint=m;
            end
            cv_p=startpoint:endpoint; %%%% test set position
            
            %%%%%%%%%%%%%% test set
            testX=dataX(index(cv_p),:);
            testY= dataY(index(cv_p),:);  %%%%label
            %%%%%%%%%%%%%% training data
            trainX=dataX;
            trainX(index(cv_p),:)='';
            trainY=dataY;
            trainY(index(cv_p),:)='';
            mtry=round(sqrt(size(trainX,2)));
            
            [Y_hat,Y,acc8,model,T72,Ts72]=Rotation_forest_new(FunPara,trainX,trainY,testX,testY,K,L,13,minleaf);
            TWSVMM2_ob=[TWSVMM2_ob,acc8];
            T7=[T7,T72];  Ts7=Ts7+Ts72;
        end
    end
    all_acc=mean(TWSVMM2_ob); all_train_time=mean(T7);
    [zz]=save_to_file('Result_Accuracy_RRoF.txt',Dataset_name,all_acc);
    [zz]=save_to_file('Training_Time_RRoF.txt',Dataset_name,all_train_time);
end %For each Dataset
rmpath(genpath('./RotationForest'));