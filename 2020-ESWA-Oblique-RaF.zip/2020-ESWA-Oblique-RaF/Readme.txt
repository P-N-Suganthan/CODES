This code is based on oblique Random Forest of Zhang Le's implementation available from 
(https://github.com/P-N-Suganthan/CODES/blob/master/2015-TCyb-oblique-RF.rar
and TWSVM code from http://www.optimal-group.org/Resource.html


Paper:  Ganaie, M. A., M. Tanveer, and P. N. Suganthan. "Oblique Decision Tree Ensemble via Twin Bounded SVM." Expert Systems with Applications 143 (2020): 113072. 

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the distribution

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.)

This code is not optimized for efficiency. It has been tested on Windows 10 with MATLAB R2010b.

Please cite the following papers if you are using this code.

Reference: [1]. Ganaie, M. A., M. Tanveer, and P. N. Suganthan. "Oblique Decision Tree Ensemble via Twin Bounded SVM." Expert Systems with Applications 143 (2020): 113072.
           [2]. Zhang, Le, and Ponnuthurai N. Suganthan. "Oblique Decision Tree Ensemble via Multisurface Proximal Support Vector Machine."  IEEE Transactions on Cybernetics, Year: 2015, Volume: PP, Issue: 99(2014).
           [3]. Shao, Yuan-Hai, Chun-Hua Zhang, Xiao-Bo Wang, and Nai-Yang Deng. "Improvements on twin support vector machines." IEEE transactions on neural networks 22, no. 6 (2011): 962-968.
		   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%% How to run the code %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
1) Data_path: The whole data set and partitions are available from:
    http://persoal.citius.usc.es/manuel.fernandez.delgado/papers/jmlr/data.tar.gz.
2) Optimal_Parameters folder contains optimal parameters corresponding to different classifiers.
3) Run the appropriate file like use_optimal_TBRaF to generate results of classifiers.
4) Result_Accuracy and Training_Time stores the final accuracy and training time.

For more details please refer to the paper.

If you have problems about this software, please contact: phd1901141006@iiti.ac.in

18/06/2020