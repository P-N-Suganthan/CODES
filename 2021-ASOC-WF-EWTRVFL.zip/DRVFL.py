# -*- coding: utf-8 -*-
"""
Created on Wed Apr  1 07:59:13 2020

@author: lenovo
"""

import numpy as np
import LinearRegression as LR
from scipy.special import expit
from sklearn.linear_model import Ridge
import numpy as np
from sklearn.linear_model import Lasso
class linear_layer(object):
    def __init__(self,**kwargs):
        self.mode=kwargs.get('mode','Ridge')
        self.regular_param=kwargs.get('regular_param',0.1)
        self.with_bias=kwargs.get('bias',True)
    def fit(self,x,y):
        """
        x (n_sample,dims)
        y (n_sample,out_dim)
        """
        if self.with_bias:
            x = self._add_constant(x)
        if self.mode=='Ridge':
            xTx=np.dot(x.T,x)
            ridge_xTx=xTx+self.regular_param * np.eye(x.shape[1])
            ridge_inv=np.linalg.pinv(ridge_xTx)
            self.w=np.dot(ridge_inv,np.dot(x.T,y))#w (input_dim,out_dim)
        elif self.mode=='LS':
            xTx=np.dot(x.T,x)
            ridge_inv=np.linalg.pinv(xTx)
            self.w=np.dot(ridge_inv,np.dot(x.T,y))#w (input_dim,out_dim)
        elif self.mode=='Lasso':
            model=Lasso(alpha=self.regular_param,fit_intercept=False)
            model.fit(x,y)
            self.w=model.coef_
            
    def predict(self,data):
        if self.with_bias:
            data = self._add_constant(data)
        return np.dot(data,self.w)
        
    def _add_constant(self, x):
        """
        Add constant
        :param x:
        :return:
        """
        bias = np.ones((x.shape[0],1))
        # end if
        return np.concatenate((bias, x), axis=1)
def sigmoid(x):
    #print(x,type(x))
#    if -x > np.log(np.finfo(type(x)).max):
#        return 0.0 
    z = 1/(1 + np.exp(-x)) 
    return z
class deep_rvfl(object):
    
    def __init__(self,**kwargs):
        self.input_dim=kwargs.get('input_dim',1)
        self.hidden_dim=kwargs.get('hidden_dim',[100])       
        self.sparsity = kwargs.get('sparsity',1)#sparsity 越大越不sparse w_in sparse
        self.with_bias=kwargs.get('with_bias',1)
        self.win_distrib = kwargs.get('win_distrib','Gaussian')
        self.wbias_distrib = kwargs.get('wbias_distrib','Gaussian')
        self.input_scaling = kwargs.get('input_scaling',1)
        self.seed=kwargs.get('seed',None)
        self.mode=kwargs.get('mode','Ridge')
        self.regular_param=kwargs.get('regular_param',0.1)
    
        self.w_in=self.generate_win(None,seed=self.seed)#(self.input_dim, self.hidden_dim)
        self.n_layers=len(self.hidden_dim)
        self.enhance_layers=[]
    def forward(self,x):
        in_dim=self.input_dim
        h_layers=[]
        h_state=[]
        for i in range(self.n_layers):
            h_layer=enhance_layer(input_dim=in_dim,hidden_dim=self.hidden_dim[i])
            in_dim=self.hidden_dim[i]
            x=h_layer.enhance_(x)
            h_state.append(x)
        return h_state,h_layers
    def fit(self,x,y):
        h_state,h_layers=self.forward(x)
        self.regress=[]
        for i in range(self.n_layers):
            reg=Ridge(alpha=self.regular_param)
            print(x.shape,h_state[i].shape)
            x_temp=np.concatenate([x,h_state[i]],axis=1)
            reg.fit(x_temp,y)
            self.regress.append(reg)
        # return regress
    def predict(self,x):
        h_state,h_layers=self.forward(x)
        pres=[]#np.zeros(self.n_layers)
        for i in range(self.n_layers):
            x_temp=np.concatenate([x,h_state[i]],axis=1)
            p=self.regress[i].predict(x_temp)
            print(p.shape,x_temp.shape)
            pres.append(p)
        return np.concatenate(pres,axis=1)
    def ensemble(self,pres,weight):
        
        return np.dot(pres,weight)
    def generate_win(self, w_in, seed=None):
        """
        Generate Win matrix
        :return:
        """
        # Manual seed
        if seed is not None:
            np.random.seed(seed)
            
        # Initialize input weight matrix
        if w_in is None:
            # Distribution
            if self.win_distrib == 'uniform':
                w_in = self.generate_uniform_matrix(size=(self.input_dim, self.hidden_dim[0]),
                                                    sparsity=self.sparsity)
            else:
                w_in = self.generate_gaussian_matrix((self.input_dim, self.hidden_dim[0]), 
                                                     self.sparsity, mean=0, std=1)
            # end if
            w_in *= self.input_scaling
        else:
            if callable(w_in):
                w_in = w_in(self.hidden_dim, self.input_dim)


        return w_in
    @staticmethod
    def generate_gaussian_matrix(size, sparsity, mean=0.0, std=1.0):
        """
        Generate gaussian Win matrix
        :return:
        """
        if sparsity is None:
            w = np.random.normal(mean,std,size=size)
        else:
            w_ = np.random.normal(mean,std,size=size)
            mask = np.random.binomial(1,sparsity,size)
            w =np.multiply(w_,mask)
            #print(w)
        # end if
        return w
    @staticmethod
    def generate_uniform_matrix(size, sparsity):
        """
        Generate gaussian Win matrix
        :return:
        """
        if sparsity is None:
            w = np.random.uniform(-1,1,size=size)
        else:
            w_ = np.random.uniform(-1,1,size=size)
            mask = np.random.binomial(1,sparsity,size)
            w =np.multiply(w_,mask)
            #print(w)
        # end if
        return w
    
           

import pylops          
def ReLU(x):
    return x * (x > 0)  
def leakyReLU(x):
    return np.where(x > 0, x, x * 0.01)
class enhance_layer(object):
    
    def __init__(self,**kwargs):
        self.input_dim=kwargs.get('input_dim',1)
        self.hidden_dim=kwargs.get('hidden_dim',100)
        #self.input_dim=kwargs.get('input_dim',1)    
       
        self.sparsity = kwargs.get('sparsity',1)#sparsity 越大越不sparse w_in sparse
        self.with_bias=kwargs.get('with_bias',1)
        self.win_distrib = kwargs.get('win_distrib','Gaussian')
        self.wbias_distrib = kwargs.get('wbias_distrib','Gaussian')
        self.input_scaling = kwargs.get('input_scaling',1)
        self.seed=kwargs.get('seed',1)
        self.mode=kwargs.get('mode','Ridge')
        self.bound=kwargs.get('bound',1)
        self.mean=kwargs.get('mean',0)
        self.std=kwargs.get('std',1)
        self.method=kwargs.get('method',None)
        self.act=kwargs.get('activation','sigmoid')
        # if self.method is not None:
        self.w_in=self.generate_win(None,seed=self.seed)
        self.w_ista=None
        # else:
        #     self.w_in=self.generate_win(None,seed=self.seed)
            # h=self.enhance_()
    def enhance_(self,x,method=None):
        """
        Enhance layer which transforms the input data [len_samples,input_dim] into 
        [len_samples,hidden_dim]
        """
        # print(method,x.shape)
        if method is  None:
            # print('if')
            if self.act=='sigmoid':
                # print('sigmoid')
                return sigmoid(np.dot(x.reshape(-1,self.input_dim),self.w_in))
            elif self.act=='tanh':
                # print('tanh')
                return np.tanh(np.dot(x.reshape(-1,self.input_dim),self.w_in))
            elif self.act=='relu':
                # print('relu')
                return ReLU(np.dot(x.reshape(-1,self.input_dim),self.w_in))
            elif self.act=='leakyrelu':
                # print('relu')
                return leakyReLU(np.dot(x.reshape(-1,self.input_dim),self.w_in))
        elif method=='fista' and self.w_ista==None:
            print('elif')
            h=sigmoid(np.dot(x.reshape(-1,self.input_dim),self.w_in))
            Aop = pylops.MatrixMult(h)
            w=np.zeros((self.input_dim,self.hidden_dim))
            eps = 0.5
            for i in range(self.input_dim):
                # print('h',h.shape,x.shape)
                w_ = pylops.optimization.sparsity.ISTA(Aop, x[:,i], 1000, eps=eps,
                                           tol=0, returninfo=True)[0]
                w[i,:]=w_
            self.w_ista=w
            # print('w',w_.shape)
            return sigmoid(np.dot(x.reshape(-1,self.input_dim),self.w_ista))
        elif method=='fista' and self.w_ista is not None:
            return sigmoid(np.dot(x.reshape(-1,self.input_dim),self.w_ista))
            
    def generate_win(self, w_in, seed=None):
        """
        Generate Win matrix
        :return:
        """
        # Manual seed
        if seed is not None:
            np.random.seed(seed)
            
        # Initialize input weight matrix
        if w_in is None:
            # Distribution
            if self.win_distrib == 'uniform':
                w_in = self.generate_uniform_matrix(size=(self.input_dim, self.hidden_dim),
                                                    sparsity=self.sparsity,bound=self.bound)
            else:
                w_in = self.generate_gaussian_matrix((self.input_dim, self.hidden_dim), 
                                                     self.sparsity, self.mean, self.std)
            # end if
            w_in *= self.input_scaling
        else:
            if callable(w_in):
                w_in = w_in(self.hidden_dim, self.input_dim)


        return w_in
    @staticmethod
    def generate_gaussian_matrix(size, sparsity, mean=0.0, std=1.0):
        """
        Generate gaussian Win matrix
        :return:
        """
        if sparsity is None:
            w = np.random.normal(mean,std,size=size)
        else:
            w_ = np.random.normal(mean,std,size=size)
            mask = np.random.binomial(1,sparsity,size)
            w =np.multiply(w_,mask)
            #print(w)
        # end if
        return w
    @staticmethod
    def generate_uniform_matrix(size, sparsity,bound):
        """
        Generate gaussian Win matrix
        :return:
        """
        if sparsity is None:
            w = np.random.uniform(-bound,bound,size=size)
        else:
            w_ = np.random.uniform(-bound,bound,size=size)
            mask = np.random.binomial(1,sparsity,size)
            w =np.multiply(w_,mask)
            #print(w)
        # end if
        return w
class RVFL(object):
    
    def __init__(self,**kwargs):
        self.input_dim=kwargs.get('input_dim',1)
        self.hidden_dim=kwargs.get('hidden_dim',100)       
        self.sparsity = kwargs.get('sparsity',1)#sparsity 越大越不sparse w_in sparse
        self.with_bias=kwargs.get('with_bias',1)
        self.win_distrib = kwargs.get('win_distrib','Gaussian')
        self.wbias_distrib = kwargs.get('wbias_distrib','Gaussian')
        self.input_scaling = kwargs.get('input_scaling',1)
        self.seed=kwargs.get('seed',None)
        self.mode=kwargs.get('mode','Ridge')
        self.regular_param=kwargs.get('regular_param',0.1)
    
        self.w_in=self.generate_win(None,seed=self.seed)#(self.input_dim, self.hidden_dim)
    def enhance_layer(self,x):
        """
        Enhance layer which transforms the input data [len_samples,input_dim] into 
        [len_samples,hidden_dim]
        """
#        z=np.zeros((x.shape[0],self.hidden_dim))
#        b=np.dot(x.reshape(-1,self.input_dim),self.hidden_dim)
        
        return sigmoid(np.dot(x.reshape(-1,self.input_dim),self.w_in))
        
    def fit(self,x,y,enhance_nodes=None):
        """
        x[len_samples,input_dim]: input data which pass to enhance layer
        y[len_samples,1]: target
        """
        #enhance
        #if enhance_nodes is None:
        enhance_nodes=self.enhance_layer(x)
        #print('RVFL',x.shape,enhance_nodes.shape)
        concat=np.hstack((x,enhance_nodes))
        self.regression=LR.linear_layer(mode=self.mode,regular_param=self.regular_param,
                                        bias=self.with_bias)
        self.regression.fit(concat,y)
     
       
    def predict(self,x):
        enhance_nodes=self.enhance_layer(x)
        concat=np.hstack((x,enhance_nodes))
        prediction=self.regression.predict(concat)
        return prediction
    def generate_win(self, w_in, seed=None):
        """
        Generate Win matrix
        :return:
        """
        # Manual seed
        if seed is not None:
            np.random.seed(seed)
            
        # Initialize input weight matrix
        if w_in is None:
            # Distribution
            if self.win_distrib == 'uniform':
                
                w=np.random.uniform(-self.bound,self.bound,self.input_dim*self.hidden_dim)
                w_in=w.reshape(self.input_dim*self.hidden_dim)
            else:
                w_in = self.generate_gaussian_matrix((self.input_dim, self.hidden_dim), 
                                                     self.sparsity, self.mean, self.std)
            # end if
            w_in *= self.input_scaling
        else:
            if callable(w_in):
                w_in = w_in(self.hidden_dim, self.input_dim)


        return w_in
    @staticmethod
    def generate_gaussian_matrix(size, sparsity, mean=0.0, std=1.0):
        """
        Generate gaussian Win matrix
        :return:
        """
        if sparsity is None:
            w = np.random.normal(mean,std,size=size)
        else:
            w_ = np.random.normal(mean,std,size=size)
            mask = np.random.binomial(1,sparsity,size)
            w =np.multiply(w_,mask)
            #print(w)
        # end if
        return w
    @staticmethod
    def generate_uniform_matrix(size, sparsity, mean=0.0, std=1.0):
        """
        Generate gaussian Win matrix
        :return:
        """
        if sparsity is None:
            w = np.random.uniform(-1,1,size=size)
        else:
            w_ = np.random.uniform(-1,1,size=size)
            mask = np.random.binomial(1,sparsity,size)
            w =np.multiply(w_,mask)
            #print(w)
        # end if
        return w