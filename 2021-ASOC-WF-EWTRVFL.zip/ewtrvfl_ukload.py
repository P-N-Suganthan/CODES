# -*- coding: utf-8 -*-
"""
Created on Sat May 29 13:44:24 2021

@author: ruobi
"""

import pandas as pd
import numpy as np
import ForecastLib
from basics import setup_seed
from vmdpy import VMD
import pywt
from PyEMD import EMD
import ewtpy
from sklearn import preprocessing
import matplotlib.pyplot as plt
from sklearn.svm import SVR
import lightgbm
from itertools import product
from WFbaselines import WFLSTM,TSLSTM
from sklearn import preprocessing
from shippingCNN_basics import shipCNN,TSCNN,setup_seed,shipRCNN,TSRCNN,TSDMLP,TSRNN,TSGRU
import matplotlib.pyplot as plt
from DRVFL import deep_rvfl,enhance_layer
from sklearn.linear_model import Ridge,Lasso,ElasticNet
from sklearn.linear_model import Lasso
class linear_layer(object):
    def __init__(self,**kwargs):
        self.mode=kwargs.get('mode','Ridge')
        self.regular_param=kwargs.get('regular_param',0.1)
        self.with_bias=kwargs.get('bias',True)
    def fit(self,x,y):
        """
        x (n_sample,dims)
        y (n_sample,out_dim)
        """
        if self.with_bias:
            x = self._add_constant(x)
        if self.mode=='Ridge':
            
            xTx=np.dot(x.T,x)
            # print('xtx',xTx[0,0],xTx[0,-1])
            ridge_xTx=xTx+self.regular_param * np.eye(x.shape[1])
            # print(self.regular_param)
            # print('rxtx',ridge_xTx[0,0],ridge_xTx[0,-1])
            ridge_inv=np.linalg.pinv(ridge_xTx)
            self.w=np.dot(ridge_inv,np.dot(x.T,y))#w (input_dim,out_dim)
        elif self.mode=='LS':
            xTx=np.dot(x.T,x)
            ridge_inv=np.linalg.pinv(xTx)
            self.w=np.dot(ridge_inv,np.dot(x.T,y))#w (input_dim,out_dim)
        elif self.mode=='Lasso':
            model=Lasso(alpha=self.regular_param,fit_intercept=False)
            model.fit(x,y)
            self.w=model.coef_
            
    def predict(self,data):
        if self.with_bias:
            data = self._add_constant(data)
        return np.dot(data,self.w)
        
    def _add_constant(self, x):
        """
        Add constant
        :param x:
        :return:
        """
        bias = np.ones((x.shape[0],1))
        # end if
        return np.concatenate((bias, x), axis=1)
def ewtrvfl_pre(allx,ally,h1,l,seed=0,bound=1):
    trainy=ally[:-l,:]
    testy=ally[-l:,:]
    n_node=h1[1]
    alpha=h1[2]
    input_s=h1[3]
    reg_type=h1[4]
    act=h1[5]
    enh1=enhance_layer(input_dim=allx.shape[1],hidden_dim=n_node,
                               input_scaling=input_s,seed=seed,sparsity=1,
                               win_distrib='Gaussian',bound=bound,
                               activation=act)
    # print(enh1.w_in[0][0])
    enh_s=enh1.enhance_(allx)
    x_prime=np.hstack((allx,enh_s))
    trainx=x_prime[:-l,:]
    testx=x_prime[-l:,:]
    reg=linear_layer(mode='Ridge',regular_param=alpha,
                            bias=1)
    reg.fit(trainx,trainy)
    pre=reg.predict(testx)
    return pre

    
    
def format_data1(dat,order,step=1,idx=0,type_='direct'):
    n_sample=dat.shape[0]-order-step+1
    x=np.zeros((n_sample,dat.shape[1]*order))
    y=np.zeros((n_sample,1))
    for i in range(n_sample):
        x[i,:]=dat[i:i+order,:].ravel()
        y[i]  =dat[i+order+step-1,idx]
    return x,y
def get_data(name):
    #file_name = 'C:\\Users\\lenovo\\Desktop\\FuzzyTimeSeries\\pyFTS-master\\pyFTS\\'+name+'.csv'
    file_name = name+'.csv'
    #D:\Multivarate paper program\monthly_data
    dat = pd.read_csv(file_name)
    dat = dat.fillna(method='ffill')
    return dat,dat.columns


def compute_error(actuals,predictions,history=None):
    actuals=actuals.ravel()
    predictions=predictions.ravel()
    
    metric=ForecastLib.TsMetric()
    error={}
    error['RMSE']=metric.RMSE(actuals, predictions)
    error['MAPE']=metric.MAPE(actuals,predictions)
    error['MAE']=metric.MAE(actuals,predictions)
    if history is not None:
        history=history.ravel()
        error['MASE']=metric.MASE(actuals,predictions,history)
        
    
    return error
def cv(x,hypers,pre_l,model,step=1,type_='direct'):
    cvloss=[]
    order=24
    history=x[:-pre_l,target_idx]
    best_hypers=list()
    winds=[24,48,72]
    ks=[2,3,4]
    dec_hypers=list(product(winds,ks))
    if model =='EDRVFL':
        wind_loss=[]
        wind_best=[]
        for dec_h in dec_hypers:
            decomposer=ForecastLib.TsPrep()
            # print(dec_h)
            dec=decomposer.ts_walkforward(x.ravel(), dec_h[0], dec_h[1], 'ewt',pad_raw=True)#n_sample,wind,nl
            # print(dec.shape)
            allx=np.zeros((dec.shape[0],order*(dec_h[1]+1)))
            for ii in range(dec.shape[0]):
                # print(allx[ii,:].shape,dec[ii,-order:,:].ravel().shape )
                allx[ii,:]=dec[ii,-order:,:].ravel() 
            ally=x[dec_h[0]:]
            cvloss=[]
            for h in hypers:
                # ewtrvfl_pre(allx,ally,h1,l,seed=0,bound=1)
                pre_=ewtrvfl_pre(allx,ally,h,pre_l,seed=s)#+data_[-test_l-pre_l-1:-test_l-1]
                pres=scaler.inverse_transform(pre_.reshape(-1,1))
                loss=compute_error(data_[-test_l-pre_l:-test_l],pres,history)
                total_l=loss['RMSE']
                cvloss.append(total_l)  
            wind_loss.append(min(cvloss))
            best_hyper=hypers[cvloss.index(min(cvloss))]      #window nl best   mins.append(min(cv_loss))
            wind_best.append(best_hyper)
                
        best_dec=dec_hypers[wind_loss.index(min(wind_loss))]                
        best_hypers.append(wind_best[wind_loss.index(min(wind_loss))])
            
            
    
    return best_hypers,best_dec
if __name__ == "__main__":
    setup_seed(0)#D:\Multivarate paper program
    # D:\AEMO\NSW\2015
    import warnings
    target_idx=0
    warnings.filterwarnings('ignore')
    # seeds=20
    dataset='D:\\UK load\\Monthly-hourly-load-values_2006-2015.csv'
    df_data = pd.read_csv(dataset)
        
    countrys=['IT']#['AT','BA','BE','BG','CH']
    year=2012
    seeds=10
    hours=[str(i) for i in list(range(24))]
    for co in countrys:
        for month_ in [1,4,7,10]:

            print(co+str(month_))
            pres_=[]
            for s in np.arange(seeds):
                np.random.seed(s)
                
                c_data=df_data.loc[(df_data['Country']==co)&(df_data['Year']==year)&(df_data['Month']==month_)]
                data_=c_data[hours].values.reshape(-1,1)
                scaler=preprocessing.MinMaxScaler()
                
                val_l,test_l=int(0.1*data_.shape[0]),int(0.2*data_.shape[0])
                scaler.fit(data_[:-test_l-val_l])
                norm_data=scaler.transform(data_)
            
                orders=[24]
                windows=[24,48,96]#[48*i for i in range(1,4)]
                n_levels=[3]
                lrs=[0.001]
                bss=[64]
                epochss=[1000]
                weight_decays=[0]
                nnodes=list(range(50,200,50))#[12,24,36,48,60,72]#[ pow(2,i) for i in range(1,11,2)]
                reg_types=['Ridge']
                alphas=[2**(-i) for i in range(4,8)]#np.arange(0,1.1,0.1)
                alphas.append(0)
                input_scalings=[1]#[ 2**-int(i) for i in np.arange(7)]
                
                mets=['RMSE','MAE']
                acts=['sigmoid']
                wfvmdlstm_hypers=list(product(orders,n_levels,windows,nnodes,lrs,bss,epochss))
                lstm_hypers=list(product(nnodes,orders,bss,weight_decays,lrs,epochss))
                edrvfl_hypers=list(product(orders,nnodes,alphas,input_scalings,reg_types,acts))
                # ensemble_hypers=list(product(backs,bns,mets))
                print('cross validation')
                ewtrvfl_best_hypers,ewtrvfl_best_wind=cv(norm_data[:-test_l],edrvfl_hypers,val_l,'EDRVFL',
                                      step=1,type_='direct')
                
                
                
                
                print('test')
                scaler.fit(data_[:-test_l])
                norm_data=scaler.transform(data_)
            
                history=data_[:-test_l]
                decomposer=ForecastLib.TsPrep()
                dec=decomposer.ts_walkforward(norm_data.ravel(), ewtrvfl_best_wind[0], ewtrvfl_best_wind[1]
                                              , 'ewt',pad_raw=True)
          
                # print(dec.shape,x.shape)
            
                allx,ally=dec[:,-orders[0]:,:].reshape(-1,orders[0]*(ewtrvfl_best_wind[1]+1)),norm_data[ewtrvfl_best_wind[0]:]
               
                pre_=ewtrvfl_pre(allx,ally,ewtrvfl_best_hypers[0],test_l,seed=s)
                pre=scaler.inverse_transform(pre_.reshape(-1,1))
            
                pres_.append(pre)
                e=compute_error(data_[-test_l:], pre, history)
                print(e)
            pres=np.concatenate(pres_,axis=1)
            df=pd.DataFrame(pres)           
            df.to_csv('D:\\DeepESN-master\\UKload\\EWTRVFL'+co+str(month_)+'.csv')                