%function [f1,error] = rpflow(x)

global VD ploss VI
%x = [1.1 1.1 1.089813 1.084215 1.1 1.084676 1.08 1.1 1.01 1.1 1.1 0.97 1.1 1.1 0.9 0.9 0.98 0.97 0.98 0.94 1.09 1.03 1.1 1.1 0 15.6 15];
x = contvar(1,:);

Tbranch = [19 20 31 35 36 37 41 46 54 58 59 65 66 71 73 76 80];
Qbus = [18 25 53];

data = loadcase(case57);
data.gen(1:7,6) = x(1:7);
Trat = x(8:24);
Trat = round(Trat./0.02).*0.02;
data.branch(Tbranch,9) = Trat;
Qrat = x(25:27);
Qrat = round(Qrat./0.2).*0.2;
data.bus(Qbus,6) = Qrat;

mpopt = mpoption('pf.enforce_q_lims',0,'verbose',0,'out.all',0);
result = runpf(data,mpopt);

%Constraint finding 
Vmax = data.bus(:,12);
Vmin = data.bus(:,13);
genbus = data.gen(:,1);

Qmax = data.gen(:,4)/data.baseMVA;
Qmin = data.gen(:,5)/data.baseMVA;
QG = result.gen(:,3)/data.baseMVA;

blimit = data.branch(:,6);
Slimit = sqrt(result.branch(:,14).^2+result.branch(:,15).^2);
Serr = sum((Slimit>blimit).*abs(blimit-Slimit))/data.baseMVA;

% TO find the error in Qg of gen buses- inequality constraint
Qerr = sum((QG<Qmin).*(abs(Qmin-QG)./(Qmax-Qmin))+(QG>Qmax).*(abs(Qmax-QG)./(Qmax-Qmin)));
% TO find the error in V of load buses-inequality constraint
VI = result.bus(:,8);  %V of load buses-inequality constraint
VI(genbus)=[];
Vmax(genbus)=[];
Vmin(genbus)=[];
VIerr = sum((VI<Vmin).*(abs(Vmin-VI)./(Vmax-Vmin))+(VI>Vmax).*(abs(Vmax-VI)./(Vmax-Vmin)));
VD = sum(abs(VI-1));

ploss = sum(result.branch(:,14)+result.branch(:,16));

error = [Qerr,VIerr,Serr];

%f1 = ploss; % power loss only
f1 = VD; % Cumulative voltage deviation only
result = [x';ploss;VD;QG.*100];
