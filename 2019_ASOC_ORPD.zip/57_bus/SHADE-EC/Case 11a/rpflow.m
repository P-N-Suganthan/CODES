function [f1,error] = rpflow(x)

global VD ploss VI
%x = [1.1 1.1 1.089813 1.084215 1.1 1.084676 1.08 1.1 1.01 1.1 1.1 0.97 1.1 1.1 0.9 0.9 0.98 0.97 0.98 0.94 1.09 1.03 1.1 1.1 0 15.6 15];
%x = contvar(3,:);
%x = [1.1	1.097588	1.083212	1.075434	1.094606	1.077254	1.073357	0.9	1.1	1.09	1.1	0.98	1	0.98	0.96	0.9	0.97	0.97	0.97	0.96	0.97	0.99	0.95	0.98	0	17.4	12];
%x = [1.02	1.0116	1.0107	1.0034	1.0297	1.007	1.036	0.9653	0.9942	0.9714	1.0541	1.0876	1.0039	1.0017	0.918	0.9001	0.9303	0.9849	1.0072	0.9	0.9589	1.0082	0.9	0.987	0.0075	19.9909	19.9974];

Tbranch = [19 20 31 35 36 37 41 46 54 58 59 65 66 71 73 76 80];
Qbus = [18 25 53];

data = loadcase(case57);
data.gen(1:7,6) = x(1:7);
data.branch(Tbranch,9) = x(8:24);
data.bus(Qbus,6) = x(25:27);

mpopt = mpoption('pf.enforce_q_lims',0,'verbose',0,'out.all',1);
result = runpf(data,mpopt);

%Constraint finding 
Vmax = data.bus(:,12);
Vmin = data.bus(:,13);
genbus = data.gen(:,1);

Qmax = data.gen(:,4)/data.baseMVA;
Qmin = data.gen(:,5)/data.baseMVA;
QG = result.gen(:,3)/data.baseMVA;

blimit = data.branch(:,6);
Slimit = sqrt(result.branch(:,14).^2+result.branch(:,15).^2);
Serr = sum((Slimit>blimit).*abs(blimit-Slimit))/data.baseMVA;

% TO find the error in Qg of gen buses- inequality constraint
Qerr = sum((QG<Qmin).*(abs(Qmin-QG)./(Qmax-Qmin))+(QG>Qmax).*(abs(Qmax-QG)./(Qmax-Qmin)));
% TO find the error in V of load buses-inequality constraint
VI = result.bus(:,8);  %V of load buses-inequality constraint
VI(genbus)=[];
Vmax(genbus)=[];
Vmin(genbus)=[];
VIerr = sum((VI<Vmin).*(abs(Vmin-VI)./(Vmax-Vmin))+(VI>Vmax).*(abs(Vmax-VI)./(Vmax-Vmin)));
VD = sum(abs(VI-1));

ploss = sum(result.branch(:,14)+result.branch(:,16));

error = [Qerr,VIerr,Serr];

f1 = ploss; % power loss only
%f1 = VD; % Cumulative voltage deviation only
result = [x';ploss;VD;QG.*100];
