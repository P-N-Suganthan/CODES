 % SHADE and EC
global scene_no scene_sel scenario
format long e;
tic
problem_size = 19;
pop_size = 40;
no_scene = 1000; % no. of scenarios created
favscn_no = 25; % no. of scenarios selected
all_scene = create_scene(no_scene);
scene_sel = scenered(all_scene,favscn_no);

Xmin = [0.95 0.95 0.95 0.95 0.95 0.95 0.9 0.9 0.9 0.9 0 0 0 0 0 0 0 0 0];
Xmax = [1.1 1.1 1.1 1.1 1.1 1.1 1.1 1.1 1.1 1.1 5 5 5 5 5 5 5 5 5];

Re = zeros(favscn_no,3); contvar = zeros(favscn_no,problem_size); sav_scene = zeros(favscn_no,7);

for sc = 1:favscn_no
scene_no = sc; % Type 1 to 20 to run scenarios
Max_FES = 30000; 
Max_Gen = 750; maxrun = 1; gn = 3; % gn is the no. of constraints
epsilon = zeros(Max_Gen,1);

% Epsilon CH parameter
Tc = 0.2*Max_Gen;
cp = 5;

W = zeros(Max_Gen,3);
fprintf('Scenario %d',sc);
Func = @rpflow;

% for runs=1:maxrun 
  feval = [];
  nfeval=0;

 %%  parameter settings for SHADE
 p_best_rate = 0.11;
 arc_rate = 1.4;
 memory_size = 5;
 memory_pos = 1;

 archive.NP = arc_rate * pop_size; % the maximum size of the archive
 archive.pop = zeros(0, problem_size); % the solutions stored in te archive
 archive.funvalues = zeros(0, 1); % the function value of the archived solutions   
    
   pop=repmat(Xmin,pop_size,1)+repmat((Xmax-Xmin),pop_size,1).*rand(pop_size,problem_size);
   val = zeros(pop_size,1); g = zeros(pop_size,gn); %PPB
   for i=1:pop_size
      [val(i,1),g(i,:)] = Func(pop(i,:));
   end
   
   nfeval=nfeval+pop_size;
   
   memory_sf = 0.5 .* ones(memory_size, 1);
   memory_cr = 0.5 .* ones(memory_size, 1);
 
 cons_max = [];
 rot=(0:1:pop_size-1); 
 
 %% Main loop

for gen=1:Max_Gen

    fitness = val;
    [~, sorted_index] = sort(fitness, 'ascend');

    mem_rand_index = ceil(memory_size * rand(pop_size, 1));
    mu_sf = memory_sf(mem_rand_index);
    mu_cr = memory_cr(mem_rand_index);
      
     %% for generating crossover rate
      cr = normrnd(mu_cr, 0.1);
      term_pos = find(mu_cr == -1);
      cr(term_pos) = 0;
      cr = min(cr, 1);
      cr = max(cr, 0);

      %% for generating scaling factor
      sf = mu_sf + 0.1 * tan(pi * (rand(pop_size, 1) - 0.5));
      pos = find(sf <= 0);

      while ~ isempty(pos)
        sf(pos) = mu_sf(pos) + 0.1 * tan(pi * (rand(length(pos), 1) - 0.5));
        pos = find(sf <= 0);
      end

      sf = min(sf, 1); 
      
      r0 = (1 : pop_size);
      popAll = [pop; archive.pop];
      [r1, r2] = gnR1R2(pop_size, size(popAll, 1), r0);
      
      pNP = max(round(p_best_rate * pop_size), 2); %% choose at least two best solutions
      randindex = ceil(rand(1, pop_size) .* pNP); %% select from [1, 2, 3, ..., pNP]
      randindex = max(1, randindex); %% to avoid the problem that rand = 0 and thus ceil(rand) = 0
      pbest = pop(sorted_index(randindex), :); %% randomly choose one of the top 100p% solutions

      vi = pop + sf(:, ones(1, problem_size)) .* (pbest - pop + pop(r1, :) - popAll(r2, :));
      vi = boundConstraint(vi, pop, Xmax, Xmin);
      
      mask = rand(pop_size, problem_size) > cr(:, ones(1, problem_size)); % mask is used to indicate which elements of ui comes from the parent
      rows = (1 : pop_size)'; cols = floor(rand(pop_size, 1) * problem_size)+1; % choose one position where the element of ui doesn't come from the parent
      jrand = sub2ind([pop_size problem_size], rows, cols); mask(jrand) = false;
      ui = vi; ui(mask) = pop(mask);
    
    newpop = ui;
    newval = zeros(pop_size,1); newg = zeros(pop_size,gn); %PPB            
    for i=1:pop_size
      [newval(i,1),newg(i,:)] = Func(newpop(i,:));
    end             
    nfeval=nfeval+pop_size;

    children_fitness = newval;
    dif = abs(fitness - children_fitness);
     
    A = vertcat(pop,newpop);
    B = vertcat(val,newval);
    G = vertcat(g,newg);

    
    %Stochastic Ranking
    cons1=(G>0).*G; 
    cons_max=max([cons_max;cons1],[],1);
    nzindex1=find(cons_max~=0);
    
    if isempty(nzindex1)
        tcons1=zeros(size(A,1),1);
    else
        tcons1=sum(cons1(:,nzindex1)./repmat(cons_max(:,nzindex1),size(A,1),1),2)./sum(1./cons_max(:,nzindex1));
    end
    
    if gen == 1
    n = ceil(0.05*size(A,1));
    [~,seq] = sort(tcons1);
    tcons111 = sort(tcons1);
    epsilon(1) = tcons1(seq(n));
    elseif(gen>1 && gen<=Tc)
    epsilon(gen) = epsilon(1)*((1-gen/Tc)^cp);
    end
    
    %inde = ceil(rand(pop_size,1).*pop_size);
    inde = (1:pop_size)';
    ind11 = find(tcons1(inde) <= epsilon(gen));
    ind11 = ind11(tcons1(pop_size+ind11) <= epsilon(gen));
    ind11 = ind11(B(pop_size+ind11)<= B(ind11));
    ind12 = find(tcons1(pop_size+inde) < tcons1(inde));
    index = union(ind11,ind12);

    A(index,:) = A(pop_size+index,:);
    B(index,:) = B(pop_size+index,:);
    G(index,:) = G(pop_size+index,:);
    tcons1(index,:) = tcons1(pop_size+index,:);

    pop(index,:) = A(pop_size+index,:);
    val(index,:) = B(pop_size+index,:);
    g(index,:) = G(pop_size+index,:);
                              
%%%%        
     %%Addition: if Offspring is better update goodCR & goodF and memory
      goodCR = cr(index);  
      goodF = sf(index);
      dif_val = dif(index);

      archive = updateArchive(archive, pop(index, :), fitness(index));
      num_success_params = numel(goodCR);

      if num_success_params > 0 
	sum_dif = sum(dif_val);
	dif_val = dif_val / sum_dif;

	%% for updating the memory of scaling factor 
	memory_sf(memory_pos) = (dif_val' * (goodF .^ 2)) / (dif_val' * goodF);

	%% for updating the memory of crossover rate
	if max(goodCR) == 0 || memory_cr(memory_pos)  == -1
	  memory_cr(memory_pos)  = -1;
	else
	  memory_cr(memory_pos) = (dif_val' * (goodCR .^ 2)) / (dif_val' * goodCR);
	end

	memory_pos = memory_pos + 1;
	if memory_pos > memory_size;  memory_pos = 1; end
      end
    
    %%...............
    
    totalpop=pop;
    totalval=val;
    totalg=g;
     
    cons=(totalg>0).*totalg; 
    cons_max=max([cons_max;cons],[],1);
    nzindex=find(cons_max~=0);
    
    if isempty(nzindex)
        tcons=zeros(1*pop_size,1);
    else

        tcons=sum(cons(:,nzindex)./repmat(cons_max(:,nzindex),1*pop_size,1),2)./sum(1./cons_max(:,nzindex));
    end 
                
  feasindex=find(tcons==0);
  if isempty(feasindex)
    [gbesttcons,ibest]=min(tcons);
    gbestval=totalval(ibest);
    gbest = totalpop(ibest,:);
  else
    [gbestval,ibest]=min(totalval(feasindex));
    gbesttcons=tcons(feasindex(ibest));
    gbest = totalpop(feasindex(ibest),:);
  end
  
  if(gen == 1)
      thegbestval = gbestval;
      thegbesttcons = gbesttcons;
      thegbest = gbest;
  elseif((gbesttcons < thegbesttcons) || (gbesttcons==0 && thegbesttcons ==0 && gbestval < thegbestval))
      thegbestval = gbestval;
      thegbesttcons = gbesttcons;
      thegbest = gbest;
  end
  
    W(gen,1)=nfeval;
    W(gen,2)=thegbestval;
    W(gen,3)=thegbesttcons;
        
 if(isempty(feval) && thegbesttcons == 0)
        feval = nfeval;
 end
  %thegbestval

end
dlmwrite(strcat('W_',char(num2str(sc)),'.txt'),W,'newline','pc');
Re(sc,1) = thegbestval;
Re(sc,2) = thegbesttcons;
Re(sc,3) = feval;

Trat = thegbest(7:10);
Trat = round(Trat./0.02).*0.02;
thegbest(7:10) = Trat;
Qrat = thegbest(11:19);
Qrat = round(Qrat./0.2).*0.2;
thegbest(11:19) = Qrat;

contvar(sc,:) = thegbest;
sav_scene(sc,:) = scenario;
end
 
dlmwrite('Result.txt',Re,'newline','pc');
dlmwrite('Save_scene.txt',sav_scene,'newline','pc');
dlmwrite('Scenario_sel.txt',scene_sel,'newline','pc');
eval('save all_scene');
eval('save contvar');
toc