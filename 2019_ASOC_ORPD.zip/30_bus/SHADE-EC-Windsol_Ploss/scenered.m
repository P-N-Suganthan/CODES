function sel_scene = scenered(all_scene,scennum_fav)

% scennum_fav is the favored scenario number after reduction
    % Initial scenario numbers, my matrix to be reduced is in all_scen
    init_scene = all_scene;
    scennum_int=size(init_scene,1);
    % In the beginning all scenarios are equiprobable
    scenprob=ones(scennum_int,1)*1/scennum_int;
% scenario reduciton algorithm 
while size(init_scene,1)>scennum_fav
    % Calculate euclidean distances
        dist_mat = squeeze(sqrt(sum(bsxfun(@minus,init_scene,reshape(init_scene',1,size(init_scene,2),size(init_scene,1))).^2,2)));
        dist_mat(~dist_mat)=inf;
        row_min = min(dist_mat);
        min_value = min(row_min);
        [row,~]= find(dist_mat==min_value); % shows the position of the minimum element, row=which row
    % Remove scenario with smallest distance and add its probability to reference scenario (the scenario to be removed is independent of its probability)
        if scenprob(row(1))>scenprob(row(2))
            init_scene(row(2),:)=[];
            scenprob(row(1),:)=scenprob(row(1),:)+scenprob(row(2),:);
            scenprob(row(2),:)=[];
        elseif scenprob(row(1))<scenprob(row(2))
            init_scene(row(1),:)=[];
            scenprob(row(2,:))=scenprob(row(2,:))+scenprob(row(1,:));
            scenprob(row(1),:)=[];
        else
            init_scene(row(2),:)=[];
            scenprob(row(1,:))=scenprob(row(1,:))+scenprob(row(2,:));
            scenprob(row(2),:)=[];
        end
end
sel_scene = [init_scene,scenprob];
