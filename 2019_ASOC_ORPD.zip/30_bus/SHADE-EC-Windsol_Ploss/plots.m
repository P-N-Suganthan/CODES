 clf
 scene_dat = load('all_scene');
 scene = scene_dat.all_scene;
 mcarlo = size(scene,1);
 
 % plot loading scenarios
 figure(1)
 histogram(scene(:,1),mcarlo,'EdgeColor','blue');
 xlabel('Network loading in %')
 ylabel('Frequency')
 
 % plot wind speed scenarios
 figure(2)
 histogram(scene(:,2),mcarlo,'EdgeColor','green');
 xlabel('Wind speed in m/s')
 ylabel('Frequency')
 
 % plot solar irradiance scenarios
 figure(3)
 histogram(scene(:,3),mcarlo,'EdgeColor','red');
 xlabel('Solar irradiance in W/m^2')
 ylabel('Frequency')
 
 % plot solar irradiance without zero irradiance
 figure(4)
 irrdata = scene(:,3);
 numzeros = sum(irrdata == 0);
 irrdata(irrdata==0)=[];
 histogram(irrdata,mcarlo-numzeros,'EdgeColor','black');
 xlabel('Solar irradiance in W/m^2')
 ylabel('Frequency')
 