function all_scene = create_scene(num_scn)
mud = 70; sigmad = 10; % load demand PDF parameters
scale = 9; shape = 2; % wind power PDF parameters
mus = 5.5; sigmas = 0.5; % solar PDF parameters
crt_sc = zeros(num_scn,3);

for i = 1:num_scn
    crt_sc(i,:) = [normrnd(mud,sigmad),wblrnd(scale,shape),(rand<=0.5)*lognrnd(mus,sigmas)];
end

all_scene = crt_sc;
