function [f1,error] = rpflow(x)

global VD ploss VI
%x = [1.1 1.0387 1.0161 1.0290 1.0123 1.1 1.0223 0.9107 1.0098 0.9744 3.4125 5 2.0981 5 3.5512 4.0005 3.1928 4.88 2.1];
%x = [1.1 1.0173 1.02 1.0001 0.9998 1.0011 1.0035 1.0281 1.0296 1.1470 1.12 1.0045 2.185 3.551 2.3512 1.8 5 3.0218 1.411];
%x = [1.0031	0.9986	1.0162	1.0084	1.0674	1.0206	1.0918	0.9	1.0067	0.9697	5	4.1036	5	0	5	5	5	5	2.62];
%x = [1.006059 1.0013 1.0193 1.01852 0.9709 1.0117 0.9943 0.9120 0.98914 0.96458 5 2.0992 5 0.3994 5 5 5 4.03057 1.5166];
%x = [1.0083 1.0101 1.0009 1.0008 1.0110 1.0010 1.0099 1.0815 1.0197 1.0153 0.0089 0.0071 0.0091 0.0400 0.0009 0.0434 0.0002 0.0273 0];
%x = [0.9729 1.0451 1.0194 0.9980 1.0761 1.0441 0.9014 1.1554 1.0499 0.9618 0.0742 0.4624 4.0325 0.0491 4.4234 0.0515 4.0049 4.9728 4.6458];
%x = [1.08128 1.072177 1.05014 1.050234 1.1 1.06883 1.08 0.902 0.99 0.976 0 0 3.8 4.9 3.95 5 2.75 5 2.4];
%x = [1.0502 1.0382 1.0107 1.0212 1.0503 1.05 0.952 1.0295 0.972 0.9661 0.0097 0.0125 0.0212 0.0541 0.0043 0.0289 0.0229 0.0498 0.0106]; 
%x = [1.05 1.041 1.0154 1.0267 1.0082 1.05 1.0585 0.9089 1.0141 1.0182 3.3 2.49 1.77 5 3.34 4.03 2.69 5 1.94];
%x = [1.1 1.0943 1.0747 1.0766 1.1 1.1 1.0433 0.9 0.97912 0.96474 5 5 4.8055 5 4.0263 5 2.5193 5 2.1925];
%x = contvar(2,:);

Tbranch = [11 12 15 36];
Qbus = [10 12 15 17 20 21 23 24 29];

data = loadcase(case30);
data.gen(1:6,6) = x(1:6);
data.branch(Tbranch,9) = x(7:10);
data.bus(Qbus,6) = x(11:19);

mpopt = mpoption('pf.enforce_q_lims',0,'verbose',0,'out.all',1);
result = runpf(data,mpopt);

%Constraint finding 
Vmax = data.bus(:,12);
Vmin = data.bus(:,13);
genbus = data.gen(:,1);

Qmax = data.gen(:,4)/data.baseMVA;
Qmin = data.gen(:,5)/data.baseMVA;
QG = result.gen(:,3)/data.baseMVA;

blimit = data.branch(:,6);
Slimit = sqrt(result.branch(:,14).^2+result.branch(:,15).^2);
Serr = sum((Slimit>blimit).*abs(blimit-Slimit))/data.baseMVA;

% TO find the error in Qg of gen buses- inequality constraint
Qerr = sum((QG<Qmin).*(abs(Qmin-QG)./(Qmax-Qmin))+(QG>Qmax).*(abs(Qmax-QG)./(Qmax-Qmin)));
% TO find the error in V of load buses-inequality constraint
VI = result.bus(:,8);  %V of load buses-inequality constraint
VI(genbus)=[];
Vmax(genbus)=[];
Vmin(genbus)=[];
VIerr = sum((VI<Vmin).*(abs(Vmin-VI)./(Vmax-Vmin))+(VI>Vmax).*(abs(Vmax-VI)./(Vmax-Vmin)));
VD = sum(abs(VI-1));

ploss = sum(result.branch(:,14)+result.branch(:,16));

error = [Qerr,VIerr,Serr];

f1 = ploss; % power loss only
%f1 = VD; % Cumulative voltage deviation only
%result = [x';ploss;VD;QG.*100];