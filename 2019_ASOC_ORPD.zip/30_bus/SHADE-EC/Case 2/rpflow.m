function [f1,error] = rpflow(x)

global VD ploss VI
%x = [1.1 1.0387 1.0161 1.0290 1.0123 1.1 1.0223 0.9107 1.0098 0.9744 3.4125 5 2.0981 5 3.5512 4.0005 3.1928 4.88 2.1];
%x = [1.1 1.0173 1.02 1.0001 0.9998 1.0011 1.0035 1.0281 1.0296 1.1470 1.12 1.0045 2.185 3.551 2.3512 1.8 5 3.0218 1.411];
%x = [1.1 1.0942 1.0749 1.0765 1.1 1.1 1.0311 0.9 0.9763 0.9616 4.6908 5 5 5 4.9934 5 5 5 1.9984];
%x = [1.006059 1.0013 1.0193 1.01852 0.9709 1.0117 0.9943 0.9120 0.98914 0.96458 5 2.0992 5 0.3994 5 5 5 4.03057 1.5166];
%x = contvar(2,:);

Tbranch = [11 12 15 36];
Qbus = [10 12 15 17 20 21 23 24 29];

data = loadcase(case30);
data.gen(1:6,6) = x(1:6);
Trat = x(7:10);
Trat = round(Trat./0.02).*0.02;
data.branch(Tbranch,9) = Trat;
Qrat = x(11:19);
Qrat = round(Qrat./0.2).*0.2;
data.bus(Qbus,6) = Qrat;

mpopt = mpoption('pf.enforce_q_lims',0,'verbose',0,'out.all',0);
result = runpf(data,mpopt);

%Constraint finding 
Vmax = data.bus(:,12);
Vmin = data.bus(:,13);
genbus = data.gen(:,1);

Qmax = data.gen(:,4)/data.baseMVA;
Qmin = data.gen(:,5)/data.baseMVA;
QG = result.gen(:,3)/data.baseMVA;

blimit = data.branch(:,6);
Slimit = sqrt(result.branch(:,14).^2+result.branch(:,15).^2);
Serr = sum((Slimit>blimit).*abs(blimit-Slimit))/data.baseMVA;

% TO find the error in Qg of gen buses- inequality constraint
Qerr = sum((QG<Qmin).*(abs(Qmin-QG)./(Qmax-Qmin))+(QG>Qmax).*(abs(Qmax-QG)./(Qmax-Qmin)));
% TO find the error in V of load buses-inequality constraint
VI = result.bus(:,8);  %V of load buses-inequality constraint
VI(genbus)=[];
Vmax(genbus)=[];
Vmin(genbus)=[];
VIerr = sum((VI<Vmin).*(abs(Vmin-VI)./(Vmax-Vmin))+(VI>Vmax).*(abs(Vmax-VI)./(Vmax-Vmin)));
VD = sum(abs(VI-1));

ploss = sum(result.branch(:,14)+result.branch(:,16));

error = [Qerr,VIerr,Serr];

%f1 = ploss; % power loss only
f1 = VD; % Cumulative voltage deviation only
%result = [x';ploss;VD;QG.*100];