%function [f1,error] = rpflow(x)

%global VD ploss VI scene_no scene_sel scenario
%x = [1.1 1.0173 1.02 1.0001 0.9998 1.0011 1.0035 1.0281 1.0296 1.1470 1.12 1.0045 2.185 3.551 2.3512 1.8 5 3.0218 1.411];
Psr = 50; Rc = 120; Gstd = 1000; % PV parameters
Vin = 3; Vout = 25; Vr = 16; Pr = 3; % Cut-in, cut-out, rated speed and rated power of wind turbine
NT = 25; % number of wind turbine
final_result = []; final_VI = [];
for i = 1:25
    %x = contvar(i,:);
%%
scn = load('all_scene');
scene_sel = scn.scene_sel(:,1:3);
x = contvar(i,:);
%%
load_demand = scene_sel(i,1)/100; % load demand for the scenario
wspeed = scene_sel(i,2); % wind speed for the scenario 
irrad = scene_sel(i,3); % solar irradiance for the scenario

Tbranch = [11 12 15 36];
Qbus = [10 12 15 17 20 21 23 24 29];

data = loadcase(case30);
data.gen(1:6,6) = x(1:6);
data.bus(:,3) = load_demand.*data.bus(:,3);
data.bus(:,4) = load_demand.*data.bus(:,4);

Trat = x(7:10);
Trat = round(Trat./0.02).*0.02;
data.branch(Tbranch,9) = Trat;
Qrat = x(11:19);
Qrat = round(Qrat./0.2).*0.2;
data.bus(Qbus,6) = Qrat;

%% wind power calculation
if (wspeed<Vin)||(wspeed>Vout)
  winpow = 0;
  elseif wspeed>=Vin && wspeed<Vr
  winpow = Pr*(wspeed-Vin)/(Vr-Vin);
  else
  winpow = Pr;
end
data.gen(3,2:5) = [NT*winpow 37 35 -30]; 

%% solar power calculation
if irrad<=Rc
solpow = Psr*(irrad^2/(Gstd*Rc));
else
solpow = min(Psr,Psr*(irrad/Gstd));
end
data.gen(4,2:5) = [solpow 37.3 25 -20]; 

%% scenario
%scenario = [scene_no,scene_sel(scene_no,1),wspeed,irrad,winpow,solpow,scene_sel(scene_no,4)];

%% power flow
mpopt = mpoption('pf.enforce_q_lims',0,'verbose',0,'out.all',0);
result = runpf(data,mpopt);

%% Constraint finding 
Vmax = data.bus(:,12);
Vmin = data.bus(:,13);
genbus = data.gen(:,1);

Qmax = data.gen(:,4)/data.baseMVA;
Qmin = data.gen(:,5)/data.baseMVA;
QG = result.gen(:,3)/data.baseMVA;

blimit = data.branch(:,6);
Slimit = sqrt(result.branch(:,14).^2+result.branch(:,15).^2);
Serr = sum((Slimit>blimit).*abs(blimit-Slimit))/data.baseMVA;

% TO find the error in Qg of gen buses-inequality constraint
Qerr = sum((QG<Qmin).*(abs(Qmin-QG)./(Qmax-Qmin))+(QG>Qmax).*(abs(Qmax-QG)./(Qmax-Qmin)));
% TO find the error in V of load buses-inequality constraint
VI = result.bus(:,8);  %V of load buses-inequality constraint
VI(genbus)=[];
Vmax(genbus)=[];
Vmin(genbus)=[];
VIerr = sum((VI<Vmin).*(abs(Vmin-VI)./(Vmax-Vmin))+(VI>Vmax).*(abs(Vmax-VI)./(Vmax-Vmin)));
VD = sum(abs(VI-1));

ploss = sum(result.branch(:,14)+result.branch(:,16));

error = [Qerr,VIerr,Serr];

%f1 = ploss; % power loss only
f1 = VD; % Cumulative voltage deviation only
Vdrop(i) = VD;
ERR(i) = sum(error);
RESULT = [x';ploss;VD;QG.*100];
final_result = [final_result,RESULT];
final_VI = [final_VI,VI];
end
Vdrop = Vdrop';
ERR = ERR';
