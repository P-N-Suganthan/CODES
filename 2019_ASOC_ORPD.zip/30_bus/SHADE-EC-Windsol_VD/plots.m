 clf
 scene_dat = load('all_scene');
 scene = scene_dat.all_scene;
 mcarlo = size(scene,1);
 
 % plot loading scenarios
 figure(1)
 [num,xout] = hist(scene(:,1),mcarlo);
 bar(xout,num/sum(num));
 xlabel('Network loading in %')
 ylabel('Relative frequency')
 
 % plot wind speed scenarios
 figure(2)
 [num,xout] = hist(scene(:,2),mcarlo);
 bar(xout,num/sum(num));
 xlabel('Wind speed in m/s')
 ylabel('Relative frequency')
 
 % plot solar irradiance scenarios
 figure(3)
 [num,xout] = hist(scene(:,3),mcarlo);
 bar(xout,num/sum(num));
 xlabel('Solar irradiance in W/m^2')
 ylabel('Relative frequency')
 
 % plot solar irradiance without zero irradiance
 figure(4)
 [num,xout] = hist(scene(:,3),mcarlo);
 zz = num./sum(num);
 idx = find(scene(:,3)==0);
 xout(idx)=[];
 zz(idx)=[];
 bar(xout,zz);
 xlabel('Solar irradiance in W/m^2')
 ylabel('Relative frequency')
 