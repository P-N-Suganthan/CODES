Title: MATLAB code for "Optimal reactive power dispatch with uncertainties in load demand and 
renewable energy sources adopting scenario-based approach" Applied Soft Cmputing DOI: 10.1016/j.asoc.2018.11.042

The author can be contacted at parthapr001@e.ntu.edu.sg

You need MATPOWER to run the program.