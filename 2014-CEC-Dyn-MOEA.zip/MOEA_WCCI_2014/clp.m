function p=clp(p)
w=[ find(p(2,:)>=2.5) find(p(1,:)>=2.01)];
p(:,w)=[];


end
