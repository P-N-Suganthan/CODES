load nps1_11
a=mean(metric(1,:));
b=mean(metric(2,:));
[a b]
avg=mean([a b])
sd=std([a b])



