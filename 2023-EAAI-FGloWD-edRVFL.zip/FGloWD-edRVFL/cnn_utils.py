#!/usr/bin/env python
# Author, Li Ruilin
import os
import time
import math
import shutil
import numpy as np
import matplotlib.pyplot as plt

import torch
import torch.nn as nn

from sklearn.metrics import confusion_matrix
from sklearn.metrics import precision_recall_fscore_support, classification_report

best_acc1 = 0


def train(train_loader, model, criterion, optimizer, epoch, adj=None, ensemble=False, train_hist=None):
    batch_time = AverageMeter('Time', ':6.3f')
    data_time = AverageMeter('Data', ':6.3f')
    losses = AverageMeter('Loss', ':.4e')
    acc = AverageMeter('Acc', ':6.2f')
    entropy_mean = AverageMeter('Entropy', ':6.5f')
    progress = ProgressMeter(
        len(train_loader),
        [batch_time, data_time, losses, acc, entropy_mean],
        prefix="Epoch: [{}]".format(epoch))

    """
    Switch to eval mode:
    Under the protocol of linear classification on frozen features/models,
    it is not legitimate to change any part of the pre-trained model.
    BatchNorm in train mode may revise running mean/std (even if it receives
    no gradient), which are part of the model parameters too.
    """
    model.train()

    end = time.time()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    for i, (signals, target) in enumerate(train_loader):
        # measure data loading time
        data_time.update(time.time() - end)

        signals = signals.cuda(device)
        target = target.cuda(device)
        if ensemble:
            signals = [torch.unsqueeze(torch.squeeze(signals[:, :, :, i, :]), dim=1) for i in range(signals.shape[3])]
            batch_size = signals[0].size(0)
        else:
            batch_size = signals.size(0)

        # compute output
        if adj is not None:
            output = model(signals, adj)
        else:
            output = model(signals)
        probs = nn.functional.softmax(output, dim=1)
        entropy = -torch.sum(probs * torch.log2(probs), 1)
        entropy_mean.update(torch.mean(entropy), batch_size)
        loss = criterion(output, target)

        # measure accuracy and record loss
        correct, _ = accuracy(output, target)
        losses.update(loss.item(), batch_size)
        acc.update(correct[0], batch_size)
        if train_hist:
            train_hist['loss'].append(loss.item())

        # compute gradient and do SGD step
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()

        print_freq = 10
        if i % print_freq == 0 or i == len(train_loader)-1:
            progress.display(i)
    return train_hist, losses


def validate(val_loader, model, criterion, adj=None, ensemble=False, train_hist=None):
    batch_time = AverageMeter('Time', ':6.3f')
    losses = AverageMeter('Loss', ':.4e')
    acc = AverageMeter('Acc', ':6.2f')
    entropy_mean = AverageMeter('Entropy', ':6.5f')
    progress = ProgressMeter(
        len(val_loader),
        [batch_time, losses, acc, entropy_mean],
        prefix='Test: ')

    # switch to evaluate mode
    model.eval()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    with torch.no_grad():
        end = time.time()
        cc = []
        ground_truth = []
        preds_result = []
        for i, (signals, target) in enumerate(val_loader):
            # signals = images.cuda(device, non_blocking=True)
            signals = signals.cuda(device)
            ground_truth += target
            target = target.cuda(device)

            if ensemble:
                signals = [torch.unsqueeze(torch.squeeze(signals[:, :, :, i, :]), dim=1) for i in range(signals.shape[3])]
                batch_size = signals[0].size(0)
            else:
                batch_size = signals.size(0)

            # compute output
            if adj is not None:
                output = model(signals, adj)
            else:
                output = model(signals)
            probs = nn.functional.softmax(output, dim=1)
            preds = probs.argmax(axis=-1)
            preds_result += preds.cpu()
            probs_b = torch.ones_like(probs) * 1e-10
            probs = torch.where(probs == 0, probs_b, probs)
            entropy = -torch.sum(probs * torch.log2(probs), 1)
            entropy_mean.update(torch.mean(entropy), batch_size)
            loss = criterion(output, target)
            if train_hist:
                train_hist['val_loss'].append(loss.item())

            # measure accuracy and record loss
            correct, c__ = accuracy(output, target)
            losses.update(loss.item(), batch_size)
            acc.update(correct[0], batch_size)
            if c__.shape == torch.Size([]):
                c__ = torch.unsqueeze(c__, 0)
            cc += c__.cpu()

            # measure elapsed time
            batch_time.update(time.time() - end)
            end = time.time()

            print_freq = 10
            # if i % print_freq == 0:
            # progress.display(i)

        # TODO: this should also be done with the ProgressMeter
        # print(' * Acc@1 {acc.avg:.3f}'
        #       .format(acc=acc))

    return acc.avg, train_hist


def adjust_learning_rate(optimizer, epoch, lr, epochs, cos):
    """Decay the learning rate based on schedule"""
    if cos:  # cosine lr schedule
        lr *= 0.5 * (1. + math.cos(math.pi * epoch / epochs))
    else:  # stepwise lr schedule
        for milestone in [120, 160]:
            lr *= 0.1 if epoch >= milestone else 1.
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr


def save_checkpoint(state, is_best, save_cp_path, epoch, filename='checkpoint.pth.tar', save_data=False):

    # if epoch == 19:
    #     torch.save(state, filename)
    # if epoch == 29:
    #     torch.save(state, filename)
    # if epoch == 39:
    #     torch.save(state, filename)
    # if epoch == 49:
    #     torch.save(state, filename)
    # if epoch == 59:
    #     torch.save(state, filename)
    # if epoch == 69:
    #     torch.save(state, filename)
    # if epoch == 79:
    #     torch.save(state, filename)
    # if epoch == 99:
    #     torch.save(state, filename)
    if save_data:
        torch.save(state, filename)
    if is_best:
        # save_cp_path = 'Checkpoints\\ShallowCNN_Mi_01_NoAug_2'
        # shutil.copyfile(filename, save_cp_path + os.sep + 'model_best.pth.tar')
        filename_best = save_cp_path + os.sep + 'model_best.pth.tar'
        torch.save(state, filename_best)
        # torch.save(state, 'model_best.pth.tar')


class ProgressMeter(object):
    def __init__(self, num_batches, meters, prefix=""):
        self.batch_fmtstr = self._get_batch_fmtstr(num_batches)
        self.meters = meters
        self.prefix = prefix

    def display(self, batch):
        entries = [self.prefix + self.batch_fmtstr.format(batch)]
        entries += [str(meter) for meter in self.meters]
        print('\t'.join(entries))

    def _get_batch_fmtstr(self, num_batches):
        num_digits = len(str(num_batches // 1))
        fmt = '{:' + str(num_digits) + 'd}'
        return '[' + fmt + '/' + fmt.format(num_batches) + ']'


class AverageMeter(object):
    """Computes and stores the average and current value"""
    def __init__(self, name, fmt=':f'):
        self.name = name
        self.fmt = fmt
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count

    def __str__(self):
        fmtstr = '{name} {val' + self.fmt + '} ({avg' + self.fmt + '})'
        return fmtstr.format(**self.__dict__)


def accuracy(output, target):
    topk = (1, )
    with torch.no_grad():
        maxk = max(topk)
        batch_size = target.size(0)

        _, pred = output.topk(maxk, 1, True, True)
        pred = pred.t()
        correct = pred.eq(target.view(1, -1).expand_as(pred))

        res = []
        for k in topk:
            correct_k = correct[:k].view(-1).float().sum(0, keepdim=True)
            res.append(correct_k.mul_(100.0 / batch_size))
        return res[0], torch.squeeze(correct)


def sanity_check(state_dict, pretrained_weights):
    """
    Linear classifier should not change any weights other than the linear layer.
    This sanity check asserts nothing wrong happens (e.g., BN stats updated).
    """
    print("=> loading '{}' for sanity check".format(pretrained_weights))
    checkpoint = torch.load(pretrained_weights, map_location="cpu")
    state_dict_pre = checkpoint['state_dict']

    for k in list(state_dict.keys()):
        # only ignore fc layer
        if 'fc.weight' in k or 'fc.bias' in k:
            continue

        # name in pretrained model
        k_pre = 'encoder_q.' + k[len('encoder_q.'):] \
            if k.startswith('encoder_q.') else 'encoder_q.' + k

        assert ((state_dict[k].cpu() == state_dict_pre[k_pre]).all()), \
            '{} is changed in linear classifier training.'.format(k)

    print("=> sanity check passed.")


def McNemar_Test(baseline_data_path, test_augmentation_data, aug_name):
    baseline_data = np.load(baseline_data_path+'.npy')
    # test_augmentation_data = np.load('Checkpoints_SA\\Resnet18_TimeWrapSingle_20_.npy')
    a = np.zeros(shape=(2, 2))
    for i in range(len(baseline_data)):
        a[0, 0] = a[0, 0] + int(baseline_data[i] and test_augmentation_data[i])
        a[0, 1] = a[0, 1] + int(not baseline_data[i] and test_augmentation_data[i])
        a[1, 0] = a[1, 0] + int( baseline_data[i] and not test_augmentation_data[i])
        a[1, 1] = a[1, 1] + int(not baseline_data[i] and not test_augmentation_data[i])

    tao = np.square(np.abs(a[0, 1]-a[1, 0]-1))/(a[0, 1]+a[1, 0])

    print('McNemar_Test result of ' + aug_name + ': {}'.format(tao))
    return tao


def loss_plot_train(hist, path = 'Train_hist.png', js=1):
    plt.figure(js + 1)
    x = range(len(hist['loss']))

    y1 = hist['loss']

    plt.plot(x, y1, label='loss')

    plt.xlabel('Iter')
    plt.ylabel('Loss')

    plt.legend(loc=4)
    plt.grid(True)
    plt.tight_layout()

    path = path + '_train_loss.png'
    plt.savefig(path)
    plt.close()


def loss_plot_val(hist, path = 'Train_hist.png', js=1):
    plt.figure(js+1)
    x = range(len(hist['val_loss']))

    y1 = hist['val_loss']

    plt.plot(x, y1, label='val_loss')

    plt.xlabel('Iter')
    plt.ylabel('val_Loss')

    plt.legend(loc=4)
    plt.grid(True)
    plt.tight_layout()

    path = path + '_val_loss.png'
    plt.savefig(path)
    plt.close()