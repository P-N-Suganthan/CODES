import scipy.io as sio
from sklearn.metrics import accuracy_score
from sklearn.linear_model import Ridge
from Utils import *


class EdRVFL():
    def __init__(self, hyper_p, D_in, weight_min=-1, weight_max=1, bias_range=(0,1)):
        self.D_in = D_in

        # hyper-parameters
        self.norm_coef = hyper_p[0]
        self.num_layer = hyper_p[1]
        self.activation = hyper_p[2]
        self.H = hyper_p[3]
        self.reg = hyper_p[4]
        self.feature_selection = hyper_p[5]
        self.final_feat = hyper_p[6]
        self.weight_r = hyper_p[7]
        self.global_reg = hyper_p[8]
        self.entro_num = hyper_p[9]

        # weight and bias initialization
        for i in range(self.num_layer):
            if i == 0:
                self.__setattr__('weight_%d'%(i), weight_min + (weight_max - weight_min) * torch.rand(D_in, self.H[i]))
            else:
                self.__setattr__('weight_%d' % (i), weight_min + (weight_max - weight_min) * torch.rand(D_in + self.H[i-1], self.H[i]))
            self.__setattr__('bias_%d'%(i),bias_range[0] + (bias_range[1] - bias_range[0]) * torch.rand(1, self.H[i]))

    def feed_data(self, Xtrain, ytrain):
        self.Xtrain = Xtrain
        self.ytrain = torch.unsqueeze(ytrain, -1) if len(ytrain.shape) == 1 else ytrain
        self.Xtrval = Xtrain
        self.ytrval = self.ytrain * 2 - 1

    def pruning(self, embedding, final_feat=None):
        prunings = torch.LongTensor(np.arange(0, embedding.size(1), 1))

        if self.feature_selection == None:
            pass

        elif self.feature_selection == 'Embedded':
            prunings = torch.LongTensor(feature_embed(embedding, self.ytrain, final_feat=final_feat))

        elif self.feature_selection == '':
            # Other model-based feature selection can be applied here such as ridge-regression-based feature pruning
            pass

        return prunings

    def train(self):
        embedding_prev = self.Xtrval

        self.ytrains_pred = np.zeros((self.num_layer+1, self.Xtrval.shape[0], 1))
        weight_matrix = np.ones((embedding_prev.shape[0],))

        for j in range(self.num_layer):
            weight_j = self.__getattribute__('weight_%d'%(j))
            bias_j = self.__getattribute__('bias_%d'%(j))
            embedding_j = self._activation(torch.mm(embedding_prev, weight_j) \
                                           + torch.mm(torch.ones([self.Xtrval.shape[0], 1]), bias_j))

            H_j = torch.cat((self.Xtrval, embedding_j), dim=1)

            prunings_j = self.pruning(H_j, self.final_feat[j])
            self.__setattr__('prunings_%d' % (j), prunings_j)

            hidden_state_train_j = np.array(H_j[:, prunings_j])

            if j == 0:
                global_embeddings = hidden_state_train_j
            else:
                global_embeddings = np.concatenate((global_embeddings, hidden_state_train_j), axis=1)

            hidden_state_train_j = np.matmul(np.diag(weight_matrix), hidden_state_train_j)

            clf_j = Ridge(alpha=self.reg[j]).fit(hidden_state_train_j, self.ytrval)
            self.__setattr__('clf_%d' % (j), clf_j)

            self.ytrains_pred[j] = clf_j.predict(hidden_state_train_j)

            weight_matrix = self.weight_computing(self.ytrains_pred[j, :, 0], np.squeeze(self.ytrval.numpy()))

            embedding_prev = H_j    # H_j

        ## global classifier ##
        self.global_clf = Ridge(alpha=self.global_reg).fit(global_embeddings, self.ytrval)
        self.ytrains_pred[j+1] = self.global_clf.predict(global_embeddings)

    def weight_computing(self, pred, ytrain):
        ytrains_pred = pred.copy()

        ytrains_pred[np.where(ytrains_pred < 0)[0]] = -1
        ytrains_pred[np.where(ytrains_pred > 0)[0]] = 1

        index_r = np.where(ytrains_pred == ytrain)[0]
        index_w = np.where(ytrains_pred != ytrain)[0]

        weight_matrix = np.zeros((ytrains_pred.shape[0],))
        a = self.weight_r

        weight_matrix[index_w] = a
        weight_matrix[index_r] = (ytrains_pred.shape[0] - a * len(index_w)) / len(index_r)

        return weight_matrix

    def predict(self, Xtest):
        self.Xtest = Xtest
        self.ytests_pred = np.zeros((self.num_layer+1, Xtest.shape[0], 1))

        embedding_prev = Xtest

        for i in range(self.num_layer):
            weight_i = self.__getattribute__('weight_%d'%(i))
            bias_i = self.__getattribute__('bias_%d'%(i))
            embedding_i = self._activation(torch.mm(embedding_prev, weight_i) \
                             + torch.mm(torch.ones([Xtest.shape[0], 1]), bias_i))

            H_i = torch.cat((Xtest, embedding_i), dim=1)

            prunings_i = self.__getattribute__('prunings_%d' % (i))
            hidden_state_test_i = np.array(H_i[:, prunings_i])

            if i == 0:
                global_embeddings = hidden_state_test_i
            else:
                global_embeddings = np.concatenate((global_embeddings, hidden_state_test_i), axis=1)

            clf_i = self.__getattribute__('clf_%d' % (i))
            self.ytests_pred[i] = clf_i.predict(hidden_state_test_i)

            embedding_prev = H_i

        ## global classifier ##
        self.ytests_pred[i+1] = self.global_clf.predict(global_embeddings)

    def category_accu_calculate(self, ytest, prob):
        prob[np.where(prob < 0)[0]] = 0
        prob[np.where(prob > 0)[0]] = 1
        accu = accuracy_score(ytest, prob)
        return prob, accu

    def voting_computing(self, ytest, val_state=False):
        # ensemble
        prob_global = np.mean(self.ytests_pred, axis=0)

        # ensemble except global representation
        prob_local = np.mean(self.ytests_pred[0:self.num_layer, :, 0], axis=0)

        _, acc_local = self.category_accu_calculate(ytest, prob_local)
        _, acc_global = self.category_accu_calculate(ytest, prob_global)

        acc_entropy, pred = self.entropy_ensemble(self.Xtest, ytest)

        if val_state:
            return acc_local, acc_entropy
        else:
            return acc_local, acc_global, acc_entropy, pred.astype(np.int).tolist()

    def entropy_ensemble(self, Xtest, ytest):
        p_interm = self.ytests_pred[:, :, 0].copy()
        a_interm = (p_interm + 1) / 2.0

        a_interm[np.where(a_interm <= 0)[0], np.where(a_interm <= 0)[1]] = 0.000001
        a_interm[np.where(a_interm >= 1)[0], np.where(a_interm >= 1)[1]] = 1 - 0.000001

        ## Entropy Formula ##
        entropy = -(1 - a_interm) * np.log(1 - a_interm) - a_interm * np.log(a_interm)
        entropy[np.where(np.isnan(entropy))[0], np.where(np.isnan(entropy))[1]] = 0

        ie = 1 - entropy

        n_test_sample = Xtest.shape[0]

        sel_pred = np.zeros((n_test_sample,))

        for i in range(n_test_sample):
            norm_ie = np.zeros((self.num_layer + 1,))
            sel_index = entropy[:, i].argsort()[0:self.entro_num]
            norm_ie[sel_index] = ie[sel_index, i] / np.sum(ie[sel_index, i])
            sel_pred[i] = np.sum(np.multiply(norm_ie, a_interm[:, i]))

        sel_pred = sel_pred * 2.0 - 1

        entropy_ensemble_accu = self.category_accu_calculate(ytest, sel_pred)[1]

        return entropy_ensemble_accu, sel_pred

    def _activation(self, x):
        assert torch.is_tensor(x)
        activation = self.activation.lower()
        assert activation in ['sigmoid', 'relu', 'tanh', 'nn.functional.elu']
        return eval('torch.%s'%(activation))(x)


class RVFLClassifier(object):
    def __init__(self, Xtrain, ytrain, Xtest, ytest):
        self.Xtrain = torch.tensor(Xtrain, dtype=torch.float32)
        self.ytrain = torch.tensor(ytrain, dtype=torch.float32)
        self.Xtest = torch.tensor(Xtest, dtype=torch.float32)
        self.ytest = torch.tensor(ytest, dtype=torch.float32)

    def EdRVFL_predict(self, hyper_p, val_state=False):
        D_in = self.Xtrain.shape[1]

        model = EdRVFL(hyper_p, D_in)
        model.feed_data(self.Xtrain, self.ytrain)

        model.train()
        model.predict(self.Xtest)

        if val_state:
            acc_local, acc_entropy = model.voting_computing(
                self.ytest, val_state=val_state)
            return acc_local, acc_entropy
        else:
            ytest_Edrvfl_ensemble_0, ytest_Edrvfl_ensemble, entropy_ensemble_accu, ytests_pred = model.voting_computing(self.ytest, val_state=val_state)
            return ytest_Edrvfl_ensemble_0, ytest_Edrvfl_ensemble, entropy_ensemble_accu, ytests_pred


def load_drivedata(input_type='raw', decomposition=False, one_hot=False, adj_return=False, decomposition_mode='dwt'):
    filename = 'drivedata\\journaltaiwanbalanced.mat'
    tmp = sio.loadmat(filename)
    subIdx = np.array(tmp['subindex'])
    x_data = np.array(tmp['EEGsample'])

    if not decomposition:
        if input_type == 'raw':
            label = np.array(tmp['substate'])
            label.astype(int)
            subIdx.astype(int)
            xdata = x_data
        elif input_type == 'feature':
            pass
        else:
            raise Exception('input_type error: {}'.format(input_type))

    samplenum = label.shape[0]
    if one_hot:
        ydata = np.zeros((samplenum, 2), dtype=np.longlong)
        for k in range(len(label)):
            if label[k] == 1:
                ydata[k] = [0, 1]
            else:
                ydata[k] = [1, 0]
    else:
        ydata = np.squeeze(label.astype(np.int64))

    return xdata, ydata, subIdx



