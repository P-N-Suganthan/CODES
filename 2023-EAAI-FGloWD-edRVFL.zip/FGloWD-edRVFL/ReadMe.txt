A demo code for the paper:  "An enhanced ensemble deep random vector functional link network for driver fatigue recognition" ( https://doi.org/10.1016/j.engappai.2023.106237 ).

To download the demo data files, please visit figshare (https://figshare.com) and search for the following DOI: 10.6084/m9.figshare.22639252.