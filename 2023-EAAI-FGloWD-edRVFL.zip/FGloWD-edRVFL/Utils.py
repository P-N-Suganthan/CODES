import numpy as np
from sklearn.ensemble import RandomForestClassifier


def feature_embed(X,y,final_feat=10):
    B,P = X.shape
    assert X.shape[0] == y.shape[0]
    regressor = RandomForestClassifier(n_estimators=20, random_state=0)
    regressor.fit(X, np.squeeze(y))
    importances = np.array(list(regressor.feature_importances_))
    rank_embed = importances.argsort()[::-1][0:final_feat]
    select_vec = np.array([1 if i in rank_embed else 0 for i in range(P)])
    pruning_mx = np.diag(select_vec)
    index = np.where(select_vec)[0]
    return index














