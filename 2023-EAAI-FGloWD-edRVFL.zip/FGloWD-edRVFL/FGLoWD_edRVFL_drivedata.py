import os
import numpy as np

import itertools

import torch
import torch.nn as nn

from rvfl_utils import RVFLClassifier, load_drivedata
from cnn_utils import validate
from nn_models import InterpretableCNN
from sklearn.model_selection import KFold
from sklearn.metrics import precision_recall_fscore_support


def feature_extractor(sub=1):
    dataset_sel = 'drivedata'

    xdata, ydata, subIdx = load_drivedata()

    # form the training data
    trainindx = np.where(subIdx != sub)[0]
    xtrain = xdata[trainindx]
    x_train = np.expand_dims(xtrain, axis=1)
    y_train = ydata[trainindx]

    # form the testing data
    testindx = np.where(subIdx == sub)[0]
    xtest = xdata[testindx]
    x_test = np.expand_dims(xtest, axis=1)
    y_test = ydata[testindx]

    trainIdx = subIdx[trainindx]
    testIdx = subIdx[testindx]

    # test dataset
    dataset = torch.utils.data.TensorDataset(torch.from_numpy(x_test.astype(np.float32)), torch.from_numpy(y_test))
    test_loader = torch.utils.data.DataLoader(dataset, batch_size=x_test.shape[0], shuffle=False)

    Xtrain = torch.tensor(x_train, dtype=torch.float32)
    Xtest = torch.tensor(x_test, dtype=torch.float32)

    Xtrain = Xtrain.cuda()
    Xtest = Xtest.cuda()

    # load cnn feature
    model_name = 'InterpretableCNN'
    model = InterpretableCNN(sampleChannel=30)

    # print(model)
    model = model.cuda()
    save_cp_path = 'Checkpoint' + os.sep + dataset_sel + os.sep + model_name + os.sep + 'transfer' + os.sep + \
                   'non_dec' + os.sep + 'withcv' + os.sep + 'inter' + os.sep + str(sub)

    # Load the pretrained model
    validation_epoch_set = np.load('validation/ICNN/ICNN_ori_validation_epoch.npy')
    epoch_no = int(validation_epoch_set[sub - 1])
    pretrained = save_cp_path + os.sep + 'checkpoint_{:04d}.pth.tar'.format(epoch_no)
    criterion = nn.CrossEntropyLoss().cuda()
    if pretrained:
        accs = []
        print('pretrained is True')
        if os.path.isfile(pretrained):
            print("=> loading checkpoint '{}'".format(pretrained))
            checkpoint = torch.load(pretrained, map_location="cpu")
            model.load_state_dict(checkpoint['state_dict'])
            print('loaded from epoch {}'.format(checkpoint['epoch']))
            acc, _ = validate(test_loader, model, criterion)
            accs.append(acc.item())
        else:
            raise Exception('pretrained path error: {}'.format(pretrained))

    # CNN features
    model.eval()
    with torch.no_grad():
        _ = model(Xtrain)
        X_train = model.feature
        Xtrain = np.array(X_train.cpu())
        _ = model(Xtest)
        X_test = model.feature
        Xtest = np.array(X_test.cpu())

    return Xtrain, Xtest, y_train, y_test, trainIdx, testIdx


def main_work_rvfl(sub, hyper_p):
    seed = 0
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)

    Xtrain, Xtest, y_train, y_test, trainIdx, testIdx = feature_extractor(sub)

    norm_coef = hyper_p[0]

    # normalization
    min_x = np.min(Xtrain)
    max_x = np.max(Xtrain)
    Xtrain = ((Xtrain - min_x) / (max_x - min_x)) * 2 * norm_coef - norm_coef
    Xtest = ((Xtest - min_x) / (max_x - min_x)) * 2 * norm_coef - norm_coef

    ############ edRVFL ###########
    RF = RVFLClassifier(Xtrain, y_train, Xtest, y_test)
    edrvfl_acc_0, edrvfl_acc, entropy_ensemble_accu, ytests_pred = RF.EdRVFL_predict(hyper_p, val_state=False)

    return edrvfl_acc_0, edrvfl_acc, entropy_ensemble_accu, y_test.tolist(), ytests_pred


def rvfl_CV(sub=1, fold=5):
    # setting seed
    seed = 0
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.deterministic = True

    model_name = 'InterpretableCNN'
    dataset_sel = 'drivedata'
    xdata, ydata, subIdx = load_drivedata()

    #       form the training data
    sub_all = np.unique(subIdx)
    train_sub_all = [i for i in sub_all if i != sub]
    train_sub_all_np = np.array(train_sub_all)

    kf = KFold(n_splits=fold, shuffle=False)

    ''' The hyper-parameter tunning is extremely time-consuming, for the purpose of convenience, I put an example hyper-parameter here'''

    norm_coef = [0.1]
    activation = ['tanh']
    H_b = [[512, 128, 128, 128]]  #
    reg_b = [[0.03125, 0.03125, 0.0625, 0.125]]
    feature_selection = ['Embedded']
    final_feat_b = [[10, 50, 50, 50]]
    weight_r = [0]
    global_reg = [0.5]
    entro_num = [2]

    # if using example hyper-parameter, please use the following range:
    for nl in range(3, 4):
        num_layer = [nl + 1]

        H = H_b
        reg = reg_b
        final_feat = final_feat_b

        ''' If you want to try hyper-parameter tunning, please use the following search space and comment out the example hyper-parameter above. '''
    # norm_coef = [0.1]
    # activation = ['tanh']
    # H_b = [[512, 128, 128, 128]]  #
    # reg_b = [[0.03125], [0.0625], [0.125]]
    # feature_selection = ['Embedded']
    # final_feat_b = [[10], [50]]
    # weight_r = [0, 0.5, 1.5]
    # global_reg = [0.5]
    # entro_num = [2, 3, 4]


    # if using the listed search space for tuning please comment out the range above and use the following range:
    # for nl in range(4):
        # num_layer = [nl+1]
        # if nl > 0:
        #     H = H_b
        #     reg = [bh[4] + reg_b[t] for t in range(len(reg_b))]
        #     final_feat = [bh[6] + final_feat_b[t] for t in range(len(final_feat_b))]
        # else:
            # H = H_b
            # reg = reg_b
            # final_feat = final_feat_b

        if num_layer[0] < 4:
            hyper_p = list(itertools.product(norm_coef, num_layer, activation, H, reg,
                                             feature_selection, final_feat, [0], [0.5], [2]))
        else:
            hyper_p = list(itertools.product(norm_coef, num_layer, activation, H, reg,
                                             feature_selection, final_feat, weight_r, global_reg, entro_num))

        loss = np.zeros((fold, len(hyper_p)))


        for i, (train_fold, val_fold) in enumerate(kf.split(train_sub_all)):
            model = InterpretableCNN(sampleChannel=30)
            model = model.cuda()

            val_sub = val_fold.tolist()
            train_sub_index = train_sub_all_np[train_fold.tolist()]
            trainindx = np.where(subIdx == train_sub_index)[0]
            xtrain = xdata[trainindx]
            x_train = np.expand_dims(xtrain, axis=1)
            y_train = ydata[trainindx]

            #       form the validation data
            val_sub_index = train_sub_all_np[val_fold.tolist()]
            testindx = np.where(subIdx == val_sub_index)[0]
            xtest = xdata[testindx]
            x_test = np.expand_dims(xtest, axis=1)
            y_test = ydata[testindx]

            # feature extraction
            dataset = torch.utils.data.TensorDataset(torch.from_numpy(x_test.astype(np.float32)),
                                                     torch.from_numpy(y_test))
            test_loader = torch.utils.data.DataLoader(dataset, batch_size=x_test.shape[0], shuffle=False)

            Xtrain = torch.tensor(x_train, dtype=torch.float32)
            Xtest = torch.tensor(x_test, dtype=torch.float32)

            Xtrain = Xtrain.cuda()
            Xtest = Xtest.cuda()

            # validation path
            save_cp_path = 'Checkpoint' + os.sep + dataset_sel + os.sep + model_name + os.sep + 'non_dec' + os.sep + 'transfer' + os.sep + \
                           'validation' + os.sep + 'inter' + os.sep + str(sub) + os.sep + 'val_sub_' + str(val_sub_index[0])

            pretrained = save_cp_path + os.sep + 'model_best.pth.tar'
            criterion = nn.CrossEntropyLoss().cuda()

            if pretrained:
                accs = []
                print('pretrained is True')
                if os.path.isfile(pretrained):
                    print("=> loading checkpoint '{}'".format(pretrained))
                    checkpoint = torch.load(pretrained, map_location="cpu")
                    model.load_state_dict(checkpoint['state_dict'])
                    print('loaded from epoch {}'.format(checkpoint['epoch']))
                    acc, _ = validate(test_loader, model, criterion)
                    accs.append(acc.item())
                else:
                    raise Exception('pretrained path error: {}'.format(pretrained))

            # feature
            model.eval()
            with torch.no_grad():
                _ = model(Xtrain)
                X_train = model.feature
                Xtrain = np.array(X_train.cpu())
                _ = model(Xtest)
                X_test = model.feature
                Xtest = np.array(X_test.cpu())




            ############ edrvfl ###########

            for ii, hp in enumerate(hyper_p):
                norm_coef = hp[0]

                min_x = np.min(Xtrain)
                max_x = np.max(Xtrain)
                X_train = ((Xtrain - min_x) / (max_x - min_x)) * 2 * norm_coef - norm_coef
                X_test = ((Xtest - min_x) / (max_x - min_x)) * 2 * norm_coef - norm_coef

                RF = RVFLClassifier(X_train, y_train, X_test, y_test)
                acc_local, acc_entropy = RF.EdRVFL_predict(hp, val_state=True)
                if nl <= 3:
                    loss[i, ii] = acc_local
                else:
                    loss[i, ii] = acc_entropy

                print('sub: {}, val_sub: {} edrvfl accuracy for norm_coef: {}, H: {}, reg:{}, global_reg: {}, final_feat:{}, weight_r: {}, entro_num: {} '
                      'is {}'.format(sub, val_sub, hp[0], hp[3], hp[4], hp[8], hp[6], hp[7], hp[9], acc_local))

        loss_result = np.mean(loss, axis=0).tolist()
        index = loss_result.index(max(loss_result))
        b_acc = loss_result[index]

        print(f'####################### sub {str(sub)} best val acc: {str(b_acc)} #################################')
        bh = hyper_p[index]
        print(f'####################### sub {str(sub)} best hyper: {str(bh)} #################################')
    return bh


if __name__ == '__main__':

########## rvfl cv ##############
    num_layer = 4
    fold = 10

    pred_set = []
    y_test_set = []
    cnn_accu_0_set = np.zeros((11, 1))
    edRVFL_accu_set = np.zeros((11, 1))
    edRVFL_accu_entropy_set = np.zeros((11, 1))

    for sub in range(1, 12):
        print('sub: {}'.format(sub))

        # training
        bh = rvfl_CV(sub=sub, fold=fold)

        # save best hyperparameter for each subject
        np.save(f'hyper/drivedata_best_hyper_sub_{str(sub)}.npy', bh)

        # testing
        edrvfl_accu_0, edrvfl_accu, entropy_ensemble_accu, y_test, pred = main_work_rvfl(sub, bh)
        pred_set = pred_set + pred
        y_test_set = y_test_set + y_test
        cnn_accu_0_set[sub-1, 0] = edrvfl_accu_0
        edRVFL_accu_set[sub-1, 0] = edrvfl_accu
        edRVFL_accu_entropy_set[sub-1, 0] = entropy_ensemble_accu
        print(f'####################sub_{str(sub)}, test acc: {str(entropy_ensemble_accu)}####################')

    for i in range(11):
        print(cnn_accu_0_set[i][0])
    print('%.4f' % np.mean(cnn_accu_0_set))
    print('%.4f' % np.mean(edRVFL_accu_set))
    print('%.4f' % np.mean(edRVFL_accu_entropy_set))

    precise, recall, fscore, _ = precision_recall_fscore_support(y_test_set, pred_set)
    print('precise: {}, recall: {}, fscore: {}'.format(precise, recall, fscore))


