% -------- prejob20 --------
global x_k20
load x_k20