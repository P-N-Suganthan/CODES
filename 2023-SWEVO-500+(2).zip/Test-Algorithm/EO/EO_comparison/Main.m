%_________________________________________________________________________________
%  Equilibrium Optimizer source code (Developed in MATLAB R2015a)
%
%  programming: Afshin Faramarzi & Seyedali Mirjalili
%
%  e-Mail: afaramar@hawk.iit.edu, afshin.faramarzi@gmail.com
%          ali.mirjalili@gmail.com
%
%  paper:
%  A. Faramarzi, M. Heidarinejad, B. Stephens, S. Mirjalili, 
%  Equilibrium optimizer: A novel optimization algorithm
%  Knowledge-Based Systems
%  DOI: https://doi.org/10.1016/j.knosys.2019.105190
%____________________________________________________________________________________

% --------------------------------------------
% fobj = @YourCostFunction
% dim = number of your variables
% Max_iteration = maximum number of iterations
% Particles_no = number of particles (search agents)
% lb=[lb1,lb2,...,lbn] where lbn is the lower bound of variable n
% ub=[ub1,ub2,...,ubn] where ubn is the upper bound of variable n
% ---------------------------------------------------------


clear all
clc
% tic;

% Run_no=30;         % Number of independent runs 
Particles_no=31;   % Number of particles
% Max_iteration=500; % Maximum number of iterations
a1 = 1.9447;
a2 = 0.9502;
GP = 0.5871;
% Function_name=INSTANCE; 
num_problems = 30;
% functions = [1,3,8,11,18,21,22,26];
Final_results = zeros(num_problems,5);    %% to save the final results ����ķֱ���min(outcome),max(outcome),median(outcome), mean(outcome),std(outcome)
Run_no = 1;
% dim = 30;
Outcomes = zeros(num_problems, Run_no);

base_folder = 'E:\̨ʽ��������\MZQ\ʵ����\Test-Algorithm\EO\EO_comparison';

for dim = [10, 30, 50]
    iteration_result = [];
    Final_results =[];
    Outcomes = [];
for fobj = 1 : num_problems
% [lb,ub,dim,fobj]=Get_Functions_details(Function_name);
    [Convergence_curve,outcome]=EO(fobj,Particles_no,a1,a2,GP,Run_no,dim);
    
    iteration_result (fobj,:) = Convergence_curve;
    Final_results(fobj, : ) = [min(outcome),max(outcome),median(outcome), mean(outcome),std(outcome)];
    Outcomes(fobj, : ) = outcome;
    fobj
    
end
folder_name = [num2str(dim) 'D_Convergence_curve.txt'];
address = [base_folder '\' folder_name];
save(address,'iteration_result', '-ascii');
end



% save 'F:\̨ʽ��������\MZQ\�����ļ�\comparision\Fifteen algorithms\Test-Algorithm\EO\EO_comparison\30D_Convergence_curve.txt' -ascii  iteration_result
% save 'H:\MZQ\�����ļ�\comparision\Fifteen algorithms\Test-Algorithm\EO\EO_comparison\30D_shiftOutcome_TenTimes.txt' -ascii  Outcomes
% save 'H:\MZQ\�����ļ�\comparision\Fifteen algorithms\Test-Algorithm\EO\EO_comparison\30D_shiftFinal_result.txt' -ascii  Final_results

% display(['The average objective function is : ', num2str(Ave,7)]);
% display(['The standard deviation is : ', num2str(Sd,7)]);
% xlswrite('H:\MZQ\�����ļ�\comparision\Fifteen algorithms\Test-Algorithm\EO\EO_comparison\Final_results.xlsx', Final_results);
% fid=fopen('Result.txt','wt');
% fprintf(fid,'%g\n',Final_results);
% fclose(fid);
% toc;
        