%% IMFO

% function Main(N,b, perc_iterat)

% https://doi.org/10.1016/j.knosys.2019.105277 (paper)

%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
clc;
clear all;
N = 118;
b = 4;
perc_iterat = 0.2963;

fhd = @cec17_func;
lb = -100;
ub = 100;
% dim = 10;
% maxFES = 100000 * dim;
% Max_iteration = round(maxFES / N );  %%% ���������� = FES / ��Ⱥ��ģ
runmax  = 1;
num_problems = 30; 
% functions = [3,5,11,15,24,29];
Final_results = zeros(num_problems,5);    %% to save the final results ����ķֱ���min(outcome),max(outcome),median(outcome), mean(outcome),std(outcome)
Outcomes = zeros(num_problems, runmax);

base_folder = 'C:\Users\84133mma\OneDrive - Erasmus University Rotterdam\Desktop\Fifteen algorithms\Test-Algorithm\IMFO\IMFO_comperison';


for dim = [30, 50]

iteration_result = [];
Final_results =[];
Outcomes = [];
maxFES = 100000 * dim;
Max_iteration = round(maxFES / N );  %%% ���������� = FES / ��Ⱥ��ģ
FM = [];
    
for function_number = 1 : num_problems
    
optimum = function_number * 100.0;
buffer = [];
for irun = 1 : runmax
    
%Initialize the positions of moths
Moth_pos=initialization(N,dim,ub,lb);
% Check if moths go out of the search space and bring it back
   
for i=1:N
        Flag4ub=Moth_pos(i,:)>ub;
        Flag4lb=Moth_pos(i,:)<lb;
        Moth_pos(i,:)=(Moth_pos(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;  
        
        % Calculate the fitness of moths
        Moth_fitness(1,i)= feval(fhd,Moth_pos(i,:)',function_number);        
end

% At early, Moth_pos, P and F are the same
P=Moth_pos;
F=P;
% same situation for the fitness
P_fitness=Moth_fitness;
F_fitness=Moth_fitness;

%compute the best fitness of moths
[fit_Mbest,I]=min(Moth_fitness);
%compute best moth
M_best=Moth_pos(I(1),:);

%variable for plot
Convergence_curve=zeros(1,Max_iteration);

%iteratons number initialization
Iteration=1;

%crossover rate setting
% CR=0.5;  
% t1=200;
% t2=200;
cr_min=0.55;
cr_max=0.65;

    while Iteration<Max_iteration+1

        CR=cr_max-(cr_max-cr_min)*Iteration/Max_iteration;           

        for i=1:N

            %create P
            %generate randomly g1,g2,g3
            g=randperm(N);
            %to avoid that i can be equal to g1,g2,g3
            g(g==i)=[];

            %mutation
            %generate the i-th flame                

            FM(i,:)=M_best(1,:)+rand()*(P(g(1),:)-P(g(2),:))+rand()*(P(g(3),:)-P(g(4),:)); %X_best double random        

            %check if we are out of search space 
            Flag4ub=FM(i,:)>ub;
            Flag4lb=FM(i,:)<lb;
            FM(i,:)=(FM(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;

            %crossover        
            %dynamic crossover rate computation                                      
            %random generation of a j dimension (j lies in [1,dim]) 
            j_rand=randperm(dim);

            for j=1:dim
                if((rand()>CR) && (j~=j_rand(1)))
                    FC(i,j)=P(i,j);
                else
                    FC(i,j)=FM(i,j);            
                end                        
            end

            %calculate the fitness of FC
            FC_fitness(1,i)=feval(fhd,FC(i,:)',function_number);
           
            %calculate the fitness of F
            F_fitness(1,i)=feval(fhd,F(i,:)',function_number);
           


            if(FC_fitness(1,i)<F_fitness(1,i))
                F(i,:)=FC(i,:);
                F_fitness(1,i)=FC_fitness(1,i);
                if (F_fitness(1,i)<fit_Mbest)
                    M_best=F(i,:);
                    fit_Mbest=feval(fhd,F(i,:)',function_number);
                  
                end
            end                
        end
%         perc_iterat=0.5; %% ���ڲ���
        delta_k=Max_iteration*perc_iterat;
        % a linearly dicreases from -1 to -2 to calculate t in Eq. (3.12)
        a=-1+Iteration*((-1)/Max_iteration); % r in the paper                

        if(Iteration<delta_k)
            %linear

%             b=1;     %%%%% ���ڲ���             
            t=(a-1)*rand+1;
            for i=1:N
                for j=1:dim            
                    distance_to_flame=abs(Moth_pos(i,j)-F(i,j));            
                    Moth_pos(i,j)=distance_to_flame*exp(b.*t).*cos(t.*2*pi)+F(i,j);                                
                end
                Flag4ub=Moth_pos(i,:)>ub;
                Flag4lb=Moth_pos(i,:)<lb;
                Moth_pos(i,:)=(Moth_pos(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;            
            end
        elseif (Iteration>=delta_k && Iteration<600)

            b=1;         %%%%% ���ڲ���        
            t=(a-1)*rand+1;

            for i=1:N
                w=abs(fit_Mbest/Moth_fitness(1,i));
                for j=1:dim            
                    distance_to_flame=abs(Moth_pos(i,j)-F(i,j));            
                    Moth_pos(i,j)=distance_to_flame*exp(b.*t).*cos(t.*2*pi)+w*F(i,j)+(1-w)*M_best(1,j);                                
                end
                Flag4ub=Moth_pos(i,:)>ub;
                Flag4lb=Moth_pos(i,:)<lb;
                Moth_pos(i,:)=(Moth_pos(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;            
            end


        else

            GEF=[];

            %sigma=0.15;


            %random
            sigma=0.1+rand()*0.15;

            %dynamic        
            phi=ceil(sigma*N);
            eta=rem(N,phi);
            delta=(N-eta)/phi;        

            for i=1:N                            
                F_fitness(1,i)=feval(fhd,F(i,:)',function_number);
                                                                
            end

            [fit_sort, pos]=sort(F_fitness(1,:));

            SF=F(pos,:);
            EF=SF(1:phi,:);

            for i=1:delta
                GEF=[GEF; EF];
            end

            GEF(delta*phi+1:N,:)=SF(1:eta,:);



            b=1;                
            t=(a-1)*rand+1;
            for i=1:N
                for j=1:dim            
                    distance_to_flame=abs(Moth_pos(i,j)-GEF(i,j));            
                    Moth_pos(i,j)=distance_to_flame*exp(b.*t).*cos(t.*2*pi)+GEF(i,j);
                end
                Flag4ub=Moth_pos(i,:)>ub;
                Flag4lb=Moth_pos(i,:)<lb;
                Moth_pos(i,:)=(Moth_pos(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
            end

        end

        for i=1:N

                Moth_fitness(1,i)=feval(fhd,Moth_pos(i,:)',function_number);
                
                P_fitness(1,i)=feval(fhd,P(i,:)',function_number);
                

                if (Moth_fitness(1,i)<P_fitness(1,i))
                    P(i,:)=Moth_pos(i,:);
                    P_fitness(1,i)=Moth_fitness(1,i);
                end

                if(P_fitness(1,i)<fit_Mbest)
                    M_best=P(i,:);
                    fit_Mbest=P_fitness(1,i);                
                end


        end   
    Convergence_curve(Iteration) =  fit_Mbest;
    Iteration=Iteration+1;
    
    end
    irun;
    buffer(irun) = fit_Mbest;
    
end
iteration_result(function_number, :) = Convergence_curve;
outcome = abs(buffer - optimum);
Final_results(function_number, : ) = [min(outcome),max(outcome),median(outcome), mean(outcome),std(outcome)];
Outcomes(function_number, : ) = outcome;
function_number
end

folder_name = [num2str(dim) 'D_Convergence_curve.txt'];
address = [base_folder '\' folder_name];
save(address,'iteration_result', '-ascii');

% save 'G:\̨ʽ��������\MZQ\�����ļ�\comparision\Fifteen algorithms\Test-Algorithm\IMFO\IMFO_comperison\10D_Convergence_curve.txt' -ascii  iteration_result
end
% save 'H:\MZQ\�����ļ�\comparision\Fifteen algorithms\Test-Algorithm\IMFO\IMFO_comperison\30D_shiftOutcome_TenTimes.txt' -ascii  Outcomes
% save 'H:\MZQ\�����ļ�\comparision\Fifteen algorithms\Test-Algorithm\IMFO\IMFO_comperison\30D_shiftFinal_result.txt' -ascii  Final_results


% Result = Results';
% save 'C:\Users\admin\Desktop\comparision\Fifteen algorithms\Test-Algorithm\IMFO\CEC2017_tuning\parameters-test\auto3_Result.txt' -ascii Result
% fid=fopen('Result.txt','wt');
% fprintf(fid,'%g\n',fit_Mbest);
% fclose(fid);

