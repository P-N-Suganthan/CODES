%% Global-best brain storm optimization (GBSO) algorithm
%% testing parameters efficiency
% function Main(PopSize,n_c, prob_one_cluster,prob_one_center,prob_two_center,Discard_Interval,F)

clc
clear all
fhd = @cec17_func;
lb = -100;
ub = 100;
Dim = 10;
MaxFEVs = 10000 * Dim;
runmax  = 1;

PopSize = 35;  %% to be adjusted in irace
n_c = 5;
prob_one_cluster =  0.0587;
prob_one_center =  0.513;
prob_two_center = 0.647;
Discard_Interval = 12;
F = 0.3234;

num_problems = 6;
functions = [3,5,11,15,24,29];
Final_results = zeros(num_problems,5);    %% to save the final results ����ķֱ���min(outcome),max(outcome),median(outcome), mean(outcome),std(outcome)
Outcomes = zeros(num_problems, runmax);

DimSize = Dim;

bias = 0;

rang_r=ub;%100;
rang_l=lb;%-100;
    


maxFES  = MaxFEVs;
genmax  = maxFES / PopSize;


% prob_one_cluster = 0.8;  %% to be adjusted in irace
% prob_one_center = 0.4;   %% to be adjusted in irace
% prob_two_center = 0.5;   %% to be adjusted in irace
% 
% 
% n_c = 5;   %% number of cluster %% to be adjusted in irace

% C = 1;
Cmin = 0.2;
Cmax = 0.8;
% F = 0.5;  %% to be adjusted in irace
% Discard_Interval = 10;    %% to be adjusted in irace
Step = (rang_r - rang_l)/20;

for function_number = functions

optimum = function_number * 100.0;
buffer = [];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for run=1:runmax
    FES = 0;
    
    Stagnation = 0;
    
    popu = rang_l + (rang_r - rang_l) * rand(PopSize,DimSize); 
    best = ones(n_c,1); 
    centers = zeros(n_c,DimSize); 
    Limits = zeros(PopSize,1);
    
    indi_temp = zeros(PopSize,DimSize);  
    
    fitness_popu = feval(fhd,popu',function_number);
    fitness_popu = fitness_popu';
    
    FES = FES + PopSize;

    [BestFit, minindex] = min(fitness_popu);
    BestIdea = popu(minindex,:);
    
    gen = 1;  
    RunBest(run,gen) = BestFit;
    
    while(FES<=maxFES)
       gen = gen + 1; 
        
       
       % Fitness-based Grouping
       group = {};
       fit_values = zeros(n_c,1);  
       [fitness_popu,Indices] = sort(fitness_popu);
       popu = popu(Indices,:);
       Limits = Limits(Indices,:);
       subgroup = PopSize / n_c;
       for idx = 1 : n_c
           index = idx : n_c : PopSize;
           group = {group{1:end} index};
           centers(idx,:) = popu(idx,:);
           fit_values(idx,1) = fitness_popu(idx,1);
       end
       

    % assign a initial big fitness value  as best fitness for each cluster in minimization problems    
    fit_values = Inf*ones(n_c,1); 
    
           
    for idx = 1:n_c
        % find the best individual in each group
        for idy=1:subgroup
          if fit_values(idx,1) > fitness_popu(group{idx}(idy),1)  % minimization
              fit_values(idx,1) = fitness_popu(group{idx}(idy),1);
              best(idx,1) = group{idx}(idy);
          end    
        end        
        % record the best individual in each group
        centers(idx,:) = popu(best(idx,1),:);        
    end
          
    %Generating new idea according to one or two grouping
    % One problem variable at a time
    indi_temp = popu;
    C = Cmin + ((Cmax-Cmin)/genmax)*gen;
    %indi_temp = zeros(PopSize,DimSize);
    for i=1:PopSize
        Attractor = zeros(1,DimSize);
        
            for j=1:DimSize
                r_1 = rand;  % probability for   select one cluster to form new individual
                %prob_one_cluster = prob_one_cluster_min + ((prob_one_cluster_max-prob_one_cluster_min)/genmax)*gen;
                if r_1 < prob_one_cluster % select one cluster
                    %Attractor(j) = indi_temp(i,j);
                    r = rand;
                    idx = ceil(rand * n_c);
                        if r < prob_one_center  % use the center
                           Attractor(j) = centers(idx,j);
                        else % use one randomly selected  cluster
                           idy=ceil(rand * subgroup);
                           while(idy==1)
                               idy=ceil(rand * subgroup);
                           end
                           Attractor(j) = popu(group{idx}(idy),j);
                        end                  
                else
                    % select two clusters
                    % pick two clusters 
                    % make sure two clusters are different
                    % make sure selected members are not centers
                    idx1 = ceil(rand * n_c);
                    idy1 = ceil(rand * subgroup);
                    while(idy1==1)
                       idy1=ceil(rand * subgroup);
                    end
                    indi_1 = group{idx1}(idy1);

                    idx2 = ceil(rand * n_c);
                    while(idx2==idx1)
                       idx2=ceil(rand * n_c);
                    end
                    idy2 = ceil(rand * subgroup);
                    while(idy2==1)
                       idy2=ceil(rand * subgroup);
                    end
                    indi_2 = group{idx2}(idy2);

                    tem = rand;
                    if rand < prob_two_center %use center
                        Attractor(j) = (1-tem) * centers(idx1,j) + tem * centers(idx2,j);
                    else   % use randomly selected individuals from each cluster            
                        Attractor(j) = (1-tem) * popu(indi_1,j) + tem *  popu(indi_2,j);
                    end
                end 
            end
         
            % Origianl
	    indi_temp(i,:) = Attractor;
            
            
            % Move Towards Global Best
            if(rand<C)
                indi_temp(i,:) = indi_temp(i,:) + C .* rand(1,DimSize) .* (BestIdea - indi_temp(i,:));
            end                               


            stepSize = exp(1-genmax/(genmax+1-gen)) * rand(1,DimSize) * Step;                
            indi_temp(i,:) = indi_temp(i,:) + stepSize .* normrnd(0,1,1,DimSize);   
            
             %if (ObjFun~=7)&&(ObjFun~=25)
                %for jj=1:DimSize
                  %indi_temp(i,j) = max(indi_temp(i,j),rang_l);   
                  %indi_temp(i,j) = min(indi_temp(i,j),rang_r); 
                  indi_temp(i,:) = max(indi_temp(i,:),rang_l);   
                  indi_temp(i,:) = min(indi_temp(i,:),rang_r); 
                %end   
             %end
             
        %end
    end
       
    fv = feval(fhd,indi_temp',function_number);
    fv = fv';
    FES = FES + PopSize;
    [fitness_popu,I] = min([fitness_popu,fv],[],2);
    popu(I==2,:) = indi_temp(I==2,:);
    Limits(I==2) = 0;
    Limits(I==1) = Limits(I==1) + 1;

    [IterBestFit,minindex] = min(fitness_popu);
    if(IterBestFit<BestFit)
        BestFit = IterBestFit;
        BestIdea = popu(minindex,:);
        %Stagnation = 0;
    %else
        %Stagnation = Stagnation + PopSize;
    end
    RunBest(run,gen) = BestFit;

    
    % Discard stagnated ideas
    Indices = find(Limits>Discard_Interval);
    if(length(Indices)>0)
        for idea = 1 : length(Indices)
            Index = Indices(idea);
            
            if(rand<0.5)
                idx1 = ceil(rand() * PopSize);
                while(idx1==Index)
                    idx1 = ceil(rand() * PopSize);
                end
                idx2 = ceil(rand() * PopSize);
                while((idx2==idx1)||(idx2==Index))
                    idx2 = ceil(rand() * PopSize);
                end
                idx3 = ceil(rand() * PopSize);
                while((idx3==idx2)||(idx3==idx1)||(idx3==Index))
                    idx3 = ceil(rand() * PopSize);
                end
                popu(Index,:) = popu(idx1,:) + F * (popu(idx2,:) - popu(idx3,:));
                
                popu(Index,:) = max(popu(Index,:),rang_l);   
                popu(Index,:) = min(popu(Index,:),rang_r); 
            else
                popu(Index,:) = rang_l + (rang_r - rang_l) * rand(1,DimSize);
            end
        end
        fitness_popu(Indices,:) = feval(fhd,popu(Indices,:)',function_number);
        Limits(Indices) = 0;
        FES = FES + length(Indices);
    end
   
    end
    run;
    buffer(run) = BestFit;
end

% for i = 1: runmax
%     buffer = [];
%     buffer = RunBest(i,:);
%     buffer(find(buffer == 0))=[];
%     best_buffer(i) = min(buffer);
% end
RunBest = RunBest;
iteration_result(find(functions == function_number),1:length(RunBest)) = RunBest;
outcome =abs(buffer - optimum);
Final_results(function_number, : ) = [min(outcome),max(outcome),median(outcome), mean(outcome),std(outcome)];
Outcome(function_number, : ) = outcome;

% Results(function_number) = mean(buffer);
function_number
% fid=fopen('Result.txt','wt');
% fprintf(fid,'%g\n',Results);
% fclose(fid);
end


save 'G:\̨ʽ��������\MZQ\�����ļ�\comparision\Fifteen algorithms\Test-Algorithm\GBSO\GBSO_comparison\10D_Convergence_curve.txt' -ascii  iteration_result
% save 'H:\MZQ\�����ļ�\comparision\Fifteen algorithms\Test-Algorithm\GBSO\GBSO_comparison\30D_shiftOutcome_TenTimes.txt' -ascii  Outcome
% save 'H:\MZQ\�����ļ�\comparision\Fifteen algorithms\Test-Algorithm\GBSO\GBSO_comparison\30D_shiftFinal_result.txt' -ascii  Final_results

% fid=fopen('Result.txt','wt');
% fprintf(fid,'%g\n',Results);
% fclose(fid);