% Please cite the following paper
%Luo Jie, Chen Huiling et al. An improved grasshopper optimization algorithm with application to financial stress prediction. Applied Mathematical Modelling, 2018, 64: 654-668.

clc;
clear all;
% function Main(N)
N = 30; %%% ��Ⱥ����
fhd = @cec17_func;
% lb = -100;
% ub = 100;
% dim = 10;
% maxFES = 10000 * dim;
% Max_iter = round(maxFES / N );  %%% ���������� = FES / ��Ⱥ��ģ
runmax  = 1;
num_problems = 30; %%% ���Ժ�������
% functions = [3,5,11,15,24,29];
Final_results = zeros(num_problems,5);    %% to save the final results ����ķֱ���min(outcome),max(outcome),median(outcome), mean(outcome),std(outcome)
Outcomes = zeros(num_problems, runmax);

base_folder = 'C:\Users\84133mma\OneDrive - Erasmus University Rotterdam\Desktop\Fifteen algorithms\Test-Algorithm\IGOA\IGOA_comparison';

for dim = [50]

iteration_result = [];
Final_results =[];
Outcomes = [];
maxFES = 10000 * dim;
Max_iter = round(maxFES / N );  %%% ���������� = FES / ��Ⱥ��ģ

Sorted_grasshopper = [];
    
for function_number = 1 : num_problems
    
optimum = function_number * 100.0;


buffer = [];

for irun = 1: runmax
lb = -100;
ub = 100;    
flag=0;
if size(ub,1)==1
    ub=ones(1,dim).*ub;
    lb=ones(1,dim).*lb;
end
if (rem(dim,2)~=0) % this algorithm should be run with a even number of variables. This line is to handle odd number of variables
    dim = dim+1;
    ub = [ub,100];
    lb = [lb,-100];
    flag=1;
end
%Initialize the population of grasshoppers
GrassHopperPositions=initialization(N,dim,ub,lb);
GrassHopperFitness = zeros(1,N);
ub=ub';
lb=lb';

fitness_history=zeros(N,Max_iter);
position_history=zeros(N,Max_iter,dim);
Convergence_curve=zeros(1,Max_iter);
Trajectories=zeros(N,Max_iter);

cMax=1;
cMin=0.00004;
%Calculate the fitness of initial grasshoppers

for i=1:size(GrassHopperPositions,1)
    if flag == 1
        GrassHopperFitness(1,i)=feval(fhd,GrassHopperPositions(i,1:end-1)',function_number);
        
    else
        GrassHopperFitness(1,i)=feval(fhd,GrassHopperPositions(i,:)',function_number);
        
    end
    fitness_history(i,1)=GrassHopperFitness(1,i);
    position_history(i,1,:)=GrassHopperPositions(i,:);
    Trajectories(:,1)=GrassHopperPositions(:,1);
end

[sorted_fitness,sorted_indexes]=sort(GrassHopperFitness);

% Find the best grasshopper (target) in the first population 
for newindex=1:N
    Sorted_grasshopper(newindex,:)=GrassHopperPositions(sorted_indexes(newindex),:);
end

TargetPosition=Sorted_grasshopper(1,:);
TargetFitness=sorted_fitness(1);
% Main loop
    l=2; % Start from the second iteration since the first iteration was dedicated to calculating the fitness of antlions
    while l<Max_iter+1

        c=cMax-l*((cMax-cMin)/Max_iter); % Eq. (2.8) in the paper
        S_i_total = [];
        for i=1:size(GrassHopperPositions,1)
            temp= GrassHopperPositions';
            for k=1:2:dim
                S_i=zeros(2,1);
                for j=1:N
                    if i~=j
                        Dist=distance(temp(k:k+1,j), temp(k:k+1,i)); % Calculate the distance between two grasshoppers

                        r_ij_vec=(temp(k:k+1,j)-temp(k:k+1,i))/(Dist+eps); % xj-xi/dij in Eq. (2.7)
                        xj_xi=2+rem(Dist,2); % |xjd - xid| in Eq. (2.7) 

                        s_ij=((ub(k:k+1) - lb(k:k+1))*c/2)*S_func(xj_xi).*r_ij_vec; % The first part inside the big bracket in Eq. (2.7)
                        S_i=S_i+s_ij;
                    end
                end
                S_i_total(k:k+1, :) = S_i;

            end

            X_new = c * S_i_total'.*randn(1,dim)+ (TargetPosition); % Eq. (2.7) in the paper
            Tp=X_new>ub';
            Tm=X_new<lb';
            X_new=(X_new.*(~(Tp+Tm)))+ub'.*Tp+lb'.*Tm;

            X_LevyPos=X_new+rand(1,dim).*Levy(dim);
            Tp=X_LevyPos>ub';
            Tm=X_LevyPos<lb';
            X_LevyPos=(X_LevyPos.*(~(Tp+Tm)))+ub'.*Tp+lb'.*Tm;

            if flag == 1
                levyFitness=feval(fhd,X_LevyPos(1:end-1)',function_number);
               
                newFitness=feval(fhd,X_new(1:end-1)',function_number);
                
            else
                levyFitness=feval(fhd,X_LevyPos',function_number);
               
                newFitness=feval(fhd,X_new',function_number);
                
            end
            if levyFitness<newFitness
                X_new=X_LevyPos;
            end   
            GrassHopperPositions_temp(i,:) = X_new'; 
        end
        % GrassHopperPositions
        GrassHopperPositions=GrassHopperPositions_temp;

        for i=1:size(GrassHopperPositions,1)
            % Relocate grasshoppers that go outside the search space 
            Tp=GrassHopperPositions(i,:)>ub';
            Tm=GrassHopperPositions(i,:)<lb';
            GrassHopperPositions(i,:)=(GrassHopperPositions(i,:).*(~(Tp+Tm)))+ub'.*Tp+lb'.*Tm;

            % Calculating the objective values for all grasshoppers
            if flag == 1
                GrassHopperFitness(1,i)=feval(fhd,GrassHopperPositions(i,1:end-1)',function_number);
               
            else
                GrassHopperFitness(1,i)=feval(fhd,GrassHopperPositions(i,:)',function_number);
                
            end
            fitness_history(i,l)=GrassHopperFitness(1,i);
            position_history(i,l,:)=GrassHopperPositions(i,:);

            Trajectories(:,l)=GrassHopperPositions(:,1);

            % Update the target
            if GrassHopperFitness(1,i)<TargetFitness
                TargetPosition=GrassHopperPositions(i,:);
                TargetFitness=GrassHopperFitness(1,i);
            end
        end
            %% opposition based part

        for i=1:size(GrassHopperPositions,1)
            Oppositions(i,:)=lb'+ub'-TargetPosition+rand.*(TargetPosition-GrassHopperPositions(i,:));
            % Calculate objective function for each search agent
            Flag4ub=Oppositions(i,:)>ub';
            Flag4lb=Oppositions(i,:)<lb';
            Oppositions(i,:)=(Oppositions(i,:).*(~(Flag4ub+Flag4lb)))+ub'.*Flag4ub+lb'.*Flag4lb;

            if flag == 1
                oppofitness(i)=feval(fhd,Oppositions(i,1:end-1)',function_number);
                
            else
                oppofitness(i)=feval(fhd,Oppositions(i,:)',function_number);
               
            end

            betterfitness=oppofitness(i);
            betterPos=Oppositions(i,:);

            % Update Alpha, Beta, and Delta
            if betterfitness<TargetFitness
                TargetFitness=betterfitness; % Update alpha
                TargetPosition=betterPos;
            end
        end

        AllPositions=[GrassHopperPositions;Oppositions];
        AllFitness=[GrassHopperFitness;oppofitness];
        % sort gwo
        [~,Index]=sort(AllFitness);
        %     [AllFitness,Index]=sort(AllFitness,'descend');

        AllPositions=AllPositions(Index,:);

        GrassHopperPositions=AllPositions(1:N,:);    
        Convergence_curve(l)=TargetFitness;

        l = l + 1;
    end
    Convergence_curve(1)=Convergence_curve(2);
    if (flag==1)
        TargetPosition = TargetPosition(1:dim-1);
    end
   buffer(irun) = TargetFitness;
   irun;
end
iteration_result(function_number, : ) = Convergence_curve;
outcome = abs(buffer - optimum);
Final_results(function_number, : ) = [min(outcome),max(outcome),median(outcome), mean(outcome),std(outcome)];
Outcomes(function_number, : ) = outcome;
function_number
end

folder_name = [num2str(dim) 'D_Convergence_curve.txt'];
address = [base_folder '\' folder_name];
save(address,'iteration_result', '-ascii');

end
% fid=fopen('Result.txt','wt');
% fprintf(fid,'%g\n',meanfitness);
% fclose(fid);
% Result = meanfitness';
% save 'H:\MZQ\�����ļ�\comparision\Fifteen algorithms\Test-Algorithm\IGOA\CEC2017_tuning\parameters-test\default_Result.txt' -ascii Result

% save 'G:\̨ʽ��������\MZQ\�����ļ�\comparision\Fifteen algorithms\Test-Algorithm\IGOA\IGOA_comparison\10D_Convergence_curve.txt' -ascii  iteration_result

% save 'H:\MZQ\�����ļ�\comparision\Fifteen algorithms\Test-Algorithm\IGOA\IGOA_comparison\10D_Outcome_TenTimes.txt' -ascii  Outcomes
% save 'H:\MZQ\�����ļ�\comparision\Fifteen algorithms\Test-Algorithm\IGOA\IGOA_comparison\10D_Final_result.txt' -ascii  Final_results



%% Functions called by IGOA
function Positions = initialization(SearchAgents_no, dim, ub, lb)

    Boundary_no = size(ub, 2); % numnber of boundaries
    % If the boundaries of all variables are equal and user enter 
    % a signle number for both ub and lb
    if Boundary_no == 1
        Positions = (ub - lb).*rand(SearchAgents_no, dim) + lb.*ones(SearchAgents_no, dim);
    end
    % If each variable has a different lb and ub
    if Boundary_no > 1
        for i = 1:dim
            ub_i = ub(i);
            lb_i = lb(i);
            Positions(:, i) = rand(SearchAgents_no, 1) .* (ub_i - lb_i) + lb_i;        
        end    
    end
end
function d = distance(a,b)
d=sqrt((a(1)-b(1))^2+(a(2)-b(2))^2);
end
function o=S_func(r)
f=0.5;
l=1.5;
o=f*exp(-r/l)-exp(-r);  % Eq. (2.3) in the paper
end
function o=Levy(d)
beta=3/2;
%Eq. (3.10)
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
u=randn(1,d)*sigma;
v=randn(1,d);
step=u./abs(v).^(1/beta);

% Eq. (3.9)
o=step;

end


