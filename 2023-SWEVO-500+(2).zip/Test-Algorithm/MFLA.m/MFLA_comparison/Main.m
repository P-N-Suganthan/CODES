% function Main(m,n,beta)
clc;
clear all;

m = 4;
n = 6;
beta = 0.5867;
fhd = @cec17_func;     

runnum=1;   %% ¶ÀÁ¢ÔËÐÐ10´Î
% m=5; 
% n=4;
q=m*n;    %% ÖÖÈº´óÐ¡
% beta=1.2;
% M=10;       %% Î¬¶È
% MAX_FES= M*1e4;
% Max_iteration = round(MAX_FES / q );
Dmin= -100;
Dmax =100;

num_problems = 30; 
% functions = [3,5,11,15,24,29];
Final_results = zeros(num_problems,5);    %% to save the final results ±£´æµÄ·Ö±ðÊÇmin(outcome),max(outcome),median(outcome), mean(outcome),std(outcome)
Outcomes = zeros(num_problems, runnum);

base_folder = 'F:\台式电脑资料\MZQ\桌面文件\comparision\Fifteen algorithms\Test-Algorithm\MFLA.m\MFLA_comparison';


for M = [10, 30, 50]

iteration_result = [];
Final_results =[];
Outcomes = [];
MAX_FES= M*1e4;
Max_iteration = round(MAX_FES / q ); 

frogA = [];
    
for func_num = 1 : num_problems

onebest=zeros(1,runnum);% 
allbest=zeros(runnum,Max_iteration);% Ã“Ã…Â½Ã¢

optimum = func_num * 100;
onebest = [];
   
for tdy=1:runnum
       
  FES=0;
  t1=clock; 
  rand('seed', sum(100*clock));   
  frog=struct('fitness',{},'center',{});
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
for i=1:q   
data=Dmin+(Dmax-Dmin).*rand(1,M);    
fitness= feval(fhd,data',func_num);

frog(i).fitness=fitness;
frog(i).center=data;
FES=FES+1;
 if i==1
       tempFrog=frog(1);
               
   end
           
           if frog(i).fitness< tempFrog.fitness
               tempFrog=frog(i);
             
           end
              allbest(tdy,FES)= tempFrog.fitness;
               
%               fprintf('MFLA(%d) =%g\n',FES,allbest(tdy,FES));

end
 

%%%%%%%%%%%%%%%%%
 
while FES<=Max_iteration%Â»Ã¬ÂºÃ�Ã…Ã…Ã�Ã²
    if  FES>Max_iteration
            break;
    end
  
    for i=1:q-1
        for j=1:q-i
            if frog(j).fitness < frog(j+1).fitness
                temp=frog(j+1).fitness;
                temp2=frog(j+1).center;

                 frog(j+1).fitness=frog(j).fitness;
                 frog(j+1).center=frog(j).center;

                 frog(j).center=temp2;
                 frog(j).fitness=temp;
            end 
        end
    end
  
    for ttt=1:m
        memory(ttt).center =zeros(size( frog(1).center,1),size( frog(1).center,2));
    end 
 

      
    for i=1:m
    
     %%%%%%%%%%%%%
        Xw= frog(i);
         XwNo=i;
          locXwNO=1;

         Xb= frog(i);
         XbNo=i;
         locXbNO=1;

         Xwb=frog(i);
          locMean=[];
          fitMeans=zeros(1,n);
               
            for tt=1:n
                  if  frog(i+m*(tt-1)).fitness<Xb.fitness
                      Xb=frog(i+m*(tt-1));
                       XbNo=i+m*(tt-1) ;
                      locXbNO=tt ;
                  end
                  if  frog(i+m*(tt-1)).fitness>Xw.fitness
                      Xw=frog(i+m*(tt-1));
                     XwNo=i+m*(tt-1) ;
                     locXwNO=tt;
                  end
                fitMeans(tt)=frog(i+m*(tt-1)).fitness;  
                 locMean=[locMean;
                               frog(i+m*(tt-1)).center];
            end
            
            w11=rand ;
             v11=rand ;
             Xwb.center=(w11/(w11+v11)).*Xb.center+(v11/(w11+v11)).*Xw.center;       
           
             for tt2=1:n     
                 dis(tt2)= norm(frog((i+m*(tt2-1))).center-frog(XbNo).center,2)^2 +eps;  
             end         
              
              %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%               temploc=locXbNO;
              temploc=locXwNO;
 
             [Mass]=massCalculation(fitMeans,1);
             
              tempDis= dis;
              tempDis([ temploc  ])=[];
              
              tempMass= Mass;
              tempMass([ temploc  ])=[];
                
              Gm= tempMass./tempDis;
              totalGm=sum(Gm);
              Gm=Gm./totalGm;
         
               tempLocalMeans= locMean;
               tempLocalMeans([ temploc  ],:)=[];
               
              mbest1=  sum(tempLocalMeans,1)/n ;
              mbest2=  sum(Gm'*ones(1,M).*tempLocalMeans,1) ;
                 
               sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
               u=randn(size(frog(1).center))*sigma;
              vw=randn(size(frog(1).center));
               step=u./abs(vw).^(1/beta)   ;
              stepsize=  rand  .*(randn) .*step; %levy Â·Ã‰Ã�Ã�Â²Â½Â³Â¤
               
              
                if rand<0.5 
                   mbest=  mbest1;
          
                else
                    mbest= mbest2;
                    
                end
                
                  temp=Xw.center;
              
                 temp= Xwb.center+rand* (stepsize.*mbest -frog((XwNo)).center)  ;
 
                temp(temp>Dmax)=Dmax;
                temp(temp<Dmin)=Dmin;
                           
                             
                 fitness =cec17_func(temp',func_num);
                 FES=FES+1;
                             
                  if  fitness <frog((XwNo)).fitness
                                 frog((XwNo)).center  = temp ;
                                 frog((XwNo)).fitness=fitness;
                 end
             % 
                   if  fitness< tempFrog.fitness    
                             tempFrog.center=temp;
                             tempFrog.fitness=fitness;
                   end                               
                 if  FES>Max_iteration
                            break;
                 end
                 allbest(tdy,FES)= tempFrog.fitness;
                              
%                 if mod(FES,2113)==0
%                                fprintf('MFLA(%d) =%g\n',FES,allbest(tdy,FES));
%                 end
                  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      
    end%m
 

%%
   %%
  for iii=1:q         
          frogA(iii,:)=frog(iii).center;    
  end
     map=zeros(q,M); % see Algorithm-2 in [1]         
  
  for i=1:q 
       u=randperm(M); 
       map(i,u(1:ceil(rand*M)))=1;
  end
      
   K=rand(size(frogA))>0 ;
   stepsize=  rand.*map.*  (frogA(randperm(q),:)-frogA(randperm(q),:));
  
  new_frogA=frogA+stepsize.* K;
  
    for jjj=1:q
       data=new_frogA(jjj,:);
       data(data>Dmax)=Dmax;
       data(data<Dmin)=Dmin;
       fitness=cec17_func(data',func_num);

       if fitness<frog(jjj).fitness
           frog(jjj).center=data;
           frog(jjj).fitness=fitness;   
       end  
         FES= FES+1;
         %Â¼Ã‡Ã‚Â¼ÃƒÂ¿Â¸Ã¶FESÃ—Ã®Â¼Ã‘ÃŠÃŠÃ“Â¦Â¶ÃˆÃ–Âµ

      if  fitness< tempFrog.fitness    
              tempFrog.center=data;
             tempFrog.fitness=fitness;
      end

       if  FES>Max_iteration
                        break;
          end
          allbest(tdy,FES)= tempFrog.fitness;
                            %Â³Ã‰Â¹Â¦Ã‚ÃŠ

%             if mod(FES,2113)==0
%                            fprintf('MFLA(%d) =%g\n',FES,allbest(tdy,FES));
%            end

             % 

    end
%          
%        



end%while
  
 etime(clock,t1) ;
 onebest(tdy)=allbest (tdy,Max_iteration);
 tdy;
end%tdy 
iteration_result (func_num, : ) = allbest;
outcome = onebest - optimum;
Final_results(func_num, : ) = [min(outcome),max(outcome),median(outcome), mean(outcome),std(outcome)];
Outcomes(func_num, : ) = outcome;
func_num
% fid=fopen('Result.txt','wt');
% fprintf(fid,'%g\n',BEST);
% fclose(fid);
end

folder_name = [num2str(M) 'D_Convergence_curve.txt'];
address = [base_folder '\' folder_name];
save(address,'iteration_result', '-ascii');

end

% save 'G:\Ì¨Ê½µçÄÔ×ÊÁÏ\MZQ\×ÀÃæÎÄ¼þ\comparision\Fifteen algorithms\Test-Algorithm\MFLA.m\MFLA_comparison\10D_Convergence_curve.txt' -ascii  iteration_result

% save 'H:\MZQ\×ÀÃæÎÄ¼þ\comparision\Fifteen algorithms\Test-Algorithm\MFLA.m\MFLA_comparison\30D_shiftOutcome_TenTimes.txt' -ascii  Outcomes
% save 'H:\MZQ\×ÀÃæÎÄ¼þ\comparision\Fifteen algorithms\Test-Algorithm\MFLA.m\MFLA_comparison\30D_shiftFinal_result.txt' -ascii  Final_results


% Result = BEST';
% save 'C:\Users\admin\Desktop\comparision\Fifteen algorithms\Test-Algorithm\MFLA.m\parameters-test\default_Result.txt' -ascii Result






% sbest(tdy)
function [M]=massCalculation(fit,min_flag)
%%%%here, make your own function of 'mass calculation'

Fmax=max(fit); Fmin=min(fit); Fmean=mean(fit); 
[i N]=size(fit);

if Fmax==Fmin
   M=ones(1,N);
else
    
   if min_flag==1 %for minimization
      best=Fmin;worst=Fmax; %eq.17-18.
   else %for maximization
      best=Fmax;worst=Fmin; %eq.19-20.
   end
  
   M=1*(fit-worst)./(best-worst)+0  ; %eq.15,

end

M=M./sum(M); %eq. 16.
end

 
 