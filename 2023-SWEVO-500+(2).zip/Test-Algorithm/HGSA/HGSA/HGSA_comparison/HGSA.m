
function [ best_buffer, Convergence_curve]=HGSA(N,G0,ElitistCheck,min_flag,Rpower,dim, F_index,Run_no)

%V:   Velocity.
%a:   Acceleration.
%M:   Mass.  Ma=Mp=Mi=M;
%dim: Dimension of the test function.
%N:   Number of agents.
%X:   Position of agents. dim-by-N matrix.
%R:   Distance between agents in search space.
%[low-up]: Allowable range for search space.
%Rnorm:  Norm in eq.8.
%Rpower: Power of R in eq.7.

 Rnorm=2; 
 
 low = -100;
 up = 100;
%  dim = 30;
 maxFES = 10000 * dim;
 max_it = round(maxFES / N) ;  %%% ���������� = FES / ��Ⱥ��ģ
%  Run_no = 1;
 fhd = @cec17_func;
 
%get allowable range and dimension of the test function.
% [low,up,dim]=test_functions_range(F_index);
alfa_min=10;
alfa_max=50;
% alfa=20; %% alfa decrease with t , this value don't using
% num_problems = 6;
% functions = [3,5,11,15,24,29];
% Final_results = zeros(num_problems,5);    %% to save the final results ����ķֱ���min(outcome),max(outcome),median(outcome), mean(outcome),std(outcome)
% Outcomes = zeros(num_problems, Run_no);

% for F_index = functions

optimum = F_index * 100.0;  %% ��������ֵ
Convergence_curve = [];
best_buffer = [];
for irun = 1:Run_no
%random initialization for agents.
X=initialization(dim,N,up,low);
%create the best so far chart and average fitnesses chart.
% BestChart=[];MeanChart=[];

V=zeros(N,dim);
a=zeros(N,dim);

    for iteration=1:max_it
    %     iteration


        %Checking allowable range. 
        X=space_bound(X,up,low); 


        %Evaluation of agents. 
%         fitness=evaluateF(X,F_index);   

        fitness = feval(fhd,X',F_index);

        %fitness_plot(iteration,:)=fitness;

        if min_flag==1
        [best best_X]=min(fitness); %minimization.

        else
        [best best_X]=max(fitness); %maximization.
        end        

        if iteration==1
           Fbest=best;Lbest=X(best_X,:);
        end
        if min_flag==1
          if best<Fbest  %minimization.
           Fbest=best;Lbest=X(best_X,:);
          end
        else 
          if best>Fbest  %maximization
           Fbest=best;Lbest=X(best_X,:);
          end
        end

%     BestChart=[BestChart Fbest];
%     MeanChart=[MeanChart mean(fitness)];



    %Calculation of M. eq.14-20
    [M]=massCalculation(fitness,min_flag); 

    alfa=(alfa_max-alfa_min)/sinh(2)*sinh(2*(iteration/max_it))+alfa_min;



    %Calculation of Gravitational constant. eq.13.
    G=Gconstant(G0,iteration,max_it,alfa); 




    [R_plot,a]=Gfield_pp(M,X,G,Rnorm,Rpower,ElitistCheck,iteration,max_it);




    [X,V]=move_sinh(X,a,V,iteration,max_it,Lbest,dim,N);

    iteration;

    Convergence_curve (iteration) = Fbest;
    end %iteration
%     display(['Run no :', num2str(irun)]);
    best_buffer(irun) = Fbest;   
end
F_index

% end





