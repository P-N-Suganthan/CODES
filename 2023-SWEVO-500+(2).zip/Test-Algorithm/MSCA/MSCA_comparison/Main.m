%% obl+caushy mutation+ CLS +DE +SCA 2018.6.19
%% Chen H, Wang M, Zhao X. A multi-strategy enhanced sine cosine algorithm for global optimization and constrained practical engineering problems. Applied Mathematics and Computation, 2020, 369: 124872.
%% Max_iteration = 10000 * dim; �����ر���
% function Main(N, pCR, a, mu)

clc;
clear all;
N = 31;  %%% ��Ⱥ��ģ
pCR = 0.0319;
a = 1;
mu = 4;
addpath('C:\Users\84133mma\OneDrive - Erasmus University Rotterdam\Desktop\Fifteen algorithms\Test-Algorithm\MSCA\MSCA_comparison\cauchy');
fhd = @cec17_func;
lb = -100;
ub = 100;
% dim = 10;
% maxFES = 10000* dim;
% Max_iteration= round(maxFES / N);  %%% ���������� = FES / ��Ⱥ��ģ
runmax  = 1;
num_problems = 30; 
% functions = [3,5,11,15,24,29];
Final_results = zeros(num_problems,5);    %% to save the final results ����ķֱ���min(outcome),max(outcome),median(outcome), mean(outcome),std(outcome)
Outcomes = zeros(num_problems, runmax);

beta_min=0.2; % ���������½� Lower Bound of Scaling Factor
beta_max=0.8; % ���������Ͻ� Upper Bound of Scaling Factor

base_folder = 'C:\Users\84133mma\OneDrive - Erasmus University Rotterdam\Desktop\Fifteen algorithms\Test-Algorithm\MSCA\MSCA_comparison';

for dim = [50]
  
iteration_result = [];
Final_results =[];
Outcomes = [];    
maxFES = 10000* dim;
Max_iteration= round(maxFES / N);  %%% ���������� = FES / ��Ⱥ��ģ

ob_X = [];
X_meaution = [];  
    
for function_number = 1 : num_problems

    optimum = function_number * 100;
    buffer = [];
for irun = 1:runmax
% pCR=0.8; %  ������� Crossover Probability
VarSize=[1,dim];
%Initialize the set of random solutions
X=initialization(N,dim,ub,lb);
Destination_position=zeros(1,dim);
Destination_fitness=inf;
Convergence_curve=zeros(1,Max_iteration);
Objective_values = zeros(1,size(X,1));
% Calculate the fitness of the first set and find the best one
for i=1:size(X,1)
    Objective_values(1,i)=feval(fhd,X(i,:)',function_number);
    if i==1
        Destination_position=X(i,:);
        Destination_fitness=Objective_values(1,i);
    elseif Objective_values(1,i)<Destination_fitness
        Destination_position=X(i,:);
        Destination_fitness=Objective_values(1,i);
    end
    
    All_objective_values(1,i)=Objective_values(1,i);
end

    %Main loop
    t=2; % start from the second iteration since the first iteration was dedicated to calculating the fitness
    while t<=Max_iteration

        % Eq. (3.4)
%         a = 2;
        Max_iteration = Max_iteration;
        r1=a-t*((a)/Max_iteration); % r1 decreases linearly from a to 0

        % Update the position of solutions with respect to destination
        for i=1:size(X,1) % in i-th solution
            for j=1:size(X,2) % in j-th dimension

                % Update r2, r3, and r4 for Eq. (3.3)
                r2=(2*pi)*rand();
                r3=2*rand;
                r4=rand();

                % Eq. (3.3)
                if r4<0.5
                    % Eq. (3.1)
                    X(i,j)= X(i,j)+(r1*sin(r2)*abs(r3*Destination_position(j)-X(i,j)));
                else
                    % Eq. (3.2)
                    X(i,j)= X(i,j)+(r1*cos(r2)*abs(r3*Destination_position(j)-X(i,j)));
                end

            end
        end

    %     
    %    for i=1:size(X,1)
    %         r= cauchyrnd(0, 1, dim);
    %         t1=randperm(dim);
    %         cauchy=r(t1(1),:);
    %         X_meaution(i,:)=X(i,:)+rand(1,dim).*cauchy;
    %         
    %         f_X_meaution(1,i)=fobj(X_meaution(i,:));
    %         
    %         f_X(1,i)=fobj(X(i,:));
    %         if f_X_meaution(1,i)<f_X(1,i)
    %             X(i,:)=X_meaution(i,:);
    %         end
    %         
    %         if  f_X_meaution(1,i)<Destination_fitness
    %             Destination_position=X_meaution(i,:);
    %             Destination_fitness=f_X_meaution(1,i);
    %         end
    %         
    %       
    %     end

         %%%****OBL***%%%%
        for i=1:size(X,1)
        ob_X(i,:) = ub + lb - X(i,:);
    %     ob_X_fitness(i)=fobj(ob_X(i,:));
    %     X_fitness(i)=fobj(X(i,:));
        end
        X_combin=[ob_X;X];
        for i=1:size(X_combin,1)
        fitness_combin(i)=feval(fhd,X_combin(i,:)',function_number);
         
          if fitness_combin(i)<Destination_fitness
             Destination_position=X_combin(i,:);
             Destination_fitness=fitness_combin(i);
          end
        end
         [~,q] = sort(fitness_combin);

        for i = 1:N
            X(i,:) = X_combin(q(i),:);
        end  

        %%%%*****��������***%%%%%%
        for i=1:size(X,1)
            r= cauchyrnd(0, 1, dim);
            t1=randperm(dim);
            cauchy=r(t1(1),:);
            X_meaution(i,:)=X(i,:)+rand(1,dim).*cauchy;
    %         Flag4ub=X_meaution(i,:)>ub;
    %         Flag4lb=X_meaution(i,:)<lb;
    %         X_meaution(i,:)=(X_meaution(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
            f_X_meaution(1,i)=feval(fhd,X_meaution(i,:)',function_number);
            
            f_X(1,i)=feval(fhd,X(i,:)',function_number);
            
            if f_X_meaution(1,i)<f_X(1,i)
                X(i,:)=X_meaution(i,:);
            end
            if f_X_meaution(1,i)<Destination_fitness
                Destination_position=X_meaution(i,:);
                Destination_fitness=f_X_meaution(1,i); 
            end     
        end
        %%%����ֲ�����***%%%��
        setCan = (Max_iteration-t+1)/Max_iteration;
        x = rand();
        if(x~=0.25&&x~=0.5&&x~=0.75)
            ch(1) = x;
        end
        for ant=1:(N)
            ch(ant+1)=mu*ch(ant)*(1-ch(ant));  %% ���纯���Ķ�
            CH(ant,:) = lb+ch(ant)*(ub-lb);    %ub��
            V = (1-setCan)*Destination_position+setCan*CH(ant);
           % ObjValV=feval(objfun,V);         %���㺯��ֵ
             [FitnessV]=feval(fhd,V',function_number);
             buffer_fobjv(1,i) = feval(fhd,X(i,:)',function_number);%������Ӧ��ֵ
            if FitnessV<buffer_fobjv(1,i) 
                X(i,:)=V;
            end
            if (FitnessV<Destination_fitness)
                Destination_fitness = FitnessV;
                Destination_position = V;
                break;
            end
        end

        %%*****Muation-Crossover****%%%
         for i=1:1:size(X,1) % ����ÿ������
            x=X(i,:); % ��ȡ����λ��

            % ���ѡ�����������Ա�����ʹ��
            A=randperm(size(X,1)); % ����˳�������������
            A(A==i)=[]; % ��ǰ��������λ���ڿգ����������м���ʱ��ǰ���岻���룩
            a0=A(1);
            b=A(2);
            c=A(3);
            % ������� Mutation
            beta=unifrnd(beta_min,beta_max,VarSize); % ���������������
            y=X(a0)+beta.*(X(b)-X(c)); % �����м���
            % ��ֹ�м���Խ��
            y=max(y,lb);
            y=min(y,ub);
            % ������� Crossover
            z=zeros(size(x)); % ��ʼ��һ���¸���
            j0=randi([1,numel(x)]); % ����һ��α���������ѡȡ������ά�ȱ�ţ�����

            for j=1:numel(x) % ����ÿ��ά��
                if j==j0 || rand<=pCR % �����ǰά���Ǵ�����ά�Ȼ����������С�ڽ������
                    z(j)=y(j); % �¸��嵱ǰά��ֵ�����м����Ӧά��ֵ
                else
                    z(j)=x(j); % �¸��嵱ǰά��ֵ���ڵ�ǰ�����Ӧά��ֵ
                end
            end

            NewSol.Position=z; % �������֮��õ��¸���
            NewSol.Cost=feval(fhd,NewSol.Position',function_number);
            buffer_fobjx(1,i) = feval(fhd,X(i,:)',function_number); % �¸���Ŀ�꺯��ֵ
            if NewSol.Cost<buffer_fobjx(1,i) % ����¸������ڵ�ǰ����
               X(i,:)=NewSol.Position; % ���µ�ǰ����
    %             if pop(i).Cost<BestSol.Cost % �����ǰ���壨���º�ģ��������Ÿ���
    %                BestSol=pop(i); % �������Ÿ���
    %             end
            end
        end    
       %%*****Muation-Crossover****%%%


        for i=1:size(X,1)
            % Check if solutions go outside the search spaceand bring them back
            Flag4ub=X(i,:)>ub;
            Flag4lb=X(i,:)<lb;
            X(i,:)=(X(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;

            % Calculate the objective values
            Objective_values(1,i)=feval(fhd,X(i,:)',function_number);
            

            % Update the destination if there is a better solution
            if Objective_values(1,i)<Destination_fitness
                Destination_position=X(i,:);
                Destination_fitness=Objective_values(1,i);
            end
        end

        Convergence_curve(t)=Destination_fitness;

        % Increase the iteration counter
        t=t+1;
    end
     Convergence_curve(1)=Convergence_curve(2);
     buffer(irun) = Destination_fitness;
     irun;
end
iteration_result(function_number,  : ) = Convergence_curve;
outcome = abs(buffer - optimum);
Final_results(function_number, : ) = [min(outcome),max(outcome),median(outcome), mean(outcome),std(outcome)];
Outcomes(function_number, : ) = outcome;
function_number
end

folder_name = [num2str(dim) 'D_Convergence_curve.txt'];
address = [base_folder '\' folder_name];
save(address,'iteration_result', '-ascii');

end

% save 'G:\̨ʽ��������\MZQ\�����ļ�\comparision\Fifteen algorithms\Test-Algorithm\MSCA\MSCA_comparison\10D_Convergence_curve.txt' -ascii  iteration_result

% save 'H:\MZQ\�����ļ�\comparision\Fifteen algorithms\Test-Algorithm\MSCA\MSCA_comparison\50D_Outcome_TenTimes.txt' -ascii  Outcomes
% save 'H:\MZQ\�����ļ�\comparision\Fifteen algorithms\Test-Algorithm\MSCA\MSCA_comparison\50D_Final_result.txt' -ascii  Final_results

% Result = meanfitness';
% save 'H:\MZQ\�����ļ�\comparision\Fifteen algorithms\Test-Algorithm\MSCA\CEC2017_tuning\parameters-test\auto1_Result.txt' -ascii Result
% fid=fopen('Result.txt','wt');
% fprintf(fid,'%g\n',meanfitness);
% fclose(fid);

% function o=Levy(d)
% beta=1.5; 
% %Eq. (3.10)
% sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
% u=randn(1,d)*sigma;
% v=randn(1,d);
% step=u./abs(v).^(1/beta);
% % Eq. (3.9)
% o=step;
% end