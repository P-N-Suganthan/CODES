% -----------------------------------------------------------------
% Snap-drift Cuckoo Search (SDCS) algorithm by Hojjat Rakhshani and Amin Rahati
% University of Sistan and Baluchestan
% -----------------------------------------------------------------
% Paper -- Citation Details:
% 1) Rakhshani, Hojjat, and Amin Rahati. "Snap-drift cuckoo search:
% A novel cuckoo search optimization algorithm." 
% Applied Soft Computing (2016).

% 2) X.-S. Yang, S. Deb, Cuckoo search via Levy flights,
% in: Proc. of World Congress on Nature & Biologically Inspired
% Computing (NaBIC 2009), December 2009, India,
% IEEE Publications, USA,  pp. 210-214 (2009).
% http://arxiv.org/PS_cache/arxiv/pdf/1003/1003.1594v1.pdf 

% 3) X.-S. Yang, S. Deb, Engineering optimization by cuckoo search,
% Int. J. Mathematical Modelling and Numerical Optimisation, 
% Vol. 1, No. 4, 330-343 (2010). 
% http://arxiv.org/PS_cache/arxiv/pdf/1005/1005.2908v2.pdf
% ----------------------------------------------------------------%


% =============================================================== %
% Notes:                                                          %
% Different implementations may lead to slightly different        %
% behavour and/or results, but there is nothing wrong with it,    %
% as this is the nature of  all metaheuristics.                   %
% -----------------------------------------------------------------

% function [Final_results, Outcomes,iteration_result]=SDCS(n,pa,J,a0,MAX_iteration,nd,Lb,Ub)

% n=15; 
clc;
clear all;
Particals_n = 24;
n= Particals_n;
pa = 0.1854;
J = 0.9618;
a0 = 0.5973;

addpath('F:\台式电脑资料\MZQ\桌面文件\comparision\Fifteen algorithms\Test-Algorithm\SDCS\SDCS\Functions');
% DIM=10;
% lb = ones(1,DIM).* -100;
% ub = ones(1,DIM).* 100;
% func_evalutions = 10000 * DIM;
% MAX_iteration = round(func_evalutions/Particals_n);




Run_num = 1;
fhd = @cec17_func;

global Se;
% J=0.3;
Se=1;

num_problems = 30; 
% functions = [3,5,11,15,24,29];
Final_results = zeros(num_problems,5);    %% to save the final results ±£´æµÄ·Ö±ðÊÇmin(outcome),max(outcome),median(outcome), mean(outcome),std(outcome)
Outcomes = zeros(num_problems, Run_num);

base_folder = 'F:\台式电脑资料\MZQ\桌面文件\comparision\Fifteen algorithms\Test-Algorithm\SDCS\SDCS\Code\SDCS_comparison';

for DIM = [10, 30, 50] 

iteration_result = [];
Final_results =[];
Outcomes = []; 
Lb = ones(1,DIM).* -100;
Ub = ones(1,DIM).* 100;
func_evalutions = 10000 * DIM;
MAX_iteration = round(func_evalutions/Particals_n);
creatematrix(DIM);



for fobj = 1 : num_problems
optimum = fobj * 100;
fmin_buffer = [];
for irun = 1:Run_num
% Random initial solutions

nest = lhsdesign(n,DIM,'smooth','off','criterion','maximin','iterations',100);
for i=1:n,
nest(i,:)=Lb+(Ub-Lb).*nest(i,:);
end

% Get the current best
fitness=10^10*ones(n,1);
[fmin,bestnest,nest,fitness]=get_best_nest(fhd,fobj,nest,nest,fitness);

N_iter=1;
% pa=0.25;

%% Starting iterations

    while (N_iter<MAX_iteration)
        % Generate new solutions (but keep the current best)
         new_nest=get_cuckoos(nest,J,a0,Lb,Ub);   
         [fnew,best,nest,fitness]=get_best_nest(fhd,fobj,nest,new_nest,fitness);
        % Update the counter
%           N_iter=N_iter+1; 
        % Discovery and randomization
         new_nest=empty_nests(nest,J,Lb,Ub,pa);   

        % Evaluate this set of solutions
          [fnew,best,nest,fitness]=get_best_nest(fhd,fobj,nest,new_nest,fitness);
        % Update the counter again
%           N_iter=N_iter+1;
        % Find the best objective so far  
        if fnew<fmin,
            fmin=fnew;
        end

        % Update Pa according to the snap/drift mode

        Pm=Se/(2*n);  %% Pm is performence measure
        if (Pm<0.5)
            %snap mode
            pa=abs(Pm-0.005);
        else
            %drift mode
            pa=Pm+0.005;
        end
        pa=max(0,pa);
        pa=min(1,pa);
        Se=0;
        Convergence_curve(N_iter) = fmin;
        N_iter=N_iter+1;
    end %% End of iterations
    irun;
    fmin_buffer(irun) = fmin;
    
end
iteration_result(fobj, :) = Convergence_curve;
outcome = abs(fmin_buffer - optimum);
Final_results(fobj, : ) = [min(outcome),max(outcome),median(outcome), mean(outcome),std(outcome)];
Outcomes(fobj, : ) = outcome;
fobj
end

folder_name = [num2str(DIM) 'D_Convergence_curve.txt'];
address = [base_folder '\' folder_name];
save(address,'iteration_result', '-ascii');

end











%% Get cuckoos by ramdom walk
function nest=get_cuckoos(nest,J,a0,Lb,Ub)
% global J
% Levy flights
n=size(nest,1);
% Levy exponent and coefficient
% For details, see equation (2.21), Page 16 (chapter 2) of the book
% X. S. Yang, Nature-Inspired Metaheuristic Algorithms, 2nd Edition, Luniver Press, (2010).
beta=3/2;
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
p=rand(1,n);
p1=randperm(n);
p2=randperm(n);
p3=randperm(n);
for j=1:n,
    % This is a simple way of implementing Levy flights
    % For standard random walks, use step=1;
    %% Levy flights by Mantegna's algorithm
    u=randn(size(nest(j,:)))*sigma;
    v=randn(size(nest(j,:)));
    step=u./abs(v).^(1/beta);

	%information sharing approach (Please refer to the article-->Equation 9)
    if p(j) < J
             nest(j,:)=a0.*(step.*(nest(p1(j)))-nest(p2(j)))+nest(p3(j));  %% the value of a0 is 0.01
    elseif p(j) < (1-J)
             nest(j,:)=a0.*((nest(p1(j)))-step.*nest(p2(j)))+nest(p3(j));  
    else
            nest(j,:)=a0.*step.*(nest(p1(j))-nest(p2(j)))+nest(p3(j));
    end
   % Apply simple bounds/limits
   nest(j,:)=simplebounds(nest(j,:),Lb,Ub);
end
end
%% Find the current best nest
function [fmin,best,nest,fitness]=get_best_nest(fhd,fobj,nest,newnest,fitness)
global Se;
% Evaluating all new solutions
for j=1:size(nest,1),
    fnew=feval(fhd,newnest(j,:)',fobj);
    if fnew<=fitness(j),
       fitness(j)=fnew;
       nest(j,:)=newnest(j,:);
       Se=Se+1;
    end
end
% Find the current best
[fmin,K]=min(fitness) ;
best=nest(K,:);
end

%% Replace some nests by constructing new solutions/nests
function new_nest=empty_nests(nest,J,Lb,Ub,pa)
% global J
% A fraction of worse nests are discovered with a probability pa
n=size(nest,1);
d=size(nest,2);
% Discovered or not -- a status vector
K=rand(size(nest))>pa;
p=rand(1,n);
p1=randperm(n);
p2=randperm(n);
stepsize=zeros(n,d);
for j=1:n
	%information sharing approach (Please refer to the article-->Equation 10)
    if p(j) < J
             stepsize(j,:)=rand.*((nest(p1(j),:))-nest(p2(j),:));  
    elseif p(j) < (1-J)
             stepsize(j,:)=(nest(p1(j),:))-rand.*nest(p2(j),:);
    else
            stepsize(j,:)=rand*(nest(p1(j),:))-nest(p2(j),:);
    end
end
new_nest=nest+stepsize.*K;
for j=1:size(new_nest,1)
    s=new_nest(j,:);
  new_nest(j,:)=simplebounds(s,Lb,Ub);  
end
end

% Application of simple constraints
function s=simplebounds(s,Lb,Ub)
s=min(s,Ub);
s=max(s,Lb);
end