% -----------------------------------------------------------------
% Snap-drift Cuckoo Search (SDCS) algorithm by Hojjat Rakhshani and Amin Rahati
% University of Sistan and Baluchestan
% -----------------------------------------------------------------
% Paper Citation Details:
% Rakhshani, Hojjat, and Amin Rahati. "Snap-drift cuckoo search: A novel cuckoo search optimization algorithm." 
% Applied Soft Computing (2016).
% ----------------------------------------------------------------%

% =============================================================== %
% Notes:                                                          %
% Different implementations may lead to slightly different        %
% behavour and/or results, but there is nothing wrong with it,    %
% as this is the nature of  all metaheuristics.                   %
% -----------------------------------------------------------------

% addpath('../Functions');
% Run_num=30;
% FEs=40000;

% function Main(Particals_n,pa,J,a0)
%---------------------------------------------30 dimensional benchmark functions---------------------------
clc;
clear all;
Particals_n = 24;
pa = 0.1854;
J = 0.9618;
a0 = 0.5973;

addpath('G:\̨ʽ��������\MZQ\�����ļ�\comparision\Fifteen algorithms\Test-Algorithm\SDCS\SDCS\Functions');
DIM=10;
lb = ones(1,DIM).* -100;
ub = ones(1,DIM).* 100;
func_evalutions = 10000 * DIM;
MAX_iteration = round(func_evalutions/Particals_n);

creatematrix(DIM);


[Final_results, Outcomes,iteration_result]=SDCS(Particals_n,pa,J,a0,MAX_iteration,DIM,lb,ub);

save 'G:\̨ʽ��������\MZQ\�����ļ�\comparision\Fifteen algorithms\Test-Algorithm\SDCS\SDCS\Code\SDCS_comparison\10D_Convergence_curve.txt' -ascii  iteration_result

% save 'H:\MZQ\�����ļ�\comparision\Fifteen algorithms\Test-Algorithm\SDCS\SDCS\Code\SDCS_comparison\50D_Outcome_TenTimes.txt' -ascii  Outcomes
% save 'H:\MZQ\�����ļ�\comparision\Fifteen algorithms\Test-Algorithm\SDCS\SDCS\Code\SDCS_comparison\50D_Final_result.txt' -ascii  Final_results



% Result = Results';
% save 'C:\Users\admin\Desktop\comparision\Fifteen algorithms\Test-Algorithm\SDCS\SDCS\Code\parameters-test\auto_Result.txt' -ascii Result

% fid=fopen('Result.txt','wt');
% fprintf(fid,'%g\n',Results);
% fclose(fid);


% for Run=1:Run_num
%     Results(1,Run)  =   SDCS(@sphere,FEs,DIM,ones(1,DIM).*-100,ones(1,DIM).*100);
%     Results(2,Run)  =   SDCS(@schwefel_2_22,FEs,DIM,ones(1,DIM).*-10,ones(1,DIM).*10);
%     Results(3,Run)  =   SDCS(@sum_squares,FEs,DIM,ones(1,DIM).*-10,ones(1,DIM).*10);
%     Results(4,Run)  =   SDCS(@step,FEs,DIM,ones(1,DIM).*-100,ones(1,DIM).*100);
%     Results(5,Run)  =   SDCS(@noise,FEs,DIM,ones(1,DIM).*-1.28,ones(1,DIM).*0.64);
%     Results(6,Run)  =   SDCS(@quartic,FEs,DIM,ones(1,DIM).*-1.28,ones(1,DIM).*1.28);
%     Results(7,Run)  =   SDCS(@ackley,FEs,DIM,ones(1,DIM).*-32,ones(1,DIM).*32);
%     Results(8,Run)  =   SDCS(@griewank,FEs,DIM,ones(1,DIM).*-600,ones(1,DIM).*600);
%     Results(9,Run)  =   SDCS(@rastrigin,FEs,DIM,ones(1,DIM).*-5.12,ones(1,DIM).*5.12);
%     Results(10,Run) =   SDCS(@schwefel_2_26,FEs,DIM,ones(1,DIM).*-500,ones(1,DIM).*500);
%     Results(11,Run) =   SDCS(@alpine,FEs,DIM,ones(1,DIM).*-10,ones(1,DIM).*10);
%     Results(12,Run) =   SDCS(@levy,FEs,DIM,ones(1,DIM).*-10,ones(1,DIM).*10);
%     Results(13,Run) =   SDCS(@schaffer,FEs,DIM,ones(1,DIM).*-100,ones(1,DIM).*100);
%     Results(14,Run) =   SDCS(@non_continuous_rastrigin,FEs,DIM,ones(1,DIM).*-5.12,ones(1,DIM).*5.12);
%     Results(15,Run) =   SDCS(@rosenbrock,FEs,DIM,ones(1,DIM).*-5,ones(1,DIM).*10);
%     Results(16,Run) =   SDCS(@Penalized1,FEs,DIM,ones(1,DIM).*-50,ones(1,DIM).*50);
%     Results(17,Run) =   SDCS(@Penalized2,FEs,DIM,ones(1,DIM).*-50,ones(1,DIM).*50);
%     Results(18,Run) =   SDCS(@rotated_ackley,FEs,DIM,ones(1,DIM).*-32,ones(1,DIM).*32);
%     Results(19,Run) =   SDCS(@rotated_rastrigin,FEs,DIM,ones(1,DIM).*-5.12,ones(1,DIM).*5.12);
%     Results(20,Run) =   SDCS(@rotated_griewank,FEs,DIM,ones(1,DIM).*-600,ones(1,DIM).*600);
%     Results(21,Run) =   SDCS(@rotated_schwefel,FEs,DIM,ones(1,DIM).*-500,ones(1,DIM).*500);
%     fprintf('Run %d has terminated\n',Run);
%     save('Reslt_30');
% end
% 
% %---------------------------------------------50 dimensional benchmark functions---------------------------
% DIM=50;
% creatematrix(DIM);
% Results=zeros(21,Run_num);
% for Run=1:Run_num
%     Results(1,Run)  =   SDCS(@sphere,FEs,DIM,ones(1,DIM).*-100,ones(1,DIM).*100);
%     Results(2,Run)  =   SDCS(@schwefel_2_22,FEs,DIM,ones(1,DIM).*-10,ones(1,DIM).*10);
%     Results(3,Run)  =   SDCS(@sum_squares,FEs,DIM,ones(1,DIM).*-10,ones(1,DIM).*10);
%     Results(4,Run)  =   SDCS(@step,FEs,DIM,ones(1,DIM).*-100,ones(1,DIM).*100);
%     Results(5,Run)  =   SDCS(@noise,FEs,DIM,ones(1,DIM).*-1.28,ones(1,DIM).*0.64);
%     Results(6,Run)  =   SDCS(@quartic,FEs,DIM,ones(1,DIM).*-1.28,ones(1,DIM).*1.28);
%     Results(7,Run)  =   SDCS(@ackley,FEs,DIM,ones(1,DIM).*-32,ones(1,DIM).*32);
%     Results(8,Run)  =   SDCS(@griewank,FEs,DIM,ones(1,DIM).*-600,ones(1,DIM).*600);
%     Results(9,Run)  =   SDCS(@rastrigin,FEs,DIM,ones(1,DIM).*-5.12,ones(1,DIM).*5.12);
%     Results(10,Run) =   SDCS(@schwefel_2_26,FEs,DIM,ones(1,DIM).*-500,ones(1,DIM).*500);
%     Results(11,Run) =   SDCS(@alpine,FEs,DIM,ones(1,DIM).*-10,ones(1,DIM).*10);
%     Results(12,Run) =   SDCS(@levy,FEs,DIM,ones(1,DIM).*-10,ones(1,DIM).*10);
%     Results(13,Run) =   SDCS(@schaffer,FEs,DIM,ones(1,DIM).*-100,ones(1,DIM).*100);
%     Results(14,Run) =   SDCS(@non_continuous_rastrigin,FEs,DIM,ones(1,DIM).*-5.12,ones(1,DIM).*5.12);
%     Results(15,Run) =   SDCS(@rosenbrock,FEs,DIM,ones(1,DIM).*-5,ones(1,DIM).*10);
%     Results(16,Run) =   SDCS(@Penalized1,FEs,DIM,ones(1,DIM).*-50,ones(1,DIM).*50);
%     Results(17,Run) =   SDCS(@Penalized2,FEs,DIM,ones(1,DIM).*-50,ones(1,DIM).*50);
%     Results(18,Run) =   SDCS(@rotated_ackley,FEs,DIM,ones(1,DIM).*-32,ones(1,DIM).*32);
%     Results(19,Run) =   SDCS(@rotated_rastrigin,FEs,DIM,ones(1,DIM).*-5.12,ones(1,DIM).*5.12);
%     Results(20,Run) =   SDCS(@rotated_griewank,FEs,DIM,ones(1,DIM).*-600,ones(1,DIM).*600);
%     Results(21,Run) =   SDCS(@rotated_schwefel,FEs,DIM,ones(1,DIM).*-500,ones(1,DIM).*500);
%     fprintf('Run %d has terminated\n',Run);
%     save('Reslt_50');
% end