function val=rotated_rastrigin(x)
global M;
y=M*(x.');
y=y.';
val=rastrigin(y);