function y = step(x)
n = length(x);
y=0;
for i=1:n
    y=y+floor(x(i)+0.5)^2;
end