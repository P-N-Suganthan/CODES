function [res]=noise(x)
d=length(x);
res=0;
for i=1:d
    res=res+(i*x(i)^4);
end
res=res+rand;