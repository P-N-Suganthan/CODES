function s = sphere(x)
% 
% Sphere function 
% Matlab Code by A. Hedar (Nov. 23, 2005).
% The number of variables n should be adjusted below.
% The default value of n = 30.
% 
n = length(x);
s = 0;
for j = 1:n
    s = s+x(j)^2; 
end
