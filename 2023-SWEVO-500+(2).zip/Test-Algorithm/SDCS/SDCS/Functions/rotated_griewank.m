function val=rotated_griewank(x)
global M;
y=M*(x.'); 
y=y.';
val=griewank(y);