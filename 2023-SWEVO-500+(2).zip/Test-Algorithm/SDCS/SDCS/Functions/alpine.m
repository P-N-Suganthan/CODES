function [res]=alpine(x)
res=0;
n = length(x);
for i=1:n
    res=res+abs(x(i)*(sin(x(i))+0.1));
end
end