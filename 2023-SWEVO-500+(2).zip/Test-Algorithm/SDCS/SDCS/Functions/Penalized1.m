function [res]=Penalized1(x)
y=1+0.25*(x+1);
n = length(x);
p1=0;
for i=1:n-1
p1=p1+((y(i)-1)^2)*(1+10*sin(pi*y(i+1))^2);
end

p1=p1+(y(n)-1)^2;

p1=p1+(10*sin(pi*y(1))^2);

p1=(pi/n)*p1;

p3=0;
for i=1:n
p3=p3+un(x(i),10,100,4);
end
res=p1+p3;


function [res]=un(x,a,k,m)
if (x>a) || (x<-a)
res=k*((x-a)^m);
else
res=0;
end