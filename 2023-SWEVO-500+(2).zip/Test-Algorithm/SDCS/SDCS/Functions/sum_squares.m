function y = sum_squares(x)
n = length(x);
y=0;
for i=1:n
    y=y+i*x(i)^2;
end