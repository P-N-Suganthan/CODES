function y = schwefel_2_26(x)
% 
% Schwefel function
% Matlab Code by A. Hedar (Nov. 23, 2005).
% The number of variables n should be adjusted below.
% The default value of n = 2.
% 
n = length(x);
% a=0.5;
s = sum(-x.*sin(sqrt(abs(x))));
y = 418.9829*n+s;
% y=sum(x.^2)^a;