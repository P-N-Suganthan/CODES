function val=rotated_schwefel(x)
global M;
y=M*(x.'); 
y=y.';
val=schwefel_2_26(y);