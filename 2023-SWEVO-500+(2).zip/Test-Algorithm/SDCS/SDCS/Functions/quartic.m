function [z]=quartic(x)
n = length(x);
s=0;
for i=1:n
    s=s+i*x(i)^4;
end
z=s;