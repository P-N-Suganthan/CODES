%Schwefel2.22
% Function Description:
%      xmin  = [0, 0, 0.....0]  (all zeroes)
%      fxmin = 0                  (zero)
function Schw =  schwefel_2_22(Swarm)
% [SwarmSize, Dim] = size(Swarm);
Schw = sum((abs(Swarm))) + prod((abs(Swarm)));
