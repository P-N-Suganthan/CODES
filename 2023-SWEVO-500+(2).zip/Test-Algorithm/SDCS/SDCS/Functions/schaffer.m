function y = schaffer(x)
z=sum(x.^2);
y=.5+((sin(z)^2-.5)/(1+0.001*z)^2);