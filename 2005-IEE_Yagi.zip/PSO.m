function [gbest,gbest_val,max_gain1,real_impi1,imag_impi1,rsll1]=PSO(fname,n,Xmin,Xmax,NP,Feval_max,FDR,radius)

%  fname='yagi_fit_gain';
%  nl=6;n=2*nl-1;
%  Xmin=[0.15*ones(1,nl) 0.1*ones(1,nl-1)];
%  Xmax=[0.35*ones(1,nl) 0.45*ones(1,nl-1)];
%  NP=20;
%  Feval_max=3500;
%  radius=.003369;
%  FDR=0; '0' means standard PSO '1'  means FDR-PSO

tr=zeros(1,500);
c1=1;c2=1;c3=0;
if FDR==1,c3=1;end
maxgen=1.5*round(Feval_max/NP);
feval_count=0;

w(1:maxgen)=0.9-(1:maxgen)*(0.7/maxgen);
vmax=.25*(Xmax-Xmin);
vmin=-vmax;
vv=zeros(NP,n);

for i=1:NP
feval_count=feval_count+1;
[particle_fit(i,1),max_gain(i,1),real_impi(i,1),imag_impi(i,1),rsll(i,1)]=feval(fname,particle_pos(i,1:n),n,Xmin,Xmax,radius);
end

pbest=particle_pos;
pbest_val=particle_fit;
[gbest_val,gbest_id]=min(particle_fit);
gbest=pbest(gbest_id,:);

tr(1)=gbest_val;

nbest=pbest;

for i=2:maxgen
    
    for j=1:NP
        if FDR~=1,
         vv(j,:)=w(i)*vv(j,:)+c1*rand(1,n).*(pbest(j,:)-particle_pos(j,:))+c2*rand(1,n).*(gbest-particle_pos(j,:));
     else
         vv(j,:)=w(i)*vv(j,:)+c1*rand(1,n).*(pbest(j,:)-particle_pos(j,:))+c2*rand(1,n).*(gbest-particle_pos(j,:))+c3*rand(1,n).*(nbest(j,:)-particle_pos(j,:));
     end   
        vv(j,:)=(vv(j,:)>=vmax).*vmax+(vv(j,:)<vmax).*vv(j,:);
        vv(j,:)=(vv(j,:)<=vmin).*vmin+(vv(j,:)>vmin).*vv(j,:);
        particle_pos_temp=vv(j,:)+particle_pos(j,:);
        
        xerr=sum(abs(min(particle_pos_temp-Xmin,0))+abs(min(Xmax-particle_pos_temp,0)),2);
        if xerr==0,feval_count=feval_count+1;[particle_fit(j,1),max_gain(j,1),real_impi(j,1),imag_impi(j,1),rsll(j,1)]=feval(fname,particle_pos_temp,n,Xmin,Xmax,radius);particle_pos(j,:)=particle_pos_temp;
          if c3~=0,
            pbest_index=find([1:NP]~=j)';
          dd=abs(pbest(pbest_index,:)-repmat(particle_pos(j,:),NP-1,1));
          dd=(dd==0)*100+(dd>0).*dd;
          fx=-pbest_val(pbest_index,1)+particle_fit(j,1)*ones(NP-1,1);
          ffx=repmat(fx,1,n);
          fdr=ffx./dd;
          [f1,f2]=max(fdr);
          for jj=1:n
          nbest(j,jj)=pbest(f2(jj),jj);
          end
      end
            if particle_fit(j,1)<pbest_val(j,1),pbest_val(j,1)=particle_fit(j,1);pbest(j,:)=particle_pos(j,:);end
            if particle_fit(j,1)<gbest_val,gbest_val=particle_fit(j,1);gbest=particle_pos(j,:);end
        end
             
    end
    if feval_count>Feval_max,break,end
    tr(i)=gbest_val;
end

[particle_fitt,max_gain1,real_impi1,imag_impi1,rsll1]=feval(fname,gbest,n,Xmin,Xmax,radius);








