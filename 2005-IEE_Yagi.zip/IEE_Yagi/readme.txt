There are six Matlab programs in the folder

                     %%%%%           Important   %%%%%

                   %%%%%% In order to run these programs SuperNEC software  is required %%%%%%


PSO_yagi- Main program for conducting yagi antenna design using various PSO algorithms PSO  ,FDR-PSO and CLPSO

There are two different PSO algorithm functions namely PSO and CLPSO
For FDR-PSO use PSO function with FDR=1 and for PSO use PSO function with FDR=0
Three different designs are considered (i.e) gain maximization, gain maximization with impedance and gain maximization with amplitude & relative SLL
Corresponding functions are 'yagi_fit_gain'  'yagi_fit_gain_impi'     'yagi_fit_gain_impi_rsll'

PSO function:
-----------------

[gbest,gbest_val,max_gain,real_impi,imag_impi,rsll]=PSO(fname,n,Xmin,Xmax,NP,Feval_max,FDR,radius);

fname-function  name
n-number of elements  (If 'nl' is number of  Yagi antenna elements then n=2*nl-1)
Xmin- lower bound on variables (first 'nl' elements coresspond to element length and the last (nl-1) elements correspond to element spacing)
Xmax-upperbound on variables (first 'nl' elements coresspond to element length and the last (nl-1) elements correspond to element spacing)
NP-numebr of individuals 
Feval_max-Maximum number of function evaluations (stopping criteria)
FDR- PSO or FDR-PSO
radius  -Radius of antenna segments
gbest- best parameter value
gbest_val - composite objective function value corresponding to gbest
max_gain- Maximum gain corresponding to gbest
real_impi- Real part of the impedance corresponding to gbest
image_impi-Imaginary part of the impedance corresponding to gbest
rsll- Relative sidelobe level corresponding to SLL

Typical function call :
-------------------------

Xmin=[0.15*ones(1,nl) 0.1*ones(1,nl-1)]; 
Xmax=[0.35*ones(1,nl) 0.45*ones(1,nl-1)]

[gbest,gbest_val,max_gain,real_impi,imag_impi,rsll]=PSO('yagi_fit_gain',n,Xmin,Xmax,10,3500,0,.003369);

CLPSO function:
---------------------
[gbest,gbest_val,max_gain,real_impi,imag_impi,rsll]=PSO(fname,n,Xmin,Xmax,NP,Feval_max,FDR,radius);

fname-function  name
n-number of elements  (If 'nl' is number of  Yagi antenna elements then n=2*nl-1)
Xmin- lower bound on variables (first 'nl' elements coresspond to element length and the last (nl-1) elements correspond to element spacing)
Xmax-upperbound on variables (first 'nl' elements coresspond to element length and the last (nl-1) elements correspond to element spacing)
NP-numebr of individuals 
Feval_max-Maximum number of function evaluations (stopping criteria)
radius  -Radius of antenna segments

Typical function call :
-------------------------

Xmin=[0.15*ones(1,nl) 0.1*ones(1,nl-1)]; 
Xmax=[0.35*ones(1,nl) 0.45*ones(1,nl-1)]

[gbest,gbest_val,max_gain,real_impi,imag_impi,rsll]=CLPSO('yagi_fit_gain',n,Xmin,Xmax,10,3500,.003369);

gbest- best parameter value
gbest_val - composite objective function value corresponding to gbest
max_gain- Maximum gain corresponding to gbest
real_impi- Real part of the impedance corresponding to gbest
image_impi-Imaginary part of the impedance corresponding to gbest
rsll- Relative sidelobe level corresponding to SLL


Reference :

S. BASKAR, A. Alphones, P. N. Suganthan and J. J. Liang, �Design of Yagi-Uda Antennas using Comprehensive Learning 
Particle Swarm Optimization�, IEE Proc. Microwaves, Antennas & Propagation, Accepted for publication
