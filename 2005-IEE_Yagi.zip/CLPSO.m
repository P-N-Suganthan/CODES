%  CLPSO function for Yagi antenna design
% fname-function  name
% n-number of elemeents
% Xmin- lower bound on varibales
% Xmax-upperbound on variables
% NP-numebr of individuals 
% Feval_max-Maximum number of function evaluations (stopping criteria)
% radius  -Radius of antenna segments

function [gbest,gbest_val,max_gain1,real_impi1,imag_impi1,rsll1]=CLPSO(fname,n,Xmin,Xmax,NP,Feval_max,radius)

for i=1:NP
particle_pos1(i,:)=Xmin+(Xmax-Xmin).*rand(1,n);
end

pc=.1;
maxgen=1.5*round(Feval_max/NP);
feval_count=0;
tr=zeros(1,500);
particle_pos=partilce_pos1;
vmax=.25*(Xmax-Xmin);
vmin=-vmax;
vv=zeros(NP,n);


for i=1:NP
feval_count=feval_count+1;
[particle_fit(i,1),max_gain(i,1),real_impi(i,1),imag_impi(i,1),rsll(i,1)]=feval(fname,particle_pos(i,1:n),n,Xmin,Xmax,radius);
end
pbest=particle_pos;
pbest_val=particle_fit;
[gbest_val,gbest_id]=min(particle_fit);
gbest=pbest(gbest_id,:);

tr(1)=gbest_val;


for i=1:maxgen
    
     w(i)=((.9-.2)*(maxgen-i)/maxgen)+.2;
    if mod(i,5)==1,
        for k=1:NP
            b(k,:)=ceil(rand(1,n)-pc);
            f(k,:)=ceil(rand(1,n)*NP);
        end
    end
    
    for j=1:NP
        for jj=1:n
        ppbest(jj)=pbest(f(j,jj),jj);
        end
        tem=(b(j,:)==1).*rand(1,n).*(ppbest-particle_pos(j,:))+(b(j,:)==0).*rand(1,n).*(pbest(j,:)-particle_pos(j,:));
        vv(j,:)=w(i)*vv(j,:)+tem;
        vv(j,:)=(vv(j,:)>=vmax).*vmax+(vv(j,:)<vmax).*vv(j,:);
        vv(j,:)=(vv(j,:)<=vmin).*vmin+(vv(j,:)>vmin).*vv(j,:);
        particle_pos_temp=vv(j,:)+particle_pos(j,:);
        xerr=sum(abs(min(particle_pos_temp-Xmin,0))+abs(min(Xmax-particle_pos_temp,0)),2);
        if xerr==0,feval_count=feval_count+1;[particle_fit(j,1),max_gain(j,1),real_impi(j,1),imag_impi(j,1),rsll(j,1)]=feval(fname,particle_pos_temp,n,Xmin,Xmax,radius);particle_pos(j,:)=particle_pos_temp;
          
            if particle_fit(j,1)<pbest_val(j,1),pbest_val(j,1)=particle_fit(j,1);pbest(j,:)=particle_pos(j,:);end
            if particle_fit(j,1)<gbest_val,gbest_val=particle_fit(j,1);gbest=particle_pos(j,:);end
        end
             
    end
    tr(i)=gbest_val;
    if feval_count>Feval_max,break,end
end
[particle_fitt,max_gain1,real_impi1,imag_impi1,rsll1]=feval(fname,gbest,n,Xmin,Xmax,radius);












