clear all
clc

                     %%%%%           Important   %%%%%

                   %%%%%% In order to run these programs SuperNEC code is required %%%%%%



% PSO_yagi is main program for conducting yagi antenna design using various PSO algorithms
% PSO  ,FDR-PSO and CLPSO
% There are two different PSO algorithm functions namely PSO and CLPSO
% For FDR-PSO use PSO function with FDR=1
% For PSO use PSO function with FDR=0
% Three different designs are considered (i.e) gain maximization, gain maximization with impedance and gain maximization with amplitude & relative SLL
% Corresponding functions are 'yagi_fit_gain'  'yagi_fit_gain_impi'     'yagi_fit_gain_impi_rsll'



%---------------------------------------------------------------------------------
%Gain_maximization code

fname='yagi_fit_gain';
nl=6;n=2*nl-1;
Xmin=[0.15*ones(1,nl) 0.1*ones(1,nl-1)];
Xmax=[[0.35 0.35*ones(1,nl-1)] 0.45*ones(1,nl-1)];
NP=10;
radius=.003369;
Feval_max=3500;

for i=1:5
 [gbest(i,:),gbest_val1(i),max_gain1(i),real_impi1(i),imag_impi1(i),rsll1(i)]=PSO(fname,n,Xmin,Xmax,NP,Feval_max,0,radius);
 [gbest(i,:),gbest_val2(i),max_gain2(i),real_impi2(i),imag_impi2(i),rsll2(i)]=PSO(fname,n,Xmin,Xmax,NP,Feval_max,1,radius);
 [gbest(i,:),gbest_val3(i),max_gain3(i),real_impi3(i),imag_impi3(i),rsll3(i)]=CLPSO(fname,n,Xmin,Xmax,NP,Feval_max,radius);
end
%-------------------------------------------------------------------------------------



%-------------------------------------------------------------------------------------
% Gain maximization with impedance code

fname='yagi_fit_gain_impi';

nl=6;n=2*nl-1;radius=.003369;
Xmin=[0.15*ones(1,nl) 0.1*ones(1,nl-1)];
Xmax=[[0.25 0.24*ones(1,nl-1)] 0.45*ones(1,nl-1)];
NP=10;
Feval_max=5000;

 for i=1:5
 [gbest(i,:),gbest_val1(i),max_gain1(i),real_impi1(i),imag_impi1(i),rsll1(i)]=PSO(fname,n,Xmin,Xmax,NP,Feval_max,0,radius);
 [gbest(i,:),gbest_val2(i),max_gain2(i),real_impi2(i),imag_impi2(i),rsll2(i)]=PSO(fname,n,Xmin,Xmax,NP,Feval_max,1,radius);
 [gbest(i,:),gbest_val3(i),max_gain3(i),real_impi3(i),imag_impi3(i),rsll3(i)]=CLPSO(fname,n,Xmin,Xmax,NP,Feval_max,radius);
 end

%--------------------------------------------------------------------------------------


%--------------------------------------------------------------------------------------
% Gain maximization with impedance and relative SLL
fname='yagi_fit_gain_impi_rsll';
nl=4;n=2*nl-1;
Xmin=[0.15*ones(1,nl) 0.1*ones(1,nl-1)];
Xmax=[[0.25 0.24*ones(1,nl-1)] 0.45*ones(1,nl-1)];
NP=10;
radius=.00225;
Feval_max=3500;

 for i=1:5
 [gbest(i,:),gbest_val1(i),max_gain1(i),real_impi1(i),imag_impi1(i),rsll1(i)]=PSO(fname,n,Xmin,Xmax,NP,Feval_max,0,radius);
 [gbest(i,:),gbest_val2(i),max_gain2(i),real_impi2(i),imag_impi2(i),rsll2(i)]=PSO(fname,n,Xmin,Xmax,NP,Feval_max,1,radius);
 [gbest(i,:),gbest_val3(i),max_gain3(i),real_impi3(i),imag_impi3(i),rsll3(i)]=CLPSO(fname,n,Xmin,Xmax,NP,Feval_max,radius);
end
 
%-----------------------------------------------------------------------------------------
