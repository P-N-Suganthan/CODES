 function [res]=yagi_fit_gain_impi_rsll(xx)

% nl=number of elements in Yagi-uda antenna
%  In order to run this program SuperNEC program is required
% n=total  number of design variables
% Xmin=[0.15*ones(1,nl) 0.1*ones(1,nl-1)];
% Xmax=[[0.35 0.35*ones(1,nl-1)] 0.45*ones(1,nl-1)];
% xx is a vector of dimension (2*nl)-1, Xmin and Xmax are lower & upper bound of variables 

n=length(xx);ns=7;radius=.00225;
nn=ceil(n/2);
length=xx(1:nn);
spacing=[0 xx(nn+1:n)];
[res,gain,real_impi,imag_impi,rsll]=yagi_sim_gain(length,spacing,radius,ns,nn);

function [cost,max_gain,real_impi,imag_impi,rsll]=yagi_sim_gain(length,spacing,radius,ns,n)

fid=fopen('temp.nec','wt');
fprintf(fid,'CM NEC Input File of a 15 Element Yagi\n');
fprintf(fid,'CE\n');

for i=1:n
if(i<10),
fprintf(fid,'GW  %d    %d   %7.5f  %7.5f   %7.5f   %7.5f   %7.5f   %7.5f   %7.5f\n',i,ns,sum(spacing(1:i)),-length(i),0.0,sum(spacing(1:i)),length(i),0.0,radius);
else
fprintf(fid,'GW %d    %d   %7.5f  %7.5f   %7.5f   %7.5f   %7.5f   %7.5f   %7.5f\n',i,ns,sum(spacing(1:i)),-length(i),0.0,sum(spacing(1:i)),length(i),0.0,radius);
end
end
 
 fprintf(fid,'GE  %d\n',0);
 fprintf(fid,'FR  %d    %d    %d    %d %3.2E %3.2E %3.2E %3.2E %3.2E %3.2E\n',0,1,0,0,300,0,0,0,0,0);
 fprintf(fid,'EX  %d    %d    %d    %d %3.2E %3.2E %3.2E %3.2E %3.2E %3.2E\n',0,2,4,0,1,0,0,0,0,0);
 fprintf(fid,'RP  %d  %d    %d %d %3.2E %3.2E %3.2E %3.2E %3.2E %3.2E\n',0,361,1,1000,0,0,1,0,10000,0);
%  fprintf(fid,'PT  %d    %d    %d    %d %3.2E %3.2E %3.2E %3.2E %3.2E %3.2E\n',1,0,0,0,0,0,0,0,0,0);
 fprintf(fid,'EN');
 fclose(fid);
 [s, w] = dos (['snec temp.nec   temp.out']);
    data = sndata ('temp.out');
    radpat = data.rpgain (1, 1);
    max_gain=max(max(radpat.gain(:,:,3)));
    imp=data.imped(1,1);
    real_impi=real(imp.impedance);
    imag_impi=imag(imp.impedance);
    
     gain=radpat.gain;
    theta=radpat.theta;
    gain1=gain(:,:,2)-max_gain;
    plot(theta,gain1)
    err1=abs(50-(real_impi));
    err2=abs(imag_impi);
  
  ga=gain(:,:,3);
  tw=sign(ga(1:360)-ga(2:361));
  [ff,vv]=size(tw);
  pp=(tw(1:vv-1)-tw(2:vv));
  bb=find(pp<0);
  [maxg,maxg_id]=max(ga);
  sl=find(ga(bb)<(max(ga)-.02));
  sll=max(ga(bb(sl)));
  if isempty(sll),rsll=0;
  else
  rsll=(max(ga)-sll);
  end  
  ss=find(ga(maxg_id:360)-max_gain<-3);
  
  if isempty(ss),
      beam_width=100;
  else
      beam_width=ss(1)*2;
  end
  if rsll>15, rsller=0;else rsller=abs(rsll-15);end
  cost=-(30*max_gain-(err1+err2)-2*abs(rsll))
  
    snres ('Exit');
    clear snres
    dos('del temp.nec temp.out');
    clear fid    length  n   radius  s  w data i imp ns radpat spacing ans   
  
    
