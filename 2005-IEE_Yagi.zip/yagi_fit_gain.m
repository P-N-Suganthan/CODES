function [cost]=yagi_fit_gain(xx)

% nl=number of elements in Yagi-uda antenna
%  In order to run this program SuperNEC program is required
% n=total  number of design variables
% Xmin=[0.15*ones(1,nl) 0.1*ones(1,nl-1)];
% Xmax=[[0.35 0.35*ones(1,nl-1)] 0.45*ones(1,nl-1)];
% xx is a vector of dimension (2*nl)-1, Xmin and Xmax are lower & upper bound of variables 
n=length(xx);
ns=7;radius=0.003369;
nn=ceil(n/2);
length=xx(1:nn);
spacing=[0 xx(nn+1:n)];
[res,gain,real_impi,imag_impi,rsll]=yagi_sim_gain(length,spacing,radius,ns,nn);


function [cost,max_gain,real_impi,imag_impi,rsll]=yagi_sim_gain(length,spacing,radius,ns,n)

fid=fopen('temp.nec','wt');
fprintf(fid,'CM NEC Input File of a 15 Element Yagi\n');
fprintf(fid,'CE\n');

for i=1:n
if(i<10),
fprintf(fid,'GW  %d    %d   %7.5f  %7.5f   %7.5f   %7.5f   %7.5f   %7.5f   %7.5f\n',i,ns,sum(spacing(1:i)),-length(i),0.0,sum(spacing(1:i)),length(i),0.0,radius);
else
fprintf(fid,'GW %d    %d   %7.5f  %7.5f   %7.5f   %7.5f   %7.5f   %7.5f   %7.5f\n',i,ns,sum(spacing(1:i)),-length(i),0.0,sum(spacing(1:i)),length(i),0.0,radius);
end
end
 
 fprintf(fid,'GE  %d\n',0);
 fprintf(fid,'FR  %d    %d    %d    %d %3.2E %3.2E %3.2E %3.2E %3.2E %3.2E\n',0,1,0,0,300,0,0,0,0,0);
 fprintf(fid,'EX  %d    %d    %d    %d %3.2E %3.2E %3.2E %3.2E %3.2E %3.2E\n',0,2,4,0,1,0,0,0,0,0);
 fprintf(fid,'RP  %d  %d    %d %d %3.2E %3.2E %3.2E %3.2E %3.2E %3.2E\n',0,361,1,1000,0,0,1,0,10000,0);
 fprintf(fid,'PT  %d    %d    %d    %d %3.2E %3.2E %3.2E %3.2E %3.2E %3.2E\n',1,0,0,0,0,0,0,0,0,0);
 fprintf(fid,'EN');
 fclose(fid);
 [s, w] = dos (['snec temp.nec   temp.out']);
    data = sndata ('temp.out');
    radpat = data.rpgain (1, 1);
    max_gain=max(max(radpat.gain(:,:,3)));
    imp=data.imped(1,1);
    real_impi=real(imp.impedance);
    imag_impi=imag(imp.impedance);
cost=-(max_gain);
rsll=0;
    snres ('Exit');
    clear snres
    dos('del temp.nec temp.out');
  
  
    
