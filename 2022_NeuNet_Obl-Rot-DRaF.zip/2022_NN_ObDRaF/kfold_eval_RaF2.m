function OptPara = kfold_eval_RaF2(options)
name=options.name; dataset_path='.\';
dataset_name=name;

dataset_path_name = strcat(dataset_path,dataset_name,'\');
load([dataset_path_name 'folds.mat']);

load(strcat(dataset_path_name,dataset_name, '.mat'))
load([dataset_path_name 'labels.mat']);
load([dataset_path_name 'validation_train.mat']);
load([dataset_path_name 'validation_test.mat']);

numOffold = size(folds,2);
expression = strcat('dataX = ',dataset_name,';');

eval(expression);
dataY=labels;
folds = logical(folds);

options.nvartosample = round(sqrt(size(dataX,2))); %default;
options.ntrees = 50; n=numOffold; ACC = zeros(1,n);
for f=1:numOffold
    test_index = folds(:,f);
    train_index = logical(1-test_index);

    trainX = dataX(train_index,:);
    trainY = dataY(train_index,:);
    testX = dataX(test_index,:);
    testY = dataY(test_index,:);
    options.nvartosample = round(sqrt(size(trainX,2))); %default;
    [model1]=ObliqueRF_train_double(trainX,trainY,'ntrees',options.ntrees,'nvartosample',options.nvartosample,'minleaf',options.minleaf,'name',name,'oblique',options.model);
    [Y1,~]=ObliqueRF_predict(testX,model1);
    ACC(1,f)=length(find(Y1==testY))/length(testY);
    clear trainX trainY testX testY;
end
mean_acc = mean(ACC);
OptPara.test_acc = mean_acc;
end