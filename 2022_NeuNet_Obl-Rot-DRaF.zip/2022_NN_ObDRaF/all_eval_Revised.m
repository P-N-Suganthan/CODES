clear all; close all; clc;  addpath(genpath(cd));

options.minleaf=1;
options.model=2; %% model Number is given  as 2:MPDRaF-T, 3:MPDRaF-P, 4:MPDRaF-N, 5:DRaF-PCA, 6:DRaF-LDA


options.name='adult';
OptPara= kfold_eval_RaF2(options);
acc=OptPara.test_acc