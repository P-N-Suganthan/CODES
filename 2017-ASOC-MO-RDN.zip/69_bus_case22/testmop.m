function mop = testmop(dimension)
%Get test multi-objective problems from a given name. 
%   The method get testing or benchmark problems for Multi-Objective
%   Optimization. The test problem will be encapsulated in a structure,
%   which can be obtained by function get_structure('testmop'). 
%   User get the corresponding test problem, which is an instance of class
%   mop, by passing the problem name and optional dimension parameters.

    mop=get_structure('testmop');
    mop=problems(mop,dimension);
    mop.od=2;
end

function p=problems(p,dim)
 p.pd=dim;
 
 p.domain=xboundary(dim);
 p.func=@gencap;
 
end

function range = xboundary(dim)
    range = zeros(dim,2);
    range(:,1)  = [5 5 0.2 0.1 5 5 0.2 0.1]; %input range and position of generator and capacitor
    %range(:,2)  = [68 68 1.8 1.8 68 68 1.8 1.8];
    range(:,2)  = [68 68 2.25 1 68 68 2.69 1];
end



