%function loss = gencap(posrat)
global bestvolt0 minvolt0 bestvolt1 minvolt1 ploss0 qloss0;

%posrat = [76; 2.65; 29; 35; 73; 89; 88; 115; 4.4; 2.9; 1.85; 1.2; 0.5; 2.35];
posrat = [74; 2.913; 42; 52;77;83;100;115;1.509;2.5;1.513;1.645;1.103;2.32];
posgen = round(posrat(1));
ratgen = posrat(2);
poscap = round(posrat(3:8));
ratcap = (posrat(9:14));

offbranch = [119 120 121 122 123 124 125 126 127 128 129 130 131 132 133];
offbranch = offbranch-1; % for 119 bus sequence number

data = loadcase(case119);
data.branch(offbranch,11) = 0; % status '0' for off lines

mpopt = mpoption('pf.alg','NR','verbose',0,'out.all',0);
result0 = runpf(data,mpopt);
ploss0 = sum(result0.branch(:,14)+result0.branch(:,16))*1e3;
qloss0 = sum(result0.branch(:,15)+result0.branch(:,17))*1e3;

bestvolt0 = result0.bus(:,8);
minvolt0 = min(bestvolt0);

data.bus(posgen,3) = data.bus(posgen,3)-ratgen;
data.bus(poscap,4) = data.bus(poscap,4)-ratcap;

result1 = runpf(data,mpopt);
ploss = sum(result1.branch(:,14)+result1.branch(:,16))*1e3;
qloss = sum(result1.branch(:,15)+result1.branch(:,17))*1e3;

bestvolt1 = result1.bus(:,8);
minvolt1 = min(bestvolt1);

loss(1,:) = ploss;
loss(2,:) = qloss;

%end