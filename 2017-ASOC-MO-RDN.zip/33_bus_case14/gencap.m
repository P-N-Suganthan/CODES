function loss = gencap(posrat)
global bestvolt0 minvolt0 bestvolt1 minvolt1 ploss0 qloss0;

%posrat = [12;30;0.469;1.057];
poscap = round(posrat(1:2));
ratcap = posrat(3:4);
ratcap(2) = ratcap(2)*(2.3-ratcap(1)); % when sum is restricted to 2.3MW

offbranch = [33 34 35 36 37];

data = loadcase(case33) ; 
data.branch(offbranch,11) = 0; % status '0' for off lines

mpopt = mpoption('pf.alg','NR','verbose',0,'out.all',0);
result0 = runpf(data,mpopt);
ploss0 = sum(result0.branch(:,14)+result0.branch(:,16))*1e3;
qloss0 = sum(result0.branch(:,15)+result0.branch(:,17))*1e3;

bestvolt0 = result0.bus(:,8);
minvolt0 = min(bestvolt0);

data.bus(poscap,4) = data.bus(poscap,4)-ratcap;

result1 = runpf(data,mpopt);
ploss = sum(result1.branch(:,14)+result1.branch(:,16))*1e3;
qloss = sum(result1.branch(:,15)+result1.branch(:,17))*1e3;

bestvolt1 = result1.bus(:,8);
minvolt1 = min(bestvolt1);

loss(1,:) = ploss;
loss(2,:) = qloss;

end