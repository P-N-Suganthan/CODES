
% however, any quesion please contact Shizheng Zhao (zh0047ng@ntu.edu.sg) or Wudong Liu (wudong.liu@gmail.com)

totalrun = 1;
%The result IDG Metrics recorded.
DM = zeros(1,totalrun);

global bestvolt0 minvolt0 bestvolt1 minvolt1 ploss0 qloss0;

seed = 10;

    for j = 1:totalrun
        
        mop = testmop(16);
        [pareto,record_prob] = ENSmoead(mop,'seed',j+seed);

        objpareto=[pareto.objective];
        %need to filter the result.
        eval(['save paretofront_' num2str(j) ' objpareto']);
        %eval(['save record_prob_' num2str(1) ' record_prob']);
      
    end
    
% print results (subproblems.curpoint has pareto values)
pareto_values = [pareto(1:end).objective]';
figure('DefaultAxesFontSize',9);
figure(1);
ploss = pareto_values(:,1);
qloss = pareto_values(:,2);
scatter(ploss,qloss,'k.');
line(ploss,qloss);
   
figure(2);
plot(bestvolt0,'-sr')
hold on
plot(bestvolt1,'-^b')
ylabel('Voltage (p.u)')
xlabel('Node')
title('Voltage profile')
legend('Before Reconfig','After Reconfig')
hold off

data = loadcase(case83);
losses = pareto(end).objective;
posrat = pareto(end).parameter;
posgen = round(posrat(1:length(posrat)/4));
genbusid = data.bus(posgen,1);
ratgen = (posrat((length(posrat)/4+1):length(posrat)/2));
poscap = round(posrat((length(posrat)/2+1):length(posrat)*3/4));
capbusid = data.bus(poscap,1);
ratcap = (posrat((length(posrat)*3/4+1):length(posrat)));

fprintf('\n Minimum voltage before configuration %0.4f p.u.',minvolt0);
fprintf('\n Minimum voltage after configuration %0.4f p.u.',minvolt1);
fprintf('\n Active power loss before configuration %0.4f kW',ploss0);
fprintf('\n Active power loss after configuration %0.4f kW',losses(1));
fprintf('\n Reactive power loss before configuration %0.4f kVAR',qloss0);
fprintf('\n Reactive power loss after configuration %0.4f kVAR',losses(2));
fprintf('\n Position of Generator on bus %d',genbusid);
fprintf('\n Rating of Generator %0.2f kW',ratgen*1000);
fprintf('\n Position of Capacitor on bus %d',capbusid);
fprintf('\n Rating of Capacitor %0.2f kVAR',ratcap*1000);

