function loss = gencap(posrat)
global bestvolt0 minvolt0 bestvolt1 minvolt1 ploss0 qloss0;

%posrat = [7;19;34;53;71;81;2;2;2;2;2;2;7;19;33;52;71;79;2;2;2;1.72;1.936;2];
%posrat = [6;33;71;79;3;2.945;2.507;3;6;31;71;79;2.26;2.841;1.923;2.539];
posgen = round(posrat(1:length(posrat)/4));
ratgen = (posrat((length(posrat)/4+1):length(posrat)/2));
poscap = round(posrat((length(posrat)/2+1):length(posrat)*3/4));
ratcap = (posrat((length(posrat)*3/4+1):length(posrat)));

offbranch = (83:95);
%offbranch = [54 6 85 71 12 88 89 82 91 38 33 40 61];

data = loadcase(case83) ; 
data.branch(offbranch,11) = 0; % status '0' for off lines

mpopt = mpoption('pf.alg','NR','verbose',0,'out.all',0);
result0 = runpf(data,mpopt);
ploss0 = sum(result0.branch(:,14)+result0.branch(:,16))*1e3;
qloss0 = sum(result0.branch(:,15)+result0.branch(:,17))*1e3;

bestvolt0 = result0.bus(:,8);
minvolt0 = min(bestvolt0);

data.bus(posgen,3) = data.bus(posgen,3)-ratgen;
data.bus(poscap,4) = data.bus(poscap,4)-ratcap;

result1 = runpf(data,mpopt);
ploss = sum(result1.branch(:,14)+result1.branch(:,16))*1e3;
qloss = sum(result1.branch(:,15)+result1.branch(:,17))*1e3;

bestvolt1 = result1.bus(:,8);
minvolt1 = min(bestvolt1);

loss(1,:) = ploss;
loss(2,:) = qloss;