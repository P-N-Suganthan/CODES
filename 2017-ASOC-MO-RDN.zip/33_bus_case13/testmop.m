function mop = testmop(dimension)
%Get test multi-objective problems from a given name. 
%   The method get testing or benchmark problems for Multi-Objective
%   Optimization. The test problem will be encapsulated in a structure,
%   which can be obtained by function get_structure('testmop'). 
%   User get the corresponding test problem, which is an instance of class
%   mop, by passing the problem name and optional dimension parameters.

    mop=get_structure('testmop');
    mop=problems(mop,dimension);
    mop.od=2;
end

function p=problems(p,dim)
 p.pd=dim;
 
 p.domain=xboundary(dim);
 p.func=@gencap;
 
end

function range = xboundary(dim)
    range = zeros(dim,2);
    range(:,1)  = [3 0.2]; %input range and position of generator and capacitor
    range(:,2)  = [32 2.3];
    %range(:,1)  = [3 3 1.08 0.8964 3 3 0.2548 0.9323];
    %range(:,2)  = [32 32 1.08 0.8964 32 32 0.2548 0.9323];
    
end



