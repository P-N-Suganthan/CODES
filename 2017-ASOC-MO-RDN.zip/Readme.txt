MATLAB Code: 

Publication: Biswas, Partha P., et al. "A multiobjective approach for optimal placement 
and sizing of distributed generators and capacitors in distribution network." 
Applied Soft Computing 60 (2017): 268-280.

Please contact author: parthapr001@e.ntu.edu.sg for any query.