function params = loadparams(~)
%LOADPARAMS Load the parameter settings from external file.
% file format 
%   Detailed explanation goes here

    params = get_structure('parameter');
    % set the default!!

    % General Setting for MOEA/D
    params.seed = 177; % random seed.
    params.popsize = 600; % population size.
    params.niche = 60;  % neighbourhhood size
    params.dmethod = 'ts'; % decomposition method of choice.
    params.iteration = 500; % total iteration.
    params.evaluation = 50000; % total function evaluation number.
    %params.iteration = 2500; % total iteration.
    %params.evaluation = 300000; % total function evaluation number.

    % new MOEA/D setting.
    params.updateprob = 0.9; % percantege to update the neighbour or the whole population.
    params.updatenb = 0.01*params.popsize; % the maximum updation number of positions replaced by the better new solutions 
    %in each subproblem every generation. In CEC09 codes, params.updatenb=(0.01*params.popsize) as below.

    % DE setting.
    params.F = 0.5; % the F rate in DE.
    params.CR = 0.5; % the CR rate in DE.

    % R-MOEA/D specific setting.
    params.dynamic = 1; % weather to use R-MOEA/D or a normal MOEA/D, 1 for R-MOEA/D
    params.selportion = 5; % the selection percentage of in R-MOEA/D
    params.decayrate = 0.95; % the decay rate in R-MOEA/D
end

