function [lbest1,assign1]=binning_continuous(chromosome,NO,n,n_obj,n_bins,assign2,assign3,oldlbest);

for i = 1 : NO
    bin_size=(max(chromosome(:, n+assign2(i,1)))-min(chromosome(:, n+assign2(i,1))))/n_bins;
    min_bin_val(i)=(min(chromosome(:, n+assign2(i,1))))+ bin_size*(assign2(i,2)-1);
    max_bin_val(i)=(min(chromosome(:, n+assign2(i,1))))+ bin_size*(assign2(i,2));    
    flagg=0;
    while (isempty(find(min_bin_val(i)<= chromosome(:, n+assign2(i,1))  &   chromosome(:, n+assign2(i,1)) <min(max_bin_val(i),max(chromosome(:, n+assign2(i,1))))+0.0001)))
        if flagg==0
        assign2(i,2)=assign2(i,2)+1;
        if assign2(i,2)>=n_bins+1,
            flagg=1;
        end
        else assign2(i,2)=assign2(i,2)-1;
        end
        min_bin_val(i)=(min(chromosome(:, n+assign2(i,1))))+ bin_size*(assign2(i,2)-1);
        max_bin_val(i)=(min(chromosome(:, n+assign2(i,1))))+ bin_size*(assign2(i,2));
    end

    index=find(min_bin_val(i)<= chromosome(:, n+assign2(i,1))  &   chromosome(:, n+assign2(i,1)) <min(max_bin_val(i),max(chromosome(:, n+assign2(i,1))))+0.0001);
    if length(index)~=1
        in_chro=chromosome(index,:);
        index_min_front_chro = find(in_chro(:,n+n_obj+1) == min(in_chro(:,n+n_obj+1)));
        if length(index_min_front_chro) ~= 1
            min_front_chro=in_chro(index_min_front_chro,:);
            [S1,S11]=size(min_front_chro);
            D1 = sqrt(sum(abs( repmat(permute(min_front_chro(:,1:n), [1 3 2]), [1 1 1])- repmat(permute(oldlbest(i,1:n), [3 1 2]), [S1 1 1]) ).^2, 3));
            [pp,p]=sort(D1,'ascend');
            lbest1(i,:) = min_front_chro(p(1),:);
        else
            lbest1(i,:) = in_chro(index_min_front_chro,:);
        end
    else
        lbest1(i,:) = chromosome(index,:);
    end
    flagg=0;
    bin_size=(max(chromosome(:, n+assign3(i,1)))-min(chromosome(:, n+assign3(i,1))))/n_bins;
    if assign3(i,2)>=n_bins+1 
        assign3(i,2)=n_bins+1;
        min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
        max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));    
        while (isempty(find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) <min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001)))
            assign3(i,2)=assign3(i,2)-1;
            min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
            max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));
        end
        index=find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) <min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001);
        in_chro=chromosome(index,:);
        index_min_front_chro = find(in_chro(:,n+n_obj+1) == min(in_chro(:,n+n_obj+1)));
        min_front_chro=in_chro(index_min_front_chro,:);
        [S1,S11]=size(min_front_chro);
        D1 = sqrt(sum(abs( repmat(permute(min_front_chro(:,1:n), [1 3 2]), [1 1 1])- repmat(permute(lbest1(i,1:n), [3 1 2]), [S1 1 1]) ).^2, 3));
%         [pp,p]=sort(D1);
%         p1=find(D1(p,1)~=0);
        p1=find(D1~=0);
        while length(p1)==0
            assign3(i,2)=assign3(i,2)-1;
            min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
            max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));    
            while (isempty(find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) <min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001)))
                assign3(i,2)=assign3(i,2)-1;
                min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
                max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));
            end
            index=find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) <min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001);
            in_chro=chromosome(index,:);
            index_min_front_chro = find(in_chro(:,n+n_obj+1) == min(in_chro(:,n+n_obj+1)));
            min_front_chro=in_chro(index_min_front_chro,:);
            [S1,S11]=size(min_front_chro);
            D1 = sqrt(sum(abs( repmat(permute(min_front_chro(:,1:n), [1 3 2]), [1 1 1])- repmat(permute(lbest1(i,1:n), [3 1 2]), [S1 1 1]) ).^2, 3));
%             [pp,p]=sort(D1);
%             p1=find(D1(p,1)~=0);
            p1=find(D1~=0);
        end
        lowestfront1 = min_front_chro(p1,:);
        lowestfront1 (:,n+n_obj+3)=assign3(i,1);
        lowestfront1 (:,n+n_obj+4)=assign3(i,2);
    else
        min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
        max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));    
        while (isempty(find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) <min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001)))
            if flagg==0
                assign3(i,2)=assign3(i,2)+1;
                if assign3(i,2)>=n_bins+1 
                    assign3(i,2)=n_bins+1;
                    flagg=1;
                end
            else 
                assign3(i,2)=assign3(i,2)-1;
            end
            min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
            max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));
        end
        flagg=0;
        if assign3(i,2)>=n_bins+1 
            assign3(i,2)=n_bins+1;
            min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
            max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));    
            while (isempty(find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) <min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001)))
                assign3(i,2)=assign3(i,2)-1;
                min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
                max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));
            end
            index=find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) <min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001);
            in_chro=chromosome(index,:);
            index_min_front_chro = find(in_chro(:,n+n_obj+1) == min(in_chro(:,n+n_obj+1)));
            min_front_chro=in_chro(index_min_front_chro,:);
            [S1,S11]=size(min_front_chro);
            D1 = sqrt(sum(abs( repmat(permute(min_front_chro(:,1:n), [1 3 2]), [1 1 1])- repmat(permute(lbest1(i,1:n), [3 1 2]), [S1 1 1]) ).^2, 3));
%             [pp,p]=sort(D1);
%             p1=find(D1(p,1)~=0);
            p1=find(D1~=0);
            while length(p1)==0
                assign3(i,2)=assign3(i,2)-1;
                min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
                max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));    
                while (isempty(find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) <min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001)))
                    assign3(i,2)=assign3(i,2)-1;
                    min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
                    max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));
                end
                index=find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) <min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001);
                in_chro=chromosome(index,:);
                index_min_front_chro = find(in_chro(:,n+n_obj+1) == min(in_chro(:,n+n_obj+1)));
                min_front_chro=in_chro(index_min_front_chro,:);
                [S1,S11]=size(min_front_chro);
                D1 = sqrt(sum(abs( repmat(permute(min_front_chro(:,1:n), [1 3 2]), [1 1 1])- repmat(permute(lbest1(i,1:n), [3 1 2]), [S1 1 1]) ).^2, 3));
%                 [pp,p]=sort(D1);
%                 p1=find(D1(p,1)~=0);
                p1=find(D1~=0);
            end
            lowestfront1 = min_front_chro(p1,:);
            lowestfront1 (:,n+n_obj+3)=assign3(i,1);
            lowestfront1 (:,n+n_obj+4)=assign3(i,2);            
        else
            index=find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) <min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001);
            in_chro=chromosome(index,:);
            index_min_front_chro = find(in_chro(:,n+n_obj+1) == min(in_chro(:,n+n_obj+1)));
            min_front_chro=in_chro(index_min_front_chro,:);
            [S1,S11]=size(min_front_chro);
            D1 = sqrt(sum(abs( repmat(permute(min_front_chro(:,1:n), [1 3 2]), [1 1 1])- repmat(permute(lbest1(i,1:n), [3 1 2]), [S1 1 1]) ).^2, 3));
%             [pp,p]=sort(D1);
%             p1=find(D1(p,1)~=0);
            p1=find(D1~=0);
            while length(p1)==0
                if flagg==0
                    assign3(i,2)=assign3(i,2)+1;
                    if assign3(i,2)>=n_bins+1 
                        assign3(i,2)=n_bins+1;
                        flagg=1;
                    end
                else assign3(i,2)=assign3(i,2)-1;
                end
                min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
                max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));    
                while (isempty(find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) <min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001)))
                    if flagg==0
                        assign3(i,2)=assign3(i,2)+1;
                        if assign3(i,2)>=n_bins+1 
                            assign3(i,2)=n_bins+1;
                            flagg=1;
                        end
                    else 
                        assign3(i,2)=assign3(i,2)-1;
                    end
                    min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
                    max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));
                end
                index=find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) <min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001);
                in_chro=chromosome(index,:);
                index_min_front_chro = find(in_chro(:,n+n_obj+1) == min(in_chro(:,n+n_obj+1)));
                min_front_chro=in_chro(index_min_front_chro,:);
                [S1,S11]=size(min_front_chro);
                D1 = sqrt(sum(abs( repmat(permute(min_front_chro(:,1:n), [1 3 2]), [1 1 1])- repmat(permute(lbest1(i,1:n), [3 1 2]), [S1 1 1]) ).^2, 3));
%                 [pp,p]=sort(D1);
%                 p1=find(D1(p,1)~=0);
                p1=find(D1~=0);
            end
            lowestfront1 = min_front_chro(p1,:);
            lowestfront1 (:,n+n_obj+3)=assign3(i,1);
            lowestfront1 (:,n+n_obj+4)=assign3(i,2);
        end
    end
    lowestfront=lowestfront1;
    [S1,S11]=size(lowestfront);
    DD = sqrt(sum(abs( repmat(permute(lowestfront(:,1:n), [1 3 2]), [1 1 1])- repmat(permute(lbest1(i,1:n), [3 1 2]), [S1 1 1]) ).^2, 3));
    index_2ndlbs=find(DD>=(mean(DD)-0.000001));
    [qq,q]=sort(DD(index_2ndlbs,1));
    lbest1(NO+i,:)=lowestfront(index_2ndlbs(q(1),1),1:n+n_obj+2);
    assign3(i,:)=lowestfront(index_2ndlbs(q(1),1),n+n_obj+3:n+n_obj+4);
end
assign1=[assign2;assign3];