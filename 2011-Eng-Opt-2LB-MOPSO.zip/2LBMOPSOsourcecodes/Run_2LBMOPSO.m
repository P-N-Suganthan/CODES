clear all
warning off

func_num=8;
     
        if func_num==1,
            func='OKA2';                                             
            n=3;                                % # of dimension
            n_obj=2;                            % # of objective
            noofcon=0;                          % # of constrain 
            %xl=[-pi -5 -5];xu=[pi 5 5];        % low bound of dimension and high bound of dimension
            mm=1;                               % mm=1 minimization; mm=-1 maximization
        elseif func_num==2,                                          
            func='SYMPART';
            n=30;
            n_obj=2;
            noofcon=0;  
            %xl=-20*ones(1,n);xu=20*ones(1,n);
            mm=1;
        elseif func_num==3,                                          
            func='S_ZDT1';
            n=30;
            n_obj=2;
            noofcon=0;
            %xl=S_ZDT1_bound(1,1:30);xu=S_ZDT1_bound(2,1:30);
            mm=1;
        elseif func_num==4,                                          
            func='S_ZDT2';
            n=30;
            n_obj=2;
            noofcon=0;
            %xl=zeros(1,n);xu=ones(1,n);
            mm=1;
        elseif func_num==5,                                          
            func='S_ZDT4';
            n=30;
            n_obj=2;
            noofcon=0;
            %xl=S_ZDT4_bound(1,1:30);xu=S_ZDT4_bound(2,1:30);
            mm=1;
        elseif func_num==6,                                          
            func='R_ZDT4';         
            n=10;
            n_obj=2;
            noofcon=0;
            %xl=R_ZDT4_bound_10D(1,1:10);xu=R_ZDT4_bound_10D(2,1:10);
            mm=1;
        elseif func_num==7,                                          
            func='S_ZDT6';
            n=30;
            n_obj=2;
            noofcon=0;
            %xl=S_ZDT6_bound(1,1:30);xu=S_ZDT6_bound(2,1:30);
            mm=1;
        elseif func_num==8,
            func='S_DTLZ2';
            n=30;
            n_obj=3;
            noofcon=0;
            mm=1;
        elseif func_num==9,
            func='R_DTLZ2';
            n=30;
            n_obj=3;
            noofcon=0;
            mm=1;
        elseif func_num==10,
            func='S_DTLZ3';
            n=30;
            n_obj=3;
            noofcon=0;
            mm=1;
        elseif func_num==11,
            func='WFG1';
            n=24;
            n_obj=3;
            noofcon=0;
            mm=1;
        elseif func_num==12,
            func='WFG8';
            n=24;
            n_obj=3;
            noofcon=0;
            mm=1;
        elseif func_num==13,
            func='WFG9';
            n=24;
            n_obj=3;
            noofcon=0;
            mm=1;
        elseif func_num==14,
            func='S_DTLZ2';
            n=30;
            n_obj=5;
            noofcon=0;
            mm=1;
        elseif func_num==15,
            func='R_DTLZ2';
            n=30;
            n_obj=5;
            noofcon=0;
            mm=1;
        elseif func_num==16,
            func='S_DTLZ3';
            n=30;
            n_obj=5;
            noofcon=0;
            mm=1;
        elseif func_num==17,
            func='WFG1';
            n=28;
            n_obj=5;
            noofcon=0;
            mm=1;
        elseif func_num==18,
            func='WFG8';
            n=28;
            n_obj=5;
            noofcon=0;
            mm=1;
        elseif func_num==19,
            func='WFG9';
            n=28;
            n_obj=5;
            noofcon=0;
            mm=1;
        end
      
    no_count=5;%2;4;6;8;10;                        % # of count
    no_bins=10;%10;%5;8;10;12;15;20;               % # of bins
    NP=50;                                         % population size
    Max_FES=10000;                                 % max function evaluations
    Max_Gen=ceil(Max_FES/NP);                      % max generations
    if n_obj==2,
        max_rep_size=100;                          % max size of external archive
    elseif n_obj==3;
        max_rep_size=150;
    else
        max_rep_size=800;
    end
    
    if (func_num==6)
        eval(['load ' func '_bound_10D.dat;'])
        eval(['bound=' func '_bound_10D;'])   
        xl=bound(1,1:n);
        xu=bound(2,1:n);
    elseif (func_num==9 | func_num==15)
        eval(['load ' func '_bound_30D.dat;'])
        eval(['bound=' func '_bound_30D;'])   
        xl=bound(1,1:n);
        xu=bound(2,1:n);
    elseif (func_num==1)
        xl=[-pi -5 -5];
        xu=[pi 5 5];
    elseif (func_num==2)
        xl=-20*ones(1,n);
        xu=20*ones(1,n);
    elseif (func_num==11 | func_num==12 | func_num==13 | func_num==17 | func_num==18 | func_num==19)
        xl=zeros(1,n);
        xu=2*(1:n);
    else
        eval(['load ' func '_bound.dat;'])
        eval(['bound=' func '_bound;'])
        xl=bound(1,1:n);
        xu=bound(2,1:n);
    end
    fname='mfsuite';
    D=n;       
    XRmin=xl;
    XRmax=xu;
    Lbound=xl;
    Ubound=xu;
    
    for run=1:25
    [nds,nds_val,feval_count]=TwoLBMOPSO(fname,func,Max_FES,n,XRmin,XRmax,NP,max_rep_size,n_obj,noofcon,xl,xu,mm,run,no_count,no_bins,func_num)
    end   
    