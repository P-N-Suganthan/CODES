function [lbest,assign]=binning_initail(chromosome,NP,n,n_obj,n_bins);

assign2=[ceil(rand(NP,1)*n_obj),  ceil(rand(NP,1)*n_bins)];
assign3=[assign2(:,1)];
assign3t=zeros(NP,2);
% assign3=[ceil(rand(NP,1)*n_obj];
%edge_obj=[];
for i = 1 : NP
    bin_size=(max(chromosome(:, n+assign2(i,1)))-min(chromosome(:, n+assign2(i,1))))/n_bins;
    min_bin_val(i)=(min(chromosome(:, n+assign2(i,1))))+ bin_size*(assign2(i,2)-1);
    max_bin_val(i)=(min(chromosome(:, n+assign2(i,1))))+ bin_size*(assign2(i,2));    
    while (isempty(find(min_bin_val(i)<= chromosome(:, n+assign2(i,1))  &   chromosome(:, n+assign2(i,1)) < min(max_bin_val(i),max(chromosome(:, n+assign2(i,1))))+0.0001)))
        assign2(i,2)=assign2(i,2)-1;
        min_bin_val(i)=(min(chromosome(:, n+assign2(i,1))))+ bin_size*(assign2(i,2)-1);
        max_bin_val(i)=(min(chromosome(:, n+assign2(i,1))))+ bin_size*(assign2(i,2));
    end
%     assign3(i,2)=assign2(i,2)+1;
    assign3(i,2)=assign2(i,2);
    index=find(min_bin_val(i)<= chromosome(:, n+assign2(i,1))  &   chromosome(:, n+assign2(i,1)) < min(max_bin_val(i),max(chromosome(:, n+assign2(i,1))))+0.0001);
    if length(index)~=1
        in_chro=chromosome(index,:);
        index_min_front_chro = find(in_chro(:,n+n_obj+1) == min(in_chro(:,n+n_obj+1)));
        if length(index_min_front_chro) ~= 1
            min_front_chro=in_chro(index_min_front_chro,:);
            inex_max_dist_chro = find(min_front_chro(:,n+n_obj+2) == max(min_front_chro(:,n+n_obj+2)));
            lbest(i,:) = min_front_chro(inex_max_dist_chro(1),:);
        else
            lbest(i,:) = in_chro(index_min_front_chro,:);
        end
    else
        lbest(i,:) = chromosome(index,:);
    end
%     assign3(i,2)=ceil((lbest(i,n+assign3(i,1))-min(chromosome(i,n+assign3(i,1))))/bin_size)+1;
    
    if assign3(i,2)>=n_bins+1 
%         assign3(i,2)=n_bins-1;
        assign3(i,2)=n_bins;
        min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
        max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));    
        while (isempty(find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001)))
            assign3(i,2)=assign3(i,2)-1;
            min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
            max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));
        end
        index=find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001);
        in_chro=chromosome(index,:);
        index_min_front_chro = find(in_chro(:,n+n_obj+1) == min(in_chro(:,n+n_obj+1)));
        min_front_chro=in_chro(index_min_front_chro,:);
        [S1,S11]=size(min_front_chro);
        D1 = sqrt(sum(abs( repmat(permute(min_front_chro(:,1:n), [1 3 2]), [1 1 1])- repmat(permute(lbest(i,1:n), [3 1 2]), [S1 1 1]) ).^2, 3));
        [pp1,p1]=sort(D1);
        lbest(NP+i,:) = min_front_chro(p1(1),:);
    else
        min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
        max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));    
        while (isempty(find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001)))
            assign3(i,2)=assign3(i,2)+1;
            min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
            max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));
        end
        if assign3(i,2)>=n_bins+1 
%             assign3(i,2)=n_bins-1;
            assign3(i,2)=n_bins;
            min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
            max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));    
            while (isempty(find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001)))
                assign3(i,2)=assign3(i,2)-1;
                min_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2)-1);
                max_bin_value(i)=(min(chromosome(:, n+assign3(i,1))))+ bin_size*(assign3(i,2));
            end
            index=find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001);
            in_chro=chromosome(index,:);
            index_min_front_chro = find(in_chro(:,n+n_obj+1) == min(in_chro(:,n+n_obj+1)));
            min_front_chro=in_chro(index_min_front_chro,:);
            [S1,S11]=size(min_front_chro);
            D1 = sqrt(sum(abs( repmat(permute(min_front_chro(:,1:n), [1 3 2]), [1 1 1])- repmat(permute(lbest(i,1:n), [3 1 2]), [S1 1 1]) ).^2, 3));
            [pp1,p1]=sort(D1);
            lbest(NP+i,:) = min_front_chro(p1(1),:);            
        else
            index=find(min_bin_value(i)<= chromosome(:, n+assign3(i,1))  &   chromosome(:, n+assign3(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3(i,1))))+0.0001);
            in_chro=chromosome(index,:);
            index_min_front_chro = find(in_chro(:,n+n_obj+1) == min(in_chro(:,n+n_obj+1)));
            min_front_chro=in_chro(index_min_front_chro,:);
            [S1,S11]=size(min_front_chro);
            D1 = sqrt(sum(abs( repmat(permute(min_front_chro(:,1:n), [1 3 2]), [1 1 1])- repmat(permute(lbest(i,1:n), [3 1 2]), [S1 1 1]) ).^2, 3));
            [pp1,p1]=sort(D1);
            lbest(NP+i,:) = min_front_chro(p1(1),:);
        end
    end
    assign3t(i,1)=ceil(rand(1,1)*n_obj);
    while (assign3t(i,1)==assign3(i,1))
        assign3t(i,1)=ceil(rand(1,1)*n_obj);
    end
    bin_size=(max(chromosome(:, n+assign3t(i,1)))-min(chromosome(:, n+assign3t(i,1))))/n_bins;
%     assign3t(i,2)=ceil((lbest(i,n+assign3t(i,1))-min(chromosome(:,n+assign3t(i,1))))/bin_size)+1;
    assign3t(i,2)=ceil((lbest(i,n+assign3t(i,1))-min(chromosome(:,n+assign3t(i,1))))/bin_size);
    if assign3t(i,2)>=n_bins+1 
%         assign3t(i,2)=n_bins-1;
        assign3t(i,2)=n_bins;
        min_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2)-1);
        max_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2));    
        while (isempty(find(min_bin_value(i)<= chromosome(:, n+assign3t(i,1))  &   chromosome(:, n+assign3t(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3t(i,1))))+0.0001)))
            assign3t(i,2)=assign3t(i,2)-1;
            min_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2)-1);
            max_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2));
        end
        index=find(min_bin_value(i)<= chromosome(:, n+assign3t(i,1))  &   chromosome(:, n+assign3t(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3t(i,1))))+0.0001);
        in_chro=chromosome(index,:);
        index_min_front_chro = find(in_chro(:,n+n_obj+1) == min(in_chro(:,n+n_obj+1)));
        min_front_chro=in_chro(index_min_front_chro,:);
        [S1,S11]=size(min_front_chro);
        D2 = sqrt(sum(abs( repmat(permute(min_front_chro(:,1:n), [1 3 2]), [1 1 1])- repmat(permute(lbest(i,1:n), [3 1 2]), [S1 1 1]) ).^2, 3));
        [pp2,p2]=sort(D2);
        lbest(2*NP+i,:) = min_front_chro(p2(1),:);
    else
        min_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2)-1);
        max_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2));    
        while (isempty(find(min_bin_value(i)<= chromosome(:, n+assign3t(i,1))  &   chromosome(:, n+assign3t(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3t(i,1))))+0.0001)))
            assign3t(i,2)=assign3t(i,2)+1;
            min_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2)-1);
            max_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2));
        end
        if assign3t(i,2)>=n_bins+1 
%             assign3t(i,2)=n_bins-1;
            assign3t(i,2)=n_bins;
            min_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2)-1);
            max_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2));    
            while (isempty(find(min_bin_value(i)<= chromosome(:, n+assign3t(i,1))  &   chromosome(:, n+assign3t(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3t(i,1))))+0.0001)))
                assign3t(i,2)=assign3t(i,2)-1;
                min_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2)-1);
                max_bin_value(i)=(min(chromosome(:, n+assign3t(i,1))))+ bin_size*(assign3t(i,2));
            end
            index=find(min_bin_value(i)<= chromosome(:, n+assign3t(i,1))  &   chromosome(:, n+assign3t(i,1)) < max_bin_value(i));
            in_chro=chromosome(index,:);
            index_min_front_chro = find(in_chro(:,n+n_obj+1) == min(in_chro(:,n+n_obj+1)));
            min_front_chro=in_chro(index_min_front_chro,:);
            [S1,S11]=size(min_front_chro);
            D2 = sqrt(sum(abs( repmat(permute(min_front_chro(:,1:n), [1 3 2]), [1 1 1])- repmat(permute(lbest(i,1:n), [3 1 2]), [S1 1 1]) ).^2, 3));
            [pp2,p2]=sort(D2);
            lbest(2*NP+i,:) = min_front_chro(p2(1),:);            
        else
            index=find(min_bin_value(i)<= chromosome(:, n+assign3t(i,1))  &   chromosome(:, n+assign3t(i,1)) < min(max_bin_value(i),max(chromosome(:, n+assign3t(i,1))))+0.0001);
            in_chro=chromosome(index,:);
            index_min_front_chro = find(in_chro(:,n+n_obj+1) == min(in_chro(:,n+n_obj+1)));
            min_front_chro=in_chro(index_min_front_chro,:);
            [S1,S11]=size(min_front_chro);
            D2 = sqrt(sum(abs( repmat(permute(min_front_chro(:,1:n), [1 3 2]), [1 1 1])- repmat(permute(lbest(i,1:n), [3 1 2]), [S1 1 1]) ).^2, 3));
            [pp2,p2]=sort(D2);
            lbest(2*NP+i,:) = min_front_chro(p2(1),:);
        end
    end
    index_f1=lbest(NP+i,n+n_obj+1);
    index_f2=lbest(2*NP+i,n+n_obj+1);
    if index_f1>index_f2
        lbest(NP+i,:)=lbest(2*NP+i,:);assign3(i,:)=assign3t(i,:);
    elseif index_f1==index_f2
        if D1(p1(1))>D2(p2(1)),
            lbest(NP+i,:)=lbest(2*NP+i,:);
            assign3(i,:)=assign3t(i,:);
        end
    end
end
lbest=lbest(1:2*NP,:);
assign=[assign2;assign3];