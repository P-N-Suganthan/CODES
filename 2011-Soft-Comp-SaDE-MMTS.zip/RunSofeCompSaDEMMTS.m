
clear all
% close all

warning off
global initial_flag; % the global flag used in test suite
NP=60; % population size
D =1000; % dimensionality of benchmark functions
Max_FES=5000*D;   % maximal number of FEs
runs = 25; % number of independent runs for each function
func=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19];
for funcnum = 1:19
   func_num = func(funcnum);
   % set the lower and upper bound for each function
   if (func_num == 1 | func_num == 2 | func_num == 3)
      VRmin = -100;
      VRmax = 100;
   end
   if (func_num == 4)
      VRmin = -5;
      VRmax = 5;
   end
   if (func_num == 5)
      VRmin = -600;
      VRmax = 600;
   end
   if (func_num == 6)
      VRmin = -32;
      VRmax = 32;
   end

   if func_num == 7
      fctn='f_Schwefel2_22';
      n_obj=1;
      VRmin = -10;
      VRmax = 10;
   end
   if func_num == 8
      fctn='f_Schwefel1_2';
      n_obj=1;       
      VRmin = -65.536;
      VRmax = 65.536;
   end
   if func_num == 9
      fctn='Extended_f_10';
      n_obj=1;       
      VRmin = -100;
      VRmax = 100;
   end
   if func_num == 10
      fctn='f_Bohachevsky';
      n_obj=1;
      VRmin = -15;
      VRmax = 15;
   end
   if func_num == 11
      fctn='f_Schaffer';
      n_obj=1;
      VRmin = -100;
      VRmax = 100;
   end
   if func_num == 12
      fctn='f_Hybrid_12';
      n_obj=1;       
      VRmin = -100;
      VRmax = 100;
   end
   if func_num == 13
      fctn='f_Hybrid_13';
      n_obj=1;       
      VRmin = -100;
      VRmax = 100;
   end
   if func_num == 14
      fctn='f_Hybrid_14';
      n_obj=1;       
      VRmin = -5;
      VRmax = 5;
   end
   if func_num == 15
      fctn='f_Hybrid_15';
      n_obj=1;
      VRmin = -10;
      VRmax = 10;
   end
   if func_num == 16
      fctn='f_Hybrid_16new';
      n_obj=1;       
      VRmin = -100;
      VRmax = 100;
   end
   if func_num == 17
      fctn='f_Hybrid_17new';
      n_obj=1;       
      VRmin = -100;
      VRmax = 100;
   end
   if func_num == 18
      fctn='f_Hybrid_18new';
      n_obj=1;       
      VRmin = -5;
      VRmax = 5;
   end
   if func_num == 19
      fctn='f_Hybrid_19new';
      n_obj=1;       
      VRmin = -10;
      VRmax = 10;
   end

for run=1:runs
    initial_flag = 0; % should set the flag to 0 for each run, each function
    func_num,run
    numst=3; %number of self-adaptive strategies
    CR=[0.9,0.2,0.9];
    Fmean=0.5;
    initXmax=ones(1,D)*VRmax;
    initXmin=ones(1,D)*VRmin;
    XRmax=initXmax;
    XRmin=initXmin;
    Ubound=XRmax;
    Lbound=XRmin;       
    [DE_gbest,DE_gbestval,DE_fitcount] = DE_LS_NichingMemory(func_num,Max_FES,D,XRmin,XRmax,Lbound,Ubound,NP,Fmean,CR,numst,run);
end
end

