function f=benchmark_func(x,func_num)

%javaclasspath('FractalFunctions.jar')
global initial_flag
persistent fhd f_bias
initial_flag=0;
if initial_flag==0
    if func_num==1      fhd=str2func('sphere_shift_func'); %[-100,100]
    elseif func_num==2  fhd=str2func('schwefel_func'); %[-100, 100]
    elseif func_num==3  fhd=str2func('rosenbrock_shift_func'); %[-100,100]
    elseif func_num==4  fhd=str2func('rastrigin_shift_func'); %[-5,5]
    elseif func_num==5  fhd=str2func('griewank_shift_func'); %[-600,600]
    elseif func_num==6  fhd=str2func('ackley_shift_func'); %[-32,32]
    elseif func_num==7  fhd=str2func('f_Schwefel2_22'); %[-1,1] 
    elseif func_num==8  fhd=str2func('f_Schwefel1_2');
    elseif func_num==9  fhd=str2func('Extended_f_10');
    elseif func_num==10 fhd=str2func('f_Bohachevsky');
    elseif func_num==11 fhd=str2func('f_Schaffer');
    elseif func_num==12 fhd=str2func('f_Hybrid_12');
    elseif func_num==13 fhd=str2func('f_Hybrid_13');
    elseif func_num==14 fhd=str2func('f_Hybrid_14');
    elseif func_num==15 fhd=str2func('f_Hybrid_15');
    elseif func_num==16 fhd=str2func('f_Hybrid_16new');
    elseif func_num==17 fhd=str2func('f_Hybrid_17new');
    elseif func_num==18 fhd=str2func('f_Hybrid_18new');
    elseif func_num==19 fhd=str2func('f_Hybrid_19new');        
    end
    %f_bias = [-450 -450 390 -330 -180 -140 0];
    load fbias_data;
end

if func_num<=6
    f=feval(fhd,x)+f_bias(func_num);
else f=feval(fhd,x);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%Unimodal%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 	1.Shifted Sphere Function 
function fit=sphere_shift_func(x)
global initial_flag
persistent o
[ps,D]=size(x);
if initial_flag==0
    load sphere_shift_func_data
    if length(o)>=D
         o=o(1:D);
    else
         o=-100+200*rand(1,D);
    end
    initial_flag=1;
end
x=x-repmat(o,ps,1);
fit=sum(x.^2,2);

% 2. Shifted Schwefel's Problem 2.21
function fit = schwefel_func(x)
   global initial_flag
   persistent o
   [ps, D] = size(x);
   if (initial_flag == 0)
      load schwefel_shift_func_data
      if length(o) >= D
          o=o(1:D);
      else
          o=-100+200*rand(1,D);
      end
      initial_flag = 1;
   end
   x=x-repmat(o,ps,1);
   fit = max(abs(x), [], 2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%Multimodal%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 	3.Shifted Rosenbrock's Function
function f=rosenbrock_shift_func(x)
global initial_flag
persistent o
[ps,D]=size(x);
if initial_flag==0
    load rosenbrock_shift_func_data
    if length(o)>=D
         o=o(1:D);
    else
         o=-90+180*rand(1,D);
    end
    initial_flag=1;
end
x=x-repmat(o,ps,1)+1;
f=sum(100.*(x(:,1:D-1).^2-x(:,2:D)).^2+(x(:,1:D-1)-1).^2,2);

% 4.Shifted Rastrign's Function
function f=rastrigin_shift_func(x)
global initial_flag
persistent o
[ps,D]=size(x);
if initial_flag==0
    load rastrigin_shift_func_data
    if length(o)>=D
         o=o(1:D);
    else
         o=-5+10*rand(1,D);
    end
    initial_flag=1;
end
x=x-repmat(o,ps,1);
f=sum(x.^2-10.*cos(2.*pi.*x)+10,2);

% 5.Shifted Griewank's Function
function f=griewank_shift_func(x)
global initial_flag
persistent o
[ps,D]=size(x);
if initial_flag==0
    load griewank_shift_func_data
    if length(o)>=D
         o=o(1:D);
    else
         o=-600+1200*rand(1,D);
    end
    o=o(1:D);
    initial_flag=1;
end
x=x-repmat(o,ps,1);
f=1;
for i=1:D
    f=f.*cos(x(:,i)./sqrt(i));
end
f=sum(x.^2,2)./4000-f+1;

% 	6.Shifted Ackley's Function
function f=ackley_shift_func(x)
global initial_flag
persistent o
[ps,D]=size(x);
if initial_flag==0
    load ackley_shift_func_data
    if length(o)>=D
         o=o(1:D);
    else
         o=-30+60*rand(1,D);
    end
    initial_flag=1;
end
x=x-repmat(o,ps,1);
f=sum(x.^2,2);
f=20-20.*exp(-0.2.*sqrt(f./D))-exp(sum(cos(2.*pi.*x),2)./D)+exp(1);

function f=f_Schwefel2_22(x)
global initial_flag
[ps,D]=size(x);
if initial_flag==0
    load f_Schwefel2_22_data
    currentGen=0;
    sum = 0.0;
    prod = 1.0;
    for i = 1:D
        currentGen = abs(x(i)-o(i));
        sum = sum+currentGen;
        prod = prod*currentGen;
    end
end
f=sum + prod;

function f=f_Schwefel2_22Noshift(x)
global initial_flag
[ps,D]=size(x);
if initial_flag==0
    currentGen=0;
    sum = 0.0;
    prod = 1.0;
    for i = 1:D
        currentGen = abs(x(i));
        sum = sum+currentGen;
        prod = prod*currentGen;
    end
end
f=sum + prod;
    
function f=f_Schwefel1_2(x)
global initial_flag
[ps,D]=size(x);
if initial_flag==0
    load f_Schwefel1_2_data
   	Sum=0.0;
    Val=0.0;
	for i = 1:D
	    Val = Val+x(i)-o(i);
	    Sum = Sum + Val * Val;
    end
end
f=Sum;

function f=f_10(x,y)
    p=(x*x+y*y);
    z=p^0.25;
    t=sin(50.0*(p^0.1));
    t=t*t+1.0;
    f=z*t;

function f=Extended_f_10(x)
global initial_flag
[ps,D]=size(x);
if initial_flag==0
    load Extended_f_10_data
    suma=0.0;
    for i=1:D-1
        suma=suma+f_10(x(i)-o(i), x(i+1)-o(i+1));
    end
end
suma=suma+f_10(x(D)-o(D), x(1)-o(1));
f=suma;

function f=Extended_f_10Noshift(x)
global initial_flag
[ps,D]=size(x);
if initial_flag==0
    suma=0.0;
    for i=1:D-1
        suma=suma+f_10(x(i), x(i+1));
    end
end
suma=suma+f_10(x(D), x(1));
f=suma;

function f=f_Bohachevsky(x)
global initial_flag
[ps,D]=size(x);
if initial_flag==0
    load f_Bohachevsky_data
    PI = 3.141592653589793;
    sum = 0.0;
    currentGen=0;
    nextGen=0;
    for i = 1:D-1;
        currentGen = x(i)-o(i);
        nextGen = x(i+1)-o(i+1);
        sum = sum+ currentGen * currentGen + 2.0 * nextGen * nextGen;
        sum = sum-0.3 * cos(3.0 * PI * currentGen) -0.4 * cos(4.0 * PI * nextGen) + 0.7;
    end
end
f=sum;

function f=f_BohachevskyNoshift(x)
global initial_flag
[ps,D]=size(x);
if initial_flag==0
    PI = 3.141592653589793;
    sum = 0.0;
    currentGen=0;
    nextGen=0;
    for i = 1:D-1;
        currentGen = x(i);
        nextGen = x(i+1);
        sum = sum+ currentGen * currentGen + 2.0 * nextGen * nextGen;
        sum = sum-0.3 * cos(3.0 * PI * currentGen) -0.4 * cos(4.0 * PI * nextGen) + 0.7;
    end
end
f=sum;

function f=f_Schaffer(x)
global initial_flag
[ps,D]=size(x);
if initial_flag==0
    load f_Schaffer_data
    sum=0;
    aux=0;
    aux2=0;
    currentGen=0;
    nextGen=0;
    for i = 1:D-1 
        currentGen = x(i)-o(i);
        currentGen = currentGen * currentGen;
        nextGen = x(i+1)-o(i+1);
        nextGen = nextGen * nextGen;
        aux = currentGen + nextGen;
        aux2 = sin(50. * (aux^0.1));
        sum = sum+(aux^0.25) * (aux2 * aux2 + 1.0);
    end
end
f=sum;

function [part1, part2]=divideFunctions(D, x, m)
    shared=0;
    rest=0;
    total=0;
    part1=[];
    part2=[];
    if (m <= 0.5) 
        shared = floor(D*m);
        rest = 2*shared;
        for i = 1:shared
        part1(i) = x(i*2);
        part2(i) = x(i*2-1);
        end
        total = D-shared;
        for i = 1:(total-shared)
            part2(i+shared) = x(i+rest);
        end
    else
        m = 1-m;
        shared = floor(D*m);
        rest = 2*shared;
        for i = 1:shared
        part1(i) = x(i*2);
        part2(i) = x(i*2-1);
        end
        total = D-shared;
        for i = 1:(total-shared)
            part1(i+shared) = x(i+rest);
        end
    end

    
function f=f_Hybrid_12(x) 
global initial_flag
[ps,D]=size(x);
m=0.25;
if initial_flag==0
    [part1, part2]=divideFunctions(D, x, m);
    f1=Extended_f_10Noshift(part1);
    f2=sphere_shift_func(part2);
    f1=max(f1,0);
    f1=max(f2,0);
    f= f1+f2;
end

function f=f_Hybrid_13(x) 
global initial_flag
[ps,D]=size(x);
m=0.25;
if initial_flag==0
    [part1, part2]=divideFunctions(D, x, m);
    f1=Extended_f_10Noshift(part1);
    f2=rosenbrock_shift_func(part2);

    f= f1+f2;
end

function f=f_Hybrid_14(x) 
global initial_flag
[ps,D]=size(x);
m=0.25;
if initial_flag==0
    [part1, part2]=divideFunctions(D, x, m);
    f1=Extended_f_10Noshift(part1);
    f2=rastrigin_shift_func(part2);

    f= f1+f2;
end

function f=f_Hybrid_15(x) 
global initial_flag
[ps,D]=size(x);
m=0.25;
if initial_flag==0
    load f_Hybrid_15_data
    for i = 1:D
	    x(i) = x(i)-o(i);
    end
    [part1, part2]=divideFunctions(D, x, m);
    f1=f_BohachevskyNoshift(part1);
    f2=f_Schwefel2_22Noshift(part2);

    f= f1+f2;
end

function f=f_Hybrid_16new(x) 
global initial_flag
[ps,D]=size(x);
m=0.75;
if initial_flag==0
    [part1, part2]=divideFunctions(D, x, m);
    f1=Extended_f_10Noshift(part1);
    f2=sphere_shift_func(part2);
    f1=max(f1,0);
    f1=max(f2,0);
    f= f1+f2;
end

function f=f_Hybrid_17new(x) 
global initial_flag
[ps,D]=size(x);
m=0.75;
if initial_flag==0
    [part1, part2]=divideFunctions(D, x, m);
    f1=Extended_f_10Noshift(part1);
    f2=rosenbrock_shift_func(part2);

    f= f1+f2;
end

function f=f_Hybrid_18new(x) 
global initial_flag
[ps,D]=size(x);
m=0.75;
if initial_flag==0
    [part1, part2]=divideFunctions(D, x, m);
    f1=Extended_f_10Noshift(part1);
    f2=rastrigin_shift_func(part2);

    f= f1+f2;
end

function f=f_Hybrid_19new(x) 
global initial_flag
[ps,D]=size(x);
m=0.75;
if initial_flag==0
    load f_Hybrid_19new_data
    for i = 1:D
	    x(i) = x(i)-o(i);
    end
    [part1, part2]=divideFunctions(D, x, m);
    f1=f_BohachevskyNoshift(part1);
    f2=f_Schwefel2_22Noshift(part2);

    f= f1+f2;
end 
%%%%% end of file %%%%%

