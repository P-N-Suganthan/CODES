function [DE_gbest,DE_gbestval,DE_fitcount] = SaDE(func_num,Max_FES,D,XRmin,XRmax,Lbound,Ubound,NP,F,CR,numst,run);

ccmhist=[]; % recording the usage history of CR values
pfithist=[]; % 
DE_get_flag = 0; 
DE_fit_cut = Max_FES;
DE_fitcount=0;
threshold_Time=0; 
aaaa=cell(1,numst); %CR for each strategy
learngen=50; % learning period for SaDE
lpcount=[];
npcount=[];
ns=[];
nf=[];
pfit=ones(1,numst);
ccm = CR;
startTime = clock;

numch=20*D; % No. of FEs arranged to SaDE in each search circle
recorditer=50*D; % recording interval for convergenc plot, can be defined by users themselves
lsbuffersize=4; % No. of MMTS search agents
eflag=1; % initialization of fitness improvement of MMTS search agents, eflag==0, no improvement on the fitness.
sssflag=0; % selecting flag of different factors base on self-adaptation for initialization of MMTS step size during each MMTS stage
FEsassign=zeros(1,4); % The matix for recording the No. of fitness improvement & No. of FEs for SaDE and MMTS in each search circle
record_flag=0; % recording flag for 3 stages, FEs=120k, 600k and 3m

%-----Initialize population and some arrays-------------------------------
pop = zeros(NP,D); %initialize pop to gain speed
XRRmin=repmat(XRmin,NP,1);
XRRmax=repmat(XRmax,NP,1);
% rand('state',state_no);
rand('state',sum(100*clock));%%%%CHANGE
pop=XRRmin+(XRRmax-XRRmin).*rand(NP,D);

popold    = zeros(size(pop));     % toggle population
val       = zeros(1,NP);          % create and reset the "cost array"
DE_gbest   = zeros(1,D);           % best population member ever
DE_fitcount    = 0;                    % number of function evaluations
bFunValue=[];
%------Evaluate the best member after initialization----------------------
ibest   = 1;                      % start with first population member
val(1)  = benchmark_func(pop(ibest,:),func_num); 
DE_gbestval = val(1);                 % best objective function value so far
DE_fitcount  = DE_fitcount + 1;
bFunValue=[bFunValue DE_gbestval];
for i=2:NP                        % check the remaining members
    val(i) = benchmark_func(pop(i,:),func_num); 
    DE_fitcount  = DE_fitcount + 1;
    if (val(i) < DE_gbestval)           % if member is better
        ibest   = i;                 % save its location
        DE_gbestval = val(i);
    end   
 bFunValue=[bFunValue DE_gbestval];
end
DE_gbest = pop(ibest,:);         % best member of current iteration
ccmhist = [1,ccm];
pfithist = [1,pfit/sum(pfit)];
%------DE-Minimization---------------------------------------------
%------popold is the population which has to compete. It is--------
%------static through one iteration. pop is the newly--------------
%------emerging population.----------------------------------------

pm1 = zeros(NP,D);              % initialize population matrix 1
pm2 = zeros(NP,D);              % initialize population matrix 2
ui  = zeros(NP,D);              % intermediate population of perturbed vectors
mui = zeros(NP,D);              % mask for intermediate population
mpo = zeros(NP,D);              % mask for old population
a1  = zeros(NP);                % index array
a2  = zeros(NP);                % index array

p=0.5; % ratio for pbests selection in JADE mutation
    if size(val,1)==1
        value=val';
    end
arch=[pop value];
upb=repmat(XRmax(1,:),D,1);
lowb=repmat(XRmin(1,:),D,1);
eval(['fid=fopen(''SaDE_MMTS_gbestval_' num2str(func_num) '_' num2str(run) '.txt'',''w'');' ]);
fprintf(fid,'%e\n',DE_gbestval);
fclose(fid);
T=3;
lastgbestval=DE_gbestval;
lastfitcount=DE_fitcount;
archive=arch; % JADE archive
iter = 1;
while DE_fitcount < Max_FES-50*D
    DE_fitcount
    DE_gbestval
    popold = pop;                   % save the old population
    a1  = randperm(NP);             % shuffle locations of vectors
    popAll = [popold; archive(:,1:D)];
    popAll = unique(popAll,'rows');
    a2  = floor(rand(1,NP)*size(popAll,1))+1;      % rotate vector locations
    
    pm1 = popold(a1,:);             % shuffled population 1
    pm2 = popAll(a2,:);             % shuffled population 2
    
    % Find the p-best solutions
        pNP = max(round(p*NP), 2);              % choose at least two best solutions
        randindex = ceil(rand(1, NP) * pNP);    % select from [1, 2, 3, ..., pNP]
        randindex = max(1, randindex);          % to avoid the problem that rand = 0 and thus ceil(rand) = 0
        pbest = archive(randindex,1:D);      % randomly choose one of the top 100p% archive

% assign the new CR values by self-adaptation
    if (iter>=learngen) 
        for i=1:numst
            if   ~isempty(aaaa{i}) 
                ccm(i)=median(aaaa{i}(:,1));   
                d_index=find(aaaa{i}(:,2)==aaaa{i}(1,2));
                aaaa{i}(d_index,:)=[];
            else
                ccm(i)=rand;
            end
        end
    end
    
    for i=1:numst
        cc_tmp=[];
        for k=1:NP
            tt=normrnd(ccm(i),0.1);
            while tt>1 || tt<0
                tt=normrnd(ccm(i),0.1);
            end
            cc_tmp=[cc_tmp;tt];;
        end
        cc(:,i)=cc_tmp;
    end
    
    % Stochastic universal sampling               %choose strategy
    rr=rand;    
    spacing=1/NP;
    randnums=sort(mod(rr:spacing:1+rr-0.5*spacing,1));      
    normfit=pfit/sum(pfit);
    partsum=0;   
    count(1)=0; 
    stpool=[];
    
    for i=1:length(pfit)
        partsum=partsum+normfit(i);
        count(i+1)=length(find(randnums<partsum));
        select(i,1)=count(i+1)-count(i);
        stpool=[stpool;ones(select(i,1),1)*i];
    end
    stpool = stpool(randperm(NP));
    
    for i=1:numst
        atemp=zeros(1,NP);
        aaa{i}=atemp;
        index{i}=[];
        if ~isempty(find(stpool == i))
            index{i} = find(stpool == i);
            atemp(index{i})=1;
            aaa{i}=atemp;
        end
    end
    
    aa=zeros(NP,D);
    for i=1:numst
            aa(index{i},:) = rand(length(index{i}),D) < repmat(cc(index{i},i),1,D);          % all random numbers < CR are 1, 0 otherwise
    end
    dd=ceil(D*rand(NP,1));
    for kk=1:NP
        aa(kk,dd(kk))=1; 
    end
    for i=1:NP
            if ~isempty(find(index{1}==i))
            ddd=ceil(D*rand(1,1));
            while (aa(i,ddd) ~= 1)
                ddd=ddd+1;
                if ddd>=D;
                    ddd=ceil(D*rand(1,1));
                end
            end
            d1=ddd;
            while (aa(i,ddd) ~= 0)
                ddd=ddd+1;
                if ddd>=D;
                    ddd=D;break;
                end
            end
            d2=ddd;
            aa(i,:)=0;
            aa(i,d1:d2)=1;     
            end
    end
    mui=aa;
    mpo = mui < 0.5;                % inverse mask to mui
    
    for i=1:numst
        % assign the new F values
        F=[];
        m=length(index{i});       
        F=normrnd(0.5,0.3,m,1);
        F=repmat(F,1,D);
        if i==1
            ui(index{i},:) = pop(index{i},:) + F.*(pbest(index{i},:) - pop(index{i},:) + pm1(index{i},:) - pm2(index{i},:));     % differential variation
            ui(index{i},:) = popold(index{i},:).*mpo(index{i},:) + ui(index{i},:).*mui(index{i},:);     % Exp crossover
        end
        if i==2
            ui(index{i},:) = pop(index{i},:) + F.*(pbest(index{i},:) - pop(index{i},:) + pm1(index{i},:) - pm2(index{i},:));     % differential variation
            ui(index{i},:) = popold(index{i},:).*mpo(index{i},:) + ui(index{i},:).*mui(index{i},:);     % Bin crossover
        end
        if i==3 
            ui(index{i},:) = pop(index{i},:) + F.*(pbest(index{i},:) - pop(index{i},:) + pm1(index{i},:) - pm2(index{i},:));     % differential variation with no xover
        end
    end    
    %%%%bounds checking
    for i=1:NP
        outbind=find(ui(i,:) < Lbound);
        if size(outbind,2)~=0
            %                 % Periodica
                            ui(i,outbind)=2*XRmin(outbind)-ui(i,outbind);
            % Random
%             ui(i,outbind)=XRmin(outbind)+(XRmax(outbind)-XRmin(outbind)).*rand(1,size(outbind,2));
            %                 % Fixed
            %                 ui(i,outbind)=XRmin(outbind);
        end            
        outbind=find(ui(i,:) > Ubound);
        if size(outbind,2)~=0
            %                 % Periodica
                            ui(i,outbind)=2*XRmax(outbind)-ui(i,outbind);
            % Random
%             ui(i,outbind)=XRmin(outbind)+(XRmax(outbind)-XRmin(outbind)).*rand(1,size(outbind,2));
            %                 % Fixed
            %                 ui(i,outbind)=XRmax(outbind);
        end
    end
    lpcount=zeros(1,numst); 
    npcount=zeros(1,numst);
    for i=1:NP
        tempval(i) = benchmark_func(ui(i,:),func_num);   % check cost of competitor
        DE_fitcount  = DE_fitcount + 1;
        FEsassign(1,2)=FEsassign(1,2)+1;
        FEsassign(1,1)=FEsassign(1,1)+(val(i)>tempval(i));
        if (tempval(i) <= val(i))  % if competitor is better than value in "cost array"
            pop(i,:) = ui(i,:);  % replace old vector with new one (for new iteration)
            val(i)   = tempval(i);  % save value in "cost array"
            tlpcount=zeros(1,numst);
            for j=1:numst
                temp=aaa{j};
                tlpcount(j)=temp(i);
                if tlpcount(j)==1
                    aaaa{j}=[aaaa{j};cc(i,j) iter];  
                end
            end
            lpcount=[lpcount;tlpcount];
            %----we update DE_gbestval only in case of success to save time-----------
            if (tempval(i) <= DE_gbestval)     % if competitor better than the best one ever
                DE_gbestval = tempval(i);      % new best value
                DE_gbest = ui(i,:);  
                archive = updateArchive(archive,DE_gbest,DE_gbestval,NP);
                if DE_get_flag == 0
                    DE_fit_cut=DE_fitcount;
                    DE_get_flag=1;
                     currentTime = etime(clock,startTime);
                     threshold_Time=currentTime;
                end
            end
        else
            tnpcount=zeros(1,numst);
            for j=1:numst
                temp=aaa{j};
                tnpcount(j)=temp(i);
            end
            npcount=[npcount;tnpcount];
        end
         bFunValue=[bFunValue DE_gbestval];% new best parameter vector ever
        if DE_fitcount+1 > Max_FES
            DE_fitcount = Max_FES;
            pfithist = [pfithist;[iter+2,pfit/sum(pfit)]];
            ccmhist = [ccmhist;[iter+2,ccm]];
            num_stop=Max_FES;
            return;
        end
    end %---end for imember=1:NP
    pfithist = [pfithist;[iter+2,pfit/sum(pfit)]];
    ccmhist = [ccmhist;[iter+2,ccm]];    
    ns=[ns;sum(lpcount,1)];
    nf=[nf;sum(npcount,1)];    
    
    if iter >= learngen,
        for i=1:numst            
            if (sum(ns(:,i))+sum(nf(:,i))) == 0
                pfit(i) = 0.01;
            else
                pfit(i) = sum(ns(:,i))/(sum(ns(:,i))+ sum(nf(:,i))) + 0.01;
            end
        end
        if ~isempty(ns), ns(1,:)=[];   end
        if ~isempty(nf), nf(1,:)=[];   end
    end 
    iter = iter + 1;
    
lsnum=max(1,ceil(lsbuffersize-lsbuffersize*DE_fitcount/(0.5*Max_FES))); % linear reduce the No. of MMTS search agents
if DE_fitcount>=numch
  %%%%%% select the MMTS search agents from the DE population by Clearing procedure
  radius2=[sum(upb(1,:)-lowb(1,:)).^2]*0.001.*(1-0.99.*DE_fitcount/Max_FES);
  matingPool1=[];
  pbestval=val';
  pool=[pop pbestval];
  pool=unique(pool,'rows');
  [y,in]=sort(pool(:,D+1));
  matingPool1=pool(in,:);
  temppool=pool;
  i=1;
  while i<=size(matingPool1,1)-1
    dist=zeros(size(matingPool1,1),1);
    dist(i+1:size(matingPool1,1),:)=sum((ones(size(matingPool1,1)-i,1)*matingPool1(i,1:D)-matingPool1(i+1:size(matingPool1,1),1:D)).^2,2)<radius2;
    matingPool1=matingPool1(dist==0,:);
    i=i+1;
  end
  while size(matingPool1,1)<lsnum
      radius2=radius2*0.95;
      matingPool1=pool(in,:);
      i=1;
      while i<=size(matingPool1,1)-1
        dist=zeros(size(matingPool1,1),1);
        dist(i+1:size(matingPool1,1),:)=sum((ones(size(matingPool1,1)-i,1)*matingPool1(i,1:D)-matingPool1(i+1:size(matingPool1,1),1:D)).^2,2)<radius2;
        matingPool1=matingPool1(dist==0,:);
        i=i+1;
      end
  end
  
pbdis=zeros(size(pop,1),D);
for i=1:size(pop,1)
    pbdis(i,:)=sum(abs(repmat(pop(i,1:D),size(pop,1),1)-pop))./size(pop,1);
end
meanpbdis=sum(pbdis)./size(pop,1);
if DE_fitcount<=0.75*Max_FES
    if sssflag==0
%     sss1=abs(meanpbdis)*(1-0.98.*DE_fitcount/(0.75*Max_FES));
%     sss2=abs(meanpbdis)*(10-9.98.*DE_fitcount/(0.75*Max_FES));
%     sss3=abs(meanpbdis)*(20-19.98.*DE_fitcount/(0.75*Max_FES));
%     sss4=abs(meanpbdis)*(40-39.98.*DE_fitcount/(0.75*Max_FES));
    sss1=abs(meanpbdis);
    sss2=abs(meanpbdis)*(10-9.*DE_fitcount/(0.75*Max_FES));
    sss3=abs(meanpbdis)*(20-19.*DE_fitcount/(0.75*Max_FES));
    sss4=abs(meanpbdis)*(40-39.*DE_fitcount/(0.75*Max_FES));
%     sss1=min(sss1,0.2*(XRmax(1,1:D)-XRmin(1,1:D)));
%     sss2=min(sss2,0.5*(XRmax(1,1:D)-XRmin(1,1:D)));
    elseif sssflag==1
%         sss=abs(meanpbdis)*(1-0.98.*DE_fitcount/(0.75*Max_FES));
        sss=abs(meanpbdis);
%         sss=min(sss,0.2*(XRmax(1,1:D)-XRmin(1,1:D)));
    elseif sssflag==2
%         sss=abs(meanpbdis)*(10-9.98.*DE_fitcount/(0.75*Max_FES));
        sss=abs(meanpbdis)*(10-9.*DE_fitcount/(0.75*Max_FES));
%         sss=min(sss,0.5*(XRmax(1,1:D)-XRmin(1,1:D)));
    elseif sssflag==3
%         sss=abs(meanpbdis)*(20-19.98.*DE_fitcount/(0.75*Max_FES));
        sss=abs(meanpbdis)*(20-19.*DE_fitcount/(0.75*Max_FES));
    elseif sssflag==4
%         sss=abs(meanpbdis)*(40-39.98.*DE_fitcount/(0.75*Max_FES));
        sss=abs(meanpbdis)*(40-39.*DE_fitcount/(0.75*Max_FES));
    end
else
%     sss=abs(meanpbdis)*(0.02-0.0199.*(DE_fitcount-0.75*Max_FES)/(0.2*Max_FES));
    sss=abs(meanpbdis)*(1-0.99.*(DE_fitcount-0.75*Max_FES)/(0.2*Max_FES));
%     sss=min(sss,0.2*(XRmax(1,1:D)-XRmin(1,1:D)));
end

 if numch==20*D;
     for d=1:D
         for b=1:lsbuffersize
            ls_archive(b,d).success=[0 0];
         end
     end
    if sssflag==0
        num=1;
        lspos(num,1:D)=matingPool1(num,1:D);
        lse(num,1)=matingPool1(num,D+1);
        lsesss1=lse(num,1);
        lspossss1=lspos(num,1:D);
        lsesss2=lse(num,1);
        lspossss2=lspos(num,1:D);
        lsesss3=lse(num,1);
        lspossss3=lspos(num,1:D);
        lsesss4=lse(num,1);
        lspossss4=lspos(num,1:D);
        laste=inf;
        lsfitcount=0;
        lsiter=0;
        dim=randperm(D);
        while (lsfitcount<=20*D)
            if laste==lsesss1
                lsiter=lsiter+1;
                if lsiter>=10,break;end                
            end
            laste=lsesss1
            lsfitcount
            if eflag==0
                if sss1(dim)<=10^(-20)
                    sss1(dim)=sss1(dim)*0.9;
                else sss1(dim)=sss1(dim)/0.9;
                end
            else
                    sss1(dim)=sss1(dim);
            end
        for i=1:D
            k=0;
            tempe(1)=-1000000;
            while tempe(1)<=lsesss1
                k=k+1;
                if k>ceil((XRmax(1,dim(i))-lspossss1(num,dim(i)))/sss1(dim(i))),break; end
                var=zeros(1,D);
                var(dim(i))=k*sss1(dim(i));
                temppos=lspossss1(num,:)+var;
                temppos(1,:)=(temppos(1,:)>XRmax(1,:)).*XRmax(1,:)+(temppos(1,:)<=XRmax(1,:)).*temppos(1,:); 
                temppos(1,:)=(temppos(1,:)<XRmin(1,:)).*XRmin(1,:)+(temppos(1,:)>=XRmin(1,:)).*temppos(1,:);
                tempe = benchmark_func(temppos, func_num);
                DE_fitcount=1+DE_fitcount;
                FEsassign(1,4)=FEsassign(1,4)+1;
                lsfitcount=lsfitcount+1;
                ls_archive(num,dim(i)).success(1,2)=ls_archive(num,dim(i)).success(1,2)+1;
                if lsesss1>=tempe
                    FEsassign(1,3)=FEsassign(1,3)+(lsesss1>tempe);
                lsesss1=tempe;
                lspossss1(num,:)=temppos;
                if lsesss1>tempe
                ls_archive(num,dim(i)).success(1,1)=ls_archive(num,dim(i)).success(1,1)+1;
                end
                end
            end
            if k<=1
            k=0;
            tempe(1)=-1000000;
            while tempe(1)<=lsesss1
                k=k+1;
                if k>ceil((lspossss1(num,dim(i))-XRmin(1,dim(i)))/sss1(dim(i))),break; end
                var=zeros(1,D);
                var(dim(i))=k*sss1(dim(i));
                temppos=lspossss1(num,:)-var;
                temppos(1,:)=(temppos(1,:)>XRmax(1,:)).*XRmax(1,:)+(temppos(1,:)<=XRmax(1,:)).*temppos(1,:); 
                temppos(1,:)=(temppos(1,:)<XRmin(1,:)).*XRmin(1,:)+(temppos(1,:)>=XRmin(1,:)).*temppos(1,:);
                tempe = benchmark_func(temppos, func_num);
                DE_fitcount=1+DE_fitcount;
                FEsassign(1,4)=FEsassign(1,4)+1;
                lsfitcount=lsfitcount+1;
                ls_archive(num,dim(i)).success(1,2)=ls_archive(num,dim(i)).success(1,2)+1;
                if lsesss1>=tempe
                    FEsassign(1,3)=FEsassign(1,3)+(lsesss1>tempe);
                lsesss1=tempe;
                lspossss1(num,:)=temppos;
                if lsesss1>tempe
                ls_archive(num,dim(i)).success(1,1)=ls_archive(num,dim(i)).success(1,1)+1;
                end
                end
            end
            end
        end
            if laste<=lsesss1
                eflag=0;
            else eflag=1;
            end
        end 
        
        lsiter=0;
        lsfitcount=0;
        while (lsfitcount<=20*D)
            if laste==lsesss2
                lsiter=lsiter+1;
                if lsiter>=10,break;end                
            end
            laste=lsesss2
            lsfitcount
            if eflag==0
                if sss2(dim)<=10^(-20)
                    sss2(dim)=sss2(dim)*0.9;
                else sss2(dim)=sss2(dim)/0.9;
                end
            else
                    sss2(dim)=sss2(dim);
            end
        for i=1:D
            k=0;
            tempe(1)=-1000000;
            while tempe(1)<=lsesss2
                k=k+1;
                if k>ceil((XRmax(1,dim(i))-lspossss2(num,dim(i)))/sss2(dim(i))),break; end
                var=zeros(1,D);
                var(dim(i))=k*sss2(dim(i));
                temppos=lspossss2(num,:)+var;
                temppos(1,:)=(temppos(1,:)>XRmax(1,:)).*XRmax(1,:)+(temppos(1,:)<=XRmax(1,:)).*temppos(1,:); 
                temppos(1,:)=(temppos(1,:)<XRmin(1,:)).*XRmin(1,:)+(temppos(1,:)>=XRmin(1,:)).*temppos(1,:);
                tempe = benchmark_func(temppos, func_num);
                DE_fitcount=1+DE_fitcount;
                FEsassign(1,4)=FEsassign(1,4)+1;
                lsfitcount=lsfitcount+1;
                ls_archive(num,dim(i)).success(1,2)=ls_archive(num,dim(i)).success(1,2)+1;
                if lsesss2>=tempe
                    FEsassign(1,3)=FEsassign(1,3)+(lsesss2>tempe);
                lsesss2=tempe;
                lspossss2(num,:)=temppos;
                if lsesss2>tempe
                ls_archive(num,dim(i)).success(1,1)=ls_archive(num,dim(i)).success(1,1)+1;
                end
                end
            end
            if k<=1
            k=0;
            tempe(1)=-1000000;
            while tempe(1)<=lsesss2
                k=k+1;
                if k>ceil((lspossss2(num,dim(i))-XRmin(1,dim(i)))/sss2(dim(i))),break; end
                var=zeros(1,D);
                var(dim(i))=k*sss2(dim(i));
                temppos=lspossss2(num,:)-var;
                temppos(1,:)=(temppos(1,:)>XRmax(1,:)).*XRmax(1,:)+(temppos(1,:)<=XRmax(1,:)).*temppos(1,:); 
                temppos(1,:)=(temppos(1,:)<XRmin(1,:)).*XRmin(1,:)+(temppos(1,:)>=XRmin(1,:)).*temppos(1,:);
                tempe = benchmark_func(temppos, func_num);
                DE_fitcount=1+DE_fitcount;
                FEsassign(1,4)=FEsassign(1,4)+1;
                lsfitcount=lsfitcount+1;
                ls_archive(num,dim(i)).success(1,2)=ls_archive(num,dim(i)).success(1,2)+1;
                if lsesss2>=tempe
                    FEsassign(1,3)=FEsassign(1,3)+(lsesss2>tempe);
                lsesss2=tempe;
                lspossss2(num,:)=temppos;
                if lsesss2>tempe
                ls_archive(num,dim(i)).success(1,1)=ls_archive(num,dim(i)).success(1,1)+1;
                end
                end
            end
            end
        end
            if laste<=lsesss2
                eflag=0;
            else eflag=1;
            end
        end
        
        lsiter=0;
        lsfitcount=0;
        while (lsfitcount<=20*D)
            if laste==lsesss3
                lsiter=lsiter+1;
                if lsiter>=10,break;end                
            end
            laste=lsesss3
            lsfitcount
            if eflag==0
                if sss3(dim)<=10^(-20)
                    sss3(dim)=sss3(dim)*0.9;
                else sss3(dim)=sss3(dim)/0.9;
                end
            else
                    sss3(dim)=sss3(dim);
            end
        for i=1:D
            k=0;
            tempe(1)=-1000000;
            while tempe(1)<=lsesss3
                k=k+1;
                if k>ceil((XRmax(1,dim(i))-lspossss3(num,dim(i)))/sss3(dim(i))),break; end
                var=zeros(1,D);
                var(dim(i))=k*sss3(dim(i));
                temppos=lspossss3(num,:)+var;
                temppos(1,:)=(temppos(1,:)>XRmax(1,:)).*XRmax(1,:)+(temppos(1,:)<=XRmax(1,:)).*temppos(1,:); 
                temppos(1,:)=(temppos(1,:)<XRmin(1,:)).*XRmin(1,:)+(temppos(1,:)>=XRmin(1,:)).*temppos(1,:);
                tempe = benchmark_func(temppos, func_num);
                DE_fitcount=1+DE_fitcount;
                FEsassign(1,4)=FEsassign(1,4)+1;
                lsfitcount=lsfitcount+1;
                ls_archive(num,dim(i)).success(1,2)=ls_archive(num,dim(i)).success(1,2)+1;
                if lsesss3>=tempe
                    FEsassign(1,3)=FEsassign(1,3)+(lsesss3>tempe);
                lsesss3=tempe;
                lspossss3(num,:)=temppos;
                if lsesss3>tempe
                ls_archive(num,dim(i)).success(1,1)=ls_archive(num,dim(i)).success(1,1)+1;
                end
                end
            end
            if k<=1
            k=0;
            tempe(1)=-1000000;
            while tempe(1)<=lsesss3
                k=k+1;
                if k>ceil((lspossss3(num,dim(i))-XRmin(1,dim(i)))/sss3(dim(i))),break; end
                var=zeros(1,D);
                var(dim(i))=k*sss3(dim(i));
                temppos=lspossss3(num,:)-var;
                temppos(1,:)=(temppos(1,:)>XRmax(1,:)).*XRmax(1,:)+(temppos(1,:)<=XRmax(1,:)).*temppos(1,:); 
                temppos(1,:)=(temppos(1,:)<XRmin(1,:)).*XRmin(1,:)+(temppos(1,:)>=XRmin(1,:)).*temppos(1,:);
                tempe = benchmark_func(temppos, func_num);
                DE_fitcount=1+DE_fitcount;
                FEsassign(1,4)=FEsassign(1,4)+1;
                lsfitcount=lsfitcount+1;
                ls_archive(num,dim(i)).success(1,2)=ls_archive(num,dim(i)).success(1,2)+1;
                if lsesss3>=tempe
                    FEsassign(1,3)=FEsassign(1,3)+(lsesss3>tempe);
                lsesss3=tempe;
                lspossss3(num,:)=temppos;
                if lsesss3>tempe
                ls_archive(num,dim(i)).success(1,1)=ls_archive(num,dim(i)).success(1,1)+1;
                end
                end
            end
            end
        end
            if laste<=lsesss3
                eflag=0;
            else eflag=1;
            end
        end
        
        lsiter=0;
        lsfitcount=0;
        while (lsfitcount<=20*D)
            if laste==lsesss4
                lsiter=lsiter+1;
                if lsiter>=10,break;end                
            end
            laste=lsesss4
            lsfitcount
            if eflag==0
                if sss4(dim)<=10^(-20)
                    sss4(dim)=sss4(dim)*0.9;
                else sss4(dim)=sss4(dim)/0.9;
                end
            else
                    sss4(dim)=sss4(dim);
            end
        for i=1:D
            k=0;
            tempe(1)=-1000000;
            while tempe(1)<=lsesss4
                k=k+1;
                if k>ceil((XRmax(1,dim(i))-lspossss4(num,dim(i)))/sss4(dim(i))),break; end
                var=zeros(1,D);
                var(dim(i))=k*sss4(dim(i));
                temppos=lspossss4(num,:)+var;
                temppos(1,:)=(temppos(1,:)>XRmax(1,:)).*XRmax(1,:)+(temppos(1,:)<=XRmax(1,:)).*temppos(1,:); 
                temppos(1,:)=(temppos(1,:)<XRmin(1,:)).*XRmin(1,:)+(temppos(1,:)>=XRmin(1,:)).*temppos(1,:);
                tempe = benchmark_func(temppos, func_num);
                DE_fitcount=1+DE_fitcount;
                FEsassign(1,4)=FEsassign(1,4)+1;
                lsfitcount=lsfitcount+1;
                ls_archive(num,dim(i)).success(1,2)=ls_archive(num,dim(i)).success(1,2)+1;
                if lsesss4>=tempe
                    FEsassign(1,3)=FEsassign(1,3)+(lsesss4>tempe);
                lsesss4=tempe;
                lspossss4(num,:)=temppos;
                if lsesss4>tempe
                ls_archive(num,dim(i)).success(1,1)=ls_archive(num,dim(i)).success(1,1)+1;
                end
                end
            end
            if k<=1
            k=0;
            tempe(1)=-1000000;
            while tempe(1)<=lsesss4
                k=k+1;
                if k>ceil((lspossss4(num,dim(i))-XRmin(1,dim(i)))/sss4(dim(i))),break; end
                var=zeros(1,D);
                var(dim(i))=k*sss4(dim(i));
                temppos=lspossss4(num,:)-var;
                temppos(1,:)=(temppos(1,:)>XRmax(1,:)).*XRmax(1,:)+(temppos(1,:)<=XRmax(1,:)).*temppos(1,:); 
                temppos(1,:)=(temppos(1,:)<XRmin(1,:)).*XRmin(1,:)+(temppos(1,:)>=XRmin(1,:)).*temppos(1,:);
                tempe = benchmark_func(temppos, func_num);
                DE_fitcount=1+DE_fitcount;
                FEsassign(1,4)=FEsassign(1,4)+1;
                lsfitcount=lsfitcount+1;
                ls_archive(num,dim(i)).success(1,2)=ls_archive(num,dim(i)).success(1,2)+1;
                if lsesss4>=tempe
                    FEsassign(1,3)=FEsassign(1,3)+(lsesss4>tempe);
                lsesss4=tempe;
                lspossss4(num,:)=temppos;
                if lsesss4>tempe
                ls_archive(num,dim(i)).success(1,1)=ls_archive(num,dim(i)).success(1,1)+1;
                end
                end
            end
            end
        end
            if laste<=lsesss4
                eflag=0;
            else eflag=1;
            end
        end
        
        lsessse=[lsesss1,lsesss2,lsesss3,lsesss4];
        bestsss=find(lsessse==min(lsessse));
        if lsessse(bestsss)==lsesss1
            sssflag=1;
            lse(num,1)=lsesss1;
            lspos(num,:)=lspossss1;
            sss=sss1;
        elseif lsessse(bestsss)==lsesss2
            sssflag=2;
            lse(num,1)=lsesss2;
            lspos(num,:)=lspossss2;
            sss=sss2;
        elseif lsessse(bestsss)==lsesss3
            sssflag=3;
            lse(num,1)=lsesss3;
            lspos(num,:)=lspossss3;
            sss=sss3;
        elseif lsessse(bestsss)==lsesss4
            sssflag=4;
            lse(num,1)=lsesss4;
            lspos(num,:)=lspossss4;
            sss=sss4;
        end
    end
    sssflag
    
    for num=2:lsnum
    lspos(num,1:D)=matingPool1(num,1:D);
    lse(num,1)=matingPool1(num,D+1);
    laste=inf;
    lsfitcount=0;
    lsiter=0;
    dim=randperm(D);
    while (lsfitcount<=20*D)
        if laste==lse(num,1)
            lsiter=lsiter+1;
            if lsiter>=10,break;end                
        end
        laste=lse(num,1)
        lsfitcount
        if eflag==0
            if sss(dim)<=10^(-20)
                sss(dim)=sss(dim)*0.9;
            else sss(dim)=sss(dim)/0.9;
            end
        else
                sss(dim)=sss(dim);
        end
    for i=1:D
        k=0;
        tempe(1)=-1000000;
        while tempe(1)<=lse(num,1)
            k=k+1;
            if k>ceil((XRmax(1,dim(i))-lspos(num,dim(i)))/sss(dim(i))),break; end
            var=zeros(1,D);
            var(dim(i))=k*sss(dim(i));
            temppos=lspos(num,:)+var;
            temppos(1,:)=(temppos(1,:)>XRmax(1,:)).*XRmax(1,:)+(temppos(1,:)<=XRmax(1,:)).*temppos(1,:); 
            temppos(1,:)=(temppos(1,:)<XRmin(1,:)).*XRmin(1,:)+(temppos(1,:)>=XRmin(1,:)).*temppos(1,:);
            tempe = benchmark_func(temppos, func_num);
            DE_fitcount=1+DE_fitcount;
            FEsassign(1,4)=FEsassign(1,4)+1;
            lsfitcount=lsfitcount+1;
            ls_archive(num,dim(i)).success(1,2)=ls_archive(num,dim(i)).success(1,2)+1;
            if lse(num,1)>=tempe
                FEsassign(1,3)=FEsassign(1,3)+(lse(num,1)>tempe);
            lse(num,1)=tempe;
            lspos(num,:)=temppos;
            if lse(num,1)>tempe
            ls_archive(num,dim(i)).success(1,1)=ls_archive(num,dim(i)).success(1,1)+1;
            end
            end
        end
        if k<=1
        k=0;
        tempe(1)=-1000000;
        while tempe(1)<=lse(num,1)
            k=k+1;
            if k>ceil((lspos(num,dim(i))-XRmin(1,dim(i)))/sss(dim(i))),break; end
            var=zeros(1,D);
            var(dim(i))=k*sss(dim(i));
            temppos=lspos(num,:)-var;
            temppos(1,:)=(temppos(1,:)>XRmax(1,:)).*XRmax(1,:)+(temppos(1,:)<=XRmax(1,:)).*temppos(1,:); 
            temppos(1,:)=(temppos(1,:)<XRmin(1,:)).*XRmin(1,:)+(temppos(1,:)>=XRmin(1,:)).*temppos(1,:);
            tempe = benchmark_func(temppos, func_num);
            DE_fitcount=1+DE_fitcount;
            FEsassign(1,4)=FEsassign(1,4)+1;
            lsfitcount=lsfitcount+1;
            ls_archive(num,dim(i)).success(1,2)=ls_archive(num,dim(i)).success(1,2)+1;
            if lse(num,1)>=tempe
                FEsassign(1,3)=FEsassign(1,3)+(lse(num,1)>tempe);
            lse(num,1)=tempe;
            lspos(num,:)=temppos;
            if lse(num,1)>tempe
            ls_archive(num,dim(i)).success(1,1)=ls_archive(num,dim(i)).success(1,1)+1;
            end
            end
        end
        end
    end
        if laste<=lse(num,1)
            eflag=0;
        else eflag=1;
        end
    end
    end
 else
     if FEsassign(1,1)~=0
     FEsLS=20*D*FEsassign(1,3)*FEsassign(1,2)/(FEsassign(1,1)*FEsassign(1,4)*lsnum); %base on FEsassign, assign the FEs to MMTS
     else FEsLS=10*D;
     end
     FEsassign(1,3:4)=0;
    for num=1:min(lsnum,size(matingPool1))
    lspos(num,1:D)=matingPool1(num,1:D);
    lse(num,1)=matingPool1(num,D+1);
    laste=inf;
    lsfitcount=0;
    lsiter=0;
    for d=1:D
        SucTime(d)=0;
        SucFEs(d)=0;
        for b=1:lsbuffersize
        SucTime(d)=SucTime(d)+ls_archive(b,d).success(1,1);
        SucFEs(d)=SucFEs(d)+ls_archive(b,d).success(1,2);
        end
        if SucFEs(d)~=0;
            SucRate(d)=SucTime(d)/SucFEs(d);
        else SucRate(d)=0;
        end
    end
    SucProb=SucRate./sum(SucRate);
    [SucProb,dim]=sort(SucProb,'descend');
    if DE_fitcount<=0.5*Max_FES
        dim=randperm(D);
    end 
    for j=1:lsbuffersize-1
        ls_archive(j,:)=ls_archive(j+1,:);
    end
    for d=1:D
        ls_archive(lsbuffersize,d).success=[0 0];
    end
    while (lsfitcount<=FEsLS)
        if laste==lse(num,1)
            lsiter=lsiter+1;
            if lsiter>=10,break;end                
        end
        if  DE_fitcount>=50*D & record_flag==0 
            record_flag=1;
            eval(['fid=fopen(''gbestval_' num2str(func_num) '_' num2str(run) '.txt'',''w'');' ]);
            fprintf(fid,'%e\n',min(lse));
            fclose(fid);
        elseif DE_fitcount>=500*D & record_flag==1
            record_flag=2;
            eval(['fid=fopen(''gbestval_' num2str(func_num) '_' num2str(run) '.txt'',''a'');' ]);
            fprintf(fid,'\n');
            fprintf(fid,'%e\n',min(lse));
            fclose(fid);
        end
        if DE_fitcount>Max_FES, break; end
        laste=lse(num,1)
        lsfitcount 
        if eflag==0
            if sss(dim)<=10^(-20)
                sss(dim)=sss(dim)*0.9;
            else sss(dim)=sss(dim)/0.9;
            end
        else
                sss(dim)=sss(dim);
        end
    for i=1:D
        k=0;
        tempe(1)=-1000000;
        while tempe(1)<=lse(num,1)
            k=k+1;
            if k>ceil((XRmax(1,i)-lspos(num,dim(i)))/sss(dim(i))),break; end
            var=zeros(1,D);
            var(dim(i))=k*sss(dim(i));
            temppos=lspos(num,:)+var;
            temppos(1,:)=(temppos(1,:)>XRmax(1,:)).*XRmax(1,:)+(temppos(1,:)<=XRmax(1,:)).*temppos(1,:); 
            temppos(1,:)=(temppos(1,:)<XRmin(1,:)).*XRmin(1,:)+(temppos(1,:)>=XRmin(1,:)).*temppos(1,:);
            tempe = benchmark_func(temppos, func_num);
            DE_fitcount=1+DE_fitcount;
            FEsassign(1,4)=FEsassign(1,4)+1;
            lsfitcount=lsfitcount+1;
            ls_archive(lsbuffersize,dim(i)).success(1,2)=ls_archive(lsbuffersize,dim(i)).success(1,2)+1;
            if lse(num,1)>=tempe
                FEsassign(1,3)=FEsassign(1,3)+(lse(num,1)>tempe);
            lse(num,1)=tempe;
            lspos(num,:)=temppos;
            if lse(num,1)>tempe
            ls_archive(lsbuffersize,dim(i)).success(1,1)=ls_archive(lsbuffersize,dim(i)).success(1,1)+1;
            end
            end
            if DE_fitcount>Max_FES-50*D, break; end
        end
        if k<=1
        k=0;
        tempe(1)=-1000000;
        while tempe(1)<=lse(num,1)
            k=k+1;
            if k>ceil((lspos(num,dim(i))-XRmin(1,i))/sss(dim(i))),break; end
            var=zeros(1,D);
            var(dim(i))=k*sss(dim(i));
            temppos=lspos(num,:)-var;
            temppos(1,:)=(temppos(1,:)>XRmax(1,:)).*XRmax(1,:)+(temppos(1,:)<=XRmax(1,:)).*temppos(1,:); 
            temppos(1,:)=(temppos(1,:)<XRmin(1,:)).*XRmin(1,:)+(temppos(1,:)>=XRmin(1,:)).*temppos(1,:);
            tempe = benchmark_func(temppos, func_num);
            DE_fitcount=1+DE_fitcount;
            FEsassign(1,4)=FEsassign(1,4)+1;
            lsfitcount=lsfitcount+1;
            ls_archive(lsbuffersize,dim(i)).success(1,2)=ls_archive(lsbuffersize,dim(i)).success(1,2)+1;
            if lse(num,1)>=tempe
                FEsassign(1,3)=FEsassign(1,3)+(lse(num,1)>tempe);
            lse(num,1)=tempe;
            lspos(num,:)=temppos;
            if lse(num,1)>tempe
            ls_archive(lsbuffersize,dim(i)).success(1,1)=ls_archive(lsbuffersize,dim(i)).success(1,1)+1;
            end
            end
            if DE_fitcount>Max_FES-50*D, break; end
        end
        end
        if DE_fitcount>Max_FES-50*D, break; end
    end
        if laste<=lse(num,1)
            eflag=0;
        else eflag=1;
        end
    end
    end
 end
%%%%%%%%%%%%%%%%% replace the nearest DE population members by better MMTS solutions
  Distan = sqrt(sum(abs( repmat(permute(pop(:,1:D), [1 3 2]), [1 size(lspos,1) 1])- ...
     repmat(permute(lspos(:,1:D), [3 1 2]), [size(pop,1) 1 1]) ).^2, 3));
    [sortDistan,sortDistanid]=sort(Distan);
    index0=0;
    for num=1:size(lspos,1)
        index1=sortDistanid(1,num);
        nnn=2;
        while index1==index0
            index1=sortDistanid(nnn,num);
            nnn=nnn+1;
        end
        pop(index1,1:D)=lspos(num,1:D).*(lse(num,1)<=pbestval(index1,1))+pop(index1,1:D).*(lse(num,1)>pbestval(index1,1));
        pbestval(index1,1)=lse(num,1).*(lse(num,1)<=pbestval(index1,1))+pbestval(index1,1).*(lse(num,1)>pbestval(index1,1));
        index0=index1;
    end
    val=pbestval';
    if (min(lse) <= DE_gbestval)     % if competitor better than the best one ever
        DE_gbestval = min(lse);      % new best value
        lsnumindex=find(lse==min(lse));
        DE_gbest = lspos(lsnumindex(1),1:D);  
        archive = updateArchive(archive,DE_gbest,DE_gbestval,NP); % update JADE archive
    end
if DE_fitcount>=recorditer
    eval(['fid=fopen(''SaDE_MMTS_gbestval_' num2str(func_num) '_' num2str(run) '.txt'',''a'');' ]);
    fprintf(fid,'\n');
    fprintf(fid,'%e\n',min(lse));
    fclose(fid);
    recorditer=recorditer+50*D;
end
numch=DE_fitcount+20*D;
FEsassign(1,1:2)=0; % reinitilization of FEsassign for the next search circle
end

  if DE_fitcount>=recorditer
      eval(['fid=fopen(''SaDE_MMTS_gbestval_' num2str(func_num) '_' num2str(run) '.txt'',''a'');' ]);
      fprintf(fid,'\n');
      fprintf(fid,'%e\n',min(DE_gbestval));
      fclose(fid);
      recorditer=recorditer+50*D;
  end
    if  DE_fitcount>=50*D & record_flag==0 
        record_flag=1;
        eval(['fid=fopen(''gbestval_' num2str(func_num) '_' num2str(run) '.txt'',''w'');' ]);
        fprintf(fid,'%e\n',min(DE_gbestval));
        fclose(fid);
    elseif DE_fitcount>=500*D & record_flag==1
        record_flag=2;
        eval(['fid=fopen(''gbestval_' num2str(func_num) '_' num2str(run) '.txt'',''a'');' ]);
        fprintf(fid,'\n');
        fprintf(fid,'%e\n',min(DE_gbestval));
        fclose(fid);
    end 
    if DE_fitcount>Max_FES, break; end    
end %---end while ((DE_fitcount < Max_FES-50*D) ...
while DE_fitcount < Max_FES
    options = optimset('LargeScale','on','MaxFunEvals',max(50*D,5000),'Display','off');
            [gbval,tmpid]=sort(val);
            k=1;
                [x,fval,exitflag,output] = fminunc(fhd,pop(tmpid(k),:),options,func_num);
                DE_fitcount=DE_fitcount+output.funcCount;
                if fval<val(tmpid(k))
                    pop(tmpid(k),:)=x;
                    val(tmpid(k))=fval;
                end
        [DE_gbestval,index]=min(val);
        DE_gbest=pop(index,:);
end
          eval(['fid=fopen(''SaDE_MMTS_gbestval_' num2str(func_num) '_' num2str(run) '.txt'',''a'');' ]);
          fprintf(fid,'\n');
          fprintf(fid,'%e\n',DE_gbestval);
          fclose(fid);
          
          eval(['fid=fopen(''gbestval_' num2str(func_num) '_' num2str(run) '.txt'',''a'');' ]);
          fprintf(fid,'\n');
          fprintf(fid,'%e\n',DE_gbestval);
          fclose(fid);