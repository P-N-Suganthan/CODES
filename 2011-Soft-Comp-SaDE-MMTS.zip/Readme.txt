==========================
Instructions for the SaDE-MMTS.rar file 
==========================

I.    Data files
 Matlab testing files for the Test Suite for the Special Issue of Soft Computing on Scalability of Evolutionary Algorithms and other Metaheuristics for Large Scale Continuous Optimization Problems. (converted from original c.files)


II.   m.files
RunSofeCompSaDEMMTS.m ----- Main program for calling the testing of Test Suite for the Special Issue of Soft Computing on Scalability of Evolutionary Algorithms and other Metaheuristics for Large Scale Continuous Optimization Problems

DE_LS_NichingMemory.m ----- SaDE-MMTS algorithm main program

benchmark_func.m ---------- Test Suite for the Special Issue of Soft Computing on Scalability of Evolutionary Algorithms and other Metaheuristics for Large Scale Continuous Optimization Problems

updateArchive.m ----------- JADE archive updating program
