
function archive = updateArchive(archive, DE_gbest, DE_gbestval, NP)

gbest=[DE_gbest DE_gbestval];
archive = [archive;gbest];
archive = unique(archive, 'rows');
if size(archive,1) <= NP     % add all new individuals
    archive = archive;
else                                % randomly remove some solutions
    rndpos = randperm(size(archive,1)); % equivelent to "randperm";
    rndpos = rndpos(1:NP);
    archive  = archive(rndpos, :);
end
[a,index]=sort(archive(:,size(archive,2)),'ascend');
archive=archive(index,:);