function RETree = Obliquecartree_train(Data1,Labels1,Index,varargin)
%RETree = cartree(Data,Labels,varargin)
%parameters that can be set are:
%       minleaf      : the minimum amount of samples in a leaf (default 1)
%       nvartosample : the number of (randomly selected) variables 
%                      to consider at each node (default all)


okargs =   {'minparent' 'minleaf' 'nvartosample' 'method'  'oblique' };
defaults = {2 1 round(sqrt(size(Data1,2))) 'c'  1};
[eid,emsg,minparent,minleaf,m,method,o] = getargs(okargs,defaults,varargin{:});
Data=Data1(Index,:);
Labels=Labels1(Index);
N = numel(Labels);
L = 2*ceil(N/minleaf) - 1;
M = size(Data,2);
nodeDataIndx = cell(L,1);
nodeDataIndx{1} = 1 : N;
nodevar=cell(L,1);
nodep=cell(L,1);
nodeCutVar = zeros(L,1);
nodeCutValue = zeros(L,1);
nodeflags = zeros(L+1,1);
nodelabel = zeros(L,1);
childnode = zeros(L,1);
nodeflags(1) = 1;
current_node = 1;
while nodeflags(current_node) == 1;
    
     currentDataIndx = nodeDataIndx{current_node};
    free_node = find(nodeflags == 0,1);
    if  numel(unique(Labels(currentDataIndx)))==1
        
         nodelabel(current_node) = Labels(currentDataIndx(1));
      
        nodeCutVar(current_node) = 0;
        nodeCutValue(current_node) = 0;
        nodevar{current_node}=0;
        nodep{current_node}=0;
    else
        if numel(currentDataIndx)>2*minparent
             
             node_var = randperm(M);
             node_var = node_var(1:m);
                  
           
            
            
          
             X=Data(currentDataIndx,node_var);
          
         switch o
             case 1
                   Delta=0.001; 
                   %MPSVM-T
              [bestCutVar, b] =hyperplane_psvm_reg(X,Labels(currentDataIndx),minleaf,Delta);
             case 2
                 %MPSVM-P
                   
              [bestCutVar, b] =hyperplane_psvm_reg_v1(X,Labels(currentDataIndx),minleaf);
             case 3
                 %PCA
               [bestCutVar, b] =hyperplane_pca_reg(X,Labels(currentDataIndx),minleaf);      
            
                  
             case 4
                 %LDA
                 
              [bestCutVar, b] =hyperplane_lda_reg(X,Labels(currentDataIndx),minleaf); 
              
             case 5
                 %ls
              [bestCutVar, b] =hyperplane_ls_reg(X,Labels(currentDataIndx),minleaf); 
             otherwise
                   error('the method has not been implemented yet!')
                  
        
                       
         end  

            if bestCutVar~=-1
               nodeCutVar(current_node) = bestCutVar;
               nodevar{current_node}=node_var;
               nodep{current_node}=b;
               D=X*b(1:end-1);
              nodeDataIndx{free_node} = currentDataIndx(D<b(end));
              nodeDataIndx{free_node+1} = currentDataIndx(D>=b(end));
              nodeflags(free_node:free_node + 1) = 1;
              childnode(current_node)=free_node;
            else
             
              nodelabel(current_node)  = mean(Labels(currentDataIndx));
               
                
            end
        else
            
              nodelabel(current_node)  = mean(Labels(currentDataIndx));
            
        end
    end
    current_node = current_node+1;
end

RETree.nodeDataIndex=  nodeDataIndx(1:current_node-1);
RETree.p=nodep(1:current_node-1);
RETree.node_var=nodevar(1:current_node-1);
RETree.nodeCutVar = nodeCutVar(1:current_node-1);
RETree.childnode = childnode(1:current_node-1);
RETree.nodelabel = nodelabel(1:current_node-1);
RETree.dataindex=Index;
