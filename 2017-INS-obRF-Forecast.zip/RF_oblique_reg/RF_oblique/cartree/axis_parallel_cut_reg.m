function [bestCutVar, bestCutValue] =axis_parallel_cut_reg(Labels,Data,minleaf)
Var=1000000*ones(size(Data));
[nSam,nFea]=size(Data);
for i=1:nFea
    data=Data(:,i);
for j=1:nSam
    data1=data(data>=data(j));
    data2=data(data<data(j));
    var1=(numel(data1)*var(data1)+numel(data2)*var(data2))/nSam;
    Var(j,i)=var1;
end   
end
idx1=min(min(Var));
idx=find(Var==idx1,1);
[m,n]=ind2sub([nSam,nFea],idx);
data=Data(:,n);
bestCutValue=data(m);

num_s=min(numel(data(data>=bestCutValue)), numel(data(data<bestCutValue)));
bestCutVar=n;
if num_s<=minleaf
  bestCutVar=-1;  
end
end