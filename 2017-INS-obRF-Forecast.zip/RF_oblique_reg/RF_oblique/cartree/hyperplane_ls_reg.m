function[bestCutVar,W_new]=hyperplane_ls_reg(Data,Label,minleaf)
lambda=0.01;
flag_temp=1;

BAD_flag=0;
XX=unique(Label);
if length(XX)==1
   bestCutVar=-1;
   BAD_flag=1;
   W_new=zeros(size(Data,2)+1,1)';
end
if BAD_flag==0
[idx1,idx2]=group_reg(Label);

label=Label;
label(idx1)=1;
label(idx2)=-1;
flag=(size(Data,1)>size(Data,2));
if flag==1
W=((Data'*Data+lambda*eye(size(Data,2)))\Data')*label;
W1=[W;0];

W=[W1,W1];
else

% nFea=size(Data,2);
% idx=randperm(nFea);
% idx1=idx(1);
% W1=zeros(nFea+1,1);
% W1(idx1)=1;
% W1(end)=median(unique(Data(:,idx1)));
% idx2=idx(2);
% W2=zeros(nFea+1,1);
% W2(idx2)=1;
% W2(end)=median(unique(Data(:,idx2)));
[bestCutVar, bestCutValue] =axis_parallel_cut_reg(Label,Data,minleaf);
if bestCutVar~=-1
W1=zeros(size(Data,2)+1,1);
W1(bestCutVar)=1;
W1(end)=bestCutValue;
W=[W1,W1];
else
    W=zeros(size(Data,2)+1,2);
end

end
 [bestCutVar,W_new]=select_hyperplane_reg(W,Data,minleaf);
 if flag_temp==0
      bestCutVar=bestCutVar1;
 end
end
