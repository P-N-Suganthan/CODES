% function [bestCutVar,W_new,gini1,gini2,W3,W4]=select_hyperplane(W,Data,Labels)

function [bestCutVar,W_new]=select_hyperplane_reg(W,Data,minleaf)
W1=W(:,1);
W2=W(:,2);
X1=Data*W1(1:end-1)-W1(end);
X2=Data*W2(1:end-1)-W2(end);
LX1=X1(X1<=0);
RX1=X1(X1>0);
LX2=X2(X2<=0);
RX2=X2(X2>0);
% diff1=abs(mean(LX1)-mean(RX1));
% diff2=abs(mean(LX2)-mean(RX2));
diff1=numel(LX1)*std(LX1)+std(RX1)*numel(RX1);
diff2=numel(LX2)*std(LX2)+std(RX2)*numel(RX2);
if diff1<diff2
    bestCutVar=1;
    W_new=W1;
    min_s=min(numel(LX1),numel(RX1));
    if min_s<minleaf
      bestCutVar=-1  ;
    end
else
  bestCutVar=1;
    W_new=W2;  
     min_s=min(numel(LX2),numel(RX2));
    if min_s<minleaf
      bestCutVar=-1  ;
    end
end
 

end