function [idx1,idx2]=group_reg(Label)
mlabel=median(unique(Label));
idx1=find(Label>mlabel);
idx2=find(Label<=mlabel);
end