function[bestCutVar,W_new]=hyperplane_psvm_reg_v1(Data,Label,minleaf)

flag_temp=1;

BAD_flag=0;
XX=unique(Label);
if length(XX)==1
   bestCutVar=-1;
   BAD_flag=1;
   W_new=zeros(size(Data,2)+1,1)';
end
if BAD_flag==0
[idx1,idx2]=group_reg(Label);
Data_A=Data(idx1,:);
Data_B=Data(idx2,:);
A=[Data_A,-1*ones(size(Data_A,1),1)];
B=[Data_B,-1*ones(size(Data_B,1),1)];
G=A'*A/size(A,1);
H=B'*B/size(B,1);

flag1=rank(G)==size(G,1);
flag2=rank(H)==size(H,1);
flag=flag1*flag2;
if flag==1
[eig_vector1,eig_value]=my_eig(H,G);
eig_vector1=eig_vector1(:,1);
W1=eig_vector1;
[eig_vector2,eig_value]=my_eig(G,H);
W2=eig_vector2(:,1);

W=[W1,W2];
else

% nFea=size(Data,2);
% idx=randperm(nFea);
% idx1=idx(1);
% W1=zeros(nFea+1,1);
% W1(idx1)=1;
% W1(end)=median(unique(Data(:,idx1)));
% idx2=idx(2);
% W2=zeros(nFea+1,1);
% W2(idx2)=1;
% W2(end)=median(unique(Data(:,idx2)));
[bestCutVar, bestCutValue] =axis_parallel_cut_reg(Label,Data,minleaf);
if bestCutVar~=-1
W1=zeros(size(Data,2)+1,1);
W1(bestCutVar)=1;
W1(end)=bestCutValue;
W=[W1,W1];
else
    W=zeros(size(Data,2)+1,2);
end

end
 [bestCutVar,W_new]=select_hyperplane_reg(W,Data,minleaf);
 if flag_temp==0
      bestCutVar=bestCutVar1;
 end
end
