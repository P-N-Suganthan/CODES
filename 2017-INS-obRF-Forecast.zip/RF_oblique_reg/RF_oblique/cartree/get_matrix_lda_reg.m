function [Sb,Sw]=get_matrix_lda_reg(Input,Target)
[n, m] = size(Input);
Target1=Target;
thresh=median(unique(Target));
Target1(Target1>=thresh)=1;
Target1(Target1<thresh)=-1;
Target=Target1;
ClassLabel = unique(Target);
k = length(ClassLabel);

nGroup     = NaN(k,1);     % Group counts

Sw  = zeros(m,m);   % Pooled covariance
Sb  = zeros(m,m);
mean_data=mean(Input);
for i = 1:k,
   
    Group      = (Target == ClassLabel(i));
    nGroup(i)  = sum(double(Group));
    Sw = Sw + ((nGroup(i) - 1) / (n - k) ).* cov(Input(Group,:));
    Sb=Sb+nGroup(i)* (mean(Input(Group,:))-mean_data)'*(mean(Input(Group,:))-mean_data);
end

end