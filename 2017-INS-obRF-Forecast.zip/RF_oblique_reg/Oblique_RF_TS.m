
clear;
clc;
Generic_Scale;
dataX=full(train_x);
[m,n]=size(dataX);
dataX=[train_x;test_x];
M=size(dataX,1);
mean_x=mean(dataX);
dataX=dataX-repmat(mean_x,M,1);
stdX=std(dataX);
dataX=dataX./repmat(stdX,M,1);
train_x=dataX(1:m,:);
test_x=dataX(m+1:end,:);
ntree=500;
   
flag=0;
P=[];

for mtry= 1:1:8;   
flag = flag+1;
model2=ObliqueRF_train(train_x,train_y,'ntrees',ntree,'nvartosample',mtry,'oblique',5,'minleaf',3);
[Y2,~]=ObliqueRF_predict(test_x,model2);
    
Y2=Y2';
unscaledpredict_y = train_y * scalesize + minvalue;
unscaledptest_y = Y2 * scalesize + minvalue;
unscaledtrain_y = train_y * scalesize + minvalue;
unscaledtest_y = test_y * scalesize + minvalue;

performance = errormeasure(unscaledtrain_y,unscaledpredict_y,unscaledtest_y,unscaledptest_y);
per={flag,performance(2),performance(6)}
P=[P,performance(end)];

end
