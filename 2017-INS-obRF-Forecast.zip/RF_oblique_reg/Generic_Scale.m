%data scaling
clear all;
clc;
load('manchas.mat');
%%
ODATA = manchas(1:end);
%POINTS = [0,1488,2832,4320,5760,7248,8688,10176,11664,13104,14592,16032,17520];


%ODATA = QDATA(POINTS(1)+1:POINTS(2));


DATA = (ODATA-min(ODATA))/(max(ODATA)-min(ODATA));
minvalue = min(ODATA);
scalesize = max(ODATA)-min(ODATA);
trainlength = floor(size(DATA,1)/20);
%trainlength = 100;
stepsize = 10;
samplesize = trainlength + stepsize-1;
ototalsize = length(ODATA)-samplesize;
trainsize = floor(ototalsize*7/100)*10;
testsize = floor(ototalsize*3/100)*10;
totalsize = trainsize + testsize;
%%
for i=1:totalsize+samplesize-trainlength;
    for j=1:trainlength;
    x(i,j)=DATA(i+j-1);
    end;
end;
%%
for i=1:trainsize;
    for j=1:trainlength;
       % if j<49
        train_x(i,j)=x(i,j);
       % else if j<97
                   % train_x(i,j)=(x(i+48,j-48)-x(i,j-48)+1)/2;
            
                %end;
       % end;
    end;
end;

train_y=DATA(samplesize+1:samplesize+trainsize);
%%
for i=1:testsize;
    for j=1:trainlength;
       % if j<49
    test_x(i,j)=x(i+trainsize,j);
    % else if j<97
                   %test_x(i,j)=(x(i+trainsize+48,j-48)-x(i+trainsize,j-48)+1)/2;
     
               % end;
       % end;
    end;
end;

test_y= DATA(trainsize+samplesize+1:trainsize+testsize+samplesize);
persistence_y = DATA(trainsize+trainlength:trainsize+testsize+trainlength-1);

unscaledtest_y = test_y * scalesize + minvalue;
unscaledptest_y = persistence_y * scalesize + minvalue;
performance2 = errormeasure(unscaledtest_y,unscaledptest_y,unscaledtest_y,unscaledptest_y);