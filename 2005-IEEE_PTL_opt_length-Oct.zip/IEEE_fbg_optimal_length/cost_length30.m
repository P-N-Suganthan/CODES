function cost=cost_length30(dn_pro);
Rdes=.99;
slen=.75+.75*dn_pro(31,1);

dn_pro=dn_pro(1:30,1)';

dw=2.5e-006;
waveL_s=1.5497;
 waveL_e=1.5503;
w=waveL_s:dw:waveL_e;

neff=1.452;     
G_period=(1.55/(2*neff));
N_sample=30;

[w,R,w_b,Tg,w_b2,Dp]=apodized_length(dn_pro,N_sample,neff,G_period,waveL_s,waveL_e,dw,slen);

 
db_nsector_array=20*log10(R);
Rdb=db_nsector_array;

hpbw1=find(db_nsector_array(121:241)<=-3);
sllbw1=find(db_nsector_array(121:241)<=-40);

if isempty(hpbw1) 
hpbwer1=120;
ppripmin=abs(min(Rdb));
if isempty(sllbw1)| sllbw1(1)>120,
if isempty(sllbw1),
    sllbwer1=70;sllmax1=abs(max(Rdb));else
    sllbwer1=120;sllmax1=abs(max(Rdb));end
else
sllbwer1=abs(sllbw1(1)-50); 
sllmax1=max(db_nsector_array(121+sllbw1(1):241));
end
end
    
if ~isempty(hpbw1) 
hpbwer1=abs(hpbw1(1)-40);

rip_band=round(.75*40);
ppripmin=abs(abs(max(db_nsector_array(121:121+rip_band)))-abs(min(db_nsector_array(121:121+rip_band))));


if isempty(sllbw1)| sllbw1(1)>120,
if isempty(sllbw1),
    sllbwer1=70;sllmax1=abs(max(Rdb));else
    sllbwer1=120;sllmax1=abs(max(Rdb));
end
else
sllbwer1=abs(sllbw1(1)-50); 
sllmax1=max(db_nsector_array(121+sllbw1(1):241));
end
end

    
Rmax=max(R);
if Rmax>=Rdes,Rmaxerr=0; else Rmaxerr=abs(Rdes-Rmax);end
if ppripmin<=.5,ppriperr=0;else ppriperr=10*abs(ppripmin-.5);end
if sllmax1 <-40,sler1=0;else sler1=abs(sllmax1+40);end
Tg_ripple=abs(max(Tg(1:80))-min(Tg(1:80)));
if Tg_ripple<=0.5,Tg_err=0;else Tg_err=(Tg_ripple-0.5);end


 len=30*slen;

cost=abs(hpbwer1)+abs(sler1)+abs(ppriperr)+sllbwer1+.2*Tg_err+.0000002*len+.01*Rmaxerr;

 
