[optimum_value,optimum_fit]=cmaes_main_length20(fname,feval_max,Xmin,Xmax,N_runs)


% There are three main programs used for finding  optimimum index modulation profiles and subsection change in length 
using CMAES algorithm for the 20 , 30 and 40 sections FBG filter

% CMAES.m - Program for cmaes optimization algorithm

% function name(fname) cost_length20, cost_length30 ,cost_length40

% feval_max-Maximum number of function evaluations

% Xmin-lower bound on design variables (index modulation) and minimum subsection change in length (dl)

% Xmax-upper bound on design variables (index modulation) and maximum subsection change in length (dl)

% number of runs

% optimum_fit - obejective function @ optimum value
% optimum_value- optimum design variables 

% n-number of uniform fbg sections

% apodized_length.m is used for simulating FBG structure


Typical function call for 20 sections FBG filter:
------------------------------------------------

Xmin=[-3e-4*ones(20,1);0];
Xmax=[3e-4*ones(20,1);1];

[optimum_value,optimum_fit]=cmaes_main_length20('cost_length20',20000,Xmin,Xmax,1)



Typical function call for 30 sections FBG filter:
------------------------------------------------

Xmin=[-3e-4*ones(30,1);0];
Xmax=[3e-4*ones(30,1);1];

[optimum_value,optimum_fit]=cmaes_main_length30('cost_length30',20000,Xmin,Xmax,1)



Typical function call for 40 sections FBG filter:
------------------------------------------------

Xmin=[-3e-4*ones(40,1);0];
Xmax=[3e-4*ones(40,1);1];

[optimum_value,optimum_fit]=cmaes_main_length40('cost_length40',20000,Xmin,Xmax,1)


Reference:

S. BASKAR, A. Alphones,P. N.  Suganthan, N. Q. Ngo and R. T. Zheng, �Design of optimal length low-dispersion FBG filter 
using covariance matrix adapted evolution�, IEEE Trans. on Photonics Technology Letters, Vol.17, No.10, October 2005. 