function [optimum_value,optimum_fit]=cmaes_main_length30(fname,feval_max,Xmin,Xmax,N_run)

% function name(fname) cost_length30
% apodized.m is used for simulating FBG structure
% n-number of uniform fbg sections (30)
% dl- subsection length
% N-Total number of variables  (n+1)
% Xmin-lower bound
% Xmax-upper bound
% N_run- number of runs
% window-filter window
% feval_max-Maximum number of function evaluations
% optimum_fit - best fitness  value
% optimum_value- design variables corresponding to best

% fname='cost_length30'
% Xmin=[-3e-4*ones(30,1);0];
% Xmax=[3e-4*ones(30,1);1];
% feval_max=1000;    

opts.StopFunEvals=feval_max;
warning off
n=30;N=n+1;
window=[0.44:.04:1  1:-.04:.44]';
opts.lbounds =Xmin;  
opts.UBounds =Xmax;
opts.StopFitness=1e-4;

for jj=1:N_run
xmeanw=Xmin+(Xmax-Xmin).*rand(N,1);
sigma=.5*(Xmax-Xmin);
optimum_value(:,jj)=cmaes(fname,xmeanw,sigma,opts);
optimum_fit(jj)=feval(fname,optimum_value(:,jj)); 
end
 