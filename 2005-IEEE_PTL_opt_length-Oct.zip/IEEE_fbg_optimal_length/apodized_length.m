 function [w,R,w_b,Tg,w_b2,Dp]=apodized_length(dn_pro,N_sample,neff1,Gspace1,waveL_s,waveL_e,dw,slen);
 dN_pitch=round((slen*10^-3)/(Gspace1*10^-6));


 
w=waveL_s:dw:waveL_e;
 N_pitch=dN_pitch*ones(1,N_sample);
Gspace=Gspace1*ones(1,N_sample);
neff=neff1*ones(1,N_sample);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

N_wave=length(w);

waveL_1=repmat(w',1,N_sample);
Gspace_1=repmat(Gspace,N_wave,1);
N_pitch_1=repmat(N_pitch,N_wave,1);
neff_1=repmat(neff,N_wave,1);
dn_1=repmat(dn_pro,N_wave,1);

Bragg=pi./Gspace_1;
z_1=Gspace_1.*N_pitch_1;

P_shift=(2*pi./waveL_1).*neff_1-Bragg;%-dsita_1;
K=-i*(pi./2*neff_1.*Gspace_1).*dn_1;
S=sqrt((abs(K)).^2-P_shift.^2);

F11=cosh(S.*z_1)+i.*P_shift.*sinh(S.*z_1)./S;
F21=conj(K).*sinh(S.*z_1)./S;
F12=K.*sinh(S.*z_1)./S;
F22=cosh(S.*z_1)-i.*P_shift.*sinh(S.*z_1)./S;


%elements of the transfer matrix
T11=F11(:,1);T12=F12(:,1);T21=F21(:,1);T22=F22(:,1);


for m=1:N_sample-1
   %%%%%%for superstructure FBG%%%%%%%%%%%
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   LT11=T11.*F11(:,m+1)+T12.*F21(:,m+1);
   LT12=T11.*F12(:,m+1)+T12.*F22(:,m+1);
   LT21=T21.*F11(:,m+1)+T22.*F21(:,m+1);
   LT22=T21.*F12(:,m+1)+T22.*F22(:,m+1);
   T11=LT11;T12=LT12;T21=LT21;T22=LT22;
end
r=-T21./T22;
t=1./T22;
R=(abs(r)).^2;
phase_r=unwrap(angle(r));
a1=diff(phase_r);
a=diff(a1);
ii=1;


for mm=82:162
% for mm=120-bw+1:120+bw+1
    pr(ii)=phase_r(mm);
    c(ii)=a(mm); %%%dispersion coefficient
    c1(ii)=a1(mm);
    w_b(ii)=w(mm)+0.5*dw;
    w_b2(ii)=w_b(ii)+0.5*dw;
    ii=ii+1;
end

Tg=-w_b.^2.*c1./(2*pi*3E14*dw)*1E12;%ps
Dp=-w_b2.^2*1E9.*(c/(dw*dw)+2*c1./(w_b2*dw))./(2*pi*3E14);%ps/n

% 
