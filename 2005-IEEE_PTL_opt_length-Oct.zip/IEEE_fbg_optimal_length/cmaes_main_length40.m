function [optimum_value,optimum_fit]=cmaes_main_length40(fname,feval_max,Xmin,Xmax,N_run)

% function name(fname) cost_bas_fit40
% apodized.m is used for simulating FBG structure
% n-number of uniform fbg sections (40)
% dl- subsection length
% N-Total number of variables  (n+1)
% Xmin-lower bound
% Xmax-upper bound
% N_run- number of runs
% window-filter window
% feval_max-Maximum number of function evaluations
% optimum_fit - best fitness  value
% optimum_value- design variables corresponding to best


opts.StopFunEvals=feval_max;
warning off
window=[0.4109 0.5 0.5500 0.6 0.6891  0.75  0.8145 0.86   0.9141 0.96   1  1  1.0000 0.99    0.9780   0.95  0.9141 0.86 0.8145  0.75  0.6891 0.62  0.5500 0.48    0.4109  0.35  0.2855 0.24    0.1859 0.16 0.1220 0.11    0.1000   0.11   0.1220 0.16   0.1859  0.24  0.2855 0.2855 ]';% very good window
opts.lbounds =Xmin;  
opts.UBounds =Xmax;
opts.StopFitness=1e-4;
n=40;N=n+1;

for jj=1:N_run
xmeanw=Xmin+(Xmax-Xmin).*rand(N,1);
sigma=.5*(Xmax-Xmin);
optimum_value(:,jj)=cmaes(fname,xmeanw,sigma,opts);
optimum_fit(jj)=feval(fname,optimum_value(:,jj)); 
end