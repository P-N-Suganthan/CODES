# US-RVFL
The codes for **Representation learning using deep random vector functional link networks for clustering**.
[[Paper]](https://www.sciencedirect.com.remotexs.ntu.edu.sg/science/article/pii/S0031320322002254)
