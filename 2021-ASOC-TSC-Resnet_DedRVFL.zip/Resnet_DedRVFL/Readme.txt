Time Series Classification Using Diversified Ensemble Deep Random Vector Functional Link and Resnet Features

1. Contents
a) Demo
b) edRVFL Codes with the following variants:
   i)    2S_AFE: edRVFL with 2-Stage tuning & 2 activation functions
   ii)   2S_AFE_W: weighted edRVFL with 2-Stage tuning & 2 activation functions
   iii)  2S_SAF: edRVFL with 2-Stage tuning & single activation function
   iv)   D_2S_AFE: edRVFL with diverse N/C, 2-Stage tuning & 2 activation functions
   v)    D_2S_AFE_W: weighted edRVFL with diverse N/C, 2-Stage tuning & 2 activation functions
   vi)   D_FS_2S_AFE: edRVFL with diverse N/C, diverse features, 2-Stage tuning & 2 activation functions
   vii)  D_FS_2S_AFE_W: weighted edRVFL with diverse N/C, diverse features, 2-Stage tuning & 2 activation functions
   viii) FS_2S_AFE: edRVFL with diverse features, 2-Stage tuning & 2 activation functions
   ix)   FS_2S_AFE_W: weighted edRVFL with diverse features, 2-Stage tuning & 2 activation functions
   x)    GS_AFE: edRVFL with grid search & 2 activation functions
   xi)   GS_SAF: edRVFL with grid search & single activation function
c) ResNet Codesd) Softmax Codes 
e) Repackaged Dataset Files
f) TUne indices

2. Usage Example
Follow the instructions in the readme file inside Demo folder.

3. Data
Datasets can be found in:
http://www.cs.ucr.edu/~eamonn/time_series_data/

Train & Test files can be repackaged into a mat file (named as "_R.mat") that contains:
a) trainX
b) trainY
c) testX
d) testY

See "ECG200_R.mat" in "Demo/Data files/ECG200" for sample.

We use 4-fold stratified cross-validation. Tune indices is fixed and found in "_Tune.mat" files. The files are available in "Tune Indices" folder.