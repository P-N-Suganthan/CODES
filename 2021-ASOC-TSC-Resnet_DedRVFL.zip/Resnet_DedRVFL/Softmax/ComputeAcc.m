function acc = ComputeAcc(Y,ProbScores)

Class_dist = zeros(size(Y));

for i=1:numel(ProbScores)
  Dist_temp = ProbScores{i};  
  Class_dist = Class_dist + Dist_temp;
end

AvgProbScores = Class_dist./numel(ProbScores);                                               
[MaxProb,indx] = max(AvgProbScores,[],2);

% votes = zeros(size(Y));
% 
% for i=1:numel(ProbScores)
%     [~,voteT] = max(ProbScores{i},[],2);
%     idx = sub2ind(size(votes),1:numel(voteT),voteT');
%     votes(idx) = votes(idx) + 1;
% end
%                                              
% [MaxVotes,indx] = max(votes,[],2);
[~, Ind_corrClass] = max(Y,[],2);
acc = mean(indx == Ind_corrClass);

end