function [model,TrainAcc,TrainTime,Scores] = MRVFL_Ensemble_Train(trainX,trainY,C)
nSets = numel(trainX);

TrainTime = 0;
Scores = cell(nSets,1);
for i = 1:nSets
    [model(i),Scores{i},TrainTimeT] = MRVFLtrain(trainX{i},trainY,C(i));

    TrainTime = TrainTime + TrainTimeT;

end

TrainAcc = ComputeAcc(trainY,Scores);

end