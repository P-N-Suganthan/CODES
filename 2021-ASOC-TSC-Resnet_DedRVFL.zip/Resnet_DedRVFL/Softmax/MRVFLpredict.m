function [Scores,TestTime] = MRVFLpredict(testX,model)

[Nsample,~] = size(testX);

beta = model.beta;

tic;

%% First Layer
A1_out = [testX,ones(Nsample,1)]; %bias in the output layer
testY_temp = A1_out*beta;

% Softmax to generate probabilites
testY_temp1 = bsxfun(@minus,testY_temp,max(testY_temp,[],2)); %for numerical stability
num = exp(testY_temp1);
dem = sum(num,2);
prob_scores = bsxfun(@rdivide,num,dem);
Scores = prob_scores;

clear A1_out testY_temp testY_temp1 num dem prob_scores

%% Calculate the testing time
TestTime = toc;

end