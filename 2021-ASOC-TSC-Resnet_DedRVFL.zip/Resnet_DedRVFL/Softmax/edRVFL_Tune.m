function [C,ValAcc,ValTime,AllResults,AllValTime] = edRVFL_Tune(trainX,trainY,testX,testY,options)

% Initialisation
[kFold,nSets] = size(trainX);
ValAcc = zeros(nSets,0);
ValTime = zeros(nSets,1);
C = zeros(nSets,0);
AllResults = cell(nSets,1);
AllValTime = zeros(nSets,1);

for set_no = 1:nSets

    % Hyperparameters to tune and range
    C_range = options.C;

    % Initialisation
    ValTimeT = 0;
    BestAcc = 0;
    count = 1;
    
    % Evaluates each configuration.
    for p1 = 1:numel(C_range)

        % Configures model
        CT = C_range(p1);

        % K-fold Cross Validation
        for k = 1:kFold
            
            % Training and Testing
            ResultsT(k) = MRVFL(trainX(k,set_no),trainY{k},testX(k,set_no),testY{k},CT);

        end

        % Mean validation results for the tested configuration
        mean_acc = mean([ResultsT.TestAcc]);
        
        % Adds time taken for parameter tuning.
        ValTimeT = ValTimeT + sum([ResultsT.TrainTime]) + sum([ResultsT.TestTime]);

        % Save the best configuration obtained so far.
        if mean_acc > BestAcc

            BestAcc = mean_acc;
            Best_C = C_range(p1);

        end

        % Record Results
        ResultT1(count).C = C_range(p1);
        ResultT1(count).MeanValAcc = mean_acc;
        ResultT1(count).ValAcc = [ResultsT.TestAcc];

        count = count + 1;
    end

    fprintf('Best: C = 2^%d, Val. Acc. = %f%%\n',...
       log2(Best_C),BestAcc*100);

    AllResults{set_no,1} = ResultT1;
    AllValTime(set_no,1) = ValTimeT;
    
    clear ResultsT1
    

    %% Final Result
    ValAcc(set_no) = BestAcc;
    ValTime(set_no) = sum(AllValTime(set_no,:));
    C(set_no) = Best_C;
    
    
end
end
