function [model,Scores,TrainTime] = MRVFLtrain(trainX,trainY,C)

[nSample,~] = size(trainX);

tic;
    
A1_out = [trainX,ones(nSample,1)]; %direct links+bias in the output layer
beta = l2_weights(A1_out,trainY,C,nSample);
    
% Output Layer predictions
trainY_temp = A1_out*beta;

% Softmax to generate probabilites
trainY_temp1 = bsxfun(@minus,trainY_temp,max(trainY_temp,[],2)); %for numerical stability
num = exp(trainY_temp1);
dem = sum(num,2);
prob_scores = bsxfun(@rdivide,num,dem);
Scores = prob_scores;
    
clear A1_out trainY_temp trainY_temp1 num dem prob_scores

TrainTime = toc;

model.C = C;
model.beta = beta;

end