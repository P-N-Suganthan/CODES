function [TestAcc,TestTime,Scores] = MRVFL_Ensemble_Predict(testX,testY,model)
nSets = numel(testX);

% Initialisation
TestTime = 0;
Scores = cell(nSets,1);
for i = 1:nSets
     [Scores{i},TestTimeT] = MRVFLpredict(testX{i},model(i));
    
    TestTime = TestTime + TestTimeT;
    
end

TestAcc = ComputeAcc(testY,Scores);

end

