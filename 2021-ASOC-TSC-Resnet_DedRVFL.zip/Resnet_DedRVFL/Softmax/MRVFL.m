function [Results,Model,TrainScores,TestScores]  = MRVFL(trainX,trainY,testX,testY,C)

% Train RVFL
[Model,TrainAcc,TrainTime,TrainScores] = MRVFL_Ensemble_Train(trainX,trainY,C);

% Using trained model, predict the testing data
[TestAcc,TestTime,TestScores] = MRVFL_Ensemble_Predict(testX,testY,Model);

Results.TrainAcc = TrainAcc;
Results.TestAcc = TestAcc;
Results.TrainTime = TrainTime;
Results.TestTime = TestTime;

end
%EOF