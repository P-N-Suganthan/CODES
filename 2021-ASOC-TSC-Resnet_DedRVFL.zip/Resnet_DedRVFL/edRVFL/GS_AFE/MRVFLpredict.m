function [TestAcc,TestTime,Scores] = MRVFLpredict(testX,testY,model)

[Nsample,~] = size(testX);

% Initialization
L = model.L;
w = model.w;
b = model.b;
beta = model.beta;
activation = model.activation;
mu = model.mu;
sigma = model.sigma;

Scores = cell(L,1); %depends on number of hidden layer

tic;
    
A_input = testX;
dl_link = testX;

%% First Layer
for i = 1:L

    % Hidden Layer Operation
    A1 = A_input * w{i};

    A1 = A1 + repmat(b{i},Nsample,1);

    % Normalisation
    A1 = bsxfun(@rdivide,A1-repmat(mu{i},size(A1,1),1),sigma{i});
    
    % Activation Function
    switch lower(activation)
        case 'relu' % Range: [0,inf]
            A1 = relu(A1);

        case {'sig','sigmoid'} % Range: [0,1]
            A1 = sigmoid(A1);
            
        case {'sin','sine'} % Range: [-1,1]
            % Force values to be within -pi/2 to pi/2
            A1 = max(A1,-pi/2);
            A1 = min(A1,pi/2);
            
            A1 = sin(A1);
            
        case 'hardlim' % Range: [0,1]
            A1 = double(hardlim(A1));
            
        case 'tribas' % Range: [0,1]
            A1 = tribas(A1);
            
        case 'radbas' % Range: [0,1]
            A1 = radbas(A1);
            
        case 'sign' % Range: [-1,1]
            A1 = sign(A1);
            
        case 'selu' % Range: [-1,inf]
            A1 = selu(A1);
            
        otherwise
            error('Activation function not recognized.');

    end     


    % Output layer
    A1_out = [A1,dl_link,ones(Nsample,1)]; %bias in the output layer
    testY_temp = A1_out*beta{i};

    % Softmax to generate probabilites
    testY_temp1 = bsxfun(@minus,testY_temp,max(testY_temp,[],2)); %for numerical stability
    num = exp(testY_temp1);
    dem = sum(num,2);
    prob_scores = bsxfun(@rdivide,num,dem);
    Scores{i} = prob_scores;

    A_input = [A1, testX];

    % Direct Links for next layer
    dl_link = [A1, testX];

    clear A1 A1_out testY_temp1 num dem prob_scores
end

%% Calculate the testing time
TestTime = toc;

TestAcc = ComputeAcc(testY,{Scores},1);

end