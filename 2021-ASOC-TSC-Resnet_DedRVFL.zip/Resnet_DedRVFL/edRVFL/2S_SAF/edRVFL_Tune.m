function [TunedParameters,ValAcc,ValTime,AllResults,AllValTime] = ...
    edRVFL_Tune(trainX,trainY,testX,testY,options)

% Template of Classifier Parameters
ModelParameters.L = 20;
ModelParameters.N = 100;
ModelParameters.scale = 1;
ModelParameters.C = 0.1;
ModelParameters.activation = 'relu';
ModelParameters.weight = 1;

Activations = options.activations;
L = options.L;

% Initialisation
[kFold,nSets] = size(trainX);
ValAcc = zeros(nSets,1);
ValTime = zeros(nSets,1);
TunedParameters(nSets,1) = ModelParameters;
AllResults = cell(nSets,3,numel(Activations));
AllValTime = zeros(nSets,2);

for set_no = 1:nSets
    % Initialisation
    ValTimeT = 0;
    Best_Ns = zeros(numel(Activations),1);
    Best_Cs = zeros(numel(Activations),1);
    ValAccs = zeros(numel(Activations),1);
    
    %% Tuning Stage 1: Selecting Activation Function, N(1), C(1)
    for p3 = 1:numel(Activations)
        %% Tuning Stage 1a
        % Initialisation
        BestAccT = 0;
        count = 1;
        
        % Coarse ranges of parameters to be tested.
        N_range_1a = options.N;
        C_range_1a = options.C;
        
        % Evaluates each configuration.
        for p1 = 1:numel(N_range_1a)
            for p2 = 1:numel(C_range_1a)

                % Configures model
                optionsT = ModelParameters;
                optionsT.N = N_range_1a(p1);
                optionsT.C = C_range_1a(p2);
                optionsT.L = 1;
                optionsT.activation = Activations{p3};

                % K-fold Cross Validation
                for k = 1:kFold

                    % Training and Testing
                    ResultsT(k) = MRVFL(trainX(k,set_no),trainY{k},testX(k,set_no),testY{k},optionsT);

                end

                % Mean validation results for the tested configuration
                mean_accT = mean([ResultsT.TestAcc]);
                
                % Adds time taken for parameter tuning.
                ValTimeT = ValTimeT + sum([ResultsT.TrainTime]) + sum([ResultsT.TestTime]);
                
                % Save the best configuration obtained so far in stage 1a.
                if mean_accT > BestAccT

                    BestAccT = mean_accT;
                    Best_NT = N_range_1a(p1);
                    Best_CT = C_range_1a(p2);

                end

                % Record Results
                ResultT1(count).N = N_range_1a(p1);
                ResultT1(count).C = C_range_1a(p2);
                ResultT1(count).Activation = Activations{p3};
                ResultT1(count).MeanValAcc = mean_accT;
                ResultT1(count).ValAcc = [ResultsT.TestAcc];

                count = count + 1;
            end
        end

        %% Tuning Stage 1b
        count = 1;
        BestAccT = 0;
        
        % Fine ranges of parameters to be tested.
        N_range_1b = Best_NT + options.Nadj;
        C_range_1b = Best_CT*options.Cadj;

        % Evaluates each configuration.
        for p1 = 1:numel(N_range_1b)
            for p2 = 1:numel(C_range_1b)

                % Configures model
                optionsT = ModelParameters;
                optionsT.N = N_range_1b(p1);
                optionsT.C = C_range_1b(p2);
                optionsT.activation = Activations{p3};
                optionsT.L = 1;

                % K-fold Cross Validation
                for k = 1:kFold

                    % Training and Testing
                    ResultsT(k) = MRVFL(trainX(k,set_no),trainY{k},testX(k,set_no),testY{k},optionsT);

                end

                % Mean validation results for the tested configuration
                mean_accT = mean([ResultsT.TestAcc]);
                
                % Adds time taken for parameter tuning.
                ValTimeT = ValTimeT + sum([ResultsT.TrainTime]) + sum([ResultsT.TestTime]);

                % Save the best configuration obtained so far in stage 1b.
                if mean_accT > BestAccT

                    BestAccT = mean_accT;
                    Best_NT = N_range_1b(p1);
                    Best_CT = C_range_1b(p2);

                end

                % Record Results
                ResultT2(count).N = N_range_1b(p1);
                ResultT2(count).C = C_range_1b(p2);
                ResultT2(count).Activation = Activations{p3};
                ResultT2(count).MeanValAcc = mean_accT;
                ResultT2(count).ValAcc = [ResultsT.TestAcc];

                count = count + 1;
            end
        end
        
        % Save the best configuration obtained for selected activation function.
        Best_Ns(p3) = Best_NT;
        Best_Cs(p3) = Best_CT;
        ValAccs(p3) = BestAccT;
        
        % Record Results
        AllResults{set_no,1,p3} = ResultT1;
        AllResults{set_no,2,p3} = ResultT2;
        clear ResultT1 ResultT2
    end
    
    % Activation Functions Selection
    [BestAcc,idx] = max(ValAccs);
    Best_N(1) = Best_Ns(idx);
    Best_C(1) = Best_Cs(idx);
    Best_Act = Activations{idx};

    % Records the validation time for stage 1 tuning.
    AllValTime(set_no,1) = ValTimeT;
    
    % Displays the best configuration found in stage 1.
    fprintf('Stage 1 Best: N = %d, C = 2^%d, activation = %s, Val. Acc. = %f%%, Time = %f\n',...
       Best_N(1), log2(Best_C(1)), Best_Act, BestAcc*100, ValTimeT);

    %% Final Result
    ValAcc(set_no) = BestAcc;
    ValTime(set_no) = sum(AllValTime(set_no,:));
    
    % Set best configuration
    TunedParameters(set_no,1) = ModelParameters;
    TunedParameters(set_no,1).L = L;
    TunedParameters(set_no,1).N = Best_N;
    TunedParameters(set_no,1).C = Best_C;
    TunedParameters(set_no,1).activation = Best_Act;
end
end
