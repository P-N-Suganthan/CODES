clear;
clc;

% Experiment Parameters
input_dir = '../Datasets';           % Path to datasets + features (.mat file)
problems = ["Adiac";"ChlorineConcentration";"Computers";"CricketX";"CricketY";
    "CricketZ";"DistalPhalanxOutlineAgeGroup";"DistalPhalanxOutlineCorrect";"DistalPhalanxTW";"Earthquakes";
    "ECG200";"ECG5000";"ElectricDevices";"FaceAll";"FacesUCR";
    "FiftyWords";"Fish";"FordA";"FordB";"Ham";
    "HandOutlines";"Haptics";"InlineSkate";"InsectWingbeatSound";"LargeKitchenAppliances";
    "MedicalImages";"MiddlePhalanxOutlineAgeGroup";"MiddlePhalanxOutlineCorrect";"MiddlePhalanxTW";"NonInvasiveFatalECGThorax1";
    "NonInvasiveFatalECGThorax2";"OSULeaf";"PhalangesOutlinesCorrect";"Phoneme";"Plane";
    "ProximalPhalanxOutlineAgeGroup";"ProximalPhalanxOutlineCorrect";"ProximalPhalanxTW";"RefrigerationDevices";"ScreenType";
    "ShapesAll";"SmallKitchenAppliances";"StarlightCurves";"Strawberry";"SwedishLeaf";
    "SyntheticControl";"Trace";"TwoPatterns";"UWaveGestureLibraryAll";"UWaveGestureLibraryX";
    "UWaveGestureLibraryY";"UWaveGestureLibraryZ";"Wafer";"WordSynonyms";"Yoga"];  % List of datasets

kFold = 4;  % Number of tuning folds

% Tuning Options
% N in 3:20:323
% C in 2.^(-8:1:17);
% Activations in {'relu','sigmoid','selu','radbas','sine'};
TuneOptions.nClf = 20;                % Number of classifiers in the ensemble
TuneOptions.N = 43:60:283;            % Range of N
TuneOptions.C = 2.^(-6:3:15);         % Range of C = 1/lamda
TuneOptions.Nadj = -40:20:40;         % Range of N fine adjustments
TuneOptions.Cadj = 2.^(-2:2);         % Range of C fine adjustments
TuneOptions.scale = 1;                % Scaling parameter
TuneOptions.activations = {'relu','sigmoid','selu','radbas','sine'};   % Activation Functions
TuneOptions.nActFun = 2;              % Number of activation functions to select

for i = 1:numel(problems)
    
    clear('dataX','dataY','TRAIN_idx','TEST_idx','ResultFold');
    
    % Collect dataset
    load(sprintf('%s/%s/%s_R.mat',input_dir,problems(i),problems(i)));        % Original TrainX, TestX
    load(sprintf('%s/%s/%s_ResNet.mat',input_dir,problems(i),problems(i)));     % ResNet Features
    load(sprintf('%s/%s/%s_Tune.mat',input_dir,problems(i),problems(i)));     % Tune Indices
    load(sprintf('%s/%s/%s_ResNet_Tune.mat',input_dir,problems(i),problems(i)));   % ResNet Features (Tune)

    % Encode target
    trainY = OneVAllEncode(trainY);
    testY = OneVAllEncode(testY); 

    % Create training/testing split
    trainX = TRAIN_ResNetdata(1,:);          % Using ResNet Features 
    testX = TEST_ResNetdata(1,:);            % Using ResNet Features 

    % Data Normalisation
    nSets = numel(trainX);
    for set_no = 1:nSets
        mean_X = mean(trainX{set_no},1);
        std_X = std(trainX{set_no});
        std_X(std_X==0) = 1e-4;                 % For numerical stability
        trainX{set_no} = bsxfun(@rdivide,trainX{set_no}-repmat(mean_X,size(trainX{set_no},1),1),std_X);
        testX{set_no} = bsxfun(@rdivide,testX{set_no}-repmat(mean_X,size(testX{set_no},1),1),std_X);
    end

    % Collect validation data and validation data normalisation
    trainX_val = cell(kFold,nSets);
    trainY_val = cell(kFold,1);
    testX_val = cell(kFold,nSets);
    testY_val = cell(kFold,1);
    for k = 1:kFold
        for set_no = 1:nSets
            % Standard Normalisation
            meanX_val = mean(TRAIN_ResNetdata_Tune{k,set_no},1);
            stdX_val = std(TRAIN_ResNetdata_Tune{k,set_no});
            stdX_val(stdX_val==0) = 1e-4;         % For numerical stability
            trainX_val{k,set_no} = bsxfun(@rdivide,TRAIN_ResNetdata_Tune{k,set_no}-repmat(meanX_val,size(TRAIN_ResNetdata_Tune{k,set_no},1),1),stdX_val);
            testX_val{k,set_no} = bsxfun(@rdivide,TEST_ResNetdata_Tune{k,set_no}-repmat(meanX_val,size(TEST_ResNetdata_Tune{k,set_no},1),1),stdX_val);
        end
        
        trainY_val{k} = trainY(train_tune(k,:),:);
        testY_val{k} = trainY(test_tune(k,:),:);
    end

    % Parameter Tuning
    [ModelParameters,ValAcc,ValTime,AllValResults,AllValTime] = edRVFL_Tune(trainX_val,trainY_val,testX_val,testY_val,TuneOptions);

    % Train and Evaluate Classifier
    [ResultT,model,TrainScores,TestScores] = MRVFL(trainX,trainY,testX,testY,ModelParameters);

    %% Results

    % Calculate performance parameters
    Results.TrainAcc = ResultT.TrainAcc;
    Results.TestAcc = ResultT.TestAcc;
    Results.ValAcc = ValAcc;
    Results.ValTime = ValTime;
    Results.TrainTime = ResultT.TrainTime;
    Results.TestTime = ResultT.TestTime;

    % Displays experiment results
    fprintf('Train Acc = %f%% Test Acc = %f%%\n',Results.TrainAcc*100,Results.TestAcc*100)

    if i == 1
        mkdir('D 2S AFE/');
    end

    ResultFilename = sprintf('D 2S AFE/Result_%s.mat',problems(i));
    save(ResultFilename,'Results','ModelParameters','AllValResults','AllValTime');     % Save result
end
 