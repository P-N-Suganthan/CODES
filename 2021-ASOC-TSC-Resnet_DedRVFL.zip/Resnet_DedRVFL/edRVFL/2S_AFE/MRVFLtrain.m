function [model,TrainAcc,TrainTime,Scores] = MRVFLtrain(trainX,trainY,option)

if ~isfield(option,'L')|| isempty(option.L)
    option.L=10;
end
if ~isfield(option,'scale')|| isempty(option.scale)
    option.scale=1;
end
if ~isfield(option,'activation')|| isempty(option.activation)
    option.activation='relu';
end

% Initialization
[nSample,~] = size(trainX);
N = option.N;
L = option.L;
C = option.C;
s = option.scale;  %scaling factor
activation = option.activation;

Scores = cell(L,1);
beta = cell(L,1);
weights = cell(L,1);
biases = cell(L,1);
mu = cell(L,1);
sigma = cell(L,1);

A_input = trainX;
dl_link = trainX;

tic;
for i = 1:L
        
    % Hidden Layer Initialisation + Operation
    w = s*(2*rand(size(A_input,2),N)-1);
    b = s*rand(1,N);
    A1 = A_input * w;

    % Add bias
    A1 = A1 + repmat(b,nSample,1);
    
    % Normalisation
    mu{i} = mean(A1,1);
    sigma{i} = std(A1);
    A1 = bsxfun(@rdivide,A1-repmat(mu{i},size(A1,1),1),sigma{i});

    % Activation Function
    switch lower(activation)
        case 'relu' % Range: [0,inf]
            A1 = relu(A1);

        case {'sig','sigmoid'} % Range: [0,1]
            A1 = sigmoid(A1);
            
        case {'sin','sine'} % Range: [-1,1]
%             % Force values to be within -pi/2 to pi/2
%             A1 = max(A1,-pi/2);
%             A1 = min(A1,pi/2);
            
            A1 = sin(A1);
            
        case 'hardlim' % Range: [0,1]
            A1 = double(hardlim(A1));
            
        case 'tribas' % Range: [0,1]
            A1 = tribas(A1);
            
        case 'radbas' % Range: [0,1]
            A1 = radbas(A1);
            
        case 'sign' % Range: [-1,1]
            A1 = sign(A1);
            
        case 'selu' % Range: [-1,inf]
            A1 = selu(A1);
            
        otherwise
            error('Activation function not recognized.');

    end 

    % Output layer
    A1_out = [A1,dl_link,ones(nSample,1)]; %direct links+bias in the output layer
    beta1 = l2_weights(A1_out,trainY,C,nSample);

    % Output Layer predictions
    trainY_temp = A1_out*beta1;

    % Softmax to generate probabilites
    trainY_temp1 = bsxfun(@minus,trainY_temp,max(trainY_temp,[],2)); %for numerical stability
    num = exp(trainY_temp1);
    dem = sum(num,2);
    prob_scores = bsxfun(@rdivide,num,dem);
    Scores{i} = prob_scores;

    % Store these for later use
    weights{i} = w; 
    biases{i} = b;
    beta{i} = beta1;

    % Output for next layer
    A_input = [A1, trainX];

    % Direct Links for next output layer
    dl_link = [A1, trainX];
    
    clear A1 A1_out beta1 w b trainY_temp trainY_temp1 num dem prob_scores
end

TrainTime = toc;

TrainAcc = ComputeAcc(trainY,{Scores},1);

model.L = L;
model.N = N;
model.C = C;
model.w = weights;
model.b = biases;
model.beta = beta;
model.activation = activation;
model.mu = mu;
model.sigma = sigma;
model.weight = option.weight;

end