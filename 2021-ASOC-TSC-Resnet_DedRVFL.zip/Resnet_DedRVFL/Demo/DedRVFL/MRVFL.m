function [Results,Model,TrainScores,TestScores]  = MRVFL(trainX,trainY,testX,testY,option)

if ~isfield(option,'seed')||isempty(option(1).seed)
    option(1).seed = 0;
end

% Requried for consistency
s = RandStream('mcg16807','Seed',option(1).seed);
RandStream.setGlobalStream(s);

% Train RVFL
[Model,TrainAcc,TrainTime,TrainScores] = MRVFL_Ensemble_Train(trainX,trainY,option);

% Using trained model, predict the testing data
[TestAcc,TestTime,TestScores] = MRVFL_Ensemble_Predict(testX,testY,Model);

Results.TrainAcc = TrainAcc;
Results.TestAcc = TestAcc;
Results.TrainTime = TrainTime;
Results.TestTime = TestTime;

end
%EOF