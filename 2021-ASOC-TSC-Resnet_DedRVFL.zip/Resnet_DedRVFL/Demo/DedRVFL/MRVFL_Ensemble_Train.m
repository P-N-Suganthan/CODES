function [model,TrainAcc,TrainTime,Scores] = MRVFL_Ensemble_Train(trainX,trainY,option)
nSets = numel(trainX);
nClf = size(option,2);

TrainTime = 0;
Scores = cell(nSets,nClf);
for i = 1:nSets
    for j = 1:nClf
        [model(i,j),~,TrainTimeT,Scores{i,j}] = MRVFLtrain(trainX{i},trainY,option(i,j));

        TrainTime = TrainTime + TrainTimeT;
    end
end

Weights = reshape([model.weight],nSets,[]);
Weights = Weights/sum(sum(Weights));

TrainAcc = ComputeAcc(trainY,Scores,Weights);

end