function result = selu(x)

scale = 1.0507009873554804934193349852946;
alpha = 1.6732632423543772848170429916717;

result = (x>=0).*(scale*x)+ ~(x>=0).*(scale*alpha*(exp(x)-1));

end