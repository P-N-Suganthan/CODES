function [TestAcc,TestTime,Scores] = MRVFL_Ensemble_Predict(testX,testY,model)
nSets = numel(testX);
nClf = size(model,2);

% Initialisation
TestTime = 0;
Scores = cell(nSets,nClf);
for i = 1:nSets
    for j = 1:nClf
        [~,TestTimeT,Scores{i,j}] = MRVFLpredict(testX{i},testY,model(i,j));

        TestTime = TestTime + TestTimeT;
    end
end

Weights = reshape([model.weight],nSets,[]);
Weights = Weights/sum(sum(Weights));

TestAcc = ComputeAcc(testY,Scores,Weights);

end

