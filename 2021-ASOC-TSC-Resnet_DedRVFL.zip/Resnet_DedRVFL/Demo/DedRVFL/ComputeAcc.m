function acc = ComputeAcc(Y,ProbScores,Weights)

Score = zeros(size(Y));
AvgProbScores = cell(numel(ProbScores),1);
for i=1:numel(ProbScores)
    ProbScoresT = ProbScores{i};
    Class_dist = zeros(size(Y));
    for j = 1:numel(ProbScoresT)
       Dist_temp = ProbScoresT{j};  
       Class_dist = Class_dist + Dist_temp;
       
    end
    AvgProbScores{i} = Class_dist./numel(ProbScores);     
    
    Score = Score + Weights(i)*AvgProbScores{i};
end
                                        
[MaxProb,indx] = max(Score,[],2);
[~, Ind_corrClass] = max(Y,[],2);
acc = mean(indx == Ind_corrClass);

end