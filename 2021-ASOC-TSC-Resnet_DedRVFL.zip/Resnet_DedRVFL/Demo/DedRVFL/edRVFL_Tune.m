function [TunedParameters,ValAcc,ValTime,AllResults,AllValTime] = ...
    edRVFL_Tune(trainX,trainY,testX,testY,options)

% Template of Classifier Parameters
ModelParameters.L = 20;
ModelParameters.N = [100,100];
ModelParameters.scale = 1;
ModelParameters.C = [0.1,0.1];
ModelParameters.Fea_ratio = 0.5;
ModelParameters.activation = 'relu';
ModelParameters.weight = 1;

Activations = options.activations;
nClf = options.nClf;
nFunct = options.nActFun;

% Initialisation
[kFold,nSets] = size(trainX);
ValAcc = zeros(nSets,1);
ValTime = zeros(nSets,1);
TunedParameters(nSets,1) = ModelParameters;
AllResults = cell(nSets,4,numel(Activations));
AllValTime = zeros(nSets,3);

for set_no = 1:nSets
    % Initialisation
    ValTimeT = 0;
    Best_Ns = zeros(numel(Activations),1);
    Best_Cs = zeros(numel(Activations),1);
    ValAccs = zeros(numel(Activations),1);
    
    %% Tuning Stage 1: Selecting Activation Function, N(1), C(1)
    for p3 = 1:numel(Activations)
        %% Tuning Stage 1a
        % Initialisation
        BestAcc1 = 0;
        count = 1;
        
        % Coarse ranges of parameters to be tested.
        N_range_1a = options.N;
        C_range_1a = options.C;
        
        % Evaluates each configuration.
        for p1 = 1:numel(N_range_1a)
            for p2 = 1:numel(C_range_1a)

                % Configures model
                optionsT = ModelParameters;
                optionsT.N = N_range_1a(p1);
                optionsT.C = C_range_1a(p2);
                optionsT.L = 1;
                optionsT.activation = Activations{p3};

                % K-fold Cross Validation
                for k = 1:kFold

                    % Training and Testing
                    ResultsT(k) = MRVFL(trainX(k,set_no),trainY{k},testX(k,set_no),testY{k},optionsT);

                end

                % Mean validation results for the tested configuration
                mean_accT = mean([ResultsT.TestAcc]);
                
                % Adds time taken for parameter tuning.
                ValTimeT = ValTimeT + sum([ResultsT.TrainTime]) + sum([ResultsT.TestTime]);
                
                % Save the best configuration obtained so far in stage 1a.
                if mean_accT > BestAcc1

                    BestAcc1 = mean_accT;
                    Best_NT = N_range_1a(p1);
                    Best_CT = C_range_1a(p2);

                end

                % Record Results
                ResultT1(count).N = N_range_1a(p1);
                ResultT1(count).C = C_range_1a(p2);
                ResultT1(count).Activation = Activations{p3};
                ResultT1(count).MeanValAcc = mean_accT;
                ResultT1(count).ValAcc = [ResultsT.TestAcc];

                count = count + 1;
            end
        end

        %% Tuning Stage 1b
        count = 1;
        
        % Fine ranges of parameters to be tested.
        N_range_1b = Best_NT + options.Nadj;
        C_range_1b = Best_CT*options.Cadj;

        % Evaluates each configuration.
        for p1 = 1:numel(N_range_1b)
            for p2 = 1:numel(C_range_1b)

                % Configures model
                optionsT = ModelParameters;
                optionsT.N = N_range_1b(p1);
                optionsT.C = C_range_1b(p2);
                optionsT.activation = Activations{p3};
                optionsT.L = 1;

                % K-fold Cross Validation
                for k = 1:kFold

                    % Training and Testing
                    ResultsT(k) = MRVFL(trainX(k,set_no),trainY{k},testX(k,set_no),testY{k},optionsT);

                end

                % Mean validation results for the tested configuration
                mean_accT = mean([ResultsT.TestAcc]);
                
                % Adds time taken for parameter tuning.
                ValTimeT = ValTimeT + sum([ResultsT.TrainTime]) + sum([ResultsT.TestTime]);

                % Save the best configuration obtained so far in stage 1b.
                if mean_accT > BestAcc1

                    BestAcc1 = mean_accT;
                    Best_NT = N_range_1b(p1);
                    Best_CT = C_range_1b(p2);

                end

                % Record Results
                ResultT2(count).N = N_range_1b(p1);
                ResultT2(count).C = C_range_1b(p2);
                ResultT2(count).Activation = Activations{p3};
                ResultT2(count).MeanValAcc = mean_accT;
                ResultT2(count).ValAcc = [ResultsT.TestAcc];

                count = count + 1;
            end
        end
        
        % Save the best configuration obtained for selected activation function.
        Best_Ns(p3) = Best_NT;
        Best_Cs(p3) = Best_CT;
        ValAccs(p3) = BestAcc1;
        
        % Record Results
        AllResults{set_no,1,p3} = ResultT1;
        AllResults{set_no,2,p3} = ResultT2;
        clear ResultT1 ResultT2
    end
    
    % Activation Functions Selection
    [ValAccs,idx] = sort(ValAccs,'descend');
    Best_Ns = Best_Ns(idx);
    Best_Cs = Best_Cs(idx);
    Acts_sorted = Activations(idx);

    % Records the validation time for stage 1 tuning.
    AllValTime(set_no,1) = ValTimeT;

    for act_no = 1:nFunct
        Best_N(1) = Best_Ns(act_no);
        Best_C(1) = Best_Cs(act_no);
        Best_Act = Acts_sorted{act_no};
    
        % Displays the best configuration found in stage 1.
        fprintf('Stage 1: N = %d, C = 2^%d, activation = %s, Val. Acc. = %f%%, Time = %f\n',...
           Best_N(1), log2(Best_C(1)), Best_Act, ValAccs(act_no)*100, ValTimeT);

        %% Tuning Stage 2: Selecting N(2), C(2)
        % Initialization
        count = 1;
        BestAcc2 = 0;
        ValTimeT = 0;

        % Ranges of parameters to be tested.
        N_range_2 = Best_N(1) + [-20,0,20];
        N_range_2 = N_range_2(N_range_2>0);   % Remove Parameters < 0
        C_range_2 = Best_C(1)*2.^(-1:1);

        % Evaluates each configuration.
        for p1 = 1:numel(N_range_2)
            for p2 = 1:numel(C_range_2)

                % Configures model
                optionsT = ModelParameters;
                optionsT.N = [Best_N(1),N_range_2(p1)];
                optionsT.C = [Best_C(1),C_range_2(p2)];
                optionsT.activation = Best_Act;
                optionsT.Fea_ratio = 1;
                optionsT.L = 2;

                % K-fold Cross Validation
                for k = 1:kFold

                    % Training and Testing
                    ResultsT(k) = MRVFL(trainX(k,set_no),trainY{k},testX(k,set_no),testY{k},optionsT);

                end

                % Mean validation results for the tested configuration
                mean_acc = mean([ResultsT.TestAcc]);

                % Adds time taken for parameter tuning.
                ValTimeT = ValTimeT + sum([ResultsT.TrainTime]) + sum([ResultsT.TestTime]);

                % Save the best configuration obtained so far in stage 2.
                if mean_acc > BestAcc2

                    BestAcc2 = mean_acc;
                    Best_N(2) = N_range_2(p1);
                    Best_C(2) = C_range_2(p2);

                end

                % Record Results
                ResultT3(count).N = N_range_2(p1);
                ResultT3(count).C = C_range_2(p2);
                ResultT3(count).MeanValAcc = mean_acc;
                ResultT3(count).ValAcc = [ResultsT.TestAcc];

                count = count + 1;

            end
        end

        % Adds the validation time for stage 2 tuning.
        AllValTime(set_no,2) = AllValTime(set_no,2) + ValTimeT;

        % Displays the best configuration found in stage 2.
        fprintf('Stage 2 Best: N = %d, C = 2^%d, Val. Acc. = %f%%, Time = %f\n',...
           Best_N(2), log2(Best_C(2)), BestAcc2*100, ValTimeT);

        % Record Results
        AllResults{set_no,3,act_no} = ResultT3;
        clear ResultT3

        %% Tuning Stage 3: Selecting the ratio of features going forward.
        % Initialization
        count = 1;
        BestAcc3 = 0;
        ValTimeT = 0;
        
        if act_no <= rem(nClf,nFunct)
            L = ceil(nClf/nFunct);
        else
            L = floor(nClf/nFunct);
        end

        % Ranges of parameters to be tested.
        ratio_range = options.Fea_ratio;

        % Evaluates each configuration.
        for p1 = 1:numel(ratio_range)

            % Configures model
            optionsT = ModelParameters;
            optionsT.N = Best_N;
            optionsT.C = Best_C;
            optionsT.activation = Best_Act;
            optionsT.Fea_ratio = ratio_range(p1);
            optionsT.L = 5;

            % K-fold Cross Validation
            for k = 1:kFold

                % Training and Testing
                ResultsT(k) = MRVFL(trainX(k,set_no),trainY{k},testX(k,set_no),testY{k},optionsT);

            end

            % Mean validation results for the tested configuration
            mean_acc = mean([ResultsT.TestAcc]);

            % Adds time taken for parameter tuning.
            ValTimeT = ValTimeT + sum([ResultsT.TrainTime]) + sum([ResultsT.TestTime]);

            % Save the best configuration obtained so far in stage 3.
            if mean_acc > BestAcc3

                BestAcc3 = mean_acc;
                Best_ratio = ratio_range(p1);

            end

            % Record Results
            ResultT4(count).Fea_ratio = ratio_range(p1);
            ResultT4(count).MeanValAcc = mean_acc;
            ResultT4(count).ValAcc = [ResultsT.TestAcc];

            count = count + 1;

        end

        % Adds the validation time for stage 3 tuning.
        AllValTime(set_no,3) = AllValTime(set_no,3) + ValTimeT;

        % Displays the best configuration found in stage 3.
        fprintf('Stage 3 Best: Ratio = %.1f, Val. Acc. = %f%%, Time = %f\n',...
           Best_ratio, BestAcc3*100, ValTimeT);

        % Record Results
        AllResults{set_no,4,act_no} = ResultT4;

        clear ResultT4

        %% Final Result
        ValAcc(set_no,act_no) = BestAcc3;
        
        % Set best configuration
        TunedParameters(set_no,act_no) = ModelParameters;
        TunedParameters(set_no,act_no).L = L;
        TunedParameters(set_no,act_no).N = Best_N;
        TunedParameters(set_no,act_no).C = Best_C;
        TunedParameters(set_no,act_no).Fea_ratio = Best_ratio;
        TunedParameters(set_no,act_no).activation = Best_Act;
        TunedParameters(set_no,act_no).weight = ValAcc(set_no,act_no);         % Weights based on Validation Acc.
    end
    
    ValTime(set_no) = sum(AllValTime(set_no,:));

end
end
