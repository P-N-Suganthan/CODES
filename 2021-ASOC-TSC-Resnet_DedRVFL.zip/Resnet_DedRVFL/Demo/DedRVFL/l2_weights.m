function x = l2_weights(A,b,C,Nsample)

if C == Inf
    if size(A,2)<Nsample
        x = pinv(A'*A)*A'*b;
    else
        x = A'*pinv(A*A')*b;
    end
else  
    if size(A,2)<Nsample
       x = (eye(size(A,2))/C+A'*A) \ A'*b;
    else
        x = A'*((eye(size(A,1))/C+A*A') \ b);
    end
end


end
% toc

