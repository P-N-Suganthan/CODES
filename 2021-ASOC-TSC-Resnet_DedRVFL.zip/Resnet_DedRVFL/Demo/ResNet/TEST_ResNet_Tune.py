#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Nov 12 01:09:17 2016

For Tensorflow 1.x only
"""

from __future__ import print_function

from keras.models import Model
from keras.layers import Input, Dense, Add, Activation
from keras.utils import np_utils
from keras import backend as K
import numpy as np
import keras
import tensorflow as tf
from keras.callbacks import ReduceLROnPlateau
from keras.callbacks import ModelCheckpoint
from keras.callbacks import EarlyStopping
# from keras.utils.vis_utils import plot_model
from math import ceil
import time
import os
import errno
from pathlib import Path
import scipy.io

np.random.seed(813306)


# Function to construct the ResNet model and outputs tensors
def build_resnet(input_shape, n_feature_maps, n_classes):
    pool_out = list()

    # NETWORK STRUCTURE
    # Input Layer
    x = Input(shape=input_shape)

    # First Block
    # print('build conv_x')
    conv_x = keras.layers.normalization.BatchNormalization()(x)
    conv_x = keras.layers.Conv2D(n_feature_maps, (8, 1), padding='same')(conv_x)
    conv_x = keras.layers.normalization.BatchNormalization()(conv_x)
    conv_x = Activation('relu')(conv_x)

    # print('build conv_y')
    conv_y = keras.layers.Conv2D(n_feature_maps, (5, 1), padding='same')(conv_x)
    conv_y = keras.layers.normalization.BatchNormalization()(conv_y)
    conv_y = Activation('relu')(conv_y)

    # print('build conv_z')
    conv_z = keras.layers.Conv2D(n_feature_maps, (3, 1), padding='same')(conv_y)
    conv_z = keras.layers.normalization.BatchNormalization()(conv_z)

    # Shortcut connection
    is_expand_channels = not (input_shape[-1] == n_feature_maps)
    if is_expand_channels:
        shortcut_y = keras.layers.Conv2D(n_feature_maps, (1, 1), padding='same')(x)
        shortcut_y = keras.layers.normalization.BatchNormalization()(shortcut_y)
    else:
        shortcut_y = keras.layers.normalization.BatchNormalization()(x)
    # print('Merging skip connection')
    y = Add()([shortcut_y, conv_z])
    y = Activation('relu')(y)

    pool_out.append(keras.layers.pooling.GlobalAveragePooling2D()(y))

    for l in range(1, nBlocks):
        # print('build conv_x')
        x1 = y
        conv_x = keras.layers.Conv2D(n_feature_maps * 2, (8, 1), padding='same')(x1)
        conv_x = keras.layers.normalization.BatchNormalization()(conv_x)
        conv_x = Activation('relu')(conv_x)

        # print('build conv_y')
        conv_y = keras.layers.Conv2D(n_feature_maps * 2, (5, 1), padding='same')(conv_x)
        conv_y = keras.layers.normalization.BatchNormalization()(conv_y)
        conv_y = Activation('relu')(conv_y)

        # print('build conv_z')
        conv_z = keras.layers.Conv2D(n_feature_maps * 2, (3, 1), padding='same')(conv_y)
        conv_z = keras.layers.normalization.BatchNormalization()(conv_z)

        # Shortcut connection
        is_expand_channels = not (input_shape[-1] == n_feature_maps * 2)
        if is_expand_channels:
            shortcut_y = keras.layers.Conv2D(n_feature_maps * 2, (1, 1), padding='same')(x1)
            shortcut_y = keras.layers.normalization.BatchNormalization()(shortcut_y)
        else:
            shortcut_y = keras.layers.normalization.BatchNormalization()(x1)
        print('Merging skip connection')
        y = Add()([shortcut_y, conv_z])
        y = Activation('relu')(y)

        pool_out.append(keras.layers.pooling.GlobalAveragePooling2D()(y))

    out = Dense(n_classes, activation='softmax')(pool_out[nBlocks - 1])
    # print('        -- model was built.')
    return x, out, pool_out


# Function to collect the dataset
def read_mat_data(problem_path):
    mat_data = scipy.io.loadmat(problem_path + '_R.mat')
    x_data_mat = mat_data['trainX']
    y_data_mat = mat_data['trainY'].reshape(mat_data['trainY'].shape[0], )

    mat_data2 = scipy.io.loadmat(problem_path + '_Tune.mat')
    train_tune = mat_data2['train_tune'].astype(np.bool)
    test_tune = mat_data2['test_tune'].astype(np.bool)

    return x_data_mat, y_data_mat, train_tune, test_tune


# Function to setup Tensorflow session with given settings
def set_session(gpu="", per_process_gpu_memory=0, log_device=False, processor_type="GPU"):
    assert processor_type in ["GPU", "CPU"], "Processor type  can only be either CPU or GPU."
    if processor_type == "GPU":
        #  Set Tensorflow GPU configuration.
        if per_process_gpu_memory <= 0:
            gpu_options = tf.GPUOptions(allow_growth=True, visible_device_list=gpu)
        else:
            gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=per_process_gpu_memory, visible_device_list=gpu)

        tf_config = tf.ConfigProto(
            device_count={'GPU': 1},
            allow_soft_placement=True,
            gpu_options=gpu_options,
            log_device_placement=log_device)
        session = tf.Session(config=tf_config)
    else:
        gpu_options = tf.GPUOptions(allow_growth=True, visible_device_list="0")
        tf_config = tf.ConfigProto(
            device_count={'GPU': 0},
            gpu_options=gpu_options,
            log_device_placement=log_device)
        session = tf.Session(config=tf_config)

    return session


# Settings
input_dir = '../Data files/'
nb_epochs = 1500
nBlocks = 4
kFolds = 4
processor = "GPU"
GPU = "0"
flist = ['ECG200']

for each in flist:        # For each dataset
    # Initialisation
    Losses = np.zeros([kFolds, ])
    Train_Acc = np.zeros([kFolds, ])
    Test_Acc = np.zeros([kFolds, ])
    Train_Time = np.zeros([kFolds, ])
    train_feature_vector = np.zeros([kFolds, nBlocks], dtype=np.object)
    test_feature_vector = np.zeros([kFolds, nBlocks], dtype=np.object)
    nb_classes = 0  
    batch_size = 0

    # Collects dataset
    file_path = input_dir + each + '/' + each
    x_data, y_data, train_tune, test_tune = read_mat_data(file_path)

    for k in range(kFolds):

        x_train = x_data[train_tune[k, :], :]
        y_train = y_data[train_tune[k, :]]
        x_test = x_data[test_tune[k, :], :]
        y_test = y_data[test_tune[k, :]]

        nb_classes = len(np.unique(y_data))  # Number of Classes
        batch_size = min(ceil(x_train.shape[0] / 10), 16)  # Batch size

        # Label normalisation - set values to 0 ~ Number of classes
        y_train = (y_train - y_data.min()) / (y_data.max() - y_data.min()) * (
                    nb_classes - 1)  # Label Normalisation
        y_test = (y_test - y_data.min()) / (y_data.max() - y_data.min()) * (nb_classes - 1)  # Label Normalisation

        # Creates a boolean matrix containing 1 if i = label and 0 otherwise
        Y_train = np_utils.to_categorical(y_train, nb_classes)
        Y_test = np_utils.to_categorical(y_test, nb_classes)

        # Normalise x_train
        x_train_mean = x_train.mean()
        x_train_std = x_train.std()
        x_train = (x_train - x_train_mean) / x_train_std

        # Normalise x_test (Note: uses mean and std of training samples)
        x_test = (x_test - x_train_mean) / x_train_std

        # Reshape x_train and x_test
        x_train = x_train.reshape(x_train.shape + (1, 1,))
        x_test = x_test.reshape(x_test.shape + (1, 1,))

        start_time = time.perf_counter()

        # Starts Tensorflow session with defined settings
        with set_session(GPU, processor_type=processor):

            # Build ResNet model
            x, out, pool = build_resnet(x_train.shape[1:], 64, nb_classes)

            # Define Model inputs and outputs
            model = Model(inputs=x, outputs=out)

            # OPTIMISER
            # Adam optimiser with default parameters [lr=0.002, beta_1=0.9, beta_2=0.999, epsilon=1e-8, decay=0.0]
            optimizer = keras.optimizers.Adam()
            model.compile(loss='categorical_crossentropy',
                        optimizer=optimizer,
                        metrics=['accuracy'])

            # Displays network structure in text
            model.summary()

            # Creates directory for model files
            try:
                os.makedirs('ModelsT/' + each)
            except OSError as e:
                if e.errno != errno.EEXIST:
                    raise

            # Writes model structure into .json file
            json_filename = 'ModelsT/' + each + '/ResNet_' + each + '_model.json'

            # Serialize model to JSON
            model_json = model.to_json()
            with open(json_filename, "w") as json_file:
                json_file.write(model_json)

            # # Displays network structure
            # model_plot = 'Models/' + each + '/ResNet' + each + '_model.png'
            # plot_model(model, to_file=model_plot, show_shapes=True, show_layer_names=True)

            model_filename = 'ModelsT/' + each + '/ResNet_' + each + '_model' + str(k) + '.h5'

            # CALLBACKS (Functions to be executed during training)
            # Reduce learning rate if model does not improve
            reduce_lr = ReduceLROnPlateau(monitor='loss', factor=0.5,
                                          patience=50, min_lr=0.0001)

            # Early Stopping
            early_stop = EarlyStopping(monitor='loss', patience=100)

            # Saves best model
            model_check = ModelCheckpoint(filepath=model_filename, monitor='loss',
                                          save_best_only=True, period=1)

            model_path = Path(model_filename)
            # TRAINING (Comment this to use pre-trained weights instead of retraining)
            hist = model.fit(x_train, Y_train, batch_size=batch_size, epochs=nb_epochs,
                             verbose=1, validation_data=(x_test, Y_test),
                             callbacks=[reduce_lr, early_stop, model_check])

            Train_Time[k] = time.perf_counter() - start_time

            # Load best model
            model.load_weights(model_filename)

            # TESTING
            [Losses[k], Train_Acc[k]] = model.evaluate(x_train, Y_train, batch_size=batch_size, verbose=1)
            [holder, Test_Acc[k]] = model.evaluate(x_test, Y_test, batch_size=batch_size, verbose=1)

            # Extract ResNet features
            Extractor = Model(inputs=x, outputs=pool)
            train_feature_vectorT = Extractor.predict(x_train, batch_size=batch_size)
            test_feature_vectorT = Extractor.predict(x_test, batch_size=batch_size)

            for j in range(nBlocks):
                train_feature_vector[k, j] = train_feature_vectorT[j].astype(np.float64)
                test_feature_vector[k, j] = test_feature_vectorT[j].astype(np.float64)

        K.clear_session()              # Clear

        # Displays results for each fold
        print('Fold', k, 'Train Acc =', Train_Acc[k], 'Test Acc =', Test_Acc[k], 'Train Time =', Train_Time[k], 's')

    # Creates directory for extracted ResNet features files
    try:
        os.makedirs('FeatureVectorT/' + each)
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise

    # Write obtained filter parameters and extracted ResNet features to .mat format
    feature_vector_matfile = 'FeatureVectorT/' + each + '/' + each + '_ResNet_Tune.mat'
    matlab_vars = {'TRAIN_ResNetdata_Tune': train_feature_vector,
                   'TEST_ResNetdata_Tune': test_feature_vector
                   }
    scipy.io.savemat(feature_vector_matfile, long_field_names=True, do_compression=True,
                     mdict=matlab_vars)
