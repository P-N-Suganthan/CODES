The codes are not optimized for efficiency. The codes have been cleaned for better readability
and documented and are not exactly the same as used in our paper. Results obtained may not be  
exactly identical to the published results. We have re-run and checked the codes only in few
datasets so if you find any bugs/issues, please write to Wen Xin (wenxin001@e.ntu.edu.sg).

Requirements:
1. python with the following packages
  a. Keras 
  b. Tensorflow
  c. numpy
  d. scipy

2. MATLAB


Usage Steps:
1. Training Resnet and creating features.
  a. Run TEST_ResNet.py to create features for training and testing.
  b. Run TEST_ResNet_Tune.py to create features for edRVFL tuning.

2. Training edRVFL.
  - Run Main.m


Hyperparameters:
1. Resnet
  - nb_epochs = 1500        (Number of epochs to train Resnet)
  - nBlocks = 6             (Number of Resnet blocks)

2. edRVFL
  - nClf = 20;                                                 (Number of classifiers in edRVFL ensemble)
  - N = 43:60:283;                                             (Number of neurons in edRVFL, Coarse range)
  - C = 2.^(-6:3:15);                                          (Regularization parameter C = 1/lamda, Coarse range)
  - Nadj = -40:20:40;                                          (Number of neurons in edRVFL, Fine range)
  - Cadj = 2.^(-2:2);                                          (Regularization parameter C = 1/lamda, Fine range)
  - scale = 1;                                                 (Scaling parameter)
  - Fea_ratio = flip(0.3:0.1:0.9);                             (Proportion of feature to keep as direct links)
  - activations = {'relu','sigmoid','selu','radbas','sine'};   (Activation Functions)
  - nActFun = 2;                                               (Number of activation functions to use)


Tuning Proceedure:
1. Generate features for tuning sets (4-fold cross-validation) using TEST_ResNet_Tune.py.
2. Set number of layers in edRVFL to 1.
3. Tune N and C using a coarse range of values.
4. Fine tune N and C using a fine range of value around the chosen N and C.
5. Set number of layers in edRVFL to 2. Fix optimal N and C for first layer. 
6. Tune N and C for second layer with at most 1 step higher/lower (based on fine ranges) than optimal N and C.
7. Set the number of layer in edRVFL to 5. Fix optimal N and C for second layer.
8. Set and fix N and C for third layer onwards. (Pick a random value between {N,2N}/{C,2C})
9. Tune Fea_ratio with all other hyperparameters fixed.


Files used in this experiment:
1. ECG200_R.mat
  - 
2. ECG200_Tune.mat
  -
3. ECG200_ResNet.mat
  - Generated using TEST_ResNet.py
4. ECG200_ResNet_Tune.mat
  - Generated using TEST_ResNet_Tune.py


Cite as:
W. X. Cheng, P. N. Suganthan, and R. Katuwal, “Time series classification using diversified Ensemble Deep Random Vector Functional Link and Resnet features,” Applied Soft Computing, vol. 112, p. 107826, 2021, doi: https://doi.org/10.1016/j.asoc.2021.107826.