# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
import numpy as np
import numpy.matlib
from math import sqrt
from scipy.special import expit
from sklearn import metrics
from easydict import EasyDict

class RVFL_layer(object):
    def __init__(self, classes, attr):
        super().__init__()
        self.attr = attr
        self.attr.lamb = 2**self.attr.C
        self.classes = classes
        self.Params = EasyDict()

    def sigmoid(self,x):
        return 1 / (1 + np.exp(-x))
    
    def matrix_inverse(self, x, target):
        n_sample, n_D = x.shape
        
        if self.attr.lamb == 1:
            beta = np.dot(np.linalg.pinv(x), target)

        elif n_D<n_sample:
            beta = np.matmul(np.matmul(np.linalg.inv(np.identity(x.shape[1])/self.attr.lamb+np.matmul(x.T,x)),x.T),target)
        else:
            beta = np.matmul(x.T,np.matmul(np.linalg.inv(np.identity(x.shape[0])/self.attr.lamb+np.matmul(x,x.T)),target))

        return beta
    
    def train(self, X, target):
        attr = self.attr
        raw_X = X
        n_sample, n_D = X.shape
        # print(X.shape)
        w = (2 * np.random.rand(self.attr.N, n_D) - 1)  * self.attr.tuning_vector
        b = np.random.rand(1, self.attr.N)
        w = w.T
        self.w = w
            
        self.b = b

        A_ = X @ w + b
        # layer normalization
        A_mean = np.mean(A_, axis=0)
        A_std = np.std(A_, axis=0)
        self.mean = A_mean
        self.std = A_std

        A_ = (A_ - A_mean) / A_std
        A_ = A_ + np.repeat(b, n_sample, 0)
        # A_ = attr.gama * A_ + attr.alpha


        A_ = self.sigmoid(A_)


        A_merge = np.concatenate([raw_X, A_, np.ones((n_sample, 1))], axis=1)

        self.A_ = A_
        beta_ = self.matrix_inverse(A_merge, target)
        self.beta = beta_
        predict_score = A_merge @ beta_

        self.Params['w'] = self.w
        self.Params['b'] = self.b
        self.Params['beta'] = self.beta
        self.Params['mean'] = self.mean
        self.Params['std'] = self.std

        return predict_score
    
    def eval(self, X, params=None):
        raw_X = X
        n_sample, n_D = raw_X.shape

        if params is not None:
            self.Params = params
        
        A_ = X @ self.Params.w + self.Params.b
        A_ = (A_ - self.Params.mean) / self.Params.std
        A_ = A_ + np.repeat(self.Params.b, n_sample, 0)


        A_ = self.sigmoid(A_)
        
        
        self.A_t = A_

        A_merge = np.concatenate([raw_X, A_, np.ones((n_sample, 1))], axis=1)
        predict_score = A_merge @ self.Params.beta
        return predict_score
    
    def rvfl(self, previous_X, Y, previous_Xt, Yt):
        # train_score = softmax(self.train(previous_X, Y))
        # eval_score = softmax(self.eval(previous_Xt))
        train_score = self.train(previous_X, Y)
        eval_score = self.eval(previous_Xt)
        train_acc = np.mean(np.argmax(train_score,-1).ravel()==np.argmax(Y,axis=1))
        eval_acc = np.mean(np.argmax(eval_score,-1).ravel()==np.argmax(Yt,axis=1))
        # print(train_acc, eval_acc)
        return [train_acc, eval_acc], [train_score, eval_score]