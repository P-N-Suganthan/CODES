from SCN import SCN
import numpy as np
import itertools
import matplotlib.pyplot as plt
import scipy.io
from data.uci import UCIDataset

import numpy as np
from sklearn.model_selection import train_test_split as Split
from sklearn.feature_selection import VarianceThreshold
import argparse
from time import time
from data.uci import UCIDataset
from pathlib import Path

import logging



def get_logger(logger_name, log_file, level=logging.INFO):
    l = logging.getLogger(logger_name)
    formatter = logging.Formatter('%(asctime)s : %(message)s', "%Y-%m-%d %H:%M:%S")
    fileHandler = logging.FileHandler(log_file, mode='a')
    fileHandler.setFormatter(formatter)

    l.setLevel(level)
    l.addHandler(fileHandler)

    return logging.getLogger(logger_name)


# openml.study.get_suite(218)
parser = argparse.ArgumentParser(description='edRVFL')
parser.add_argument('--data', type=str, default='image-segmentation')
# parser.add_argument('-s', type=int, default=0)
# parser.add_argument('-e', type=int, default=1)
args = parser.parse_args()
data_list = sorted(Path("/home/hu/eRVFL/UCIdata/").glob('*'))

Path("exps/").mkdir(exist_ok=True)

L_max = 10                   # maximum hidden node number
tol = 0.01                    # training tolerance
T_max = 250                    # maximun candidate nodes number
Lambdas = [0.5, 1, 5, 10, 30, 50, 100]  # scope sequence
r = [0.9, 0.99, 0.999, 0.9999, 0.99999, 0.999999]  # 1-r contraction sequence
nB = 1       # batch size
verbose = 4

# Model Initialization
# M = SCN(L_max, T_max, tol, Lambdas, r, nB, verbose)

# mat = scipy.io.loadmat('Demo_Iris.mat')
# T = mat['T']
# X = mat['X']
# T2 = mat['T2']
# X2 = mat['X2']
# class_names = np.array(['setosa', 'versicolor', 'virginica'])

# ErrorList,RateList = M.classification(np.array(X), np.array(T))
# ea, ta = M.getAccuracy(X, T)
# eB, tB = M.getAccuracy(X2, T2)

# print(np.diag(tB).sum()/tB.sum())

# for item in range(args.s, args.e):
dataname = args.data
# logging.basicConfig(filename=f'./exps/{item}_{dataname}.log', filemode='a',level=logging.DEBUG, format=LOG_FORMAT)

logger = get_logger(logger_name=f'{dataname}',log_file=f'./exps/{dataname}_SCN_30Mar.log')
logger.info(f'Data Name is : {dataname}')
# dataset = UCIDataset(args.data)
dataset = UCIDataset(dataname)
CV_NUM = dataset.n_CV
N_TYPES = dataset.n_types
acx = []
for seed in [2,32,1024,2048]:
    np.random.seed(seed=seed)
    result = np.zeros(CV_NUM)
    accs = []
    for i in range(CV_NUM):
        network = SCN(L_max, T_max, tol, Lambdas, r, nB, verbose)
        # a = time()
        trainX, trainY, evalX, evalY, testX, testY, full_train_x, full_train_y = dataset.getitem(i)
        shape = full_train_x.shape[1]
        # print(f"Data Shape:{full_X.shape}\t Classes:{N_TYPES}")
        logging.info(f"Data Shape:{full_train_x.shape}\t Classes:{N_TYPES}")
        # print(f"Loading Time:{time()-a:.2f}")
        ErrorList,RateList = network.classification(np.array(trainX), np.array(trainY))
        (ErrorA, CMA) = network.getAccuracy(evalX, evalY)
        (ErrorB, CMB) = network.getAccuracy(testX, testY)
        (ErrorB, CMC) = network.getAccuracy(trainX, trainY)
        accuracy = np.diag(CMB).sum()/CMB.sum()
        accuracy_EVAL = np.diag(CMA).sum()/CMA.sum()
        accuracy_TRAIN = np.diag(CMC).sum()/CMC.sum()
        accs.append(accuracy)
        acx.append(accuracy)
        logger.info(f"Fold {i} :{accuracy:.4f}, EVAL: {accuracy_EVAL:.4f}, Train: {accuracy_TRAIN:.4f}")
    print(accs)
    logging.info("***********************************************************")
    logging.info(f"Seed : {seed}")
    logger.info(f"Final soft raw :{np.array(accs).mean():.4f}, Details:{np.array(accs)}, std:{np.array(accs).std():.4f}")
print(acx)
logging.info("***********************************************************")
logger.info(f"ACX:{np.array(acx).mean():.4f}, Details:{np.array(acx)}, std:{np.array(acx).std():.4f}")