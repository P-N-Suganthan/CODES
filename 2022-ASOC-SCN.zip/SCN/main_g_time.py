from RVFLG import RVFL_layer
from functools import partial
from torch.nn import functional as F
from hyperopt import fmin, tpe, hp, STATUS_OK
import time
from data.uci import UCIDataset
import random
import numpy as np
import logging
from easydict import EasyDict

import time

search_space = {
    # 'L': hp.quniform('L',1,3,1),
    'C': hp.uniform('C',-12,6),
    'tp0': hp.loguniform('tp0',-1,5.5),
    'tp1': hp.loguniform('tp1',-1,5.5),
    'tp2': hp.loguniform('tp2',-1,5.5),
    'tp3': hp.loguniform('tp3',-1,5.5),
    'tp4': hp.loguniform('tp4',-1,5.5),
    'tp5': hp.loguniform('tp5',-1,5.5),
    'tp6': hp.loguniform('tp6',-1,5.5),
    'tp7': hp.loguniform('tp7',-1,5.5),
    'tp8': hp.loguniform('tp8',-1,5.5),
    'tp9': hp.loguniform('tp9',-1,5.5),
}


def objective(trainX,trainY,evalX,evalY,args):
    attr = {'C':args['C'],'N': 10, 'tuning_vector': [args['tp0'],args['tp1'],args['tp2'],args['tp3'],args['tp4'],args['tp5'],args['tp6'],args['tp7'],args['tp8'],args['tp9']]}
    attr = EasyDict(attr)
    net = RVFL_layer(classes=evalY.shape[-1], attr=attr)
    net.train(X=trainX,target=trainY)
    yhat = net.eval(evalX)
    # loss = F.cross_entropy(yhat,evalY.argmax(1).cuda(device)).detach()
    loss = 1-((yhat.argmax(1) == evalY.argmax(1)).sum() / len(evalX))*1.
    return {
        'loss': loss,
        'status': STATUS_OK,
        'eval_time': time.time(),
        'other_stuff': {'type': None, 'value': [0, 1, 2]},
        }

def test_func(trainX,trainY,evalX,args):
    attr = {'C':args['C'],'N': 10, 'tuning_vector': [args['tp0'],args['tp1'],args['tp2'],args['tp3'],args['tp4'],args['tp5'],args['tp6'],args['tp7'],args['tp8'],args['tp9']]}
    attr = EasyDict(attr)
    net = RVFL_layer(classes=evalY.shape[-1], attr=attr)
    net.train(X=trainX,target=trainY)
    yhat = net.eval(evalX)
    return yhat


dataset = 'contrac'
data = UCIDataset(f'{dataset}')

print(print(f"**************{dataset}**************"))
accs = []

np.random.seed(seed=10)
for k in range(4):

    trainX, trainY, evalX, evalY, testX, testY, full_train_x, full_train_y = data.getitem(k)
    a = time.time()
    best = fmin(
        fn = partial(objective,trainX, trainY, evalX, evalY),
        space=search_space,
        algo=tpe.suggest,
        max_evals=100
    )

    p = time.time() - a

    print(p)

    # z = test_func(full_train_x, full_train_y, testX,args=best)

    # acc = ((z.argmax(1)== testY.argmax(1)).sum() / len(testX))*100.

    # accs.append(acc)


