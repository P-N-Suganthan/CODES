from RVFL import RVFL_layer
from functools import partial
from torch.nn import functional as F
from hyperopt import fmin, tpe, hp, STATUS_OK
import time
from data.uci import UCIDataset
import random
import numpy as np
import logging
from easydict import EasyDict

def get_logger(logger_name, log_file, level=logging.INFO):
    l = logging.getLogger(logger_name)
    formatter = logging.Formatter('%(asctime)s : %(message)s', "%Y-%m-%d %H:%M:%S")
    fileHandler = logging.FileHandler(log_file, mode='a')
    fileHandler.setFormatter(formatter)

    l.setLevel(level)
    l.addHandler(fileHandler)

    return logging.getLogger(logger_name)

search_space = {
    # 'L': hp.quniform('L',1,3,1),
    'C': hp.uniform('C',-12,6),
    'tp0': hp.loguniform('tp0',-1,5.5),
}


def objective(trainX,trainY,evalX,evalY,args):
    attr = {'C':args['C'],'N': 10, 'tuning_vector': args['tp0']}
    attr = EasyDict(attr)
    net = RVFL_layer(classes=evalY.shape[-1], attr=attr)
    net.train(X=trainX,target=trainY)
    yhat = net.eval(evalX)
    # loss = F.cross_entropy(yhat,evalY.argmax(1).cuda(device)).detach()
    loss = 1-((yhat.argmax(1) == evalY.argmax(1)).sum() / len(evalX))*1.
    return {
        'loss': loss,
        'status': STATUS_OK,
        'eval_time': time.time(),
        'other_stuff': {'type': None, 'value': [0, 1, 2]},
        }

def test_func(trainX,trainY,evalX,args):
    attr = {'C':args['C'],'N': 10, 'tuning_vector': args['tp0']}
    attr = EasyDict(attr)
    net = RVFL_layer(classes=evalY.shape[-1], attr=attr)
    net.train(X=trainX,target=trainY)
    yhat = net.eval(evalX)
    return yhat

# for dataset in ['contrac','image-segmentation','semeion','ozone','yeast']:
for dataset in ['blood','breast-tissue','primary-tumor','titanic','wine-quality-red']:
    try:
        data = UCIDataset(f'{dataset}')
    except:
        logger = get_logger(logger_name=f'{dataset}',log_file=f'./exps/{dataset}_pRVFL.log')
        logger.info(f'Data Name is : {dataset}, FAILED')
        continue
    logger = get_logger(logger_name=f'{dataset}',log_file=f'./exps/{dataset}_pRVFL.log')
    logger.info(f'Data Name is : {dataset}')
    print(print(f"**************{dataset}**************"))
    accs = []
    for seed in [2,32,1024,2048]:
        np.random.seed(seed=seed)
        for k in range(4):
            trainX, trainY, evalX, evalY, testX, testY, full_train_x, full_train_y = data.getitem(k)
            best = fmin(
                fn = partial(objective,trainX, trainY, evalX, evalY),
                space=search_space,
                algo=tpe.suggest,
                max_evals=100
            )
            print(best)
            logger.info(best)
            z = test_func(full_train_x, full_train_y, testX,args=best)
            acc = ((z.argmax(1)== testY.argmax(1)).sum() / len(testX))*100.
            print(acc)
            logger.info(acc)
            accs.append(acc)
    print("****************************")
    print(np.array(accs).mean(), np.array(accs).std())
    logger.info('Accuracy: %.2f%% (+/- %.2f%%)' % (np.array(accs).mean(), np.array(accs).std()))
