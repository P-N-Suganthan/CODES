All the final versions of papers in CEC2010 Large Scale Global Optimization Challenge are included.

The Results of the Large Scale Global Optimization Challenge is show in slides.pdf.

The MATLAB source codes of 7938 Dynamic Multi-Swarm Particle Swarm Optimizer with
Subregional Harmony Search are also included.
The calling program--"RunCEC10".
Main function of algorithm--"DMS_PSO_HS_NichingMemory_linesearch".
CEC2010 Large Scale Global Optimization benchmark functions--"benchmark_func".