function [gbest,gbestval,fitcount]= DMS_PSO_HS_NichingMemory_linesearch(func_num,Max_FES,group_num,Particle_Number,Dimension,VRmin,VRmax,run)


rand('state',sum(100*clock));
fhd=str2func('benchmark_func');
group_ps=Particle_Number;
ps=group_num*group_ps;
D=Dimension;
L_FES=5*D;
L2_FES=5*D;
L_num=ceil(0.25.*group_num);
cc=[1.49445 1.49445];   %acceleration constants
iwt=0.729;
% iwt=0.9-(1:me)*(0.7/me);

if length(VRmin)==1
    VRmin=repmat(VRmin,1,D);
    VRmax=repmat(VRmax,1,D);
end
VRmin=repmat(VRmin,ps,1);
VRmax=repmat(VRmax,ps,1);
mv=0.2*(VRmax-VRmin);
Vmin=-mv;
Vmax=-Vmin;
pos=VRmin+(VRmax-VRmin).*rand(ps,D);

for i=1:ps;
    e(i,1) = benchmark_func(pos(i,:), func_num);
end

fitcount=ps;
vel=Vmin+2.*Vmax.*rand(ps,D);%initialize the velocity of the particles
pbest=pos;
pbestval=e; %initialize the pbest and the pbest's fitness value
for i=1:group_num
    group_id(i,:)=[((i-1)*group_ps+1):i*group_ps];
    pos_group(group_id(i,:))=i;
    [gbestval(i),gbestid]=min(pbestval(group_id(i,:)));
    gbest(i,:)=pbest(group_id(i,gbestid),:);%initialize the gbest and the gbest's fitness value
end

arch=[pbest pbestval];
numclg=2;
numch=20000;
recorditer=60000;
lsbuffersize=5;
eflag=1;
sssflag=0;
FEsassign=zeros(1,4);
get_flag=0;
iter=0;
upb=repmat(VRmax(1,:),D,1);
lowb=repmat(VRmin(1,:),D,1);
record_flag=0;
sn_flag=0;
arch_LS=[];
eval(['fid=fopen(''DMS_PSO_HS_NichingMemory_gbestval_' num2str(func_num) '_' num2str(run) '.txt'',''w'');' ]);
fprintf(fid,'%e\n',min(gbestval));
fclose(fid);
lastgbestval=min(gbestval);
lastfitcount=fitcount;

while fitcount<0.98*Max_FES

    iter=iter+1;
    for k=1:ps
    aa(k,:)=cc(1).*rand(1,D).*(pbest(k,:)-pos(k,:))+cc(2).*rand(1,D).*(gbest(pos_group(k),:)-pos(k,:));
    vel(k,:)=iwt.*vel(k,:)+aa(k,:); 
    vel(k,:)=(vel(k,:)>mv(k,:)).*mv(k,:)+(vel(k,:)<=mv(k,:)).*vel(k,:); 
    vel(k,:)=(vel(k,:)<(-mv(k,:))).*(-mv(k,:))+(vel(k,:)>=(-mv(k,:))).*vel(k,:);
    pos1(k,:)=pos(k,:)+vel(k,:); 
    keep_d=rand(1,D)<0.5;
    pos(k,:)=keep_d.*pbest(k,:)+(1-keep_d).*pos1(k,:); 
    if (sum(pos(k,:)>VRmax(k,:))+sum(pos(k,:)<VRmin(k,:)))==0;

    e(k,1) = benchmark_func(pos(k,:), func_num);
    fitcount=fitcount+1;
    FEsassign(1,2)=FEsassign(1,2)+1;
    tmp=(pbestval(k)<e(k));
    FEsassign(1,1)=FEsassign(1,1)+(pbestval(k)>e(k));
    temp=repmat(tmp,1,D);
    pbest(k,:)=temp.*pbest(k,:)+(1-temp).*pos(k,:);
    pbestval(k)=tmp.*pbestval(k)+(1-tmp).*e(k);%update the pbest
    if pbestval(k)<gbestval(pos_group(k))
    gbest(pos_group(k),:)=pbest(k,:);
    gbestval(pos_group(k))=pbestval(k);
    end
    end
    
    end
    
    change_flag=0;

    if change_flag==1|mod(iter,5)==0
        fitcount
        min(gbestval)
        rc=randperm(ps);
        group_id=[];gbest=[];gbestval=[];
        for k=1:group_num
            group_id(k,:)=rc(((k-1)*group_ps+1):k*group_ps);
            pos_group(group_id(k,:))=k;
            [gbestval(k),gbestid]=min(pbestval(group_id(k,:)));
            gbest(k,:)=pbest(group_id(k,gbestid),:);
        end
    end


%Harmony search
if mod(iter,1)==0
HMCR=0.9;
PAR=0.01+(0.9-0.01)/Max_FES*fitcount;
          
for k=1:group_num
    for d=1:D
        if rand(1,1)<=HMCR
            rpd=randperm(group_ps);
            posHS(k,d)=pbest(group_id(k,rpd(1)),d);
            if rand(1,1)<=PAR
                posHS(k,d)=gbest(k,d);
            end
        else posHS(k,d)=gbest(k,d)+(VRmax(1,d)-VRmin(1,d)).*0.01.*(2*rand(1,1)-1);
        end
    end
    if (sum(posHS(k,:)>VRmax(k,:))+sum(posHS(k,:)<VRmin(k,:)))==0;
        eHS(k,1)=benchmark_func(posHS(k,:),func_num);
        fitcount=fitcount+1;
        FEsassign(1,2)=FEsassign(1,2)+1;
        [gworstval(k),gworstid]=max(pbestval(group_id(k,:)));
        tmp=(gworstval(k)<eHS(k));
        FEsassign(1,1)=FEsassign(1,1)+(gworstval(k)>eHS(k));
        temp=repmat(tmp,1,D);
        pbest(group_id(k,gworstid),:)=temp.*pbest(group_id(k,gworstid),:)+(1-temp).*posHS(k,:);
        pbestval(group_id(k,gworstid))=tmp.*pbestval(group_id(k,gworstid))+(1-tmp).*eHS(k);%update the pbest by HS
        if pbestval(group_id(k,gworstid),:)<gbestval(pos_group(k))
        gbest(pos_group(k),:)=pbest(group_id(k,gworstid),:);
        gbestval(pos_group(k))=pbestval(group_id(k,gworstid));
        end
    end
end
end

lsnum=max(1,ceil(lsbuffersize-lsbuffersize*fitcount/(0.5*Max_FES)));
if fitcount>=numch
  radius2=[sum(upb(1,:)-lowb(1,:)).^2]*0.0001.*(1-0.99.*fitcount/Max_FES);
  matingPool1=[];
  posit=[pos e];
  pbestpos=[pbest pbestval];
  pool=[posit;pbestpos];
  pool=unique(pool,'rows');
  [y,in]=sort(pool(:,D+1));
  matingPool1=pool(in,:);
  temppool=pool;
  i=1;
  while i<=size(matingPool1,1)-1
    dist=zeros(size(matingPool1,1),1);
    dist(i+1:size(matingPool1,1),:)=sum((ones(size(matingPool1,1)-i,1)*matingPool1(i,1:D)-matingPool1(i+1:size(matingPool1,1),1:D)).^2,2)<radius2;
    matingPool1=matingPool1(dist==0,:);
    i=i+1;
  end
  while size(matingPool1,1)<lsnum
      radius2=radius2*0.95;
      matingPool1=pool(in,:);
      i=1;
      while i<=size(matingPool1,1)-1
        dist=zeros(size(matingPool1,1),1);
        dist(i+1:size(matingPool1,1),:)=sum((ones(size(matingPool1,1)-i,1)*matingPool1(i,1:D)-matingPool1(i+1:size(matingPool1,1),1:D)).^2,2)<radius2;
        matingPool1=matingPool1(dist==0,:);
        i=i+1;
      end
  end 
  
pbdis=zeros(size(pbest,1),D);
for i=1:size(pbest,1)
    pbdis(i,:)=sum(abs(repmat(pbest(i,1:D),size(pbest,1),1)-pbest))./size(pbest,1);
end
meanpbdis=sum(pbdis)./size(pbest,1);
if fitcount<=0.75*Max_FES
    if sssflag==0
    sss1=abs(meanpbdis)*(1-0.98.*fitcount/(0.75*Max_FES));
    sss2=abs(meanpbdis)*(20-19.98.*fitcount/(0.75*Max_FES));
    elseif sssflag==1
        sss=abs(meanpbdis)*(1-0.98.*fitcount/(0.75*Max_FES));
    elseif sssflag==2
        sss=abs(meanpbdis)*(20-19.98.*fitcount/(0.75*Max_FES));
    end
else sss=abs(meanpbdis)*(0.02-0.0199.*(fitcount-0.75*Max_FES)/(0.25*Max_FES));
end

 if numch==20000;
     for d=1:D
         for b=1:lsbuffersize
            archive(b,d).success=[0 0];
         end
     end
    if sssflag==0
        num=1;
        lspos(num,1:D)=matingPool1(num,1:D);
        lse(num,1)=matingPool1(num,D+1);
        lsesss1=lse(num,1);
        lspossss1=lspos(num,1:D);
        lsesss2=lse(num,1);
        lspossss2=lspos(num,1:D);
        laste=inf;
        lsfitcount=0;
        lsiter=0;
        dim=randperm(D);
        while (lsfitcount<=20000)
            lsiter=lsiter+1;
            laste=lsesss1
            lsfitcount
            if eflag==0
                if sss1(dim)<=10^(-15)
                    sss1(dim)=sss1(dim)*0.9;
                else sss1(dim)=sss1(dim)/0.9;
                end
            else
                    sss1(dim)=sss1(dim);
            end
        for i=1:D
            k=0;
            tempe(1)=0;
            while tempe(1)<=lsesss1
                k=k+1;
                if k>ceil((VRmax(1,dim(i))-lspossss1(num,dim(i)))/sss1(dim(i))),break; end
                var=zeros(1,D);
                var(dim(i))=k*sss1(dim(i));
                temppos=lspossss1(num,:)+var;
                temppos(1,:)=(temppos(1,:)>VRmax(1,:)).*VRmax(1,:)+(temppos(1,:)<=VRmax(1,:)).*temppos(1,:); 
                temppos(1,:)=(temppos(1,:)<VRmin(1,:)).*VRmin(1,:)+(temppos(1,:)>=VRmin(1,:)).*temppos(1,:);
                tempe = benchmark_func(temppos, func_num);
                fitcount=1+fitcount;
                FEsassign(1,4)=FEsassign(1,4)+1;
                lsfitcount=lsfitcount+1;
                archive(num,dim(i)).success(1,2)=archive(num,dim(i)).success(1,2)+1;
                if lsesss1>=tempe
                    FEsassign(1,3)=FEsassign(1,3)+(lsesss1>tempe);
                lsesss1=tempe;
                lspossss1(num,:)=temppos;
                if lsesss1>tempe
                archive(num,dim(i)).success(1,1)=archive(num,dim(i)).success(1,1)+1;
                end
                end
            end
            if k<=1
            k=0;
            tempe(1)=0;
            while tempe(1)<=lsesss1
                k=k+1;
                if k>ceil((lspossss1(num,dim(i))-VRmin(1,dim(i)))/sss1(dim(i))),break; end
                var=zeros(1,D);
                var(dim(i))=k*sss1(dim(i));
                temppos=lspossss1(num,:)-var;
                temppos(1,:)=(temppos(1,:)>VRmax(1,:)).*VRmax(1,:)+(temppos(1,:)<=VRmax(1,:)).*temppos(1,:); 
                temppos(1,:)=(temppos(1,:)<VRmin(1,:)).*VRmin(1,:)+(temppos(1,:)>=VRmin(1,:)).*temppos(1,:);
                tempe = benchmark_func(temppos, func_num);
                fitcount=1+fitcount;
                FEsassign(1,4)=FEsassign(1,4)+1;
                lsfitcount=lsfitcount+1;
                archive(num,dim(i)).success(1,2)=archive(num,dim(i)).success(1,2)+1;
                if lsesss1>=tempe
                    FEsassign(1,3)=FEsassign(1,3)+(lsesss1>tempe);
                lsesss1=tempe;
                lspossss1(num,:)=temppos;
                if lsesss1>tempe
                archive(num,dim(i)).success(1,1)=archive(num,dim(i)).success(1,1)+1;
                end
                end
            end
            end
        end
            if laste<=lsesss1
                eflag=0;
            else eflag=1;
            end
        end 
        
        lsfitcount=0;
        while (lsfitcount<=20000)
            lsiter=lsiter+1;
            laste=lsesss2
            lsfitcount
            if eflag==0
                if sss2(dim)<=10^(-15)
                    sss2(dim)=sss2(dim)*0.9;
                else sss2(dim)=sss2(dim)/0.9;
                end
            else
                    sss2(dim)=sss2(dim);
            end
        for i=1:D
            k=0;
            tempe(1)=0;
            while tempe(1)<=lsesss2
                k=k+1;
                if k>ceil((VRmax(1,dim(i))-lspossss2(num,dim(i)))/sss2(dim(i))),break; end
                var=zeros(1,D);
                var(dim(i))=k*sss2(dim(i));
                temppos=lspossss2(num,:)+var;
                temppos(1,:)=(temppos(1,:)>VRmax(1,:)).*VRmax(1,:)+(temppos(1,:)<=VRmax(1,:)).*temppos(1,:); 
                temppos(1,:)=(temppos(1,:)<VRmin(1,:)).*VRmin(1,:)+(temppos(1,:)>=VRmin(1,:)).*temppos(1,:);
                tempe = benchmark_func(temppos, func_num);
                fitcount=1+fitcount;
                FEsassign(1,4)=FEsassign(1,4)+1;
                lsfitcount=lsfitcount+1;
                archive(num,dim(i)).success(1,2)=archive(num,dim(i)).success(1,2)+1;
                if lsesss2>=tempe
                    FEsassign(1,3)=FEsassign(1,3)+(lsesss2>tempe);
                lsesss2=tempe;
                lspossss2(num,:)=temppos;
                if lsesss2>tempe
                archive(num,dim(i)).success(1,1)=archive(num,dim(i)).success(1,1)+1;
                end
                end
            end
            if k<=1
            k=0;
            tempe(1)=0;
            while tempe(1)<=lsesss2
                k=k+1;
                if k>ceil((lspossss2(num,dim(i))-VRmin(1,dim(i)))/sss2(dim(i))),break; end
                var=zeros(1,D);
                var(dim(i))=k*sss2(dim(i));
                temppos=lspossss2(num,:)-var;
                temppos(1,:)=(temppos(1,:)>VRmax(1,:)).*VRmax(1,:)+(temppos(1,:)<=VRmax(1,:)).*temppos(1,:); 
                temppos(1,:)=(temppos(1,:)<VRmin(1,:)).*VRmin(1,:)+(temppos(1,:)>=VRmin(1,:)).*temppos(1,:);
                tempe = benchmark_func(temppos, func_num);
                fitcount=1+fitcount;
                FEsassign(1,4)=FEsassign(1,4)+1;
                lsfitcount=lsfitcount+1;
                archive(num,dim(i)).success(1,2)=archive(num,dim(i)).success(1,2)+1;
                if lsesss2>=tempe
                    FEsassign(1,3)=FEsassign(1,3)+(lsesss2>tempe);
                lsesss2=tempe;
                lspossss2(num,:)=temppos;
                if lsesss2>tempe
                archive(num,dim(i)).success(1,1)=archive(num,dim(i)).success(1,1)+1;
                end
                end
            end
            end
        end
            if laste<=lsesss2
                eflag=0;
            else eflag=1;
            end
        end
        if lsesss1>lsesss2
            sssflag=2;
            lse(num,1)=lsesss2;
            lspos(num,:)=lspossss2;
        else sssflag=1;
            lse(num,1)=lsesss1;
            lspos(num,:)=lspossss1;
        end
    end
    sssflag
    if sssflag==2;
        sss=sss2;
    else sss=sss1;
    end
    for num=2:lsnum
    lspos(num,1:D)=matingPool1(num,1:D);
    lse(num,1)=matingPool1(num,D+1);
    laste=inf;
    lsfitcount=0;
    lsiter=0;
    dim=randperm(D);
    while (lsfitcount<=20000)
        lsiter=lsiter+1;
        laste=lse(num,1)
        lsfitcount
        if eflag==0
            if sss(dim)<=10^(-15)
                sss(dim)=sss(dim)*0.9;
            else sss(dim)=sss(dim)/0.9;
            end
        else
                sss(dim)=sss(dim);
        end
    for i=1:D
        k=0;
        tempe(1)=0;
        while tempe(1)<=lse(num,1)
            k=k+1;
            if k>ceil((VRmax(1,dim(i))-lspos(num,dim(i)))/sss(dim(i))),break; end
            var=zeros(1,D);
            var(dim(i))=k*sss(dim(i));
            temppos=lspos(num,:)+var;
            temppos(1,:)=(temppos(1,:)>VRmax(1,:)).*VRmax(1,:)+(temppos(1,:)<=VRmax(1,:)).*temppos(1,:); 
            temppos(1,:)=(temppos(1,:)<VRmin(1,:)).*VRmin(1,:)+(temppos(1,:)>=VRmin(1,:)).*temppos(1,:);
            tempe = benchmark_func(temppos, func_num);
            fitcount=1+fitcount;
            FEsassign(1,4)=FEsassign(1,4)+1;
            lsfitcount=lsfitcount+1;
            archive(num,dim(i)).success(1,2)=archive(num,dim(i)).success(1,2)+1;
            if lse(num,1)>=tempe
                FEsassign(1,3)=FEsassign(1,3)+(lse(num,1)>tempe);
            lse(num,1)=tempe;
            lspos(num,:)=temppos;
            if lse(num,1)>tempe
            archive(num,dim(i)).success(1,1)=archive(num,dim(i)).success(1,1)+1;
            end
            end
        end
        if k<=1
        k=0;
        tempe(1)=0;
        while tempe(1)<=lse(num,1)
            k=k+1;
            if k>ceil((lspos(num,dim(i))-VRmin(1,dim(i)))/sss(dim(i))),break; end
            var=zeros(1,D);
            var(dim(i))=k*sss(dim(i));
            temppos=lspos(num,:)-var;
            temppos(1,:)=(temppos(1,:)>VRmax(1,:)).*VRmax(1,:)+(temppos(1,:)<=VRmax(1,:)).*temppos(1,:); 
            temppos(1,:)=(temppos(1,:)<VRmin(1,:)).*VRmin(1,:)+(temppos(1,:)>=VRmin(1,:)).*temppos(1,:);
            tempe = benchmark_func(temppos, func_num);
            fitcount=1+fitcount;
            FEsassign(1,4)=FEsassign(1,4)+1;
            lsfitcount=lsfitcount+1;
            archive(num,dim(i)).success(1,2)=archive(num,dim(i)).success(1,2)+1;
            if lse(num,1)>=tempe
                FEsassign(1,3)=FEsassign(1,3)+(lse(num,1)>tempe);
            lse(num,1)=tempe;
            lspos(num,:)=temppos;
            if lse(num,1)>tempe
            archive(num,dim(i)).success(1,1)=archive(num,dim(i)).success(1,1)+1;
            end
            end
        end
        end
    end
        if laste<=lse(num,1)
            eflag=0;
        else eflag=1;
        end
    end
    end
 else
     if FEsassign(1,1)~=0
     FEsLS=20000*FEsassign(1,3)*FEsassign(1,2)/(FEsassign(1,1)*FEsassign(1,4)*lsnum);
     else FEsLS=10000;
     end
     FEsassign(1,3:4)=0;
    for num=1:min(lsnum,size(matingPool1))
    lspos(num,1:D)=matingPool1(num,1:D);
    lse(num,1)=matingPool1(num,D+1);
    laste=inf;
    lsfitcount=0;
    lsiter=0;
    for d=1:D
        SucTime(d)=0;
        SucFEs(d)=0;
        for b=1:lsbuffersize
        SucTime(d)=SucTime(d)+archive(b,d).success(1,1);
        SucFEs(d)=SucFEs(d)+archive(b,d).success(1,2);
        end
        if SucFEs(d)~=0;
            SucRate(d)=SucTime(d)/SucFEs(d);
        else SucRate(d)=0;
        end
    end
    SucProb=SucRate./sum(SucRate);
    [SucProb,dim]=sort(SucProb,'descend');
    for j=1:lsbuffersize-1
        archive(j,:)=archive(j+1,:);
    end
    for d=1:D
        archive(lsbuffersize,d).success=[0 0];
    end
    while (lsfitcount<=FEsLS)
        lsiter=lsiter+1;
        if  fitcount>=120000 & record_flag==0 
            record_flag=1;
            eval(['fid=fopen(''gbestval_' num2str(func_num) '_' num2str(run) '.txt'',''w'');' ]);
            fprintf(fid,'%e\n',min(lse));
            fclose(fid);
        elseif fitcount>=600000 & record_flag==1
            record_flag=2;
            eval(['fid=fopen(''gbestval_' num2str(func_num) '_' num2str(run) '.txt'',''a'');' ]);
            fprintf(fid,'\n');
            fprintf(fid,'%e\n',min(lse));
            fclose(fid);
        end
        if fitcount>Max_FES, break; end
        laste=lse(num,1)
        lsfitcount 
        if eflag==0
            if sss(dim)<=10^(-15)
                sss(dim)=sss(dim)*0.9;
            else sss(dim)=sss(dim)/0.9;
            end
        else
                sss(dim)=sss(dim);
        end
    for i=1:D
        k=0;
        tempe(1)=0;
        while tempe(1)<=lse(num,1)
            k=k+1;
            if k>ceil((VRmax(1,i)-lspos(num,dim(i)))/sss(dim(i))),break; end
            var=zeros(1,D);
            var(dim(i))=k*sss(dim(i));
            temppos=lspos(num,:)+var;
            temppos(1,:)=(temppos(1,:)>VRmax(1,:)).*VRmax(1,:)+(temppos(1,:)<=VRmax(1,:)).*temppos(1,:); 
            temppos(1,:)=(temppos(1,:)<VRmin(1,:)).*VRmin(1,:)+(temppos(1,:)>=VRmin(1,:)).*temppos(1,:);
            tempe = benchmark_func(temppos, func_num);
            fitcount=1+fitcount;
            FEsassign(1,4)=FEsassign(1,4)+1;
            lsfitcount=lsfitcount+1;
            archive(lsbuffersize,dim(i)).success(1,2)=archive(lsbuffersize,dim(i)).success(1,2)+1;
            if lse(num,1)>=tempe
                FEsassign(1,3)=FEsassign(1,3)+(lse(num,1)>tempe);
            lse(num,1)=tempe;
            lspos(num,:)=temppos;
            if lse(num,1)>tempe
            archive(lsbuffersize,dim(i)).success(1,1)=archive(lsbuffersize,dim(i)).success(1,1)+1;
            end
            end
            if fitcount>0.98*Max_FES, break; end
        end
        if k<=1
        k=0;
        tempe(1)=0;
        while tempe(1)<=lse(num,1)
            k=k+1;
            if k>ceil((lspos(num,dim(i))-VRmin(1,i))/sss(dim(i))),break; end
            var=zeros(1,D);
            var(dim(i))=k*sss(dim(i));
            temppos=lspos(num,:)-var;
            temppos(1,:)=(temppos(1,:)>VRmax(1,:)).*VRmax(1,:)+(temppos(1,:)<=VRmax(1,:)).*temppos(1,:); 
            temppos(1,:)=(temppos(1,:)<VRmin(1,:)).*VRmin(1,:)+(temppos(1,:)>=VRmin(1,:)).*temppos(1,:);
            tempe = benchmark_func(temppos, func_num);
            fitcount=1+fitcount;
            FEsassign(1,4)=FEsassign(1,4)+1;
            lsfitcount=lsfitcount+1;
            archive(lsbuffersize,dim(i)).success(1,2)=archive(lsbuffersize,dim(i)).success(1,2)+1;
            if lse(num,1)>=tempe
                FEsassign(1,3)=FEsassign(1,3)+(lse(num,1)>tempe);
            lse(num,1)=tempe;
            lspos(num,:)=temppos;
            if lse(num,1)>tempe
            archive(lsbuffersize,dim(i)).success(1,1)=archive(lsbuffersize,dim(i)).success(1,1)+1;
            end
            end
            if fitcount>0.98*Max_FES, break; end
        end
        end
        if fitcount>0.98*Max_FES, break; end
    end
        if laste<=lse(num,1)
            eflag=0;
        else eflag=1;
        end
    end
    end
 end
   Distan = sqrt(sum(abs( repmat(permute(pbest(:,1:D), [1 3 2]), [1 size(lspos,1) 1])- ...
     repmat(permute(lspos(:,1:D), [3 1 2]), [size(pbest,1) 1 1]) ).^2, 3));
    [sortDistan,sortDistanid]=sort(Distan);
    index0=0;
    for num=1:size(lspos,1)
        index1=sortDistanid(1,num);
        nnn=2;
        while index1==index0
            index1=sortDistanid(nnn,num);
            nnn=nnn+1;
        end
        pbest(index1,1:D)=lspos(num,1:D).*(lse(num,1)<=pbestval(index1,1))+pbest(index1,1:D).*(lse(num,1)>pbestval(index1,1));
        pbestval(index1,1)=lse(num,1).*(lse(num,1)<=pbestval(index1,1))+pbestval(index1,1).*(lse(num,1)>pbestval(index1,1));
        index0=index1;
    end
if fitcount>=recorditer
    eval(['fid=fopen(''DMS_PSO_HS_NichingMemory_gbestval_' num2str(func_num) '_' num2str(run) '.txt'',''a'');' ]);
    fprintf(fid,'\n');
    fprintf(fid,'%e\n',min(lse));
    fclose(fid);
    recorditer=recorditer+60000;
end
numch=fitcount+20000;
eval(['save FEsassign_' num2str(func_num) '_' num2str(run) '_' num2str(fitcount) ' FEsassign']);
FEsassign(1,1:2)=0;
end

%%%arch updating
while size(arch,1)<10000
particle=[pbest pbestval];
arch=[arch;particle];
for k=1:ps
    if pos(k)~=pbest(k) & rand<=0.05
        divpos=[pos(k,1:D) e(k)];
        arch=[arch;divpos];        
    end
end
end

if ceil(fitcount/Max_FES*10)>=numclg & fitcount<=0.5*Max_FES
    numclg=ceil(fitcount/Max_FES*10)+1;
  
  radius=[sum(upb(1,:)-lowb(1,:)).^2]*0.0001.*(1-0.99.*fitcount/Max_FES);
  matingPool=[];
  arch=unique(arch,'rows');
  [y,in]=sort(arch(:,D+1));
  matingPool=arch(in,:);
  temparch=arch;
  i=1;
  while i<=size(matingPool,1)-1
    dist=zeros(size(matingPool,1),1);
    dist(i+1:size(matingPool,1),:)=sum((ones(size(matingPool,1)-i,1)*matingPool(i,1:D)-matingPool(i+1:size(matingPool,1),1:D)).^2,2)<radius;
    matingPool=matingPool(dist==0,:);
    i=i+1;
  end
  while size(matingPool,1)<group_ps
      radius=radius*0.95;
      matingPool=arch(in,:);
      i=1;
      while i<=size(matingPool,1)-1
        dist=zeros(size(matingPool,1),1);
        dist(i+1:size(matingPool,1),:)=sum((ones(size(matingPool,1)-i,1)*matingPool(i,1:D)-matingPool(i+1:size(matingPool,1),1:D)).^2,2)<radius;
        matingPool=matingPool(dist==0,:);
        i=i+1;
      end
  end
 
    [m1,mm1]=size(arch);
    [m2,mm2]=size(matingPool);
    sortid=zeros(m2,m2);
    for j=1:m2
        Dis = sqrt(sum(abs( repmat(permute(matingPool(j,1:D), [1 3 2]), [1 m2 1])- repmat(permute(matingPool(:,1:D), [3 1 2]), [1 1 1]) ).^2, 3));
        [sortD,sortid(j,:)]=sort(Dis);
        clear sortD Dis
    end
    if size(sortid,2)<group_ps
        keyboard
    else
        nicheid=sortid(:,1:group_ps);
    end
    HMCR=0.9;
    PAR=0.01+(0.9-0.01)/Max_FES*fitcount;
    sn=20;
    for k=1:min(m2,sn)
        if k==1
        HSgroup=arch(nicheid(k,:),:);
        else
            if m2>sn
            kk=randperm(min(sn,m2));
            HSgroup=matingPool(kk(1:group_ps),:);
            else HSgroup=arch(nicheid(k,:),:);
            end
        end          
    for subiter=1:D%100    
    for d=1:D
        if rand(1,1)<=HMCR
            rpd=randperm(group_ps);
            posHS(k,d)=HSgroup(rpd(1),d);
            if rand(1,1)<=PAR
                posHS(k,d)=HSgroup(1,d);
            end
        else posHS(k,d)=HSgroup(1,d)+(VRmax(1,d)-VRmin(1,d)).*0.01.*(2*rand(1,1)-1);
        end
    end
    if (sum(posHS(k,:)>VRmax(1,:))+sum(posHS(k,:)<VRmin(1,:)))==0;
        eHS(k,1)=benchmark_func(posHS(k,:),func_num);
        fitcount=fitcount+1;
        [gworstval(k),gworstid]=max(HSgroup(:,D+1));
        tmp=(gworstval(k)<eHS(k));
        temp=repmat(tmp,1,D);
        HSgroup(gworstid,1:D)=temp.*HSgroup(gworstid,1:D)+(1-temp).*posHS(k,:);
        HSgroup(gworstid,D+1)=tmp.*HSgroup(gworstid,D+1)+(1-tmp).*eHS(k);%update the pbest by HS%update the arch by HS
    end
    end
    [nichebest(k),nichebestid]=min(HSgroup(:,D+1));
    newpbest(k,:)=HSgroup(nichebestid,1:D);
    newpbestval(k)=HSgroup(nichebestid,D+1);

    newparticle(k,:)=[newpbest(k,:) newpbestval(k)];
    arch=[arch;newparticle(k,:)];
    end
    
if size(newpbestval,1)==1
    newpbestval=newpbestval';
end
newparticle=[newpbest newpbestval];
mixparticle=[matingPool;newparticle];

[gbval,gbid]=sort(gbestval);
ggbest=gbest(gbid(1),:);
[pbval,pbid]=sort(pbestval);
    Dista = sqrt(sum(abs( repmat(permute(ggbest(:,1:D), [1 3 2]), [1 size(mixparticle,1) 1])- ...
     repmat(permute(mixparticle(:,1:D), [3 1 2]), [1 1 1]) ).^2, 3));
    [sortDista,sortDistaid]=sort(sum(Dista),'descend');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%replace worse pbests and pos by farest points from mixparticle    
if length(sortDistaid)>=2
    if length(sortDistaid)>2*ps*0.2
        num=2*ps*0.2+floor((size(sortDistaid,1)-2*ps*0.2)/(0.9*Max_FES)*fitcount);
        mixpar=mixparticle(sortDistaid(1:num),:);
        [sortfit,sortfitid]=sort(mixpar(:,D+1));
        for k=1:ps*0.2
            pos(pbid(ps+1-k),:)=mixpar(sortfitid(k),1:D);
            e(pbid(ps+1-k),:)=mixpar(sortfitid(k),D+1);

            pbest(pbid(ps+1-k),:)=mixpar(sortfitid(ps*0.2+k),1:D);
            pbestval(pbid(ps+1-k),:)=mixpar(sortfitid(ps*0.2+k),D+1);
        end
    else
        for k=1:min(floor(0.5*length(sortDistaid)),ps*0.2)
            pos(pbid(ps+1-k),:)=mixparticle(sortDistaid(k),1:D);
            e(pbid(ps+1-k),:)=mixparticle(sortDistaid(k),D+1);

            pbest(pbid(ps+1-k),:)=mixparticle(sortDistaid(min(floor(0.5*length(sortDistaid)),ps*0.2)+k),1:D);
            pbestval(pbid(ps+1-k),:)=mixparticle(sortDistaid(min(floor(0.5*length(sortDistaid)),ps*0.2)+k),D+1);
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if group_num<40 & m2>=20
    sn_flag=0;
    group_num=group_num+1;
    ps=ps+group_ps;
    pos((group_ps*(group_num-1)+1):(group_ps*group_num),:)=newparticle(1:group_ps,1:D);
    e((group_ps*(group_num-1)+1):(group_ps*group_num),:)=newparticle(1:group_ps,D+1);

    pbest((group_ps*(group_num-1)+1):(group_ps*group_num),:)=newparticle((group_ps+1):(2*group_ps),1:D);
    pbestval((group_ps*(group_num-1)+1):(group_ps*group_num),:)=newparticle((group_ps+1):(2*group_ps),D+1);
    
    vel((group_ps*(group_num-1)+1):(group_ps*group_num),:)=Vmin(1:group_ps,:)+2.*Vmax(1:group_ps,:).*rand(group_ps,D);
    VRmin((group_ps*(group_num-1)+1):(group_ps*group_num),:)=VRmin(1:group_ps,:);
    VRmax((group_ps*(group_num-1)+1):(group_ps*group_num),:)=VRmax(1:group_ps,:);
    mv=0.2*(VRmax-VRmin);
else sn_flag=1;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for i=1:group_num
        group_id(i,:)=[((i-1)*group_ps+1):i*group_ps];
        pos_group(group_id(i,:))=i;
        [gbestval(i),gbestid]=min(pbestval(group_id(i,:)));
        gbest(i,:)=pbest(group_id(i,gbestid),:);%initialize the gbest and the gbest's fitness value
    end
  while size(arch,1)>10000
    radius1=[sum(upb(1,:)-lowb(1,:)).^2]*0.0001.*(1-0.99.*fitcount/Max_FES);
    if size(arch,1)>10000
        s_arch=size(arch,1);
        [mmm,mmmid]=sort(arch(:,D+1));
        arch=arch(mmmid,:);
        dist=zeros(size(arch,1),1);
        for i=2:size(arch,1)
            if (sum(arch(1,1:D)-arch(i,1:D)).^2)<radius1;
                dist(i)=1;
            end
        end
        arch=arch(dist==0,:);
        if size(arch,1)==s_arch;
            radius1=radius1*10;
        end
    end
  end
  if size(arch,1)>5000
      indexarch=randperm(size(arch,1));
      arch=arch(indexarch,:);
  end
numch=fitcount+20000;
FEsassign(1,1:2)=0;
end 

  if fitcount>=recorditer
      eval(['fid=fopen(''DMS_PSO_HS_NichingMemory_gbestval_' num2str(func_num) '_' num2str(run) '.txt'',''a'');' ]);
      fprintf(fid,'\n');
      fprintf(fid,'%e\n',min(gbestval));
      fclose(fid);
      recorditer=recorditer+60000;
  end
    if  fitcount>=120000 & record_flag==0 
        record_flag=1;
        eval(['fid=fopen(''gbestval_' num2str(func_num) '_' num2str(run) '.txt'',''w'');' ]);
        fprintf(fid,'%e\n',min(gbestval));
        fclose(fid);
    elseif fitcount>=600000 & record_flag==1
        record_flag=2;
        eval(['fid=fopen(''gbestval_' num2str(func_num) '_' num2str(run) '.txt'',''a'');' ]);
        fprintf(fid,'\n');
        fprintf(fid,'%e\n',min(gbestval));
        fclose(fid);
    end 
    if fitcount>Max_FES, break; end
end
[tmp,tmpid]=sort(gbestval);
gbest=gbest(tmpid(1),:);
gbestval=gbestval(tmpid(1));

while fitcount<Max_FES    
              options = optimset('LargeScale','off','MaxFunEvals',0.02*Max_FES,'Display','off');
            [tmp,tmpid]=sort(gbestval);
            k=1;
                [x,fval,exitflag,output] = fminunc(fhd,gbest(tmpid(k),:),options,func_num);
                fitcount=fitcount+output.funcCount;
                if fval<gbestval(tmpid(k))
                    [gbestval(tmpid(k)),gbestid]=min(pbestval(group_id(tmpid(k),:)));
                    pbest(group_id(tmpid(k),gbestid),:)=x;
                    pbestval(group_id(tmpid(k),gbestid))=fval;
                    gbest(tmpid(k),:)=x;
                    gbestval(tmpid(k))=fval;
                end
end
size(arch,1)
[tmp,tmpid]=sort(gbestval);
gbest=gbest(tmpid(1),:);
gbestval=gbestval(tmpid(1));
  eval(['fid=fopen(''DMS_PSO_HS_NichingMemory_gbestval_' num2str(func_num) '_' num2str(run) '.txt'',''a'');' ]);
  fprintf(fid,'\n');
  fprintf(fid,'%e\n',min(gbestval));
  fclose(fid);
  
  eval(['fid=fopen(''gbestval_' num2str(func_num) '_' num2str(run) '.txt'',''a'');' ]);
  fprintf(fid,'\n');
  fprintf(fid,'%e\n',min(gbestval));
  fclose(fid);
%   eval(['save archivesuccess_' num2str(func_num) '_' num2str(run) ' archive']);