
clear all

rand('state',sum(100*clock));
warning off
global initial_flag; % the global flag used in test suite

me=60000;
ps=50; % population size
Max_FES=ps*me;   % maximal number of FEs, should be set to 3e+06
D = 1000; % dimensionality of benchmark functions
runs = 25; % number of independent runs for each function, should be set to 25
group_num=10;
Particle_Number=5;
ffuc=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20];
for ff=1:20
    func_num = ffuc(ff);

   % set the lower and upper bound for each function
   if (func_num == 1 | func_num == 4 | func_num == 7 | func_num == 8 | func_num == 9 | func_num == 12 | func_num == 13 | func_num == 14 | func_num == 17 | func_num == 18 | func_num == 19 | func_num == 20)
      VRmin = -100;
      VRmax = 100;
   end
   if (func_num == 2 | func_num == 5 | func_num == 10 | func_num == 15)
      VRmin = -5;
      VRmax = 5;
   end
   if (func_num == 3 | func_num == 6 | func_num == 11 | func_num == 16)
      VRmin = -32;
      VRmax = 32;
   end
    
for run=1:runs
    initial_flag = 0; % should set the flag to 0 for each run, each function
    func_num,run
    [gbest,gbestval,fitcount]= DMS_PSO_HS_NichingMemory_linesearch(func_num,Max_FES,group_num,Particle_Number,D,VRmin,VRmax,run);
    gbestval
    fitcount_res(func_num,run)=fitcount;gbestval_res(func_num,run)=gbestval;gbest_res(func_num,run,:)=gbest;
end

mean(gbestval_res')
end

