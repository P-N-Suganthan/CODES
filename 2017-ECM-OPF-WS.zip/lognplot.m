function lognplot()
global mcarlo SP1 nbins
mu = 6; sigma = 0.6;
Psr = 50; % [MW] Equivalent rated power output of the PV generator
Gstd = 800; %[W/m2] Solar irradiation in the standard enviroment
Rc = 120; % [W/m2] A certain irradiation
nbins = 30; % No. of bins for histogram
mcarlo = 8000; % No. of Montecalro scenarios

G1 = lognrnd(mu,sigma,mcarlo,1);

% lognormal plots activate if you need to plot
%%{
figure(3)
histfit(G1,nbins,'lognormal')
xlim([0 4000])
xlabel('Solar irradiance (W/m^2) for solar PV at bus 13')
ylabel('Frequency')
legend('Solar irradiance')
%}

% Power calculation
G1und = G1(G1<=Rc);
G1over = G1(G1>Rc);
P1und = Psr*(G1und.^2/(Gstd*Rc));
P1over = Psr*(G1over./Gstd);
SP1 = vertcat(P1und,P1over);

% plots of power activate if you need to plot
%%{
figure(4)
% hist(SP1,nbins);
[num,xout] = hist(SP1,nbins);
bar(xout,num/sum(num));
xlim([0 250])
xlabel('Available real power (MW) from solar PV at bus 13')
ylabel('Relative frequency')
%}
