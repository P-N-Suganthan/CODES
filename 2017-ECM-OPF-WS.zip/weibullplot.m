function weibullplot()
global scale shape
scale = [9 10]; % Enter shape parameters of 2 windfarms for Weibull dist
shape = [2 2]; % Enter shape parameters of 2 windfarms for Weibull dist

W1 = wblrnd(scale(1),shape(1),8000,1);
figure(1)
histfit(W1,30,'weibull')
xlabel('Wind speed (m/s) for wind generator at bus 5')
ylabel('Frequency')
legend ('Wind distribution')

W2 = wblrnd(scale(2),shape(2),8000,1);
figure(2)
histfit(W2,30,'weibull')
xlabel('Wind speed (m/s) for wind generator at bus 11')
ylabel('Frequency')
legend ('Wind distribution')