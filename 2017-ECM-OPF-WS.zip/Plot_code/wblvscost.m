NT = [25 20]; % No. of turbines in the 3 farms
%Find wind generator related parameters
%windgen parameter sl no. bus costcoeff
wgenpar = [1   5   1.60;
           2   11  1.75];
Crwj = 3; Cpwj = 1.5; Vin = 3; Vout = 25; Vr = 16; Pr = 3;

%stochastic wind power cost

count1 = 1; count2 = 1; wovest1 = zeros(); wundest1 = zeros(); wgencost1 = zeros();
wovest2 = zeros(); wundest2 = zeros(); wgencost2 = zeros(); shape = [2 2];
dcost1 = zeros(); dcost2 = zeros();
schwpow = 25; 

for scale = 2:16
    Prw0 = 1-exp(-(Vin/scale)^shape(1))+exp(-(Vout/scale)^shape(1));
    Prwwr = exp(-(Vr/scale)^shape(1))-exp(-(Vout/scale)^shape(1));
    Prww1 = (shape(1)*(Vr-Vin))/((scale^shape(1))*(NT(1)*Pr));
    Prww = @(wp)((schwpow-wp)*Prww1*((Vin + (wp/(NT(1)*Pr))*(Vr-Vin))^(shape(1)-1))*(exp(-((Vin + (wp/(NT(1)*Pr))*(Vr-Vin))/scale)^shape(1))));
    wovest11 = integral(Prww,0,schwpow,'ArrayValued',true);
    wovest1(count1) = schwpow*Prw0*Crwj+Crwj*wovest11;
    
    Prww = @(wp)((wp-schwpow)*Prww1*((Vin + (wp/(NT(1)*Pr))*(Vr-Vin))^(shape(1)-1))*(exp(-((Vin + (wp/(NT(1)*Pr))*(Vr-Vin))/scale)^shape(1))));
    wundest11 = integral(Prww,schwpow,NT(1)*Pr,'ArrayValued',true);
    wundest1(count1) = (NT(1)*Pr-schwpow)*Prwwr*Cpwj+Cpwj*wundest11;
    dcost1(count1) = wgenpar(1,3)*schwpow;
    wgencost1(count1) = dcost1(count1)+wovest1(count1)+wundest1(count1);
    count1 = count1+1;
end

figure(1)
plotgraph1 = [(2:16)',wovest1',wundest1',dcost1',wgencost1'];
plot(plotgraph1(:,1),plotgraph1(:,2),'mo-',plotgraph1(:,1),plotgraph1(:,3),'rx-',plotgraph1(:,1),plotgraph1(:,4),'b.-',plotgraph1(:,1),plotgraph1(:,5),'k*-');
legend('Reserve cost','Penalty cost','Direct cost','Total cost')
xlabel('Weibull scale parameter (c) for windfarm#1')
ylabel('Cost ($/h)')

schwpow = 20;
for scale = 2:16
    Prw0 = 1-exp(-(Vin/scale)^shape(2))+exp(-(Vout/scale)^shape(2));
    Prwwr = exp(-(Vr/scale)^shape(2))-exp(-(Vout/scale)^shape(2));
    Prww1 = (shape(2)*(Vr-Vin))/((scale^shape(2))*(NT(2)*Pr));
    Prww = @(wp)((schwpow-wp)*Prww1*((Vin + (wp/(NT(2)*Pr))*(Vr-Vin))^(shape(2)-1))*(exp(-((Vin + (wp/(NT(2)*Pr))*(Vr-Vin))/scale)^shape(2))));
    wovest21 = integral(Prww,0,schwpow,'ArrayValued',true);
    wovest2(count2) = schwpow*Prw0*Crwj+Crwj*wovest21;
    
    Prww = @(wp)((wp-schwpow)*Prww1*((Vin + (wp/(NT(2)*Pr))*(Vr-Vin))^(shape(2)-1))*(exp(-((Vin + (wp/(NT(2)*Pr))*(Vr-Vin))/scale)^shape(2))));
    wundest21 = integral(Prww,schwpow,NT(2)*Pr,'ArrayValued',true);
    wundest2(count2) = (NT(2)*Pr-schwpow)*Prwwr*Cpwj+Cpwj*wundest21;
    dcost2(count2) = wgenpar(2,3)*schwpow;
    wgencost2(count2) = wgenpar(2,3)*schwpow+wovest2(count2)+wundest2(count2);
    count2 = count2+1;
end

figure(2)
plotgraph2 = [(2:16)',wovest2',wundest2',dcost2',wgencost2'];
plot(plotgraph2(:,1),plotgraph2(:,2),'mo-',plotgraph2(:,1),plotgraph2(:,3),'rx-',plotgraph2(:,1),plotgraph2(:,4),'b.-',plotgraph2(:,1),plotgraph2(:,5),'k*-');
legend('Reserve cost','Penalty cost','Direct cost','Total cost')
xlabel('Weibull scale parameter (c) for windfarm#2')
ylabel('Cost ($/h)')