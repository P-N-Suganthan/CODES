scale = [9 10]; % Enter shape parameters of 3 windfarms for Weibull dist
shape = [2 2]; % Enter shape parameters of 3 windfarms for Weibull dist
NT = [25 20]; % No. of turbines in the 3 farms

%Find wind generator related parameters
%windgen parameter sl no. bus costcoeff
wgenpar = [1   5   1.60;
           2   11  1.75];
Crwj = 3; Cpwj = 1.5; Vin = 3; Vout = 25; Vr = 16; Pr = 3;

%stochastic wind power cost
Prw0 = 1-exp(-(Vin./scale).^shape)+exp(-(Vout./scale).^shape);
Prwwr = exp(-(Vr./scale).^shape)-exp(-(Vout./scale).^shape);
count1 = 1; count2 = 1; wovest1 = zeros(); wundest1 = zeros(); wgencost1 = zeros();
wovest2 = zeros(); wundest2 = zeros(); wgencost2 = zeros(); dcost1 = zeros();
dcost2 = zeros();

for schwpow = 0:5:NT(1)*Pr
    Prww1 = (shape(1)*(Vr-Vin))/((scale(1)^shape(1))*(NT(1)*Pr));
    Prww = @(wp)((schwpow-wp)*Prww1*((Vin + (wp/(NT(1)*Pr))*(Vr-Vin))^(shape(1)-1))*(exp(-((Vin + (wp/(NT(1)*Pr))*(Vr-Vin))/scale(1))^shape(1))));
    wovest11 = integral(Prww,0,schwpow,'ArrayValued',true);
    wovest1(count1) = schwpow*Prw0(1)*Crwj+Crwj*wovest11;
    
    Prww = @(wp)((wp-schwpow)*Prww1*((Vin + (wp/(NT(1)*Pr))*(Vr-Vin))^(shape(1)-1))*(exp(-((Vin + (wp/(NT(1)*Pr))*(Vr-Vin))/scale(1))^shape(1))));
    wundest11 = integral(Prww,schwpow,NT(1)*Pr,'ArrayValued',true);
    wundest1(count1) = (NT(1)*Pr-schwpow)*Prwwr(1)*Cpwj+Cpwj*wundest11;
    dcost1(count1) = wgenpar(1,3)*schwpow;
    wgencost1(count1) = dcost1(count1)+wovest1(count1)+wundest1(count1);
    count1 = count1+1;
end

figure(1)
plotgraph1 = [(0:5:NT(1)*Pr)',wovest1',wundest1',dcost1',wgencost1',];
plot(plotgraph1(:,1),plotgraph1(:,2),'mo-',plotgraph1(:,1),plotgraph1(:,3),'rx-',plotgraph1(:,1),plotgraph1(:,4),'b.-',plotgraph1(:,1),plotgraph1(:,5),'k*-');
legend('Reserve cost','Penalty cost','Direct cost','Total cost')
xlabel('Scheduled wind power P_{ws} (MW) from WG1 at bus 5')
ylabel('Cost ($/h)')

for schwpow = 0:5:NT(2)*Pr
    Prww1 = (shape(2)*(Vr-Vin))/((scale(2)^shape(2))*(NT(2)*Pr));
    Prww = @(wp)((schwpow-wp)*Prww1*((Vin + (wp/(NT(2)*Pr))*(Vr-Vin))^(shape(2)-1))*(exp(-((Vin + (wp/(NT(2)*Pr))*(Vr-Vin))/scale(2))^shape(2))));
    wovest21 = integral(Prww,0,schwpow,'ArrayValued',true);
    wovest2(count2) = schwpow*Prw0(2)*Crwj+Crwj*wovest21;
    
    Prww = @(wp)((wp-schwpow)*Prww1*((Vin + (wp/(NT(2)*Pr))*(Vr-Vin))^(shape(2)-1))*(exp(-((Vin + (wp/(NT(2)*Pr))*(Vr-Vin))/scale(2))^shape(2))));
    wundest21 = integral(Prww,schwpow,NT(2)*Pr,'ArrayValued',true);
    wundest2(count2) = (NT(2)*Pr-schwpow)*Prwwr(2)*Cpwj+Cpwj*wundest21;
    dcost2(count2) = wgenpar(2,3)*schwpow;
    wgencost2(count2) = dcost2(count2)+wovest2(count2)+wundest2(count2);
    count2 = count2+1;
end

figure(2)
plotgraph2 = [(0:5:NT(2)*Pr)',wovest2',wundest2',dcost2',wgencost2'];
plot(plotgraph2(:,1),plotgraph2(:,2),'mo-',plotgraph2(:,1),plotgraph2(:,3),'rx-',plotgraph2(:,1),plotgraph2(:,4),'b.-',plotgraph2(:,1),plotgraph2(:,5),'k*-');
legend('Reserve cost','Penalty cost','Direct cost','Total cost')
xlabel('Scheduled wind power P_{ws} (MW) from WG2 at bus 11')
ylabel('Cost ($/h)')
