sigma = 0.6;
Psr = 50; % [MW] Equivalent rated power output of the PV generator
Gstd = 800; %[W/m2] Solar irradiation in the standard enviroment
Rc = 120; % [W/m2] A certain irradiation
nbins = 30; % No. of bins for histogram
mcarlo = 8000; % No. of Montecalro scenarios
schspow = 20;

C1und = zeros(); C1over = zeros(); dcost = zeros();
sgencost = zeros(); count=1;
sgenpar = [1   13  1.60];
Crsj = 3; % Reserve cost for solar power overestimation ($/MW)
Cpsj = 1.5; % Penalty cost for solar power underestimation ($/MW)

for mu = 2:0.5:7
G1 = lognrnd(mu,sigma,mcarlo,1);
% Power calculation
G1und = G1(G1<=Rc);
G1over = G1(G1>Rc);
P1und = Psr*(G1und.^2/(Gstd*Rc));
P1over = Psr*(G1over./Gstd);
SP1 = vertcat(P1und,P1over);

% Segregate over and underestimated power on the power histogram
[histy1,histx1] = hist(SP1,nbins);

Lowind1 = histx1<schspow;
Highind1 = histx1>schspow;
allP1und = schspow-histx1(histx1<schspow);
allP1over = histx1(histx1>schspow)-schspow;
ProbP1und = histy1(Lowind1)./mcarlo;
ProbP1over = histy1(Highind1)./mcarlo;

% Finding under and over estimation cost
C1und(count) = sum(Crsj*(ProbP1und.*allP1und));
C1over(count) = sum(Cpsj*(ProbP1over.*allP1over));
dcost(count) = sgenpar(1,3)*schspow;
sgencost(count) = dcost(count)+C1und(count)+C1over(count); % solar generator cost
count = count+1;
end

plotgraph = [(2:0.5:7)',C1und',C1over',dcost',sgencost'];
figure(1)
plot(plotgraph(:,1),plotgraph(:,2),'mo-',plotgraph(:,1),plotgraph(:,3),'rx-',plotgraph(:,1),plotgraph(:,4),'b.-',plotgraph(:,1),plotgraph(:,5),'k*-');
legend('Reserve cost','Penalty cost','Direct cost','Total cost')
xlabel('Variation of solar PV power cost vs lognormal mean (\mu)')
ylabel('Cost ($/h)')