MATLAB Code: "Optimal power flow solutions incorporating stochastic wind and solar power." 
Energy Conversion and Management 148 (2017): 1194-1207.

You need MATPOWER to run the program.
'Plot_code' folder is for various plots (some of the case studies) in the paper.
The author can be contacted at parthapr001@e.ntu.edu.sg