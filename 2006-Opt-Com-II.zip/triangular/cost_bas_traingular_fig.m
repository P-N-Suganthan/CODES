function [cost,w,R]=cost_bas_triangular_fig(dn_pro);
%       dn_pro=   1.0e-003 *[ 0.00000000001000   0.00000000002000   0.00002702538820   0.02087561878989   0.02245618109595   0.01541609675014   0.01987115714175 0.06440061654172   0.11691952590602   0.14679227179704   0.12241519105892   0.06805061587738   0.00938493839925   0.00000000007000 0.00000000006000   0.00722082646860   0.00443734855135   0.00598931866419   0.00587163827619   0.00898779367552 ]';              
nn=length(dn_pro);
slen=2;
dn_pro=dn_pro(1:nn)';

 
 Rdes=0.99;
  dw=1.666666666666667e-006;
  waveL_s=1.5498;
  waveL_e=1.5502;
  Rmask=[zeros(1,60) 0:0.015:.9 .9-.015:-0.015:0 zeros(1,60)];

  
w=waveL_s:dw:waveL_e;

neff=1.452;     
G_period=(1.55/(2*neff));
N_sample=length(dn_pro);
GG=G_period*ones(1,N_sample);
ll=round((slen*10^-3)./(GG*10^-6));

[w,R]=chirped_apodized0(dn_pro,N_sample,neff,GG,waveL_s,waveL_e,dw,ll);
Rerr=sum((R'-Rmask).^2);
Rmaxerr=abs(max(R)-Rdes);
cost=Rerr;
