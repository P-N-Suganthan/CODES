clear all
clc
global slen

func='cost_bas_traingular_bw';  
opts.StopFunEvals=10000;
n=20;
 window=[0.9946    0.9785    0.9520    0.9160    0.8711    0.8186    0.7598    0.6960    0.6288    0.5600    0.4912    0.4240    0.3602    0.3014  0.2489    0.2040    0.1680    0.1415    0.1254    0.1200]';
for ii=1:1
    for jjj=9:9
        slen=jjj/4;
Xmin = [0.00000000000000001.*window]; 
Xmax= [(1+.5*ii)*0.0001.*window;]; 
opts.lbounds =Xmin;  
opts.UBounds =Xmax;
for jj=1:1
xmeanw=Xmin+(Xmax-Xmin).*rand(n,1);
sigma=.1*(Xmax-Xmin);
xbest=cmaes_taiwan(func,xmeanw,sigma,opts);
[R,bw(jjj),Rer(jjj)]=feval('cost_bas_traingular_bw_fig',xbest);
end
end
bww(ii,:)=bw;
err(ii,:)=Rer;
end
 
