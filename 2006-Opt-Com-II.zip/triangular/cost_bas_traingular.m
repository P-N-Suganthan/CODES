function [cost]=cost_bas_triangular(dn_pro);
                       
nn=length(dn_pro);
slen=2;
dn_pro=dn_pro(1:nn)';

 Rdes=0.9;
  dw=1.666666666666667e-006;
  waveL_s=1.5498;
  waveL_e=1.5502;
  Rmask=[zeros(1,60) 0:0.015:.9 .9-.015:-0.015:0 zeros(1,60)];

  
w=waveL_s:dw:waveL_e;

neff=1.452;     
G_period=(1.55/(2*neff));
N_sample=length(dn_pro);
GG=G_period*ones(1,N_sample);
ll=round((slen*10^-3)./(GG*10^-6));

[w,R]=chirped_apodized0(dn_pro,N_sample,neff,GG,waveL_s,waveL_e,dw,ll);
Rerr=sum(abs(R'-Rmask).^2);
Rmaxerr=abs(max(R)-Rdes).^2;
cost=Rerr+Rmaxerr;
 
