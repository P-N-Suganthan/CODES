global N_sample neff GG waveL_s waveL_e dw ll slen
func='cost_bas_traingular_chirped';
opts.StopFunEvals=10000;
n=20;
window=[(1:n/2) n/2:-1:1]'/(n/2);
Xmin = [0.00000000000000001.*window;]; 
Xmax= [0.0005.*window;]; 
opts.lbounds =Xmin;  
opts.UBounds =Xmax;

neff=1.452;     
GG_period=[1074.63 1066.7 581.9 1066 1071 1067.49311294766]/1000;
chrip_rates=[0.137 0.05 0.4 0.4 0.073 0.073]*.1;
max_length=[127 127 60 50 60 100];
center_wave=GG_period*neff;
dl=0.003;
dw=2*dl/240;
waveL_s=center_wave(4)-dl;
waveL_e=center_wave(4)+dl;
w=waveL_s:dw:waveL_e;

G_period=(center_wave(4)/(2*neff));

N_sample=(n*5);
sub_len=40/N_sample;
len=N_sample*sub_len;
NN=round((len*10^-3)./(G_period*10^-6));
chrip_change=chrip_rates(4)*len*.5;
G_max=G_period+chrip_change*1e-3;
G_min=G_period-chrip_change*1e-3;
GG=[G_min:2*chrip_change*1e-3/(NN-1):G_max];
cum_GG=cumsum([0 GG]);

for i=1:N_sample
lle=find(cum_GG<sub_len*i*1000);
sl=length(lle);
ll(i)=lle(sl);
end

ll=[ll(1) ll(2:N_sample)-ll(1:N_sample-1)];
ll(i)=NN-sum(ll(1:N_sample-1));
 
GG=GG(1:NN);
 for jj=1:1
xmeanw=Xmin+(Xmax-Xmin)*.5;
sigma=.1*(Xmax-Xmin);
xbest=cmaes_taiwan(func,xmeanw,sigma,opts);
end
 
