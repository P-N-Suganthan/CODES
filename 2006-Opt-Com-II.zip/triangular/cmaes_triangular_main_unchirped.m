func='cost_bas_traingular';
opts.StopFunEvals=10000;
n=20;
window=.1*[1:9 10 10 9 8 7 6 5 4 3 2 1]';

opts.lbounds = [0.0000000000001.*window]; 
opts.UBounds= [0.0003.*window]; 

xmeanw=opts.lbounds+(opts.UBounds-opts.lbounds).*rand(n,1);
sigma=.1*(opts.UBounds-opts.lbounds);
[xbest,ff,aa,bb,tr]=cmaes_function(func,xmeanw,sigma,opts);
ff=feval(func,xbest);
[cost,w,R]=cost_bas_traingular_fig(xbest);
 
