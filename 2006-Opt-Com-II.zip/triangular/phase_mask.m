neff=1.452;     
G_period=(1.55/(2*neff));
G_period=[1074.63 1066.7 581.9 1066 1071]/1000;
center_wave=G_period*neff;