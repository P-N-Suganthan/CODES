function [indexvalue] = DBDCD_MOGA22(dataset, k, num)
% DBDCD_MOGA: Density based distinct cluster detection for MOGA
%	Usage:
%	[indexvalue] = DBDCD_MOGA(dataset, k, num)
%
%	dataset: Sample dataset to be clustered 
%	k: density control paramter
%   num: the number of data needed to be kept
%	indexvalue: the index of the solutions

%	Anderson, Kai QIN (A. K. Qin), Jan. 29, 2005. 

  if nargin < 3, k = 3;, end

% Construct Euclidean distance matrix of dataset
  [row, col] = size(dataset);
  mindata=min(dataset);
  maxdata=max(dataset);
  dataset=(dataset-ones(row,1)*mindata).*10000./(ones(row,1)*(maxdata-mindata).*10000);
  
  tdataset=[dataset,[1:row]'];

  distmat = zeros(row, row);

  if col == 1,
	  distmat = abs(dataset*ones(1,row)-ones(row,1)*dataset');
  else 
	  for i = 1:row
		  distmat(:,i) = sqrt(sum(((dataset-ones(row,1)*dataset(i,:))').^2))';
	  end
  end

% Sort distmat and obtained the sorted 
  distmat = distmat + diag(inf*ones(1,row));

% Clustering procedure
  densedata=[];
  tdistmat=distmat;
  structdata=tdataset;
%   plot(structdata(:,1),structdata(:,2),'r.');
  for i=1:row-num
      [sortdistmat,sortindex]=sort(tdistmat,1);
      [value,index]=min(harmmean(sortdistmat(1:k,:)));
%       [value,index]=min(sortdistmat(k,:));
      densedata=[densedata;structdata(index,:)];
%       figure
%       plot(densedata(:,1),densedata(:,2),'go');
      structdata(index,:)=[];
      tdistmat(index,:)=[];
      tdistmat(:,index)=[];
  end
%   figure;
%   plot(structdata(:,1),structdata(:,2),'r.');
%   figure;
%   plot(densedata(:,1),densedata(:,2),'g.');
      
  indexvalue=[structdata(:,size(structdata,2))];
      