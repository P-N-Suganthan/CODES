function rep=crowding_distance(rep,dim,n_obj,xl,xu,max_rep_size)

% rep=[p1;p2;rep];
fxmax=max(rep(:,dim+1:dim+n_obj));    
fxmin=min(rep(:,dim+1:dim+n_obj));    
repsize=size(rep,1);
crowding_dist_obj=zeros(1,repsize);
crowding_dist_var=zeros(1,repsize);
normalized_obj=zeros(1,repsize);
normalized_var=zeros(1,repsize);
% dd=zeros(nr,1);

for k=1:n_obj
    [f,index]=sort(rep(:,dim+k));
    range=(fxmax(k)-fxmin(k));
    if range==0,
        range=.00001;
    end
    normalized_obj(index(2:repsize-1))=(f(3:repsize)-f(1:repsize-2))./range;    
    crowding_dist_obj(index(1))=100000+range;
    crowding_dist_obj(index(repsize))=100000+range;
    crowding_dist_obj(index(2:repsize-1))=crowding_dist_obj(index(2:repsize-1))+normalized_obj(index(2:repsize-1)); 
end

for j=1:dim
    [xx,xindex]=sort(rep(:,j));
    xrange = xx(repsize)-xx(1);
    if xrange==0,
        xrange=.00001;
    end
    normalized_var(xindex(1))=xx(2)-xx(1) + xx(3)-xx(1);
    normalized_var(xindex(repsize))=xx(repsize)-xx(repsize-1) + xx(repsize)-xx(repsize-2);
    normalized_var(xindex(2:repsize-1))=(xx(3:repsize)-xx(1:repsize-2))./xrange;
    crowding_dist_var=crowding_dist_var + normalized_var;
    bound_ind=find(rep(:,j)==xl(j)|rep(:,j)==xu(j));
    if ~isempty(bound_ind)
        crowding_dist_var(bound_ind)=crowding_dist_var(bound_ind) + 2*normalized_var(bound_ind);
    end
end

crowding_dist_obj=crowding_dist_obj/n_obj;
crowding_dist_var=crowding_dist_var/dim;
avg_cd_obj=mean(crowding_dist_obj);
avg_cd_var=mean(crowding_dist_var);

abv_ind = find(crowding_dist_obj>avg_cd_obj | crowding_dist_var>avg_cd_var);
cd=min(crowding_dist_obj,crowding_dist_var);
if ~isempty(abv_ind)  
    cd(abv_ind) =max(crowding_dist_obj(abv_ind),crowding_dist_var(abv_ind));
end

[sortrep,ind]=sort(cd);
rep=rep(ind(1:repsize-1),:);