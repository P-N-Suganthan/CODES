function Sf=SO_func(x,n_obj,func,i)
f=feval('mfsuite',x,n_obj,func);
Sf=f(i);