function [ins_stat,del_stat,del_list]=PADE_nondom_ins_del(xx1,x1,dim,n_obj,epsilon,err)
% global max_rep_size err

%    xx1=[0.01662273219196  -0.10774510426144   0.81890422682983 -18.26162616527171   3.00031493517716
%    0.17712304523191  -1.12845387725084   0.05870011628900 -15.93484262477205  -2.20701824154584
%    4.09924298842255  -2.14329700221076  -1.43339918568001  -9.93561954036018  -4.29896019992867
%   -1.29781996181839  -0.75660568609079  -0.50068774718326 -15.74539733877492  -4.02845564254840
%    0.74887533305111  -0.12727710272579  -0.42622360999057 -17.73932826677727   2.70542941942449];
% x1=[-1.53287176675673   0.33280104973835   0.41749628735099 -16.29447704089401  -2.16231026654993];
% dim=3;
% n_obj=2;
ins_stat=0;
del_stat=0;
del_list=[1];
[np,nn]=size(xx1);
ff=repmat(x1(1,dim+1:dim+n_obj),np,1);
epsilon=repmat(epsilon,np,1);
err=repmat(err,np,1);
% f1=(xx1(:,dim+1:dim+n_obj)<=ff);
% f2=(xx1(:,dim+1:dim+n_obj)<ff);
% f4=(xx1(:,dim+1:dim+n_obj)>=ff);
% f5=(xx1(:,dim+1:dim+n_obj)>ff);

f1=(xx1(:,dim+1:dim+n_obj)-ff<=0);
f2=(xx1(:,dim+1:dim+n_obj)-ff + epsilon <0);
f3=(xx1(:,dim+1:dim+n_obj)-ff + epsilon <err);
f4=(ff-xx1(:,dim+1:dim+n_obj)<=0);
f5=(ff-xx1(:,dim+1:dim+n_obj) + epsilon <0);
f6=(ff-xx1(:,dim+1:dim+n_obj) + epsilon <err);

f7=(xx1(:,dim+1:dim+n_obj)-ff + epsilon <-err);
f8=(ff-xx1(:,dim+1:dim+n_obj) + epsilon <-err);

% stat2=find((sum(f1,2)==n_obj)&(sum(f7,2)>0));
% stat1=find((sum(f4,2)==n_obj)&(sum(f8,2)>0));

stat2=find(((sum(f1,2)==n_obj)&(sum(f2,2)>0))|((sum(f3,2)==n_obj)&(sum(f6,2)<n_obj)));
stat1=find(((sum(f4,2)==n_obj)&(sum(f5,2)>0))|((sum(f6,2)==n_obj)&(sum(f3,2)<n_obj)));


if(~isempty(stat2)),%some member of rep dom x1
    ins_stat=0;
    if (~isempty(stat1)),%x1 dom some member of rep 
        del_stat=1;del_list=[1 stat1'];
    else
        del_stat=0;del_list=[1];
    end
end
if (isempty(stat2))&(~isempty(stat1)), %no rep dom x1 and x1 dom some member of rep 
    del_stat=1;del_list=[1 stat1'];ins_stat=1;
end

if (isempty(stat2)&isempty(stat1)), % non-dom each other
    ins_stat=1;
    %     if np<=max_rep_size,ins_stat=1;
    %     else
    %         fx1=hyperfit(x1,dim);
    %         for i=1:np
    %             fxx1(i)=hyperfit(xx1(i,:),dim);
    %         end
    %         [yr,Ir]=min(fxx1);
    %         if fx1>yr,
    %             ins_stat=1;
    %             del_stat=1;del_list=[1 Ir];
    %         end
    %     end
end
