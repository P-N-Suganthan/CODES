clear all
warning off

NP=50;
Max_FES=300001;
Max_Gen=6000;
runs=1;

localflag=1;
drawflag=0;
% F0=2.0;
F0=1.0;
CR=0.2;
strategy=1;
flag_no=5;
numst=2;


func=7;

            if func==1
                n=30;n_obj=2;
                xl(1)=0;xl(2:n)=-1;xu=ones(1,n);
                fname='cec09_testfn'; 
            elseif func==2
                n=30;n_obj=2;
                xl(1)=0;xl(2:n)=-1;xu=ones(1,n);
                fname='cec09_testfn'; 
            elseif func==3
                n=30;n_obj=2;
                xl(1:n)=0;
                xu=ones(1,n);
                fname='cec09_testfn'; 
            elseif func==4
                n=30;n_obj=2;
                xl(1)=0;xl(2:n)=-2;xu(1)=1;xu(2:n)=2;
                fname='cec09_testfn'; 
            elseif func==5
                n=30;n_obj=2;
                xl(1)=0;xl(2:n)=-1;xu=ones(1,n);
                fname='cec09_testfn'; 
            elseif func==6
                n=30;n_obj=2;
                xl(1)=0;xl(2:n)=-1;xu=ones(1,n);
                fname='cec09_testfn'; 
            elseif func==7
                n=30;n_obj=2;
                xl(1)=0;xl(2:n)=-1;xu=ones(1,n);
                fname='cec09_testfn'; 
            elseif func==8
                n=30;n_obj=3;
                xl(1:2)=0;xl(3:n)=-2;xu(1:2)=1;xu(3:n)=2;
                fname='cec09_testfn'; 
            elseif func==9
                n=30;n_obj=3;
                xl(1:2)=0;xl(3:n)=-2;xu(1:2)=1;xu(3:n)=2;
                fname='cec09_testfn'; 
            elseif func==10
                n=30;n_obj=3;
                xl(1:2)=0;xl(3:n)=-2;xu(1:2)=1;xu(3:n)=2;  
                fname='cec09_testfn'; 
            elseif func==11
                eval(['load D:\CEC07codes_0503\Data\R2_DTLZ2_bound_30D.dat;'])
                eval(['bound=R2_DTLZ2_bound_30D;'])   
                xl=bound(1,1:n);
                xu=bound(2,1:n);
                fname='mfsuite';
            elseif func==12
                eval(['load D:\CEC07codes_0503\Data\R2_DTLZ3_bound_30D.dat;'])
                eval(['bound=R2_DTLZ3_bound_30D;'])   
                xl=bound(1,1:n);
                xu=bound(2,1:n);
                fname='mfsuite';
            else
                eval(['load D:\CEC07codes_0503\Data\WFG1_bound_30D.dat;'])
                eval(['bound=WFG1_bound_30D;'])   
                xl=bound(1,1:n);
                xu=bound(2,1:n);
                fname='mfsuite';   
            end
                 
            XRmin=xl;
            XRmax=xu;
            Lbound=xl;
            Xmin=xl;
            Ubound=xu;
            Xmax=xu;
          
    if n_obj==2,
        max_rep_size=100;
    elseif n_obj==3;
        max_rep_size=150;
    else
        max_rep_size=800;       
    end
     
    for iternum=1:runs  
%         [rep,pop,outnum,n_flag] = thesis_MOSaDE_LS_M5_original(fname,...
%             Max_FES,n,XRmin,XRmax,Lbound,Ubound,NP,max_rep_size,Max_Gen,F0,CR,strategy,n_obj,numst,func,localflag,drawflag);
        
        [rep,pop,outnum,n_flag,collector] = thesis_MOSaDE_LS_M5_z22(fname,...
            Max_FES,n,XRmin,XRmax,Lbound,Ubound,NP,max_rep_size,Max_Gen,F0,CR,strategy,n_obj,numst,func,localflag,drawflag);
        eval(['save IGD_' num2str(func) '_' num2str(iternum) ' collector']);
    end