igd=[];

eval(['load IGD_3_1;'])
eval(['IGD_1= collector(:,1);'])
eval(['load IGD_3_2;'])
eval(['IGD_2= collector(:,1);'])
eval(['load IGD_3_3;'])
eval(['IGD_3= collector(:,1);'])
eval(['load IGD_3_4;'])
eval(['IGD_4= collector(:,1);'])
eval(['load IGD_3_5;'])
eval(['IGD_5= collector(:,1);'])
eval(['load IGD_3_6;'])
eval(['IGD_6= collector(:,1);'])
eval(['load IGD_3_7;'])
eval(['IGD_7= collector(:,1);'])
eval(['load IGD_3_8;'])
eval(['IGD_8= collector(:,1);'])
eval(['load IGD_3_9;'])
eval(['IGD_9= collector(:,1);'])
eval(['load IGD_3_10;'])
eval(['IGD_10= collector(:,1);'])
eval(['load IGD_3_11;'])
eval(['IGD_11= collector(:,1);'])
eval(['load IGD_3_12;'])
eval(['IGD_12= collector(:,1);'])
eval(['load IGD_3_13;'])
eval(['IGD_13= collector(:,1);'])
eval(['load IGD_3_14;'])
eval(['IGD_14= collector(:,1);'])
eval(['load IGD_3_15;'])
eval(['IGD_15= collector(:,1);'])
eval(['load IGD_3_16;'])
eval(['IGD_16= collector(:,1);'])
eval(['load IGD_3_17;'])
eval(['IGD_17= collector(:,1);'])
eval(['load IGD_3_18;'])
eval(['IGD_18= collector(:,1);'])
eval(['load IGD_3_19;'])
eval(['IGD_19= collector(:,1);'])
eval(['load IGD_3_20;'])
eval(['IGD_20= collector(:,1);'])
eval(['load IGD_3_21;'])
eval(['IGD_21= collector(:,1);'])
eval(['load IGD_3_22;'])
eval(['IGD_22= collector(:,1);'])
eval(['load IGD_3_23;'])
eval(['IGD_23= collector(:,1);'])
eval(['load IGD_3_24;'])
eval(['IGD_24= collector(:,1);'])
eval(['load IGD_3_25;'])
eval(['IGD_25= collector(:,1);'])
eval(['load IGD_3_26;'])
eval(['IGD_26= collector(:,1);'])
eval(['load IGD_3_27;'])
eval(['IGD_27= collector(:,1);'])
eval(['load IGD_3_28;'])
eval(['IGD_28= collector(:,1);'])
eval(['load IGD_3_29;'])
eval(['IGD_29= collector(:,1);'])
eval(['load IGD_3_30;'])
eval(['IGD_30= collector(:,1);'])

% igd=[IGD_1 IGD_2 IGD_3];
igd=[IGD_1 IGD_2 IGD_3 IGD_4 IGD_5 IGD_6 IGD_7 IGD_8 IGD_9 IGD_10 IGD_11 IGD_12 IGD_13 IGD_14 IGD_15 IGD_16 IGD_17 IGD_18 IGD_19 IGD_20 IGD_21 IGD_22 IGD_23 IGD_24 IGD_25 IGD_26 IGD_27 IGD_28 IGD_29 IGD_30];
[x,y]=size(igd);
m=mean(igd');
s=std(igd');
X=(300000/length(m))*(1:length(m));
SUBPLOT(1,2,1),plot(X,m)
ylabel('Mean(IGD)');
xlabel('FEs');
% hold on
SUBPLOT(1,2,2),plot(X,s)
ylabel('STD(IGD)');
xlabel('FEs');
[sorted_igd,index]=sort(igd(x,:));
index
sorted_igd(1)
sorted_igd(15)
sorted_igd(30)
m(x)
s(x)
