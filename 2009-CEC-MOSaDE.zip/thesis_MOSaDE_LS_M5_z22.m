function [rep,pop,outnum,n_flag,collector] = thesis_MOSaDE_LS(fname,...
    Max_FES,D,XRmin,XRmax,Lbound,Ubound,NP,max_rep_size,Max_Gen,F0,CR,strategy,n_obj,numst,func,localflag,drawflag);
collector=[];
learngen=50;
for i=1:n_obj+1
  eval(['ccmhist' num2str(i) '=[];']);
  eval(['pfithist' num2str(i) '=[];']);
  eval(['aaaa' num2str(i) '=cell(1,numst);']); 
  eval(['lpcount' num2str(i) '=[];']); 
  eval(['npcount' num2str(i) '=[];']);
  eval(['ns' num2str(i) '=[];']);
  eval(['nf' num2str(i) '=[];']);
  eval(['n_flag' num2str(i) '=zeros(NP,1);']);
  eval(['ccm' num2str(i) '=CR*ones(1,numst);']);
  eval(['pfit' num2str(i) '=ones(1,numst);']);
end

rand('state',sum(100*clock));


if length(Lbound)==1
    Lbound=repmat(Lbound,1,D);
    Ubound=repmat(Ubound,1,D);
end
if length(XRmin)==1
    XRmin=repmat(XRmin,1,D);
    XRmax=repmat(XRmax,1,D);
end
%-----Initialize population and some arrays-------------------------------
pop = zeros(NP,D); %initialize pop to gain speed
popold    = zeros(size(pop));     % toggle population
nfeval    = 0;                    % number of function evaluations

XRRmin=repmat(XRmin,NP,1);
XRRmax=repmat(XRmax,NP,1);
pop=XRRmin+(XRRmax-XRRmin).*rand(NP,D);

for i=1:NP
    nfeval=nfeval+1;
    pop(i,D+1:D+n_obj)=feval(fname,pop(i,1:D),func);
end


rep=pop;
rep(:,D+n_obj+1)=zeros(NP,1);
for i=1:n_obj+1
ccm=eval(['ccm' num2str(i)]);
pfit=eval(['pfit' num2str(i)]);
eval(['ccmhist' num2str(i) '=[1,ccm];']);
eval(['pfithist' num2str(i) '=[1,pfit/sum(pfit)];']);
end

fmin=min(rep(:,D+1:D+n_obj),[],1);
fmax=max(rep(:,D+1:D+n_obj),[],1);
err=0.00001.*(fmax-fmin);
epsilon=zeros(1,n_obj);


%------DE-Minimization---------------------------------------------
pm1 = zeros(NP,D);              % initialize population matrix 1
pm2 = zeros(NP,D);              % initialize population matrix 2
pm3 = zeros(NP,D);              % initialize population matrix 3
pm4 = zeros(NP,D);              % initialize population matrix 4
pm5 = zeros(NP,D);              % initialize population matrix 5
bm  = zeros(NP,D);              % initialize DE_gbestber  matrix
ui  = zeros(NP,D);              % intermediate population of perturbed vectors
mui = zeros(NP,D);              % mask for intermediate population
mpo = zeros(NP,D);              % mask for old population
rot = (0:1:NP-1);               % rotating index array (size NP)
rotd= (0:1:D-1);                % rotating index array (size D)
rt  = zeros(NP);                % another rotating index array
rtd = zeros(D);                 % rotating index array for exponential crossover
a1  = zeros(NP);                % index array
a2  = zeros(NP);                % index array
a3  = zeros(NP);                % index array
a4  = zeros(NP);                % index array
a5  = zeros(NP);                % index array
ind = zeros(4);

iter = 0;
while iter < Max_Gen
    
%     F0=F0-1.9/Max_Gen;    %%%%%%%F0==2.0
    F0=F0-0.95/Max_Gen;    %%%%%%%F0==1.0
    
    popold = pop(:,1:D);                   % save the old population    
    ind = randperm(14);              % index pointer array    
    a1  = randperm(NP);             % shuffle locations of vectors
    rt = rem(rot+ind(1),NP);        % rotate indices by ind(1) positions
    a2  = a1(rt+1);                 % rotate vector locations
    rt = rem(rot+ind(2),NP);
    a3  = a2(rt+1);
    rt = rem(rot+ind(3),NP);
    a4  = a3(rt+1);
    rt = rem(rot+ind(4),NP);
    a5  = a4(rt+1);
    rt = rem(rot+ind(5),NP);
    a6  = a5(rt+1);
    rt = rem(rot+ind(6),NP);
    a7  = a6(rt+1);
    rt = rem(rot+ind(7),NP);
    a8  = a7(rt+1);
    rt = rem(rot+ind(8),NP);
    a9  = a8(rt+1);
    rt = rem(rot+ind(9),NP);
    a10  = a9(rt+1);
    rt = rem(rot+ind(10),NP);
    a11  = a10(rt+1);
    rt = rem(rot+ind(11),NP);
    a12  = a11(rt+1);
    rt = rem(rot+ind(12),NP);
    a13  = a12(rt+1);
    rt = rem(rot+ind(13),NP);
    a14  = a13(rt+1);
    rt = rem(rot+ind(14),NP);
    a15  = a14(rt+1);
    pm1 = popold(a1,:);             % shuffled population 1
    pm2 = popold(a2,:);             % shuffled population 2
    pm3 = popold(a3,:);             % shuffled population 3
    pm4 = popold(a4,:);             % shuffled population 4
    pm5 = popold(a5,:);             % shuffled population 5
    pm6 = popold(a6,:);
    pm6 = popold(a7,:);             % shuffled population 5
    pm7 = popold(a8,:);
    pm8 = popold(a9,:);
    pm9 = popold(a10,:);             % shuffled population 1
    pm10 = popold(a11,:);             % shuffled population 2
    pm11 = popold(a12,:);             % shuffled population 3
    pm12 = popold(a13,:);             % shuffled population 4
    pm13 = popold(a14,:);             % shuffled population 5
    pm14 = popold(a15,:);
    rep_size=size(rep,1);   
    for i=1:NP
        h=ceil(rand*rep_size);
        bm(i,:)=rep(h,1:D);     
    end  
   
for i=1:n_obj 
  kak1(1:NP,i)=pop(1:NP,D+i)/max(pop(1:NP,D+i),[],1);
end
kak2=kak1>0.5;
if(rand<=0.5)
[kak3,kkk]=max(sum(kak2,1));
else
kkk=n_obj+1;
end

  aaaa=eval(['aaaa' num2str(kkk)]); 
  ccm=eval(['ccm' num2str(kkk)]);
  pfit=eval(['pfit' num2str(kkk)]); 

    if (iter>=learngen)        
        for i=1:numst
            if   ~isempty(aaaa{i}) 
                ccm(i)=median(aaaa{i}(:,1));   
                d_index=find(aaaa{i}(:,2)==aaaa{i}(1,2));
                aaaa{i}(d_index,:)=[];
            else
                ccm(i)=rand;
            end
        end
    end
    for i=1:numst
        cc_tmp=[];
        for k=1:NP
            tt=normrnd(ccm(i),0.1);
            while tt>1 | tt<0
                tt=normrnd(ccm(i),0.1);
            end
            cc_tmp=[cc_tmp;tt];;
        end
        cc(:,i)=cc_tmp;
    end
    
    rr=rand;
    spacing=1/NP;
    randnums=sort(mod(rr:spacing:1+rr-0.5*spacing,1));  
    
    normfit=pfit/sum(pfit);
    partsum=0;
    count(1)=0;
    stpool=[];
    
    for i=1:length(pfit)
        partsum=partsum+normfit(i);
        count(i+1)=length(find(randnums<partsum));
        select(i,1)=count(i+1)-count(i);
        stpool=[stpool;ones(select(i,1),1)*i];
    end
    stpool = stpool(randperm(NP));
    
    for i=1:numst
        atemp=zeros(1,NP);
        aaa{i}=atemp;
        index{i}=[];
        if ~isempty(find(stpool == i))
            index{i} = find(stpool == i);
            atemp(index{i})=1;
            aaa{i}=atemp;
        end
    end
    aa=zeros(NP,D);
    for i=1:numst
        aa(index{i},:) = rand(length(index{i}),D) < repmat(cc(index{i},i),1,D);         
    end
    
    mui=aa;
    if (strategy > 1)
        st = strategy-1;		  % binomial crossover
    else
        st = strategy;		  % exponential crossover
        mui=sort(mui');	          % transpose, collect 1's in each column
        for i=1:NP
            n=floor(rand*D);
            if n > 0
                rtd = rem(rotd+n,D);
                mui(:,i) = mui(rtd+1,i); %rotate column i by n
            end
        end
        mui = mui';			  % transpose back
    end
    dd=ceil(D*rand(NP,1));
    for kk=1:NP
        mui(kk,dd(kk))=1; 
    end

   
   mpo = mui < 0.5; 
    for i=1:numst     
        F=[];
        m=length(index{i});       
        F=normrnd(F0,0.1,m,1);
        F=repmat(F,1,D);
         if i==1
            ui(index{i},1:D) = popold(index{i},:) + F.*(pm1(index{i},:) - pm2(index{i},:));        % differential variation
            ui(index{i},1:D) = popold(index{i},:).*mpo(index{i},:) + ui(index{i},1:D).*mui(index{i},:);     % crossover
        end
       
        if i==2
            ui(index{i},1:D) = popold(index{i},:) + F.*(pm4(index{i},:) - pm5(index{i},:)+pm6(index{i},:) - pm7(index{i},:));       % differential variation
            ui(index{i},1:D) = popold(index{i},:).*mpo(index{i},:) + ui(index{i},1:D).*mui(index{i},1:D);      % crossover
        end

%         if i==3
%             F=[];
%             m=length(index{i});       
%             tol=0.5;
%             F=0.5.*exp(tol.*(normrnd(0,1,m,1)-tol/2));
%             F=repmat(F,1,D);
%             ui(index{i},1:D) = popold(index{i},:) + 0.6.*(pm8(index{i},:)-popold(index{i},:)) + F.*(pm9(index{i},:) - pm10(index{i},:));       % differential variation
%            
%         end        
%         if i==4
%             ui(index{i},1:D) = popold(index{i},:) + F.*(bm(index{i},:)-popold(index{i},:)) + F.*(pm11(index{i},:) - pm12(index{i},:) + pm13(index{i},:) - pm14(index{i},:));       % differential variation
%             ui(index{i},1:D) = popold(index{i},:).*mpo(index{i},:) + ui(index{i},1:D).*mui(index{i},1:D);     % crossover
%         end
       
    end
    
    
    outcount=0; 
    for i=1:NP
        
        outLbind=find(ui(i,1:D) < Lbound);
        if size(outLbind,2)~=0
           
            ui(i,outLbind)=XRmin(outLbind)+(XRmax(outLbind)-XRmin(outLbind)).*rand(1,size(outLbind,2));
           
            
        end
        outUbind=find(ui(i,1:D) > Ubound);
        if size(outUbind,2)~=0
           
            ui(i,outUbind)=XRmin(outUbind)+(XRmax(outUbind)-XRmin(outUbind)).*rand(1,size(outUbind,2));
           
        end
        if size(outLbind,2)~=0 | size(outUbind,2)~=0
            outcount=outcount+1;         
        end
    end
    outnum(iter+1)=outcount;
    
    %----------fitness evaluation
    for i=1:NP

        ui(i,D+1:D+n_obj)=feval(fname,ui(i,1:D),func);
        nfeval  = nfeval + 1;
    end
    
    for i=1:NP
        dist=sum((pop(:,1:D)-repmat(ui(i,1:D),NP,1)).^2,2);
        [junk,near_idx]=min(dist);
        f1=pop(near_idx,D+1:D+n_obj)-ui(i,D+1:D+n_obj)<=0;
        f2=pop(near_idx,D+1:D+n_obj)-ui(i,D+1:D+n_obj)<0;
        f3=pop(near_idx,D+1:D+n_obj)-ui(i,D+1:D+n_obj)<err;        
        
        f4=ui(i,D+1:D+n_obj)-pop(near_idx,D+1:D+n_obj)<=0;
        f5=ui(i,D+1:D+n_obj)-pop(near_idx,D+1:D+n_obj) <0;
        f6=ui(i,D+1:D+n_obj)-pop(near_idx,D+1:D+n_obj) <err;
        for ik=1:n_obj
               ff=pop(i,D+ik)-ui(i,D+ik)<=0; 
               npcount=eval(['npcount' num2str(ik) ]);
               lpcount=eval(['lpcount' num2str(ik) ]); 
               aaaa=eval(['aaaa' num2str(ik)]); 
              if ff==1,                    
                  tlpcount=zeros(1,numst);
              for j=1:numst
                temp=aaa{j};
                tlpcount(j)=temp(i);
                if tlpcount(j)==1
                    aaaa{j}=[aaaa{j};cc(i,j) iter];  
                end
              end
             lpcount=[lpcount;tlpcount];  
              else
                
                tnpcount=zeros(1,numst);
                for j=1:numst
                    temp=aaa{j};
                    tnpcount(j)=temp(i);
                end
                npcount=[npcount;tnpcount];
              end 
             eval(['npcount' num2str(ik) '=npcount;']);
             eval(['lpcount' num2str(ik) '=lpcount;']);
             eval(['aaaa' num2str(ik) '=aaaa;']);
            end
        
                
        if ((sum(f1)==n_obj)&(sum(f2)>0))|((sum(f3)==n_obj)&(sum(f6)<n_obj)), %parent dominates child
            n_flag(near_idx)=1;
         
           npcount=eval(['npcount' num2str(n_obj+1) ]); 
           aaaa =eval(['aaaa' num2str(n_obj+1)]);
            tnpcount=zeros(1,numst);
                for j=1:numst
                    temp=aaa{j};
                    tnpcount(j)=temp(i);
                end
                npcount=[npcount;tnpcount];
           eval(['npcount' num2str(n_obj+1) '=npcount;']);
           eval(['aaaa' num2str(n_obj+1) '=aaaa;']);
             
               
            
           
        elseif ((sum(f4)==n_obj)&(sum(f5)>0))|((sum(f6)==n_obj)&(sum(f3)<n_obj)),% child dominates parent
            pop(near_idx,1:D+n_obj)=ui(i,1:D+n_obj);     
            n_flag(near_idx)=0;
           
              lpcount=eval(['lpcount' num2str(n_obj+1) ]); 
                    
               tlpcount=zeros(1,numst);
              for j=1:numst
                temp=aaa{j};
                tlpcount(j)=temp(i);
                if tlpcount(j)==1
                    aaaa{j}=[aaaa{j};cc(i,j) iter];  
                end
              end
             lpcount=[lpcount;tlpcount];  
             eval(['lpcount' num2str(n_obj+1) '=lpcount;']);
             
           [ins_stat,del_stat,del_list]=PADE_nondom_ins_del(rep(:,1:D+n_obj),ui(i,:),D,n_obj,epsilon,err);
            if del_stat==1,
                [rep,rep_size]=matdelete(rep,del_list(2:length(del_list)));
            end
            if ins_stat==1, 
                rep=[rep;ui(i,:) 0];
            end
        else                           
            f=crowding_dis_rep(pop(near_idx,1:D+n_obj),ui(i,1:D+n_obj),rep(:,1:D+n_obj),D,n_obj,Lbound,Ubound,err);        
         
               npcount=eval(['npcount' num2str(n_obj+1) ]);
               lpcount=eval(['lpcount' num2str(n_obj+1) ]); 
               aaaa=eval(['aaaa' num2str(n_obj+1)]); 
              if f==1,                    
                  tlpcount=zeros(1,numst);
              for j=1:numst
                temp=aaa{j};
                tlpcount(j)=temp(i);
                if tlpcount(j)==1
                    aaaa{j}=[aaaa{j};cc(i,j) iter];  
                end
              end
             lpcount=[lpcount;tlpcount];  
              else
                
                tnpcount=zeros(1,numst);
                for j=1:numst
                    temp=aaa{j};
                    tnpcount(j)=temp(i);
                end
                npcount=[npcount;tnpcount];
              end 
             eval(['npcount' num2str(n_obj+1) '=npcount;']);
             eval(['lpcount' num2str(n_obj+1) '=lpcount;']);
             eval(['aaaa' num2str(n_obj+1) '=aaaa;']);
            
            [ins_stat,del_stat,del_list]=PADE_nondom_ins_del(rep(:,1:D+n_obj),ui(i,:),D,n_obj,epsilon,err);
            if del_stat==1,
                [rep,rep_size]=matdelete(rep,del_list(2:length(del_list)));
            end
            if ins_stat==1, 
                rep=[rep;ui(i,:) 0];
            end
        end
        
       

        if nfeval+1 > Max_FES
            for ik=1:n_obj+1
            pfithist=eval(['pfithist' num2str(ik)]);
            pfit=eval(['pfit' num2str(ik)]);
            ccmhist=eval(['ccmhist' num2str(ik)]);
            ccm=eval(['ccm' num2str(ik)]);
            pfithist = [pfithist;[iter+2,pfit/sum(pfit)]];
            ccmhist = [ccmhist;[iter+2,ccm]];
            eval(['pfithist' num2str(ik) '=pfithist;']);
            eval(['ccmthist' num2str(ik) '=ccmhist;']);
            end
            return;
        end
        
    end %---end for imember=1:NP
    
    fmin=min(rep(:,D+1:D+n_obj),[],1);
    fmax=max(rep(:,D+1:D+n_obj),[],1);
    
    err=0.0001.*(fmax-fmin);    
    
    if size(rep,1)>1
        f_range=fmax-fmin;
    else
        f_range=rand(1,n_obj);
    end
    ls_r=f_range./sum(f_range);
    

   
    for ik=1:n_obj+1
        
    pfithist=eval(['pfithist' num2str(ik)]);
    ccmhist=eval(['ccmhist' num2str(ik)]);
    pfit=eval(['pfit' num2str(ik)]);
    ccm=eval(['ccm' num2str(ik)]);
    ns=eval(['ns' num2str(ik)]);
    nf=eval(['nf' num2str(ik)]);
    lpcount=eval(['lpcount' num2str(ik)]);
    npcount=eval(['npcount' num2str(ik)]);
    pfithist = [pfithist;[iter+2,pfit/sum(pfit)]];
    ccmhist = [ccmhist;[iter+2,ccm]];
    ns=[ns;sum(lpcount,1)];
    nf=[nf;sum(npcount,1)];  
    eval(['pfithist' num2str(ik) '=pfithist;']);
    eval(['ccmhist' num2str(ik) '=ccmhist;']);
    eval(['ns' num2str(ik) '=ns;']);
    eval(['nf' num2str(ik) '=nf;']);
    end
    
    if iter >= learngen;  
       for ik=1:n_obj+1
         ns=eval(['ns' num2str(ik)]);
         nf=eval(['nf' num2str(ik)]); 
         pfit=eval(['pfit' num2str(ik)]);
        for i=1:numst            
            if (sum(ns(:,i))+sum(nf(:,i))) == 0
                pfit(i) = 0.01;
            else
                pfit(i) = sum(ns(:,i))/(sum(ns(:,i))+ sum(nf(:,i))) + 0.01;
            end
        end
        if ~isempty(ns), ns(1,:)=[];   end
        if ~isempty(nf), nf(1,:)=[];   end
       eval(['ns' num2str(ik) '=ns;']);
       eval(['nf' num2str(ik) '=nf;']); 
       eval(['pfit' num2str(ik) '=pfit;']);
     end
    end   
    iter = iter + 1;
     if mod(iter,60)==0
        if n_obj==2
            PF=[rep(:,D+1),rep(:,D+2)]';
        elseif n_obj==3
            PF=[rep(:,D+1),rep(:,D+2),rep(:,D+3)]';
        else PF=[rep(:,D+1),rep(:,D+2),rep(:,D+3),rep(:,D+4),rep(:,D+5)]';
        end
        if func==1
            PFStar  = load('pf_data/UF1.dat');
        elseif func==2
            PFStar  = load('pf_data/UF2.dat');
        elseif func==3
            PFStar  = load('pf_data/UF3.dat');
        elseif func==4
            PFStar  = load('pf_data/UF4.dat');
        elseif func==5
            PFStar  = load('pf_data/UF5.dat');
        elseif func==6
            PFStar  = load('pf_data/UF6.dat');
        elseif func==7
            PFStar  = load('pf_data/UF7.dat');
        elseif func==8
            PFStar  = load('pf_data/UF8.dat');
        elseif func==9
            PFStar  = load('pf_data/UF9.dat');
        elseif func==10
            PFStar  = load('pf_data/UF10.dat');
        elseif func==11
            PFStar  = load('pf_data/R2_DTLZ2_M5.dat');
        elseif func==12
            PFStar  = load('pf_data/R2_DTLZ3_M5.dat');
        else 
            PFStar  = load('pf_data/WFG1_M5.dat');
        end
        PFStar  = PFStar';
        e=IGD(PFStar, PF);
        collector=[collector;e,nfeval];
    end
  
   if(rem(iter,100)==0)
       nfeval
   end
end 
