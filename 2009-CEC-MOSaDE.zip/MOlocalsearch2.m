function [tempx,nf,exitflag] = MOlocalsearch2(fname,x,n_obj,func,i,xl,xu)
options = optimset('Display','off','LargeScale','off','MaxFunEvals',100,'DiffMinChange',1e-6,'DiffMaxChange',1e-3);%,'LevenbergMarquardt','on', 
[x,val,exitflag,output] = fminsearch('SO_func',x,options,n_obj,func,i);
  outLbind=find(x < xl);
        if size(outLbind,2)~=0
                x(outLbind)=xl(outLbind)+(xu(outLbind)-xl(outLbind)).*rand(1,size(outLbind,2));
        end
        outUbind=find(x > xu);
        if size(outUbind,2)~=0                  
            x(outUbind)=xl(outUbind)+(xu(outUbind)-xl(outUbind)).*rand(1,size(outUbind,2));
        end
nf = output.funcCount;
val=feval(fname,x,n_obj,func);
tempx=[x val];