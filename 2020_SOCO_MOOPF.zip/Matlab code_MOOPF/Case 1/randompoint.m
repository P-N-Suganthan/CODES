function ind = randompoint(prob)
%RANDOMNEW to generate a new point from 
%   Detailed explanation goes here
    %global rnduni;
    
    lowend = prob.domain(:,1);
    highend = prob.domain(:,2);
    span = highend-lowend;
        
    ind =get_structure('individual');
    ind.parameter = zeros(prob.pd, 1);
    
    for i=1:prob.pd
        %[r, rnduni] = crandom(rnduni);
        r = rand;
        %r = randsrc(1,1,[0 (1/highend(i)):(1/highend(i)):1 ; 0.75 (0.25/highend(i))*ones(1,highend(i))]);
        ind.parameter(i)=lowend(i)+span(i)*r;
    end
end
