function mop = testmop(dimension)
%Get test multi-objective problems from a given name. 
%   The method get testing or benchmark problems for Multi-Objective
%   Optimization. The test problem will be encapsulated in a structure,
%   which can be obtained by function get_structure('testmop'). 
%   User get the corresponding test problem, which is an instance of class
%   mop, by passing the problem name and optional dimension parameters.

    mop=get_structure('testmop');
    mop=problems(mop,dimension);
    mop.od=4;
end

function p=problems(p,dim)
 p.pd=dim;
 
 p.domain=xboundary(dim);
 p.func=@pflow;
 
end

function range = xboundary(dim)
    range = zeros(dim,2);
    range(:,1)  = [20 15 10 10 12 0.95 0.95 0.95 0.95 0.95 0.95 0 0 0 0 0 0 0 0 0 0.9 0.9 0.9 0.9];
    range(:,2)  = [80 50 35 30 40 1.1 1.1 1.1 1.1 1.1 1.1 5 5 5 5 5 5 5 5 5 1.1 1.1 1.1 1.1];
end



