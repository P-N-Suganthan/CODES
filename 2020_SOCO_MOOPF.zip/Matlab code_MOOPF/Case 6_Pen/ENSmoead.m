function [pareto,record_prob,violation]= ENSmoead(mop,varargin)
%ENSMOEAD run ENSmoea/d algorithms for the given mop.
% MOP could be obtained by function 'testmop.m'.
% the controlling parameter can be passed in by varargin, the folliwing
% parameters are defined in here. More other parameters can be passed by
% modify loadparams.m problem by problem.
%   seed: the random seed.
%   popsize: The subproblem's size.
%   niche: the neighboursize, must less then the popsize.
%   evaluation: the total evaluation of the moead algorithms before finish.
%   dynamic: whether to use dynamic resource allocation.
%   selportion: the selection portion for the dynamic resource allocation

    %global variable definition.
    global subproblems params itrCounter evalCounter subp_success FE_num temp viol_mat;
    %global idealpoint objDim parDim evalCounter;
    
    %load the parameters.
    params=loadparams(varargin);
    record_prob=[];

    evalCounter = 0;
    itrCounter = 5;
    
    %and Initialize the algorithm.
    init(mop);
    FE_num = 0;
    temp=struct('subp_size',[],'neighbour',[]);
    while ~terminate()
        evolve(mop); % one generation of evaluation.
        itrCounter=itrCounter+1;
        if (rem(itrCounter,50)==0 && itrCounter>=150)
            niche_success=0;
            for ii=1:params.popsize
                niche_success=niche_success+subp_success(ii);
            end
                if FE_num==0,
                    niche_prob=0;
                else 
                    niche_prob=niche_success/FE_num;
                end
            min_prob=0.05;
            niche_prob=max(niche_prob,min_prob);       
            reassign_prob=niche_prob;
            %Reset up the neighbourhood.
            leng=params.popsize;
            distanceMatrix=zeros(leng, leng);
            record_prob=[record_prob; reassign_prob];
            for i=1:leng
                for j=i+1:leng
                    A=subproblems(i).weight;B=subproblems(j).weight;
                    distanceMatrix(i,j)=(A-B)'*(A-B);
                    distanceMatrix(j,i)=distanceMatrix(i,j);
                end
            end
        end
               
        if (rem(itrCounter,50)==0) % updating of the utility.
            util_update(); 
            status();
        end        
    end
  
    pareto = [subproblems.curpoint];
    violation = viol_mat;

end

% The evoluation setp in MOEA/D
function evolve(mop)
  global subproblems idealpoint params subp_size FE_num oldselindex nadir viol_mat

  % select the subproblem according to its utility.
  % if params.dynamic is not true, then no selection is used.
  if (params.dynamic)
    selindex = util_select();
  else
    selindex = 1:length(subproblems);  
  end
  
  %disp(selindex());

  global selectionSize;
  selectionSize = length(selindex);
  %disp(selectionSize)
  
  for i=1:length(selindex)
    index = selindex(i);
    r = rand;
    updateneighbour = r < params.updateprob;
    %new point generation using genetic operations, and evaluate it.
    ind = genetic_op(index, updateneighbour, mop.domain);
    
    nichesizeind=find(params.niche==subp_size(index));
    FE_num(nichesizeind)=FE_num(nichesizeind)+1;
    
    [obj,cons_viol,ind] = evaluate(mop,ind);
    %update the idealpoint.

    idealpoint = min(idealpoint, obj);
    nadir = max(nadir, obj); %PPB
        
    %updation.
    update(index, ind, updateneighbour, cons_viol);

    %clear!
    %clear ind obj updateneighbour;
    %end
  end
  oldselindex=selindex;
end

% update the index's neighbour with the given individual.
% index is the subproblem's index in the main population.
% ind is the individual structure.
% updatenieghbour is a bool determine whether the neighbourhood of index, or the whole population should be updated.
% this procedure is also governed by a parameter from params: params.updatenb, which determine how many subproblem
% should be updated at most by this new individual.
function update(index, ind, updateneighbour, cons_viol)
  global subproblems idealpoint params subp_success viol_mat;
  
  % collect the updation index
  if (updateneighbour)
    updateindex = subproblems(index).neighbour;
  else
    updateindex = 1:length(subproblems);
  end
  
  updateindex = random_shuffle(updateindex);
  time=0;
  
  %disp(updateindex);
  for i=1:length(updateindex)
      idx = updateindex(i);
      updateweight = subproblems(idx).weight;
      newobj=subobjective(updateweight, ind.objective,  idealpoint, 'te');
      old=subobjective(updateweight, subproblems(idx).curpoint.objective,  idealpoint, 'te');
      if newobj<old
          subp_success(idx)=subp_success(idx)+1;
          subproblems(idx).curpoint=ind;
          viol_mat(idx) = cons_viol;
         %disp(sprintf('UP -- ID: %d, Type: %d, T: %d, UI: %d -- %f', index-1, updateneighbour, time, idx-1, ind.parameter));
         time = time+1; 
      end
      if (time>=params.updatenb)
          return;
      end
  end

end

function y =terminate()
    global params evalCounter;
    y = evalCounter>params.evaluation;
end

function status()
    global evalCounter itrCounter selectionSize subproblems;
    %average utility
    averageutil = mean([subproblems.utility]);
    %if (~rem(itrCounter, 30))
    fprintf('\n Itr:%d\tSel:%d\tEval:%d\tUtilM:%1.4f', ...
        itrCounter, selectionSize, evalCounter, averageutil);
    %end
end