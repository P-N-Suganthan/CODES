function mop = testmop(dimension)
%Get test multi-objective problems from a given name. 
%   The method get testing or benchmark problems for Multi-Objective
%   Optimization. The test problem will be encapsulated in a structure,
%   which can be obtained by function get_structure('testmop'). 
%   User get the corresponding test problem, which is an instance of class
%   mop, by passing the problem name and optional dimension parameters.

    mop=get_structure('testmop');
    mop=problems(mop,dimension);
    mop.od=4;
end

function p=problems(p,dim)
 p.pd=dim;
 
 p.domain=xboundary(dim);
 p.func=@pflow;
 
end

function range = xboundary(dim)
    range = zeros(dim,2);
    range(:,1)  = [30 40 30 100 30 100 0.95*ones(1,7) 0 0 0 0.9*ones(1,17)];
    range(:,2)  = [100 140 100 550 100 410 1.1*ones(1,7) 20 20 20 1.1*ones(1,17)];
end



