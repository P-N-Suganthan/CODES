MATLAB Code for:
Multi-objective optimal power flow solutions using a constraint handling technique of evolutionary algorithms
May 2019-Soft Computing; DOI: 10.1007/s00500-019-04077-1.

Case wise MATLAB code is shared. You need to download MATPOWER to run the program. 
Run the Main.m file. Any change in objective can be implemented via pflow.m file.

For any clarification please contact the following:

parthapr001@e.ntu.edu.sg
