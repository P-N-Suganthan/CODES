
% however, any quesion please contact Shizheng Zhao (zh0047ng@ntu.edu.sg) or Wudong Liu (wudong.liu@gmail.com)

totalrun = 10;
%The result IDG Metrics recorded.
DM = zeros(1,totalrun);

global params subproblems subproblem_old evalCounter viol_mat %bestvolt0 minvolt0 bestvolt1 minvolt1 ploss0 qloss0;

seed = 10;
dim = 24; % dimension of problem

    for run = 1:totalrun
        fprintf('Run %d',run);
        tic
        mop = testmop(dim);
        [pareto,record_prob,violation] = ENSmoead(mop,'seed',run+seed);

        objpareto = [pareto.objective]';
        par_pareto = [pareto.parameter]';
        objparviol = [objpareto,violation];
        %IGD(j) = IGD_test(objpareto);
        
        dlmwrite(strcat('PF_',char(num2str(run)),'.txt'),objparviol,'precision','%0.5f','newline','pc');
        dlmwrite(strcat('Parameter_',char(num2str(run)),'.txt'),par_pareto,'newline','pc');
        %need to filter the result.
        eval(['save paretofront_' num2str(run) ' objpareto']);
        eval(['save parameter_' num2str(run) ' par_pareto']);
        %eval(['save record_prob_' num2str(1) ' record_prob']);
        %scatter3(objpareto(:,1),objpareto(:,2),objpareto(:,3),'.');
        
        % Best compromise solution
        [no_par,no_pf] = size(objpareto);
        miu_pf = zeros(no_par,no_pf);
        for ii = 1:no_pf
        max_pareto = max(objpareto(:,ii));
        min_pareto = min(objpareto(:,ii));
        miu_pf(:,ii) = (repmat(max_pareto,no_par,1)-objpareto(:,ii))./(max_pareto-min_pareto);
        end
        miu_sum = sum(miu_pf,2);
        miu_wt = miu_sum./sum(miu_sum);
        [miu_max,idx] = max(miu_wt);
        comp_obj(run,1:(no_pf+1+no_pf)) = [objpareto(idx,:),miu_max,min(objpareto)];
    end
dlmwrite('comp.txt',comp_obj,'precision','%0.5f','newline','pc');
toc    
%print results (subproblems.curpoint has pareto values)
% pareto_values = [pareto(1:end).objective]';
% cons_value = zeros(size(pareto_values,1),1);
% 
% for ii = 1:size(pareto_values,1)
%     opt_para = pareto(ii).parameter;
%     [~,cons_value(ii,1)] = pflow(opt_para);
% end
% idx = find(cons_value>0.5);
% pareto_values(idx,:) = [];
% figure('DefaultAxesFontSize',9);
% ploss = pareto_values(:,1);
% qloss = pareto_values(:,2);
% scatter(ploss,qloss,'k.');
   
% figure(2);
% plot(bestvolt0,'-sr')
% hold on
% plot(bestvolt1,'-^b')
% ylabel('Voltage (p.u)')
% xlabel('Node')
% title('Voltage profile')
% legend('Before Reconfig','After Reconfig')
% hold off
% 
% losses = pareto(end).objective;
% posrat = pareto(end).parameter;
% posgen = round(posrat(1:length(posrat)/2));
% ratgen = posrat(length(posrat));
% 
% fprintf('\n Minimum voltage before configuration %0.4f p.u.',minvolt0);
% fprintf('\n Minimum voltage after configuration %0.4f p.u.',minvolt1);
% fprintf('\n Active power loss before configuration %0.4f kW',ploss0);
% fprintf('\n Active power loss after configuration %0.4f kW',losses(1));
% fprintf('\n Reactive power loss before configuration %0.4f kVAR',qloss0);
% fprintf('\n Reactive power loss after configuration %0.4f kVAR',losses(2));
% fprintf('\n Position of Generator on bus %d',posgen);
% fprintf('\n Rating of Generator %0.2f kW',ratgen*1000);

