C = [ ];

for i = 1:10
 
 eval(['load C:\Users\Vikas\Desktop\PARTHA\Case2A\paretofront','_',num2str(i)]);

 C = [ C ; objpareto ];

end


 S = F_output(C);

 FrontValue       = ENS_SS(S); 
 
 DistanceValue    = F_distance(S,FrontValue); 
 
 [~,M ] = sort(DistanceValue','descend'); 
 
 %K = S(M(1:500),:);
 
 if (size(M,1) >= 500)
     
     K = S(M(1:500),:);
     
 else
     
 N = size(M,1);
 
 K = S(M(1:N),:);
 
 end
 V1 = zeros(1,10);
 

 for i = 1:10
 
 eval(['load C:\Users\Vikas\Desktop\PARTHA\Case2A\paretofront','_',num2str(i)]);

 V1(i) = IGD(objpareto,K);

 end
 
   
   Result = [mean(V1),std(V1)];
 
  
  VM = sort(V1);
       
     clear C;