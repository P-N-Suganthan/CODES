
%-----------------------------------------------------------------------------------------     
C = [ ];

for i = 1:10
 
 eval(['load Case9A\paretofront','_',num2str(i)]);

 C = [ C ; objpareto ];

end
 

  S = F_output(C);

 % Point  = max(S,[],1);
 
 V1 = zeros(1,10);

 for i = 1:10
 
 eval(['load Case9A\paretofront','_',num2str(i)]);

 objpareto = (objpareto - repmat(min(S,[],1),size(objpareto,1),1))./repmat(max(S,[],1)-min(S,[],1),size(objpareto,1),1);
 
 V1(i) = Hypervolume(objpareto,ones(1,size(objpareto,2)),1000000);

 end

V1 = V1';
  Result = [max(V1),min(V1),mean(V1),std(V1)];
  
  VM = sort(V1);
  
clear C;
