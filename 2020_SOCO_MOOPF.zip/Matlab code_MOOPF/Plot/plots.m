
 clf
% Case 1 vs 1-penalty
 figure(1)
 x1 = load('paretofront1_9');
 x1 = x1.objpareto;
 x1A = load('paretofront1A_6');
 x1A = x1A.objpareto;
 plot(x1(:,1),x1(:,2),'k.:');
 hold on
 xlabel('Cost ($/h)');
 ylabel('Emission (t/h)');
 plot(x1A(:,1),x1A(:,2),'m.:');
 [h,~] = legend('MOEA/D-SF','MOEA/D-penalty');
 set(h,'FontSize',9);
 
 % Case 2
 figure(2)
 x2 = load('paretofront2_9');
 x2 = x2.objpareto;
%  x2A = load('paretofront2A_10');
%  x2A = x2A.objpareto;
 plot(x2(:,1),x2(:,2),'k.:');
 hold on
 xlabel('Cost ($/h)');
 ylabel('VD (p.u.)');
 %plot(x2A(:,1),x2A(:,2),'m.:');
 [h,~] = legend('MOEA/D-SF');%,'MOEA/D-penalty')
 set(h,'FontSize',9);

 % Case 3
 figure(3)
 x3 = load('paretofront3_3');
 x3 = x3.objpareto;
 x3A = load('paretofront3A_10');
 x3A = x3A.objpareto;
%  viol = [83 167 168];
%  x3A(viol,:)=[];
 scatter3(x3(:,1),x3(:,2),x3(:,3),'k','.');
 xlabel('Cost ($/h)');
 ylabel('Loss (MW)');
 zlabel('Emission (t/h)');
 hold on
 scatter3(x3A(:,1),x3A(:,2),x3A(:,3),'m','.');
 [h,~] = legend('MOEA/D-SF','MOEA/D-penalty');
 set(h,'FontSize',9);
 
 % Case 4
 figure(4)
 x4 = load('paretofront4_4');
 x4 = x4.objpareto;
%  x4A = load('paretofront4A_4');
%  x4A = x4A.objpareto;
 scatter3(x4(:,1),x4(:,2),x4(:,3),'k','.');
 xlabel('Cost ($/h)');
 ylabel('Emission (t/h)');
 zlabel('VD (p.u.)'); 
%  hold on
%  scatter3(x4A(:,1),x4A(:,3),x4A(:,2),'m','.');
 [h,~] = legend('MOEA/D-SF');%,'MOEA/D-penalty')
 set(h,'FontSize',9);
 
 % Case 5
 figure(5)
 x5 = load('paretofront5_10');
 x5 = x5.objpareto;
%  x5A = load('paretofront5A_8');
%  x5A = x5A.objpareto;
 scatter3(x5(:,1),x5(:,2),x5(:,3),'k','.');
 xlabel('Cost ($/h)');
 ylabel('Loss (MW)'); 
 zlabel('VD (p.u.)');
%  hold on
%  scatter3(x5A(:,1),x5A(:,3),x5A(:,2),'m','.');
 [h,~] = legend('MOEA/D-SF');%,'MOEA/D-penalty')
 set(h,'FontSize',9);

% Case 7 vs 7-penalty
 figure(6)
 x6 = load('paretofront7_5');
 x6 = x6.objpareto;
 x6A = load('paretofront7A_10');
 x6A = x6A.objpareto;
 plot(x6(:,1),x6(:,2),'k.:');
 xlabel('Cost ($/h)');
 ylabel('Emission (t/h)');
 hold on
 plot(x6A(:,1),x6A(:,2),'m.:');
 [h,~] = legend('MOEA/D-SF','MOEA/D-penalty');
 set(h,'FontSize',9);

% Case 8 vs 8-penalty
 figure(7)
 x7 = load('paretofront8_2');
 x7 = x7.objpareto;
%  x7A = load('paretofront7A_10');
%  x7A = x7A.objpareto;
 plot(x7(:,1),x7(:,2),'k.:');
 xlabel('Cost ($/h)');
 ylabel('VD (p.u.)');
%  hold on
%  plot(x7A(:,1),x7A(:,2),'m.:');
 [h,~] = legend('MOEA/D-SF');%,'MOEA/D-penalty')
 set(h,'FontSize',9);
 
 % Case 9 vs 9-penalty
 figure(8)
 x8 = load('paretofront9_4');
 x8 = x8.objpareto;
 x8A = load('paretofront9A_8');
 x8A = x8A.objpareto;
 scatter3(x8(:,1),x8(:,2),x8(:,3),'k','.');
 xlabel('Cost ($/h)');
 ylabel('VD (p.u.)');
 zlabel('Loss (MW)'); 
 hold on
 scatter3(x8A(:,1),x8A(:,3),x8A(:,2),'m','.');
 [h,~] = legend('MOEA/D-SF','MOEA/D-penalty');
 set(h,'FontSize',9);


