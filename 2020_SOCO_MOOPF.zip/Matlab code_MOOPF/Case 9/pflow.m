function [obj,error] = pflow(x)
x = x';
global VD PGS emission ploss Lind_worst VI fuelcost 
%x = [57.823	73.714	97.797	348	99.992	409.96	1.0676	1.0913	1.0578	0.99359	1.0681	1.0642	1.0519	1.9289	2.5488	0.65945	1.0041	1.0482	1.008	1.0206	0.9997	1.0073	0.99731	0.96749	0.90574	0.98476	0.96836	0.97879	0.93288	0.97548	0.99095	0.97835	0.98865];
%x = [100 68.44 100 165 100 218.5 1.06 1.053 1.032 1.015 1.015 0.996 1.01 5 5 5 0.925 0.975 1.0125 0.925 0.9375 0.9875 0.95 0.9125 0.9125 0.95 0.9375 0.95 0.9125 0.9375 1 0.9625 0.9375];
Qbus = [18 25 53];
Tbranch = [19 20 31 35 36 37 41 46 54 58 59 65 66 71 73 76 80];

data = loadcase(case57);
data.gen(2:7,2) = x(1:6);
data.gen(1:7,6) = x(7:13);
data.bus(Qbus,6) = x(14:16);
data.branch(Tbranch,9) = x(17:33);

mpopt = mpoption('pf.enforce_q_lims',0,'verbose',0,'out.all',0);
result = runpf(data,mpopt);

rpowgen = [result.gen(1,2),x(1:6)];
%rpowgen = [143.4,x(1:6)];
costcoeff = data.gencost(:,5:7);

% be careful of sequence of coefficients, 2 versions of coefficients for 57-bus system
fuelcost = sum(costcoeff(:,3)+costcoeff(:,2).*rpowgen'+costcoeff(:,1).*(rpowgen.^2)'); 

%Constraint finding 
Vmax = data.bus(:,12);
Vmin = data.bus(:,13);
genbus = data.gen(:,1);
pqbus = data.bus(:,1);
pqbus(genbus) = [];

Qmax = data.gen(:,4)/data.baseMVA;
Qmin = data.gen(:,5)/data.baseMVA;
QG = result.gen(:,3)/data.baseMVA;

PGSmax = data.gen(1,9);
PGSmin = data.gen(1,10);
PGS = result.gen(1,2);
PGSerr = (PGS<PGSmin)*(abs(PGSmin-PGS)/(PGSmax-PGSmin))+(PGS>PGSmax)*(abs(PGSmax-PGS)/(PGSmax-PGSmin));

blimit = data.branch(:,6);
Slimit = sqrt(result.branch(:,14).^2+result.branch(:,15).^2);
Serr = sum((Slimit>blimit).*abs(blimit-Slimit))/data.baseMVA;

% TO find the error in Qg of gen buses- inequality constraint
Qerr = sum((QG<Qmin).*(abs(Qmin-QG)./(Qmax-Qmin))+(QG>Qmax).*(abs(Qmax-QG)./(Qmax-Qmin)));
% TO find the error in V of load buses-inequality constraint
VI = result.bus(:,8);  %V of load buses-inequality constraint
VI_complx = VI.*(cosd(result.bus(:,9))+1i*sind(result.bus(:,9)));
vpvbus = VI_complx;
vpqbus = VI_complx;
vpvbus(pqbus) = [];
vpqbus(genbus) = [];
VI(genbus)=[];
Vmax(genbus)=[];
Vmin(genbus)=[];
VIerr = sum((VI<Vmin).*(abs(Vmin-VI)./(Vmax-Vmin))+(VI>Vmax).*(abs(Vmax-VI)./(Vmax-Vmin)));
VD = sum(abs(VI-1));

% Emission : gen_no. alpha beta gama omega miu d e
emcoeff = [
	1	0.040 -0.050 0.060 0.00002 0.5 18.0  0.037;
	2	0.030 -0.060 0.050 0.00005 1.5 16.0  0.038;
	3	0.040 -0.050 0.040 0.00001 1.0 13.5  0.041;
    4   0.035 -0.030 0.035 0.00002 0.5 18.0  0.037;
    5	0.050 -0.050 0.045 0.00004 2.0 14.0  0.040;
    6   0.045 -0.040 0.050 0.00001 2.0 15.0  0.039;
    7	0.060 -0.050 0.050 0.00001 1.5 12.0  0.045];

% % BUS ADMITTANCE MATRICES
% [Ybus,~,~] = makeYbus(data);
% Ybuspq = Ybus;
% Ybuspq(genbus,:) = [];
% Ybuspvg = Ybuspq;
% Ybuspq(:,genbus) = [];
% Ybuspvg(:,pqbus) = [];
% Fmat = -Ybuspq\Ybuspvg;
% 
% Lind = abs(1-(1./vpqbus).*(Fmat*vpvbus));
% Lind_worst = max(Lind);

% OBJECTIVE FUNCTIONS
emission = sum(emcoeff(:,2)+emcoeff(:,3).*rpowgen'/100+emcoeff(:,4).*(rpowgen.^2/100^2)'...
    +emcoeff(:,5).*exp(emcoeff(:,6).*rpowgen'/100));
ploss = sum(result.branch(:,14)+result.branch(:,16));

error = [Qerr,VIerr,Serr,PGSerr];

obj(1,:) = fuelcost; % CASE 11: fuel cost only
%f1 = fuelcost+100*VD; % CASE 12: fuel cost+voltage deviation
%f1 = fuelcost+100*Lind_worst; % CASE 13: fuel cost+L-index
%f1 = emission;
obj(2,:) = VD;
obj(3,:) = ploss;
%f1 = VD; % CASE 14: VD only


