
%___________________________________________________________________%
%  Conv-ERVFL source codes version 1.0               %
%                                                                   %
%  Developed in MATLAB R2022b(7.13)                                 %
%                                                                   %
%  Author and programmer: Dr. Tripti Goel                           %
%                                                                   %
%         e-Mail: triptigoel@ece.nits.ac.in                         %
%                 triptigoel83@gmail.com            %
%                                                                   %
%       Homepage: http://ec.nits.ac.in/tripti/                      %
%                                                                   %
%   Main paper: R. Sharma, T. Goel, M. Tanveer, P. N. Suganthan,
%     "Conv-ERVFL: Convolutional Neural Network Based Ensemble
%      RVFL Classifier for Alzheimer s Disease Diagnosis," 
%      in IEEE Journal of Biomedical and Health Informatics, 
%      2022, doi: 10.1109/JBHI.2022.3215533.              %
%                                                                   %
%___________________________________________________________________%

clc; clear all;

gpuDevice(1);
digitDatasetPath = fullfile('XXXXX');   % Give the dataset path
imds = imageDatastore(digitDatasetPath, ...
    'IncludeSubfolders',true,'LabelSource','foldernames');
tbl = countEachLabel(imds);

minSetCount = min(tbl{:,2});

start_time_train=cputime;

    [trainingSet, testSet] = splitEachLabel(imds, 0.9, 'randomize');
    
    imageSize = [224 224 3];
    augmentedTrainingSet = augmentedImageDatastore(imageSize, trainingSet, 'ColorPreprocessing', 'gray2rgb');
    augmentedTestSet = augmentedImageDatastore(imageSize, testSet, 'ColorPreprocessing', 'gray2rgb');
        
    layers = [
    imageInputLayer([224 224 3])
    
      
    convolution2dLayer(7,32,'Padding','same')
    batchNormalizationLayer
    reluLayer
    
    maxPooling2dLayer(2,'Stride',2)
              
    convolution2dLayer(5,64,'Padding','same')
    batchNormalizationLayer
    reluLayer
    
    maxPooling2dLayer(2,'Stride',2)
    
    convolution2dLayer(5,64,'Padding','same')
    batchNormalizationLayer
    reluLayer
    
    maxPooling2dLayer(2,'Stride',2)
    
    convolution2dLayer(5,64,'Padding','same')
    batchNormalizationLayer
    reluLayer
    
    maxPooling2dLayer(2,'Stride',2)
    
    convolution2dLayer(3,32,'Padding','same')
    batchNormalizationLayer
    reluLayer
    
    maxPooling2dLayer(2,'Stride',2)
    
    convolution2dLayer(3,32,'Padding','same')
    batchNormalizationLayer
    reluLayer
    
    maxPooling2dLayer(2,'Stride',2)
    
    convolution2dLayer(3,16,'Padding','same')
    batchNormalizationLayer
    reluLayer
    
    maxPooling2dLayer(2,'Stride',2)
    
    convolution2dLayer(3,32,'Padding','same')
    batchNormalizationLayer
    reluLayer    
    
    fullyConnectedLayer(3)
    softmaxLayer
    classificationLayer];

    YValidation = testSet.Labels;
      
    options = trainingOptions('sgdm', ...
     'Momentum', 0.099,...
    'InitialLearnRate',0.022, ...
    'MaxEpochs',50, ...
    'Shuffle','every-epoch', ...
    'MiniBatchSize', 24,...
    'L2Regularization', 3.0000e-2,...
    'ValidationData',augmentedTestSet, ...
    'Verbose',false, ...
    'Plots','training-progress');

    net = trainNetwork(augmentedTrainingSet,layers,options);
    
    [YPred, Scores] = classify(net,augmentedTestSet);    
    accuracy = sum(YPred == YValidation)/numel(YValidation);
    testLabels = testSet.Labels;
   trainingLabels = trainingSet.Labels;
   trainingLabels = grp2idx(trainingLabels);
   testLables = grp2idx(testLabels);
     
  option.N = 1000; 
  option.ActivationFunction = 'my_fuzzy';
       
    featureLayer1 = 'maxpool_3';
    trainingFeatures1 = activations(net, augmentedTrainingSet, featureLayer1, ...
        'MiniBatchSize', 64, 'OutputAs', 'columns');
    trainingFeatures1 = double(trainingFeatures1);
    
   
    testFeatures1 = activations(net, augmentedTestSet, featureLayer1, ...
        'MiniBatchSize', 64, 'OutputAs', 'columns');
      
    testFeatures1 = double(testFeatures1);
    
    
    
    [train_accuracy1,test_accuracy1] = RVFL_train_val(trainingFeatures1',Y',testFeatures1',Y1',option);
     load testY_temp; testY_temp1 = testY_temp;  
     load trainY_temp; trainY_temp1 =  trainY_temp;
%%    
    featureLayer2 = 'maxpool_4';
    trainingFeatures2 = activations(net, augmentedTrainingSet, featureLayer2, ...
        'MiniBatchSize', 64, 'OutputAs', 'columns');
    trainingFeatures2 = double(trainingFeatures2);
    
   
    testFeatures2 = activations(net, augmentedTestSet, featureLayer2, ...
        'MiniBatchSize', 64, 'OutputAs', 'columns');
      
    testFeatures2 = double(testFeatures2);
    

    [train_accuracy2,test_accuracy2] = RVFL_train_val(trainingFeatures2',Y',testFeatures2',Y1',option);
     load testY_temp; testY_temp2 = testY_temp;    
    load trainY_temp; trainY_temp2 =  trainY_temp;
    
    %% Feature Layer 5
    featureLayer3 = 'maxpool_5';
    trainingFeatures3 = activations(net, augmentedTrainingSet, featureLayer3, ...
        'MiniBatchSize', 64, 'OutputAs', 'columns');
    trainingFeatures3 = double(trainingFeatures3);
    
   
    testFeatures3 = activations(net, augmentedTestSet, featureLayer3, ...
        'MiniBatchSize', 64, 'OutputAs', 'columns');
      
    testFeatures3 = double(testFeatures3);
     
    [train_accuracy3,test_accuracy3] = RVFL_train_val(trainingFeatures3',Y',testFeatures3',Y1',option);
     load testY_temp; testY_temp3 = testY_temp;    
    load trainY_temp; trainY_temp3 =  trainY_temp;
%     
%     %%
%     
     featureLayer4 = 'maxpool_6';
    trainingFeatures4 = activations(net, augmentedTrainingSet, featureLayer4, ...
        'MiniBatchSize', 64, 'OutputAs', 'columns');
    trainingFeatures4 = double(trainingFeatures4);
    
   
    testFeatures4 = activations(net, augmentedTestSet, featureLayer4, ...
        'MiniBatchSize', 64, 'OutputAs', 'columns');
      
    testFeatures4 = double(testFeatures4);
    
       
    [train_accuracy4,test_accuracy4] = RVFL_train_val(trainingFeatures4',Y',testFeatures4',Y1',option);
     load testY_temp; testY_temp4 = testY_temp;  
     load trainY_temp; trainY_temp4 =  trainY_temp;
%      
%      %%
     featureLayer5 = 'maxpool_7';
    trainingFeatures5 = activations(net, augmentedTrainingSet, featureLayer5, ...
        'MiniBatchSize', 64, 'OutputAs', 'columns');
    trainingFeatures5 = double(trainingFeatures5);
    
   
    testFeatures5 = activations(net, augmentedTestSet, featureLayer5, ...
        'MiniBatchSize', 64, 'OutputAs', 'columns');
      
    testFeatures5 = double(testFeatures5);
    
     
    [train_accuracy5,test_accuracy5] = RVFL_train_val(trainingFeatures5',Y',testFeatures5',Y1',option);
     load testY_temp; testY_temp5 = testY_temp;  
     load trainY_temp; trainY_temp5 =  trainY_temp;

%     
    trainingFeatures_final = (trainY_temp1+trainY_temp2+trainY_temp3+trainY_temp4+trainY_temp5)./5; 
    testFeatures_final = (testY_temp1+testY_temp2+testY_temp3+testY_temp4+testY_temp5)./5;
    dimTrain = size(trainingSet.Files,1);
    dimTest = size(testSet.Files,1); no_person = 3;
    
    no_img_p_s_train = dimTrain/no_person;  
    TrainTargets = zeros(no_person, dimTrain);
    for j = 1:no_person
        for k = 1:no_img_p_s_train
            TrainTargets(j,((j-1)*no_img_p_s_train + k)) = 1;
        end
    end
    
    % %
    fprintf('Creating the target matrix of TestData for calculating accuracy(Performance)\n');
    no_img_p_s_test = dimTest/no_person;
    
    TestTargets = zeros(no_person, dimTest);
    for j = 1:no_person
        for k = 1:no_img_p_s_test
            TestTargets(j,((j-1)*no_img_p_s_test + k)) = 1;
        end
    end
     
    TrainTargets_ind=vec2ind(TrainTargets);  Y = TrainTargets_ind';
    TestTargets_ind=vec2ind(TestTargets);   Y1 = TestTargets_ind';
    
    [train_accuracy,test_accuracy] = RVFL_train_val(trainingFeatures_final,Y',testFeatures_final,Y1',option); 
    load testY_temp;
    load Yt_temp;
    
    confMat = confusionmat(Y1, Yt_temp);
    CM= confusionchart(confMat,{'AD','CN','MCI'});
    EVAL = Evaluate(Y1', Yt_temp);
