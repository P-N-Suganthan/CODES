function [V] = geninit(Nonodes,NoFeats)

V(:,:,1)=0.05*rand(Nonodes,NoFeats);
V(:,:,2)=0.05*rand(Nonodes,NoFeats);
V(:,:,3)=0.05*rand(Nonodes,NoFeats);
V(:,:,4)=0.05*rand(Nonodes,NoFeats);
V(:,:,5)=0.05*rand(Nonodes,NoFeats);
V(:,:,6)=0.05*rand(Nonodes,NoFeats);
V(:,:,7)=0.05*rand(Nonodes,NoFeats);
V(:,:,8)=0.05*rand(Nonodes,NoFeats);
V(:,:,9)=0.05*rand(Nonodes,NoFeats);
V(:,:,10)=0.05*rand(Nonodes,NoFeats);