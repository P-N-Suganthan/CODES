function [V] = geninit(Nonodes,NoFeats)

V(:,:,1)=0*rand(Nonodes,NoFeats);
V(:,:,2)=0.5*rand(Nonodes,NoFeats);
V(:,:,3)=-40+0.5*rand(Nonodes,NoFeats);
V(:,:,4)=-20*rand(Nonodes,NoFeats);
V(:,:,5)=30*rand(Nonodes,NoFeats);
V(:,:,6)=50+0.05*rand(Nonodes,NoFeats);
V(:,:,7)=200+0.05*rand(Nonodes,NoFeats);
V(:,:,8)=40+0.05*rand(Nonodes,NoFeats);
V(:,:,9)=-200+0.0005*rand(Nonodes,NoFeats);
V(:,:,10)=-15+0.05*rand(Nonodes,NoFeats);