function [V] = geninitmultimod(Nonodes,NoFeats)

V(:,:,1)=0.0005*rand(Nonodes,NoFeats);
V(:,:,2)=0.05*rand(Nonodes,NoFeats);
V(:,:,3)=5*rand(Nonodes,NoFeats);
V(:,:,4)=0.5*rand(Nonodes,NoFeats);
V(:,:,5)=2+0.5*rand(Nonodes,NoFeats);
V(:,:,6)=4+0.05*rand(Nonodes,NoFeats);
V(:,:,7)=4+0.5*rand(Nonodes,NoFeats);
V(:,:,8)=6+0.05*rand(Nonodes,NoFeats);
V(:,:,9)=6+0.5*rand(Nonodes,NoFeats);
V(:,:,10)=10*rand(Nonodes,NoFeats);