% Perform CFCM1 Algorithm
function [result]=CFCM1(dataset,iterationnum,Nonodes,V,mm)

%Initialization of the result Network

result.dataset=dataset;

result.NoFeats=size(result.dataset,2)-1;

result.NoClasses=max(unique(result.dataset(:,result.NoFeats+1))); %All the class label must over 1

result.m=2;

result.Max_Iter=iterationnum;

result.w=V+ones(size(V,1),1)*mean(result.dataset(:,1:result.NoFeats));

result.metric = 2;

result.previousw=result.w;
result.stopcriteria=0.0001;
flag=1;

ki=mm.ki;
yeta=mm.yeta;

fi=1-(ki-min(ki))/(max(ki)-min(ki));  

% Training procedure
for iter = 1:result.Max_Iter
    if flag==1
        %       iter
        for i=1:size(result.dataset,1)
            d=[];
            for j=1:size(result.w,1)
                d(j) = norm(result.dataset(i,1:result.NoFeats)-result.w(j,:),result.metric)^2;
            end
            d=d.^(1/(result.m-1));
            for j=1:size(result.w,1)
                U(i,j)=fi(i)/sum(d(j)./d);
                if U(i,j)==Inf
                    U(i,j)=1;
                end
            end
        end
        
        
        U=U.^result.m;
        for j=1:size(result.w,1)
            temp=zeros(1,result.NoFeats);
            for k=1:size(result.dataset,1)
                temp=temp+U(k,j)*result.dataset(k,1:result.NoFeats);
            end
            result.w(j,:)=temp/sum(U(:,j));
        end
           
%         hold off 
%         plot(result.dataset(:,1),result.dataset(:,2),'r.')
%         hold on 
%         plot(result.w(:,1),result.w(:,2),'bx')
%         drawnow
           
        crit=0;
        for i=1:size(result.w,1)
            crit=crit+norm(result.previousw(i,:)-result.w(i,:),result.metric);
        end
        crit=crit/size(result.w,1);
        if crit <= result.stopcriteria
            disp('stop');
            flag=0;
        else
            result.previousw=result.w;
        end
        
    end
end
% 
% E=zeros(1,size(result.w,1));
% for i=1:size(result.dataset,1)
%     d=[];
%     for j=1:size(result.w,1)
%         d(j) = norm(result.dataset(i,1:result.NoFeats)-result.w(j,:),result.metric);
%     end
%     [minval,s]=min(d);
%     E(s)=E(s)+minval;
% end
% E=sum(E)
% result.QE=E;