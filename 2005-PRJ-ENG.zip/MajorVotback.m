%Perform Majority voting classifier
function [CR,Gain,value] = MajorVotback(GNG,trainset,testset)
%%Normalizing the dataset into [-1,1]
% [trainset,testset]=Normalization(trainset,testset);

for i=1:size(GNG.w,1)
    eval(['Clut' int2str(i) '= [];']);
end
for i=1:size(trainset,1)
    CurVec=trainset(i,1:size(trainset,2)-1);
    d=[];
    for h=1:size(GNG.w,1)
        d(h) = norm((CurVec-GNG.w(h,:)),GNG.metric)^2;
    end
    [minval,s] = min(d);
    eval(['Clut' int2str(s) '= [Clut' int2str(s) ';trainset(i,:)];']);
end

totalent=0;
weightent=0;
nodelabel=[];
tempdelete=[];
deadnode=0;

for i=1:size(GNG.w,1)
  eval(['temp=Clut' int2str(i) ';']);
  if ~isempty(temp)
    templabel=temp(:,GNG.NoFeats+1);    
    noclass=[];
    for j=1:GNG.NoClasses
        noclass=[noclass,size(find(templabel==j),1)];
    end
    tnum=noclass./size(temp,1);
    
    entropyvalue=0;
    for m=1:size(tnum,2)
        if tnum(m)~=0
            entropyvalue=entropyvalue-tnum(m)*log2(tnum(m));
        end
    end
    weightent=weightent+(size(temp,1)/size(GNG.trainset,1))*entropyvalue;
    
    [maxval,label]=max(noclass);
    if size(find(noclass==maxval),2) >= 2
        temp = find(noclass==maxval);
        temp1=[];
        minv=9999;
        for j=1:size(temp,2)
            temp1=find(templabel==temp(j));
            value=0;
            for k=1:size(temp1,1)
                eval(['value = value + norm(Clut' int2str(i) '(temp1(k),1:GNG.NoFeats)-GNG.w(i,:),GNG.metric)^2;']);
            end
            if value < minv
                minv=value;
                label=temp(j);
            end
        end
    end
    nodelabel=[nodelabel,label];
  else
    tempdelete=[tempdelete,i];
    deadnode=deadnode+1;
    nodelabel=[nodelabel,-1];
  end
end

% GNG.w(tempdelete,:)=[];

%Calculate the classification accuracy
NoTrue=0;    %The number of correct classification
NoFalse=0;   %The number of false classification
for i=1:size(testset,1)
    d=[];
	CurVec = testset(i,1:size(testset,2)-1);	
	PClasslabel = testset(i,size(testset,2));
	for j=1:size(GNG.w,1)
		d(j) = norm(CurVec-GNG.w(j,:),GNG.metric)^2;
	end
    [minval,s]=min(d);
    if PClasslabel==nodelabel(s)
        NoTrue=NoTrue+1;
    else
        NoFalse=NoFalse+1;   %Here we merge rejection instances into the false classified instances
    end
end
CR = NoTrue/(NoTrue+NoFalse);

for j=1:GNG.NoClasses
    num=size(find(GNG.trainset(:,GNG.NoFeats)==j),1);
    if num~=0
        totalent=totalent-(num/size(GNG.trainset,1))*log2(num/size(GNG.trainset,1));
    end
end
Gain=totalent-weightent;

center=[];
for i=1:size(GNG.trainset,1)
    for j=1:GNG.NoClasses
        templab=find(GNG.trainset(:,GNG.NoFeats+1)==j);
        if size(templab,1)~=0
            center=[center;mean(GNG.trainset(templab,1:GNG.NoFeats))];
        end
    end
end
tstandneurons=center;
value=0;
Neurons=GNG.w;
while ~isempty(Neurons)
    tempd=[];
    tempneurons=[];
    for j=1:size(tstandneurons,1)
        d=[];
        for k=1:size(Neurons,1)
            d(k)=norm(Neurons(k,:)-tstandneurons(j,:),2)^2;
        end
        [minvalue,s]=min(d);
        tempd(j)=s;
        tempneurons(j)=minvalue;
    end
    deleted=[];
    for j=1:size(Neurons,1)
        temp=find(tempd==j);
        if ~isempty(temp)
            if size(temp,2)==1
                value=value+tempneurons(temp);
                deleted=[deleted,temp];
            else
                [a,b]=min(tempneurons(temp));
                deleted=[deleted,temp(b)];
                value=value+a;
            end
        end
    end
    tstandneurons(deleted,:)=[];
    Neurons(tempd(deleted),:)=[];
end
