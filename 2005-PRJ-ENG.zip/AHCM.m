% Perform AHCM Algorithm    
function [result]=AHCM(dataset,iterationnum,Nonodes,V)

%Initialization of the result Network

result.dataset=dataset;

result.NoFeats=size(result.dataset,2)-1;

result.NoClasses=max(unique(result.dataset(:,result.NoFeats+1))); %All the class label must over 1

result.m=2;

result.Max_Iter=iterationnum;

result.w=V+ones(size(V,1),1)*mean(result.dataset(:,1:result.NoFeats));

result.metric = 2;

result.previousw=result.w;
result.stopcriteria=0.0001;
flag=1;


datamean=mean(result.dataset(:,1:result.NoFeats));
dvar=[];
for i=1:size(result.dataset,1)
    dvar=[dvar,norm(result.dataset(i,1:result.NoFeats)-datamean,2)^2];
end
meanvalue=mean(dvar);
beta=1/meanvalue;

% Training procedure
for iter = 1:result.Max_Iter
    if flag==1
        for i=1:size(result.w,1)
            eval(['d' int2str(i) '=[];']);
        end
        for i=1:size(result.dataset,1)
            d=[];
            for j=1:size(result.w,1)
                d(j) = norm(result.dataset(i,1:result.NoFeats)-result.w(j,:),result.metric)^2;
            end
            [minvalue,s]=min(d);
            eval(['d' int2str(s) '=[d' int2str(s) ';result.dataset(i,:)];']);
        end
        
        
        for j=1:size(result.w,1)
            temp=zeros(1,result.NoFeats);
            tempden=0;
            eval(['datatemp=d' int2str(j) ';']);
            if size(datatemp,1)~=0
                for k=1:size(datatemp,1)
                    temp=temp+exp(-beta*norm(datatemp(k,1:result.NoFeats)-result.w(j,:),result.metric)^2)*datatemp(k,1:result.NoFeats);
                    tempden=tempden+exp(-beta*norm(datatemp(k,1:result.NoFeats)-result.w(j,:),result.metric)^2);
                end
                result.w(j,:)=temp/(tempden+1e-5);
            end
        end

%         hold off 
%         plot(result.dataset(:,1),result.dataset(:,2),'r.')
%         hold on 
%         plot(result.w(:,1),result.w(:,2),'bx')
%         drawnow
          
        crit=0;
        for i=1:size(result.w,1)
            crit=crit+norm(result.previousw(i,:)-result.w(i,:),result.metric);
        end
        crit=crit/size(result.w,1);
        if crit <= result.stopcriteria
            disp('stop');
            flag=0;
        else
            result.previousw=result.w;
        end
        
    end
end

% E=zeros(1,size(result.w,1));
% for i=1:size(result.dataset,1)
%     d=[];
%     for j=1:size(result.w,1)
%         d(j) = norm(result.dataset(i,1:result.NoFeats)-result.w(j,:),result.metric);
%     end
%     [minval,s]=min(d);
%     E(s)=E(s)+minval;
% end
% E=sum(E)
% result.QE=E;