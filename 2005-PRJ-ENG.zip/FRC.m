% Perform Fuzzy Robust Clustering Algorithm
function [result]=FRC(dataset,iterationnum,Nonodes,V)

%Initialization of the result Network
result.dataset=dataset;

% Dimensionality of feature space
result.NoFeats=size(result.dataset,2)-1;

%The max class label in the result network
result.NoClasses=max(unique(result.dataset(:,result.NoFeats+1))); %All the class label must over 1

% result learning rate e(t) coefficients
result.ei = 0.2;    %Initial value of learning rate e(t)

% The max number of iterations
result.Max_Iter=iterationnum;

% Initialize 4 reference vector weights
result.w=V;%+0.005*rand(Nonodes,result.NoFeats);

% Norm metric to be used, 2=>euclidean
result.metric = 2;

result.previousw=result.w;
result.stopcriteria=0.0001;
flag=1;

% hold off 
% plot(result.dataset(:,1),result.dataset(:,2),'r.')
% hold on 
% plot(result.w(:,1),result.w(:,2),'bx')
% drawnow

% Training procedure
rand('state',0);
for iter = 0:result.Max_Iter-1
    if flag==1
        et=result.ei*(1-iter/(result.Max_Iter-1));
        
        trndata = result.dataset;	 % Copy to working dataset from which used samples are removed
        rand('state',sum(100*clock));
        iter1=0;
        while ~isempty(trndata)
            iter1 = iter1+1;
            t=iter1+iter*size(result.dataset,1);
            %  Select input sample
            index = ceil(size(trndata,1)*rand(1,1));  % Choose a training sample randomly from the training dataset
            CurVec = trndata(index,1:result.NoFeats);
            
            yeta=[];
            for i=1:size(result.w,1)
                d=[];
                for j=1:size(result.w,1)
                    if j~=i
                        d=[d,norm(result.w(i,:)-result.w(j,:),result.metric)^2];
                    end
                end
                yeta(i)=min(d); 
            end
            yeta=yeta./2;
            
            
            temp=[];
            for i=1:size(result.w,1)
                temp(i) = norm(CurVec-result.w(i,:),result.metric)^2;
            end
            yeta=yeta+1e-5;
            for i=1:size(result.w,1)  
                result.w(i,:)=result.w(i,:)+et*exp(-(temp(i)/yeta(i))^10)*(CurVec-result.w(i,:));
            end
            trndata(index,:) = []; 
            
%             if mod(t,50) == 0 
%                 hold off 
%                 plot(result.dataset(:,1),result.dataset(:,2),'r.')
%                 hold on 
%                 plot(result.w(:,1),result.w(:,2),'bx')
%                 drawnow
%             end    
        end
        
        crit=0;
        for i=1:size(result.w,1)
            crit=crit+norm(result.previousw(i,:)-result.w(i,:),result.metric)^2;
        end
        crit=crit/size(result.w,1);
        if crit <= result.stopcriteria
            disp('stop');
            flag=0;
        else
            result.previousw=result.w;
        end
        
    end
end
 
% E=zeros(1,size(result.w,1));
% for i=1:size(result.dataset,1)
%     d=[];
%     for j=1:size(result.w,1)
%         d(j) = norm(result.dataset(i,1:result.NoFeats)-result.w(j,:),result.metric);
%     end
%     [minval,s]=min(d);
%     E(s)=E(s)+minval;
% end
% E=sum(E)
% result.QE=E;

