% Perform A modified Neural gas for clustering
function [ENG]=ENGTrain(dataset,iterationnum,Nonodes,V) %,outobvalue1,outobvalue2

%%%%%%%%%%%%%%%%%Initialization of the ENG Network%%%%%%%%%%%%%%%%%%%%%%%%%%%
ENG.dataset=dataset;

% Dimensionality of feature space
ENG.NoFeats=size(ENG.dataset,2)-1;

rangevalue=max(max(ENG.dataset(:,1:ENG.NoFeats)))-min(min(ENG.dataset(:,1:ENG.NoFeats)));

%The max class label in the ENG network
ENG.NoClasses=max(unique(ENG.dataset(:,ENG.NoFeats+1))); %All the class label must over 1

% ENG learning rate e(t) coefficients
ENG.ei = 0.8;    %Initial value of learning rate e(t)
ENG.ef = 0.05;   %Final value of learning rate e(t)

% lammda(t) determines the number of neural units significantly changing their weights during the adaptation step t
ENG.lammdai=10;
ENG.lammdaf=0.01;
epsilon=10e-5;   

% The max number of iterations
ENG.Max_Iter=iterationnum;

% Initialize 4 reference vector weights
ENG.w=V+ones(size(V,1),1)*mean(ENG.dataset(:,1:ENG.NoFeats));

% Norm metric to be used, 2=>euclidean
ENG.metric = 2;

ENG.previousw=ENG.w;
ENG.stopcriteria=0.0001;
flag=1;


% hold off 
% plot(ENG.dataset(:,1),ENG.dataset(:,2),'r.')
% hold on 
% plot(ENG.w(:,1),ENG.w(:,2),'bx')
% drawnow

harmdist=[];
for i=1:size(ENG.w,1)
    temp=0;
    for k=1:size(ENG.dataset,1)
        temp=temp+1/(norm(ENG.dataset(k,1:ENG.NoFeats)-ENG.w(i,:),ENG.metric)+epsilon);
    end
    harmdist(i)=temp/size(ENG.dataset,1);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Training procedure
rand('state',0);
for iter = 0:ENG.Max_Iter-1
    tempvalue=1./harmdist;
    tempv=[];
    
    if iter<=ENG.Max_Iter-5
        ENG.lammda2i=50;
        ENG.lammda2f=10;
    else
        ENG.lammda2i=10;
        ENG.lammda2f=0.01;
    end 
    
    if flag==1
        trndata = ENG.dataset;	 % Copy to working dataset from which used samples are removed
        rand('state',sum(100*clock));
        iter1=0;
        while ~isempty(trndata)
            iter1 = iter1+1;
            t=iter1+iter*size(ENG.dataset,1);
            
            lammdat=ENG.lammdai*((ENG.lammdaf/ENG.lammdai)^(t/(size(ENG.dataset,1)*ENG.Max_Iter)));
            
            et=ENG.ei*((ENG.ef/ENG.ei)^(t/(size(ENG.dataset,1)*ENG.Max_Iter)));
            
            if iter<=ENG.Max_Iter-5
                
                lammdat2=ENG.lammda2i*((ENG.lammda2f/ENG.lammda2i)^(t/(size(ENG.dataset,1)*(ENG.Max_Iter-5))));
                
            else
                lammdat2=ENG.lammda2i*((ENG.lammda2f/ENG.lammda2i)^((t-1-size(ENG.dataset,1)*(ENG.Max_Iter-4))/(size(ENG.dataset,1)*4)));
            end            
            
            %  Select input sample
            index = ceil(size(trndata,1)*rand(1,1));  % Choose a training sample randomly from the training dataset
            CurVec = trndata(index,1:ENG.NoFeats);
            
            %  Compute the distortions
            d=[];
            for i=1:size(ENG.w,1)
                d(i) = norm(CurVec-ENG.w(i,:),ENG.metric)+epsilon;
            end
            
            m=[];
            maxval=max(d);
            minval=min(d);
            
            [avalue,idx]=sort(d);
            m(idx) = [0:(size(ENG.w,1)-1)]; 
            
            
            for i=1:size(ENG.w,1)
                if d(i) > tempvalue(i)
                    tempvalue(i)=2/(1/d(i)+1/tempvalue(i));
                    tempv(i)=tempvalue(i);
                else
                    tempv(i)=d(i);
                    tempvalue(i)=(d(i)+tempvalue(i))/2; 
                end
                ENG.w(i,:)=ENG.w(i,:)+et*exp(-m(i)/lammdat)*(exp(-(d(i)*harmdist(i))/lammdat2))*tempv(i)*((CurVec-ENG.w(i,:))/d(i));
            end
            
            trndata(index,:) = [];
            
            if mod(t,50) == 0, 
                hold off 
                plot(ENG.dataset(:,1),ENG.dataset(:,2),'r.')
                hold on 
                plot(ENG.w(:,1),ENG.w(:,2),'bx')
                drawnow
            end
            
        end
        
        for i=1:size(ENG.w,1)
            temp=0;
            for k=1:size(ENG.dataset,1)
                temp=temp+1/(norm(ENG.dataset(k,1:ENG.NoFeats)-ENG.w(i,:),ENG.metric)+epsilon);
            end
            harmdist(i)=temp/size(ENG.dataset,1);
        end
        
        crit=0;
        for i=1:size(ENG.w,1)
            crit=crit+norm(ENG.previousw(i,:)-ENG.w(i,:),ENG.metric);
        end
        crit=crit/size(ENG.w,1);
        if crit <= ENG.stopcriteria
            disp('stop');
            flag=0;
        else
            ENG.previousw=ENG.w;
        end
        
        
        
        % Initialise connection set C - links
        tempC = zeros(size(ENG.w,1),1);
        ENG.C=-1+diag(tempC,0);  % '-1' represents having no connection
        for i=1:size(ENG.dataset,1)
            d=[];
            for j=1:size(ENG.w,1)
                d(j) = norm(ENG.dataset(i,1:size(ENG.dataset,2)-1)-ENG.w(j,:),2);	 % Find squared error
            end
            [minval,s] = min(d);
            d(s)=9999;
            [secminval,s2] =min(d); 
            ENG.C(s,s2)=0;
            ENG.C(s2,s)=0;
        end
        
        %MDL parameter calculation part       
        if iter >= ENG.Max_Iter-5  
            for i=1:size(ENG.w,1)
                eval(['ENG.Winset' int2str(i) '=[];']);
            end
            counter=zeros(1,size(ENG.w,1));
            errorvalue=zeros(1,size(ENG.w,1));
            for i=1:size(ENG.dataset,1)
                d=[];
                for j=1:size(ENG.w,1)
                    d(j) = norm(ENG.dataset(i,1:size(ENG.dataset,2)-1)-ENG.w(j,:),2);	 % Find squared error
                end
                [minval,s] = min(d);
                counter(s)=counter(s)+1;
                errorvalue(s)=errorvalue(s)+minval;
                eval(['ENG.Winset' int2str(s) '=[ENG.Winset' int2str(s) ';ENG.dataset(i,:)];']);
            end
            
            Lchange=ones(1,size(ENG.w,1));
            for h=1:size(counter,2)
                if counter(h)~=0
                    errorvalue(h)=errorvalue(h)/counter(h);
                else
                    errorvalue(h)=0;
                end
            end
            
            errorvalue=sum(errorvalue);
            
            for i=1:size(ENG.w,1)
                if counter(i)~=0
                    eval(['dataset=ENG.Winset' int2str(i) ';']);
                    erroradd=0;
                    Lchange(i)=-(size(ENG.dataset,2)-1)*(ceil(log2(rangevalue/0.0001))+1);
                    for j=1:size(dataset,1)
                        d=[];
                        for k=1:size(ENG.w,1)
                            d(k) = norm(dataset(j,1:size(dataset,2)-1)-ENG.w(k,:),2);
                        end
                        [minval,s1]=min(d);
                        d(s1)=9999;
                        [secminval,s2]=min(d);
                        
                        erroraddbefore=0;
                        erroraddafter=0;
                        for h=1:(size(dataset,2)-1)
                            if abs(dataset(j,h)-ENG.w(s2,h)) ~= 0
                                erroraddafter=erroraddafter+max(log2(abs(dataset(j,h)-ENG.w(s2,h))/0.0001),1);
                                erroraddbefore=erroraddbefore+max(log2(abs(dataset(j,h)-ENG.w(s1,h))/0.0001),1);
                            else
                                erroraddafter=erroraddafter+1;
                                erroraddbefore=erroraddbefore+1;
                            end
                        end
                        erroradd=erroradd+(erroraddafter-erroraddbefore);
                    end
                    Lchange(i)=Lchange(i)+size(ENG.dataset,1)*(log2(size(ENG.w,1)-1)-log2(size(ENG.w,1)))+2*erroradd;
                else
                    Lchange(i)=-9999;
                end
            end
            
            [Lchange,index]=sort(Lchange);
            if min(Lchange) < 0
                indextemp=index(find(Lchange < 0));
                hold on 
                plot(ENG.w(index(indextemp),1),ENG.w(index(indextemp),2),'go');       
                drawnow
                tempE=0;
                for k=1:size(indextemp,2)
                    mENG=ENG;
                    mENG.C(indextemp(k),:)=[];
                    mENG.C(:,indextemp(k))=[];
                    mENG.w(indextemp(k),:)=[];
                    E=zeros(1,size(mENG.w,1));
                    for i=1:size(mENG.dataset,1)
                        d=[];
                        for j=1:size(mENG.w,1)
                            d(j) = norm(mENG.dataset(i,1:mENG.NoFeats)-mENG.w(j,:),mENG.metric);
                        end
                        [minval,s]=min(d);
                        E(s)=E(s)+minval;
                    end
                    
                    mENG.E=E;
                    mENG = AddNode(mENG);
                    tcounter=zeros(1,size(mENG.w,1));
                    E=zeros(1,size(mENG.w,1));
                    for i=1:size(mENG.dataset,1)
                        d=[];
                        for j=1:size(mENG.w,1)
                            d(j) = norm(mENG.dataset(i,1:mENG.NoFeats)-mENG.w(j,:),mENG.metric);
                        end
                        [minval,s]=min(d);
                        E(s)=E(s)+minval;
                        tcounter(s)=tcounter(s)+1;
                    end
                    for h=1:size(tcounter,2)
                        if tcounter(h)~=0
                            E(h)=E(h)/tcounter(h);
                        else
                            E(h)=0;
                        end
                    end
                    tempE=sum(E);
                    if tempE < errorvalue
                        errorvalue=tempE;
                        ENG=mENG;
                        for mk=k:size(indextemp,2)
                            if indextemp(mk)>indextemp(k)
                                indextemp(mk)=indextemp(mk)-1;
                            end
                        end
                    end
                end
                
            end
        end
    end
end

% E=zeros(1,size(ENG.w,1));
% for i=1:size(ENG.dataset,1)
%     d=[];
%     for j=1:size(ENG.w,1)
%         d(j) = norm(ENG.dataset(i,1:ENG.NoFeats)-ENG.w(j,:),ENG.metric);
%     end
%     [minval,s]=min(d);
%     E(s)=E(s)+minval;
% end
% E=sum(E)
% ENG.QE=E;
