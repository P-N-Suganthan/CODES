% Perform A modified Neural gas for clustering
function [NG]=NG(dataset,iterationnum,Nonodes,V)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Initialization of the NG Network%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
NG.dataset=dataset;

% Dimensionality of feature space
NG.NoFeats=size(NG.dataset,2)-1;

%The max class label in the NG network
NG.NoClasses=max(unique(NG.dataset(:,NG.NoFeats+1))); %All the class label must over 1

% NG learning rate e(t) coefficients
NG.ei = 0.8;    %Initial value of learning rate e(t)
NG.ef = 0.008;   %Final value of learning rate e(t)

% lammda(t) determines the number of neural units significantly changing their weights during the adaptation step t
NG.lammdai=10;
NG.lammdaf=0.01;

% The max number of iterations
NG.Max_Iter=iterationnum;

% Initialize 4 reference vector weights
NG.w=V+ones(size(V,1),1)*mean(NG.dataset(:,1:NG.NoFeats));

% Norm metric to be used, 2=>euclidean
NG.metric = 2;

NG.previousw=NG.w;
NG.stopcriteria=0.0001;
flag=1;

% Training procedure
rand('state',0);
for iter = 0:NG.Max_Iter-1
    if flag==1
        %       iter+1
        trndata = NG.dataset;	 % Copy to working dataset from which used samples are removed
        rand('state',sum(100*clock));
        iter1=0;
        while ~isempty(trndata)
            iter1 = iter1+1;
            t=iter1+iter*size(NG.dataset,1);
            r_t=5*log(10)+log(NG.ei)+log(NG.ef/NG.ei)*t/(size(NG.dataset,1)*NG.Max_Iter);
            lammdat=NG.lammdai*((NG.lammdaf/NG.lammdai)^(t/(size(NG.dataset,1)*NG.Max_Iter)));
            et=NG.ei*((NG.ef/NG.ei)^(t/(size(NG.dataset,1)*NG.Max_Iter)));
            %  Select input sample
            index = ceil(size(trndata,1)*rand(1,1));  % Choose a training sample randomly from the training dataset
            CurVec = trndata(index,1:NG.NoFeats);
            
            %  Compute the distortions
            d=[];
            for i=1:size(NG.w,1)
                d(i) = norm(CurVec-NG.w(i,:),NG.metric);
            end
            
            m=[];
            [avalue,idx]=sort(d);
            m(idx) = [0:(size(NG.w,1)-1)]; 
            for i=1:size(NG.w,1)  
                NG.w(i,:)=NG.w(i,:)+et*exp(-m(i)/lammdat)*(CurVec-NG.w(i,:));
            end
            trndata(index,:) = [];
            
            if mod(t,50) == 0, 
                hold off 
                plot(NG.dataset(:,1),NG.dataset(:,2),'r.')
                hold on 
                plot(NG.w(:,1),NG.w(:,2),'bx')
                drawnow
            end           
        end
        
        crit=0;
        for i=1:size(NG.w,1)
            crit=crit+norm(NG.previousw(i,:)-NG.w(i,:),NG.metric);
        end
        crit=crit/size(NG.w,1);
        if crit <= NG.stopcriteria
            disp('stop');
            flag=0;
        else
            NG.previousw=NG.w;
        end
    end
end

% E=zeros(1,size(NG.w,1));
% for i=1:size(NG.dataset,1)
%     d=[];
%     for j=1:size(NG.w,1)
%         d(j) = norm(NG.dataset(i,1:NG.NoFeats)-NG.w(j,:),NG.metric);
%     end
%     [minval,s]=min(d);
%     E(s)=E(s)+minval;
% end
% E=sum(E)
% NG.QE=E;