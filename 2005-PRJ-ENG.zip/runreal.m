function [Out_result]=runreal(V,trainset)

Out_result.CR=[];
Out_result.UF=[];
Out_result.IG=[];
Out_result.deadnodes=[];
Out_result.MSE=[];
num_realcluts=3; %Need to be user-defined, e.g. 3 for irisdata

% %Cacluate the parameters ki and yeta needed for the Credibilistic Fuzzy c-means algorithm
%   mm.ki=[];
%   mm.yeta=ceil(0.5*(size(trainset,1)/num_realcluts));
%   for i=1:size(trainset,1)
%       d=[];
%       for j=1:size(trainset,1)
%           if j~=i
%               d=[d,norm(trainset(i,1:(size(trainset,2)-1))-trainset(j,1:(size(trainset,2)-1)),2)];
%           end
%       end
%       temp=sort(d);
%       a=temp(1:mm.yeta);
%       mm.ki=[mm.ki,mean(a)];
%   end
% ft=1; % ft=2;

noisenum=0;
for i=1:10
    [result]=ENGTrain(dataset,10,num_realcluts,V(:,:,i));
%     [result]=NG(dataset,10,num_realcluts,V(:,:,i));
%     [result]=KM(dataset,40,num_realcluts,V(:,:,i));
%     [result]=FCM(dataset,40,num_realcluts,V(:,:,i));
%     [result]=FPCM(dataset,40,num_realcluts,V(:,:,i));
%     [result]=AHCM(dataset,40,num_realcluts,V(:,:,i));
%     [result]=AFCM(dataset,40,num_realcluts,V(:,:,i))
%     eval(['[result]=CFCM' int2str(ft) '(dataset,40,num_realcluts,V(:,:,i),mm);']);

%     % Visualizing the clustering results
%     hold off 
%     plot(trainset(:,1),trainset(:,2),'r.')
%     hold on 
%     plot(result.w(:,1),result.w(:,2),'bx')
%     drawnow

    E=zeros(1,size(result.w,1));
    counter=zeros(1,size(result.w,1));
    for i=1:(size(result.trainset,1)-noisenum)
        d=[];
	    for j=1:size(result.w,1)
		    d(j) = norm(result.trainset(i,1:result.NoFeats)-result.w(j,:),2)^2;
	    end
        [minval,s]=min(d);
        E(s)=E(s)+minval;
        counter(s)=counter(s)+1;
    end

    Out_result.deadnodes=[Out_result.deadnodes,size(find(counter==0),2)];

    ss=0;
    for hh=1:size(counter,2)
      if counter(hh)~=0
         E(hh)=E(hh)./counter(hh);
         ss=ss+1;
      end
    end
    UF=sum(E)/ss;
    Out_result.UF=[Out_result.UF,UF];
    [Crate,gain,value] = MajorVotback(result,result.trainset(1:(size(result.trainset,1)-noisenum),:),result.trainset(1:(size(result.trainset,1)-noisenum),:));

    Out_result.CR = [Out_result.CR,Crate];
    Out_result.IG=[Out_result.IG,gain];
    Out_result.MSE=[Out_result.MSE,value];  %The true cluster centers' positions for real datasets are defined as the arithmetical average of samples in one class
end

Out_result.trainset=result.trainset;
Out_result.w=result.w;

Out_result.CR_ave=mean(Out_result.CR);
Out_result.CR_std=mean((Out_result.CR-mean(Out_result.CR)).^2)^(1/2);
Out_result.CR_max=max(Out_result.CR);
Out_result.CR_min=min(Out_result.CR);

Out_result.IG_ave=mean(Out_result.IG);
Out_result.IG_std=mean((Out_result.IG-mean(Out_result.IG)).^2)^(1/2);
Out_result.IG_max=max(Out_result.IG);
Out_result.IG_min=min(Out_result.IG);


Out_result.MSE_ave=mean(Out_result.MSE);
Out_result.MSE_std=mean((Out_result.MSE-mean(Out_result.MSE)).^2)^(1/2);
Out_result.MSE_max=max(Out_result.MSE);
Out_result.MSE_min=min(Out_result.MSE);

Out_result.UF_ave=mean(Out_result.UF);
Out_result.UF_std=mean((Out_result.UF-mean(Out_result.UF)).^2)^(1/2);
Out_result.UF_max=max(Out_result.UF);
Out_result.UF_min=min(Out_result.UF);
Out_result.ND_ave=mean(Out_result.deadnodes);
Out_result.ND_std=mean((Out_result.deadnodes-mean(Out_result.deadnodes)).^2)^(1/2);