% Perform k-means clustering algorithm
function [result]=KM(dataset,iter_num,Nonodes,V)

result.dataset=dataset;

%Initialization of the k-means clustering network
  result.NoFeats=size(result.dataset,2)-1;

  result.NoClasses=max(unique(result.dataset(:,result.NoFeats+1))); %All the class labels must be over 1


  result.Max_Iter=iter_num;

  result.w=V+ones(size(V,1),1)*mean(result.dataset(:,1:result.NoFeats));

  result.metric = 2;
  
  result.previousw=result.w;
  result.stopcriteria=1e-4;
  flag=1;
  
% Training procedure
  for iter = 1:result.Max_Iter
     if flag==1
%       iter
      for i=1:size(result.w,1)
          eval(['d' int2str(i) '=[];']);
      end
      for i=1:size(result.dataset,1)
          d=[];
	      for j=1:size(result.w,1)
		       d(j) = norm(result.dataset(i,1:result.NoFeats)-result.w(j,:),result.metric)^2;
	      end
          [minvalue,s]=min(d);
          eval(['d' int2str(s) '=[d' int2str(s) ';result.dataset(i,:)];']);
      end


      for j=1:size(result.w,1)
          temp=zeros(1,result.NoFeats);
          eval(['datatemp=d' int2str(j) ';']);
          if size(datatemp,1)~=0
		      for k=1:size(datatemp,1)
                  temp=temp+datatemp(k,1:result.NoFeats);
              end
              result.w(j,:)=temp/size(datatemp,1);
          end
      end

%      hold off 
%      plot(result.dataset(:,1),result.dataset(:,2),'r.')
%      hold on 
%      plot(result.w(:,1),result.w(:,2),'bx')
%      drawnow

      crit=0;
      for i=1:size(result.w,1)
          crit=crit+norm(result.previousw(i,:)-result.w(i,:),result.metric);
      end
      crit=crit/size(result.w,1);
      if crit <= result.stopcriteria
          flag=0;
      else
          result.previousw=result.w;
      end
      
     end
  end

% E=zeros(1,size(result.w,1));
% for i=1:size(result.dataset,1)
%     d=[];
% 	for j=1:size(result.w,1)
% 		d(j) = norm(result.dataset(i,1:result.NoFeats)-result.w(j,:),result.metric);
% 	end
%         [minval,s]=min(d);
%         E(s)=E(s)+minval;
% end
% E=sum(E);
% result.QE=E;