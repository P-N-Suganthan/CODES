function [Out_result]=runD2(V,trainset,BB)

standneurons=BB;
Out_result.UF=[];
Out_result.MSE=[];
Out_result.deadnodes=[];
Out_result.total_counter=[];
num_realcluts=121;

% %Cacluate the parameters ki and yeta needed for the Credibilistic Fuzzy c-means algorithm
%   mm.ki=[];
%   mm.yeta=ceil(0.5*(size(trainset,1)/num_realcluts));
%   for i=1:size(trainset,1)
%       d=[];
%       for j=1:size(trainset,1)
%           if j~=i
%               d=[d,norm(trainset(i,1:(size(trainset,2)-1))-trainset(j,1:(size(trainset,2)-1)),2)];
%           end
%       end
%       temp=sort(d);
%       a=temp(1:mm.yeta);
%       mm.ki=[mm.ki,mean(a)];
%   end
% ft=1; % ft=2;

n_larg_outliers=4;
for i=1:10
    [result]=ENGTrain(dataset,10,num_realcluts,V(:,:,i));
%     [result]=NG(dataset,10,num_realcluts,V(:,:,i));
%     [result]=KM(dataset,40,num_realcluts,V(:,:,i));
%     [result]=FCM(dataset,40,num_realcluts,V(:,:,i));
%     [result]=FPCM(dataset,40,num_realcluts,V(:,:,i));
%     [result]=AHCM(dataset,40,num_realcluts,V(:,:,i));
%     [result]=AFCM(dataset,40,num_realcluts,V(:,:,i))
%     eval(['[result]=CFCM' int2str(ft) '(dataset,40,num_realcluts,V(:,:,i),mm);']);
  
%   % Visualizing the clustering results
%     hold off 
%     plot(trainset(1:(size(trainset,1)-n_larg_outliers),1),trainset(1:(size(trainset,1)-n_larg_outliers),2),'r.')
%     hold on 
%     plot(result.w(:,1),result.w(:,2),'bx')
%     drawnow

    t_standneurons=standneurons;
    value=0;
    Neurons=result.w;
    tcounter=0;

    for j=1:size(t_standneurons,1)
        d=[];
        for k=1:size(Neurons,1)
            d(k)=norm(Neurons(k,:)-t_standneurons(j,:),2)^2;
        end
        [minvalue,s]=min(d);
        if minvalue <= 0.4
            tcounter=tcounter+1;
        end
    end
    Out_result.total_counter=[Out_result.total_counter,tcounter];
   
  while ~isempty(Neurons)
    tempd=[];
    tempneurons=[];
    for j=1:size(t_standneurons,1)
        d=[];
        for k=1:size(Neurons,1)
            d(k)=norm(Neurons(k,:)-t_standneurons(j,:),2)^2;
        end
        [minvalue,s]=min(d);
        tempd(j)=s;
        tempneurons(j)=minvalue;
    end
    deleted=[];
    for j=1:size(Neurons,1)
        temp=find(tempd==j);
        if ~isempty(temp)
            if size(temp,2)==1
                value=value+tempneurons(temp);
                deleted=[deleted,temp];
            else
                [a,b]=min(tempneurons(temp));
                deleted=[deleted,temp(b)];
                value=value+a;
            end
        end
    end
    t_standneurons(deleted,:)=[];
    Neurons(tempd(deleted),:)=[];
  end
  
  noisenum=246;
  E=zeros(1,size(result.w,1));
  counter=zeros(1,size(result.w,1));
  for ii=1:(size(result.trainset,1)-noisenum)
      d=[];
	  for j=1:size(result.w,1)
		  d(j) = norm(result.trainset(ii,1:result.NoFeats)-result.w(j,:),2)^2;
	  end
      [minval,s]=min(d);
      E(s)=E(s)+minval;
      counter(s)=counter(s)+1;
  end
  Out_result.deadnodes=[Out_result.deadnodes,size(find(counter==0),2)];

  ss=0;
  for hh=1:size(counter,2)
      if counter(hh)~=0
         E(hh)=E(hh)./counter(hh);
         ss=ss+1;
      end
  end
  UF=sum(E)/ss;

  Out_result.MSE(i)=value/size(result.w,1);
  Out_result.UF=[Out_result.UF,UF];
end

Out_result.trainset=result.trainset;
Out_result.w=result.w;

Out_result.MSE_ave=mean(Out_result.MSE);
Out_result.MSE_std=mean((Out_result.MSE-mean(Out_result.MSE)).^2)^(1/2);
Out_result.MSE_max=max(Out_result.MSE);
Out_result.MSE_min=min(Out_result.MSE);
Out_result.UF_ave=mean(Out_result.UF);
Out_result.UF_std=mean((Out_result.UF-mean(Out_result.UF)).^2)^(1/2);
Out_result.UF_max=max(Out_result.UF);
Out_result.UF_min=min(Out_result.UF);
Out_result.Nocluts_ave=mean(Out_result.total_counter);
Out_result.Nocluts_std=mean((Out_result.total_counter-mean(Out_result.total_counter)).^2)^(1/2);
Out_result.ND_ave=mean(Out_result.deadnodes);
Out_result.ND_std=mean((Out_result.deadnodes-mean(Out_result.deadnodes)).^2)^(1/2);