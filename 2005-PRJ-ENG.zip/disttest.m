%Test harmonic average value and the arithmetical average value of a vector "a"

function [hvalue,avalue]=disttest(a)
hvalue=0;
avalue=0;
for k=1:size(a,2)
    hvalue=hvalue+1/a(k);
    avalue=avalue+a(k);
end
hvalue=size(a,2)/hvalue;
avalue=avalue/size(a,2);
hvalue=exp(-a/hvalue);
avalue=exp(-a/avalue);
