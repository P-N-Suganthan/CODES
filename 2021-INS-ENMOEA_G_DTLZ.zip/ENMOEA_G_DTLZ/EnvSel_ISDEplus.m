function Next = EnvSel_ISDEplus(DistanceValue,K)

N                   = length(DistanceValue);
Next                = false(1,N);

[~,rank]            = sort(DistanceValue,'ascend');  
ranked              = rank(1:K);
Next(ranked)        = true;


end

