% The code of NSGA-II accomplished on MATLAB
format compact;tic;
%-----------------------------------------------------------------------------------------
% Parameters setting
for Problem = 1 : 7 % test problem
    
    for M = [ 10 15 20]    % number of objectives
        
        if Problem == 1 % DTLZ1
            K = 5;  % the parameter in DTLZ1
        elseif Problem == 2 || 3 || 4
            K = 10;  % the parameter in DTLZ2, DTLZ3, DTLZ4,
        elseif Problem == 5 || 6
            K = 10;  % the parameter in DTLZ5, DTLZ6
        elseif Problem == 7 % DTLZ7
            K = 20;  % the parameter in DTLZ7
        end
                
        if Problem == 1
            Generations = 700;	 % number of iterations
        elseif Problem == 3
            Generations = 1000;
        else
            Generations = 250;
        end
        
        if M == 2
            N = 102;            % population size
        elseif M == 4
            N = 120;
        elseif M == 6
            N = 132;
        elseif M == 8
            N = 156;
        elseif M == 10
            N = 276;
        elseif M == 15
            N = 240;
        elseif M == 20
            N = 234;
        end
        
        D = M + K - 1;
        
        MinValue   = zeros(1,D);
        MaxValue   = ones(1,D);
        Boundary   = [MaxValue;MinValue];
        Runs  =  30;
        %-------------------------------------------------------------------------------------------------------------------------------
        for run = 1 : Runs
            % Initialization
            Population            = repmat(MinValue,N,1) + repmat(MaxValue - MinValue,N,1).*rand(N,D); % initial population
            FunctionValue         = F_DTLZ(Population,Problem,M, K);	% calculate the objective values
            [FrontValue,MaxFront] = NDSort(FunctionValue,inf);               % non-dominated sort using A-ENS
            [RPSet,N1]             = UniformPoint(N,M);
            
            %% repair the number of solutions            
            if length(RPSet)< N
                mn    = N - length(RPSet);
                nn    = randi(mn,[mn,1]);
                nm    = RPSet(nn,:);
                RPSet = [RPSet;nm];
            end
            
            %PDMOEA_MR
            [SRANK,PRANK]         = SPRANK(FunctionValue,FrontValue,MaxFront);
            
            %ISDEPlus
            Dist_ISDEPlus         = F_ISDEplus(FunctionValue);
            
            % RPD_NSGAII
            [~,FrontNo_RPD,d2]    =  EnvSel_RPD_NSGAII(FunctionValue,RPSet,N);            
            ArchiveP  = [];
            ArchiveF  = [];
            
            %% initial population
            Wt        = [0.33 0.33 0.33];            
            VV        = ceil(N*0.33);
            N_sel     = [VV VV VV];
            N_selorg  = N_sel;            
            %-----------------------------------------------------------------------------------------
            % Main iterations
            for Gene = 1 : Generations
                %% Mating selection                
                % Mating Selection using PDMOEA_MR
                Mating_PDMOEA_AR    = F_mating_PDMOEA_AR(FrontValue,PRANK);
                
                % Mating Selection using ISDE+
                Mating_ISDEplus     = F_matingISDEplus(FunctionValue,Dist_ISDEPlus);
                
                % Mating Selection using RPD_NSGAII
                Mating_RPD_NSGAII    = TournamentSelection(2,N,FrontNo_RPD,d2);
                %% Offspring Generation
                Off1                  = F_operator(Population(Mating_PDMOEA_AR(1:(N_sel(1))),:),Boundary);
                Off2                  = F_operator(Population(Mating_ISDEplus(1:(N_sel(2))),:),Boundary);
                Off3                  = GA(Population(Mating_RPD_NSGAII(1:(N_sel(3))),:),{1,20,1,20},MinValue,MaxValue);
                
                Offspring             = [Off1;Off2;Off3];                
                N_off                 = size(Offspring,1);
                
                if N_off > N
                    N_rem                 = (N_off-N);
                    rem_sol               = randi(N,[N_rem,1]);
                    Offspring(rem_sol,:)  = [];
                end                
                NewF                  = F_DTLZ(Offspring,Problem,M, K);    % calculate the objective values
                %% Combining Populations
                Population            = [Population;Offspring;ArchiveP];
                FunctionValue         = [FunctionValue;NewF;ArchiveF];                
                %% Nondominated sorting
                [FrontValue,MaxFront]    = NDSort(FunctionValue,N);
                %% Distance calculation for ISDEplus
                Dist_ISDEPlus            = F_ISDEplus(FunctionValue);
                %% environmental selection                
                % environmental selection using PDMOEA_MR
                [SRANK,PRANK]                 = SPRANK(FunctionValue,FrontValue,MaxFront);
                Next_PDMOEA_AR                = EnvSel_PDMOEA_AR(FrontValue,SRANK,PRANK,N);                
                % environmental selection using ISDE+
                Next_ISDEplus                 = EnvSel_ISDEplus(Dist_ISDEPlus,N);
                
                % environmental selection using RPD_NSGAII
                [Next_RPD_NSGAII,FrontNo_RPD,d2]  = EnvSel_RPD_NSGAII(FunctionValue,RPSet,N);
                
                %% Environmental Selection of multi-algorithm
                Next_comb                        = [Next_PDMOEA_AR', Next_ISDEplus',Next_RPD_NSGAII'];
                [Next_all,Preserved]             = Environmental_selection(Next_comb,N);
                [N_sel,N_selorg,Wt]              = adap_probability(Next_all,N_selorg,Wt,N);
                
                %% Archive population
                ArchiveP                         = Population(Preserved,:);
                ArchiveF                         = FunctionValue(Preserved,:);                
                %% population for next generation
                Population    = Population(Next_all,:);     % solutions on decision space
                FunctionValue = FunctionValue(Next_all,:);  % solutions on objective space
                FrontValue    = FrontValue(Next_all);       % the front number of each solution
                PRANK         = PRANK(Next_all);
                Dist_ISDEPlus = Dist_ISDEPlus(Next_all);                
                Gene
            end
            F_output(Population,toc,'ENMOEA_G_DTLZ',Problem,M,K,run);
        end
    end
end
