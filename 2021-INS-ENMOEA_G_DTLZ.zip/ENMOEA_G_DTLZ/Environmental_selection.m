function [Next,Preserved]  = Environmental_selection(Next_comb,K)

%% Population selection
N                       = size(Next_comb,1);
Next                    = false(1,N);

Next_all                         = sum(Next_comb,2)/size(Next_comb,2);
[~,Rank_all]                     = sort(Next_all,'descend');
ranked                           = Rank_all(1:K);
Next(ranked)                     = true;

%% Archive selection
Rejected                         = Rank_all(K+1:end);

Rejected_var                     = Next_all(Rejected);
XX                               = find(Rejected_var ==0);
Preserved                        = Rejected;
Preserved(XX)                     = [];

end

