func=10;
load('paretofront_uf10_1.mat');
eval(['rep_1= objpareto;']);
load('paretofront_uf10_2.mat');
eval(['rep_2= objpareto;']);
load('paretofront_uf10_3.mat');
eval(['rep_3= objpareto;']);
load('paretofront_uf10_4.mat');
eval(['rep_4= objpareto;']);
load('paretofront_uf10_5.mat');
eval(['rep_5= objpareto;']);
load('paretofront_uf10_6.mat');
eval(['rep_6= objpareto;']);
load('paretofront_uf10_7.mat');
eval(['rep_7= objpareto;']);
load('paretofront_uf10_8.mat');
eval(['rep_8= objpareto;']);
load('paretofront_uf10_9.mat');
eval(['rep_9= objpareto;']);
load('paretofront_uf10_10.mat');
eval(['rep_10= objpareto;']);

        if func==1
            PFStar  = load('pf_data/UF1.dat');
        elseif func==2
            PFStar  = load('pf_data/UF2.dat');
        elseif func==3
            PFStar  = load('pf_data/UF3.dat');
        elseif func==4
            PFStar  = load('pf_data/UF4.dat');
        elseif func==5
            PFStar  = load('pf_data/UF5.dat');
        elseif func==6
            PFStar  = load('pf_data/UF6.dat');
        elseif func==7
            PFStar  = load('pf_data/UF7.dat');
        elseif func==8
            PFStar  = load('pf_data/UF8.dat');
        elseif func==9
            PFStar  = load('pf_data/UF9.dat');
        elseif func==10
            PFStar  = load('pf_data/UF10.dat');
        elseif func==11
            PFStar  = load('pf_data/R2_DTLZ2_M5.dat');
        elseif func==12
            PFStar  = load('pf_data/R2_DTLZ3_M5.dat');
        else 
            PFStar  = load('pf_data/WFG1_M5.dat');
        end
        PFStar  = PFStar';
        igd=[];
        igd_1=IGD(PFStar, rep_1);
        igd_2=IGD(PFStar, rep_2);
        igd_3=IGD(PFStar, rep_3);
        igd_4=IGD(PFStar, rep_4);
        igd_5=IGD(PFStar, rep_5);
        igd_6=IGD(PFStar, rep_6);
        igd_7=IGD(PFStar, rep_7);
        igd_8=IGD(PFStar, rep_8);
        igd_9=IGD(PFStar, rep_9);
        igd_10=IGD(PFStar, rep_10);
           
igd=[igd_1 igd_2 igd_3 igd_4 igd_5 igd_6 igd_7 igd_8 igd_9 igd_10];
[x,y]=size(igd);
min(igd)
m=mean(igd')
max(igd)
s=std(igd')
% X=(300000/length(m))*(1:length(m));
% SUBPLOT(1,2,1),plot(X,m)
% ylabel('Mean(IGD)');
% xlabel('FEs');
% % hold on
% SUBPLOT(1,2,2),plot(X,s)
% ylabel('STD(IGD)');
% xlabel('FEs');
% [sorted_igd,index]=sort(igd(x,:));
% index
% sorted_igd(1)
% sorted_igd(15)
% sorted_igd(30)
% m(x)
% s(x)
