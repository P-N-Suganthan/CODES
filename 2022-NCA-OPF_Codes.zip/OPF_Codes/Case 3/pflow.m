function [cumcost,error] = pflow(x)

global VD emission controlvar

x=[38.7638631224451,74.9999850035376,34.9999938432592,59.9998985327660,26.4969881211391,1.05953075160459,1.05419728155300,1.04365599181533,1.04731879122894,1.08945040744187,1.07248482152361,1.04000000000000,0.920000000000000,1,0.980000000000000,24,21,9.50649600862432,9.93607531489226,5,41,0.208723382685333,0.171833083431142,35,34,2.93264279478136,4.31280656829752];

Tbranch = [11 12 15 36];
ucost = 0.10; % energy cost per kWh

data = loadcase(case30);
data.gen(2:6,2) = x(1:5);
data.gen(1:6,6) = x(6:11);

x(12:15) = round(x(12:15)./0.02).*0.02; %use discrete steps for trafo
data.branch(Tbranch,9) = x(12:15);
genbus = data.gen(:,1);

x = [x(1:15),round(x(16:17)),x(18:19),round(x(20:21)),x(22:23),round(x(24:25)),x(26:27)]; % round location elements

while (x(16)==x(17) || ismember(x(16),genbus)), x(16)=x(16)+1; end %avoid generator buses for SVC installation
while (x(17)==x(16) || ismember(x(17),genbus)), x(17)=x(17)+1; end
SVC_bus = x(16:17);

while (x(20)==x(21) || ismember(x(20),Tbranch)), x(20)=x(20)+1; end %avoid transformer branches for TCSC installation
while (x(21)==x(20) || ismember(x(21),Tbranch)), x(21)=x(21)+1; end
TCSC_branch = x(20:21);

while (x(24)==x(25) || ismember(x(24),Tbranch)), x(24)=x(24)+1; end %avoid transformer branches for TCPS installation
while (x(25)==x(24) || ismember(x(25),Tbranch)), x(25)=x(25)+1; end
TCPS_branch = x(24:25);

data.bus(SVC_bus,6) = x(18:19);
data.branch(TCSC_branch,4) = data.branch(TCSC_branch,4)-data.branch(TCSC_branch,4).*x(22:23)';
data.branch(TCPS_branch,10) = x(26:27);
controlvar = x;

mpopt = mpoption('pf.enforce_q_lims',0,'verbose',0,'out.all',0);
result = runpf(data,mpopt);

thpowgen = [result.gen(1,2),x(1),x(3),x(5)];
thgencoeff = vertcat(data.gencost(1:2,5:7),data.gencost(4,5:7),data.gencost(6,5:7));

thgencost = sum(thgencoeff(:,1)+thgencoeff(:,2).*thpowgen'+thgencoeff(:,3).*(thpowgen.^2)'); % thermal generator cost
wgencost = windpowcost(x);

%Constraint finding 
Vmax = data.bus(:,12);
Vmin = data.bus(:,13);

Qmax = data.gen(:,4)/data.baseMVA;
Qmin = data.gen(:,5)/data.baseMVA;
QG = result.gen(:,3)/data.baseMVA;

PGSmax = data.gen(1,9);
PGSmin = data.gen(1,10);
PGS = result.gen(1,2);
PGSerr = (PGS<PGSmin)*(abs(PGSmin-PGS)/(PGSmax-PGSmin))+(PGS>PGSmax)*(abs(PGSmax-PGS)/(PGSmax-PGSmin));

blimit = data.branch(:,6);
Slimit = sqrt(result.branch(:,14).^2+result.branch(:,15).^2);
Serr = sum((Slimit>blimit).*abs(blimit-Slimit))/data.baseMVA;

% TO find the error in Qg of gen buses- inequality constraint
Qerr = sum((QG<Qmin).*(abs(Qmin-QG)./(Qmax-Qmin))+(QG>Qmax).*(abs(Qmax-QG)./(Qmax-Qmin)));
% TO find the error in V of load buses-inequality constraint
VI = result.bus(:,8);  %V of load buses-inequality constraint
VI(genbus)=[];
Vmax(genbus)=[];
Vmin(genbus)=[];
VIerr = sum((VI<Vmin).*(abs(Vmin-VI)./(Vmax-Vmin))+(VI>Vmax).*(abs(Vmax-VI)./(Vmax-Vmin)));
VD = sum(abs(VI-1));

% Emission : bus no. alpha beta gama omega miu d e Pmin
emcoeff = [
	1	0.04091 -0.05554 0.06490 0.000200 2.857 18 0.037 50;
	2	0.02543 -0.06047 0.05638 0.000500 3.333 16 0.038 20;
    8	0.05326 -0.03550 0.03380 0.002000 2.000 12 0.045 10;
	13	0.06131 -0.05555 0.05151 0.000010 6.667 13.5 0.041 12];

% VALVE EFFECT
valveff = sum(abs(emcoeff(:,7).*sin(emcoeff(:,8).*(emcoeff(:,9)-thpowgen')))); % if all have valve effects

% OBJECTIVE FUNCTIONS
emission = sum(emcoeff(:,2)+emcoeff(:,3).*thpowgen'/100+emcoeff(:,4).*(thpowgen.^2/100^2)'...
    +emcoeff(:,5).*exp(emcoeff(:,6).*thpowgen'/100));
ploss = sum(result.branch(:,14)+result.branch(:,16));

fuelvlvcost = thgencost+valveff;

cumcost = fuelvlvcost+wgencost+ploss*10^3*ucost;
error = [Qerr,VIerr,Serr,PGSerr];
RESULT = [x(1:15)';x(22:23)'*100;x(26:27)';x(18:19)';PGS;QG.*100;cumcost;ploss;VD;x(20:21)';x(24:25)';x(16:17)']