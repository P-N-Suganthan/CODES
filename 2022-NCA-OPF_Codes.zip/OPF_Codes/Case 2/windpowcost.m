function wgencost = windpowcost(x)

scale = [9 10]; % Enter shape parameters of 3 windfarms for Weibull dist
shape = [2 2]; % Enter shape parameters of 3 windfarms for Weibull dist
NT = [25 20]; % No. of turbines in the 3 farms
Vin = 3; Vout = 25; Vr = 16; Pr = 3; % Cut-in, cut-out, rated speed and rated power of turbine

%Find wind generator related parameters
%windgen parameter sl no. bus costcoeff
wgenpar = [1   5   1.60;
           2   11  1.75];
Crwj = 3; Cpwj = 1.5;
schwpow = [x(2);x(4)];

%stochastic wind power cost
%meanwpow = [28;44;40];
Prw0 = 1-exp(-(Vin./scale).^shape)+exp(-(Vout./scale).^shape);
Prwwr = exp(-(Vr./scale).^shape)-exp(-(Vout./scale).^shape);
count1 = 1;
wovest = zeros(); wundest = zeros();

for ii = 1:2
    Prww1 = (shape(ii)*(Vr-Vin))/((scale(ii)^shape(ii))*(NT(ii)*Pr));
    Prww = @(wp)((schwpow(ii)-wp)*Prww1*((Vin + (wp/(NT(ii)*Pr))*(Vr-Vin))^(shape(ii)-1))*(exp(-((Vin + (wp/(NT(ii)*Pr))*(Vr-Vin))/scale(ii))^shape(ii))));
    wovest2 = integral(Prww,0,schwpow(ii),'ArrayValued',true);
    wovest(count1) = schwpow(ii)*Prw0(ii)*Crwj+Crwj*wovest2;

    Prww = @(wp)((wp-schwpow(ii))*Prww1*((Vin + (wp/(NT(ii)*Pr))*(Vr-Vin))^(shape(ii)-1))*(exp(-((Vin + (wp/(NT(ii)*Pr))*(Vr-Vin))/scale(ii))^shape(ii))));
    wundest2 = integral(Prww,schwpow(ii),NT(ii)*Pr,'ArrayValued',true);
    wundest(count1) = (NT(ii)*Pr-schwpow(ii))*Prwwr(ii)*Cpwj+Cpwj*wundest2;
    count1 = count1+1;
end

wgencost = sum(wgenpar(:,3).*schwpow)+sum(wovest)+sum(wundest); % wind generator cost