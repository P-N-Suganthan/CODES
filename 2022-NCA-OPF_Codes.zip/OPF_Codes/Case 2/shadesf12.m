 % The Ensemble of SF and SP constraint handling methods
global  controlvar
format long e;
tic
problem_size = 27;
pop_size = 60;

Xmin = [20 0  10 0  12 ones(1,6)*0.95 ones(1,4)*0.90 3  3  -10 -10 1  1  0.0 0.0 1  1  -5  -5];
Xmax = [80 75 35 60 40 ones(1,6)*1.10 ones(1,4)*1.10 29 30  10  10 40 41 0.5 0.5 40 41  5   5];

Max_FES = 30000; 
Max_Gen = 500; maxrun = 30; gn = 4; % gn is the no. of constraints
feval = []; contvar = zeros(maxrun,problem_size);
Re = zeros(maxrun,3); W = zeros(Max_Gen,3);



Func = @pflow;

 for runs=1:maxrun 
 
  fprintf('Run %d',runs);
  nfeval=0;

 %%  parameter settings for SHADE
 p_best_rate = 0.11;
 arc_rate = 1.4;
 memory_size = 5;
 memory_pos = 1;

 archive.NP = arc_rate * pop_size; % the maximum size of the archive
 archive.pop = zeros(0, problem_size); % the solutions stored in te archive
 archive.funvalues = zeros(0, 1); % the function value of the archived solutions   
    
   pop=repmat(Xmin,pop_size,1)+repmat((Xmax-Xmin),pop_size,1).*rand(pop_size,problem_size);
   val = zeros(pop_size,1); g = zeros(pop_size,gn); %PPB
   for i=1:pop_size
      [val(i,1),g(i,:)] = Func(pop(i,:));
   end
   
   nfeval=nfeval+pop_size;
   
   memory_sf = 0.5 .* ones(memory_size, 1);
   memory_cr = 0.5 .* ones(memory_size, 1);
 
 cons_max = [];
 rot=(0:1:pop_size-1); 
 
 %% Main loop

for gen=1:Max_Gen

    fitness = val;
    [~, sorted_index] = sort(fitness, 'ascend');

    mem_rand_index = ceil(memory_size * rand(pop_size, 1));
    mu_sf = memory_sf(mem_rand_index);
    mu_cr = memory_cr(mem_rand_index);
      
     %% for generating crossover rate
      cr = normrnd(mu_cr, 0.1);
      term_pos = find(mu_cr == -1);
      cr(term_pos) = 0;
      cr = min(cr, 1);
      cr = max(cr, 0);

      %% for generating scaling factor
      sf = mu_sf + 0.1 * tan(pi * (rand(pop_size, 1) - 0.5));
      pos = find(sf <= 0);

      while ~ isempty(pos)
        sf(pos) = mu_sf(pos) + 0.1 * tan(pi * (rand(length(pos), 1) - 0.5));
        pos = find(sf <= 0);
      end

      sf = min(sf, 1); 
      
      r0 = (1 : pop_size);
      popAll = [pop; archive.pop];
      [r1, r2] = gnR1R2(pop_size, size(popAll, 1), r0);
      
      pNP = max(round(p_best_rate * pop_size), 2); %% choose at least two best solutions
      randindex = ceil(rand(1, pop_size) .* pNP); %% select from [1, 2, 3, ..., pNP]
      randindex = max(1, randindex); %% to avoid the problem that rand = 0 and thus ceil(rand) = 0
      pbest = pop(sorted_index(randindex), :); %% randomly choose one of the top 100p% solutions

      vi = pop + sf(:, ones(1, problem_size)) .* (pbest - pop + pop(r1, :) - popAll(r2, :));
      vi = boundConstraint(vi, pop, Xmax, Xmin);
      
      mask = rand(pop_size, problem_size) > cr(:, ones(1, problem_size)); % mask is used to indicate which elements of ui comes from the parent
      rows = (1 : pop_size)'; cols = floor(rand(pop_size, 1) * problem_size)+1; % choose one position where the element of ui doesn't come from the parent
      jrand = sub2ind([pop_size problem_size], rows, cols); mask(jrand) = false;
      ui = vi; ui(mask) = pop(mask);
    
    newpop = ui;
    newval = zeros(pop_size,1); newg = zeros(pop_size,gn); %PPB            
    for i=1:pop_size
      [newval(i,1),newg(i,:)] = Func(newpop(i,:));
    end             
    nfeval=nfeval+pop_size;

    children_fitness = newval;
    dif = abs(fitness - children_fitness);
     
    A = vertcat(pop,newpop);
    B = vertcat(val,newval);
    G = vertcat(g,newg);

   % Superiority of Feasible Solutions
    cons1=(G>0).*G; 
    cons_max=max([cons_max;cons1],[],1);
    nzindex1=find(cons_max~=0);
    
    if isempty(nzindex1)
        tcons1=zeros(size(A,1),1);
    else
        tcons1=sum(cons1(:,nzindex1)./repmat(cons_max(:,nzindex1),size(A,1),1),2)./sum(1./cons_max(:,nzindex1));
    end        
   
%PPB
     ind11 = find(tcons1((pop_size+1):2*pop_size) < tcons1(1:pop_size));
     ind12 = find(tcons1((pop_size+1):2*pop_size) == 0);
     ind12 = ind12((tcons1(ind12) == 0));
     ind12 = ind12(B(pop_size+ind12)<= B(ind12));
     index = union(ind11,ind12);
     pop(index,:) = A(pop_size+index,:);
     val(index,:) = B(pop_size+index,:);
     g(index,:) = G(pop_size+index,:);
     
     %%Addition: if Offspring is better update goodCR & goodF and memory
     
      goodCR = cr(index);  
      goodF = sf(index);
      dif_val = dif(index);

      archive = updateArchive(archive, pop(index, :), fitness(index));
      num_success_params = numel(goodCR);

      if num_success_params > 0 
	sum_dif = sum(dif_val);
	dif_val = dif_val / sum_dif;

	%% for updating the memory of scaling factor 
	memory_sf(memory_pos) = (dif_val' * (goodF .^ 2)) / (dif_val' * goodF);

	%% for updating the memory of crossover rate
	if max(goodCR) == 0 || memory_cr(memory_pos)  == -1
	  memory_cr(memory_pos)  = -1;
	else
	  memory_cr(memory_pos) = (dif_val' * (goodCR .^ 2)) / (dif_val' * goodCR);
	end

	memory_pos = memory_pos + 1;
	if memory_pos > memory_size;  memory_pos = 1; end
      end
    
    %%...............
    
    totalpop=pop;
    totalval=val;
    totalg=g;
     
    cons5=(totalg>0).*totalg; 
    cons_max=max([cons_max;cons5],[],1);
    nzindex5=find(cons_max~=0);
    
    if isempty(nzindex5)
        tcons5=zeros(1*pop_size,1);
    else

        tcons5=sum(cons5(:,nzindex5)./repmat(cons_max(:,nzindex5),1*pop_size,1),2)./sum(1./cons_max(:,nzindex5));
    end 
                
  feasindex=find(tcons5==0);
  if isempty(feasindex)
    [gbesttcons,ibest]=min(tcons5);
    gbestval=totalval(ibest);
    gbest = totalpop(ibest,:);
  else
    [gbestval,ibest]=min(totalval(feasindex));
    gbesttcons=tcons5(feasindex(ibest));
    gbest = totalpop(feasindex(ibest),:);
  end
  
  if(gen == 1)
      thegbestval = gbestval;
      thegbesttcons = gbesttcons;
      thegbest = gbest;
  elseif((gbesttcons < thegbesttcons) || (gbesttcons==0 && thegbesttcons ==0 && gbestval < thegbestval))
      thegbestval = gbestval;
      thegbesttcons = gbesttcons;
      thegbest = gbest;
  end

    W(gen,1)=thegbestval;
    W(gen,2)=thegbesttcons;
    W(gen,3)=nfeval;
    
 if(isempty(feval) && thegbesttcons == 0)
        feval = nfeval;
 end
%  thegbestval
%  fuelcost
%  Lind_worst
 end
dlmwrite(strcat('W_',char(num2str(runs)),'.txt'),W,'newline','pc');
Re(runs,1) = gbestval;
Re(runs,2) = gbesttcons;
Re(runs,3) = feval;

contvar(runs,:) = thegbest;
 end
toc
dlmwrite('Result.txt',Re,'precision','%0.5f','newline','pc');
eval('save contvar');