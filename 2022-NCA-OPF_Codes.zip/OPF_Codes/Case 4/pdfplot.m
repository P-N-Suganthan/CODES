function demand_sum = pdfplot()

%% Load PDF
mu = 70;
sigma = 10;
load = (30:1:110);
norm = normpdf(load,mu,sigma);
loading = [60,70,80];
%cdfload = cdf('Normal',loading,mu,sigma);

figure(1)
%grid on
plot(load,norm,'LineWidth',1.5);
line([loading(1) loading(1)],[0 normpdf(loading(1),mu,sigma)],'LineWidth',1.5);
line([loading(2) loading(2)],[0 normpdf(loading(2),mu,sigma)],'LineWidth',1.5);
line([loading(3) loading(3)],[0 normpdf(loading(3),mu,sigma)],'LineWidth',1.5);
xlabel('Network loading in %')
ylabel('Probability density')

%% Calculation of mean demand values
demand = [0 60 70 80 120];
meanp = @(pd)((1/sqrt(0.5*pi()*sigma^2))*exp(-(pd-mu)^2/(2*sigma^2)));
meand = @(pd)(pd*((1/sqrt(0.5*pi()*sigma^2))*exp(-(pd-mu)^2/(2*sigma^2))));

loadmeanp = zeros(); loadmeand = zeros();
for ii = 1:length(demand)-1
loadmeanp(ii) = 0.5*integral(meanp,demand(ii),demand(ii+1),'ArrayValued',true);
loadmeand(ii) = (0.5/loadmeanp(ii))*integral(meand,demand(ii),demand(ii+1),'ArrayValued',true);
end
demand_sum = [loadmeanp' loadmeand'];