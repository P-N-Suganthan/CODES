function [cumcost,error] = pflow(x)

global VD emission controlvar demand_sum scene

demand_sum = pdfplot();
scene = 1;
%x = [23.2886	 57.9693	 10.0318	 50.1553	 12.0202	 1.0745	 1.0602	 1.0351	 1.0392	 1.0891	 1.0446	 3.0249	 4.0981	 1.5334	 4.7114	 3.8315	 4.5366	 1.7651	 4.8512	 3.1730	 1.0615	 0.9146	 0.9853	 0.9803	 15.1313	 36.2960	 -0.0196	 0.0444	 18.1938	 13.6176	 0.2775	 3.2957];
x = [23.0697	 57.7389	 10.0232	 50.7029	 12.0130	 1.0728	 1.0575	 1.0373	 1.0388	 1.0985	 1.0723	 1.0254	 0.9162	 0.9995	 0.9672	 23.9653	 10.4598	 4.3607	 4.8717	 28.6415	 1.8904	 -0.0061	 0.0205	 24.5878	 14.1656	 -0.0155	 3.2905];
%x = contvar(3,:);

%% scenario creation
scenario = ...
[1 demand_sum(1,1) demand_sum(1,2);
2  demand_sum(2,1) demand_sum(2,2);
3  demand_sum(3,1) demand_sum(3,2);
4  demand_sum(4,1) demand_sum(4,2)];

%%
load_demand = scenario(scene,3)/100; % load demand in percentage
Tbranch = [11 12 15 36];
ucost = 0.10; % energy cost per kWh

data = loadcase(case30);
data.gen(2:6,2) = x(1:5);
data.gen(1:6,6) = x(6:11);

x(12:15) = round(x(12:15)./0.02).*0.02; %use discrete steps for trafo
data.branch(Tbranch,9) = x(12:15);
genbus = data.gen(:,1);

x = [x(1:15),round(x(16:17)),x(18:19),round(x(20:21)),x(22:23),round(x(24:25)),x(26:27)]; % round location elements

while (x(16)==x(17) || ismember(x(16),genbus)), x(16)=x(16)+1; end %avoid generator buses for SVC installation
while (x(17)==x(16) || ismember(x(17),genbus)), x(17)=x(17)+1; end
SVC_bus = x(16:17);

while (x(20)==x(21) || ismember(x(20),Tbranch)), x(20)=x(20)+1; end %avoid transformer branches for TCSC installation
while (x(21)==x(20) || ismember(x(21),Tbranch)), x(21)=x(21)+1; end
TCSC_branch = x(20:21);

while (x(24)==x(25) || ismember(x(24),Tbranch)), x(24)=x(24)+1; end %avoid transformer branches for TCPS installation
while (x(25)==x(24) || ismember(x(25),Tbranch)), x(25)=x(25)+1; end
TCPS_branch = x(24:25);

data.bus(SVC_bus,6) = x(18:19);
data.bus(:,3) = load_demand.*data.bus(:,3);
data.bus(:,4) = load_demand.*data.bus(:,4);
data.branch(TCSC_branch,4) = data.branch(TCSC_branch,4)-data.branch(TCSC_branch,4).*x(22:23)';
data.branch(TCPS_branch,10) = x(26:27);
controlvar = x;

mpopt = mpoption('pf.enforce_q_lims',0,'verbose',0,'out.all',1);
result = runpf(data,mpopt);

thpowgen = [result.gen(1,2),x(1),x(3),x(5)];
thgencoeff = vertcat(data.gencost(1:2,5:7),data.gencost(4,5:7),data.gencost(6,5:7));

thgencost = sum(thgencoeff(:,1)+thgencoeff(:,2).*thpowgen'+thgencoeff(:,3).*(thpowgen.^2)'); % thermal generator cost
wgencost = windpowcost(x);

%Constraint finding 
Vmax = data.bus(:,12);
Vmin = data.bus(:,13);

Qmax = data.gen(:,4)/data.baseMVA;
Qmin = data.gen(:,5)/data.baseMVA;
QG = result.gen(:,3)/data.baseMVA;

PGSmax = data.gen(1,9);
PGSmin = data.gen(1,10);
PGS = result.gen(1,2);
PGSerr = (PGS<PGSmin)*(abs(PGSmin-PGS)/(PGSmax-PGSmin))+(PGS>PGSmax)*(abs(PGSmax-PGS)/(PGSmax-PGSmin));

blimit = data.branch(:,6);
Slimit = sqrt(result.branch(:,14).^2+result.branch(:,15).^2);
Serr = sum((Slimit>blimit).*abs(blimit-Slimit))/data.baseMVA;

% TO find the error in Qg of gen buses- inequality constraint
Qerr = sum((QG<Qmin).*(abs(Qmin-QG)./(Qmax-Qmin))+(QG>Qmax).*(abs(Qmax-QG)./(Qmax-Qmin)));
% TO find the error in V of load buses-inequality constraint
VI = result.bus(:,8);  %V of load buses-inequality constraint
VI(genbus)=[]
Vmax(genbus)=[];
Vmin(genbus)=[];
VIerr = sum((VI<Vmin).*(abs(Vmin-VI)./(Vmax-Vmin))+(VI>Vmax).*(abs(Vmax-VI)./(Vmax-Vmin)));
VD = sum(abs(VI-1));

% Emission : bus no. alpha beta gama omega miu d e Pmin
emcoeff = [
	1	0.04091 -0.05554 0.06490 0.000200 2.857 18 0.037 50;
	2	0.02543 -0.06047 0.05638 0.000500 3.333 16 0.038 20;
    8	0.05326 -0.03550 0.03380 0.002000 2.000 12 0.045 10;
	13	0.06131 -0.05555 0.05151 0.000010 6.667 13.5 0.041 12];

% VALVE EFFECT
valveff = sum(abs(emcoeff(:,7).*sin(emcoeff(:,8).*(emcoeff(:,9)-thpowgen')))); % if all have valve effects

% OBJECTIVE FUNCTIONS
emission = sum(emcoeff(:,2)+emcoeff(:,3).*thpowgen'/100+emcoeff(:,4).*(thpowgen.^2/100^2)'...
    +emcoeff(:,5).*exp(emcoeff(:,6).*thpowgen'/100));
ploss = sum(result.branch(:,14)+result.branch(:,16));

fuelvlvcost = thgencost+valveff;
gencost = fuelvlvcost+wgencost;
cumcost = gencost+ploss*10^3*ucost;
error = [Qerr,VIerr,Serr,PGSerr];
RESULT = [x(1:15)';x(22:23)'*100;x(26:27)';x(18:19)';PGS;QG.*100;gencost;ploss;cumcost;VD;x(20:21)';x(24:25)';x(16:17)'];