clear all
clc

% function name(fname) fbg_fit
% apodized.m is used for simulating FBG structure
% n-number of uniform fbg sections
% np-swarm (population) size
% Xmin-lower bound
% Xmax-upper bound
% window-filter window
% feval_max-Maximum number of function evaluations
% optimum_fit - best fitness  value
% optimum_value- design variables corresponding to best
% maxgen-Maximum number of generations

maxgen=1000;
np=40;
fname='fbg_fit';
n=20;
window=[0.4109 0.5500    0.6891    0.8145    0.9141    1    1.0000    0.9780    0.9141    0.8145    0.6891    0.5500    0.4109    0.2855    0.1859 0.1220    0.1000    0.1220    0.1859    0.2855  ];
        
Xmin = [-0.0003*window]; 
Xmax= [0.0003*window]; 
c1=1;c2=1;c3=1;
feval_max=20000;
feval_count=0;

for i=1:np
particle_pos(i,:)=Xmin+(Xmax-Xmin).*rand(1,n);
end

w(1:maxgen)=1.2-(1:maxgen)*(1/maxgen);
vmax=.5;
vmin=-vmax;
vv=vmin+(vmax-vmin).*rand(np,n);

for i=1:np
feval_count=feval_count+1;
particle_fit(i,1)=feval(fname,particle_pos(i,1:n));
end

pbest=particle_pos;
pbest_val=particle_fit;
[gbest_val,gbest_id]=min(particle_fit);
gbest=pbest(gbest_id,:);

tr(1)=gbest_val;

nbest=pbest;

i=0;
while (feval_count<feval_max)
    i=i+1;
    for j=1:np 
        if i<1000,
    vv(j,:)=w(i)*vv(j,:)+c1*rand(1,n).*(pbest(j,:)-particle_pos(j,:))+c2*rand(1,n).*(gbest-particle_pos(j,:))+c3*rand(1,n).*(nbest(j,:)-particle_pos(j,:));
else
    vv(j,:)=.2*vv(j,:)+c1*rand(1,n).*(pbest(j,:)-particle_pos(j,:))+c2*rand(1,n).*(gbest-particle_pos(j,:))+c3*rand(1,n).*(nbest(j,:)-particle_pos(j,:));
          end
        vv(j,:)=(vv(j,:)>=vmax).*vmax+(vv(j,:)<vmax).*vv(j,:);
        vv(j,:)=(vv(j,:)<=vmin).*vmin+(vv(j,:)>vmin).*vv(j,:);
        particle_pos_temp=vv(j,:)+particle_pos(j,:);
        
        xerr=sum(abs(min(particle_pos_temp-Xmin,0))+abs(min(Xmax-particle_pos_temp,0)),2);
        if xerr==0,feval_count=feval_count+1;particle_fit(j,1)=feval(fname,particle_pos_temp);particle_pos(j,:)=particle_pos_temp;
          if c3~=0,
            pbest_index=find([1:np]~=j)';
          dd=abs(pbest(pbest_index,:)-repmat(particle_pos(j,:),np-1,1));
          dd=(dd==0)*100+(dd>0).*dd;
          fx=-pbest_val(pbest_index,1)+particle_fit(j,1)*ones(np-1,1);
          ffx=repmat(fx,1,n);
          fdr=ffx./dd;
          [f1,f2]=max(fdr);
          for jj=1:n
          nbest(j,jj)=pbest(f2(jj),jj);
          end
      end
            if particle_fit(j,1)<pbest_val(j,1),pbest_val(j,1)=particle_fit(j,1);pbest(j,:)=particle_pos(j,:);end
            if particle_fit(j,1)<gbest_val,gbest_val=particle_fit(j,1);gbest=particle_pos(j,:);end
        end
    end
    tr(i)=gbest_val;
  
end
optimum_value=gbest;
optimum_fit=gbest_val;












