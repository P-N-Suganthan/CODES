[optimum_value,optimum_fit]=pso_main(fname,np,n,Xmin,Xmax,feval_max)

% function name(fname) fbg_fit
% apodized.m is used for simulating FBG structure
% n-number of uniform fbg sections
% np-swarm (population) size
% Xmin-lower bound on design variables (index modulation)
% Xmax-upper bound on design variables (index modulation)
% feval_max-Maximum number of function evaluations
% optimum_fit - best fitness  value corresponding to gbest
% optimum_value- design variables corresponding to gbest

Typical function call:
------------------------

[optimum_value,optimum_fit]=pso_main('fbg_fit',40,20,-3e-4*ones(1,20),3e-4*ones(1,20),20000)


Reference:

S. BASKAR, R. T. Zheng, A. Alphones, N. Q. Ngo and P. N.  Suganthan, �Particle Swarm Optimization for the Design of 
Low-Dispersion Fiber Bragg Gratings�, IEEE Trans. on Photonics Technology Letters, Vol.17, No.3, pp.615-617, March 2005. 